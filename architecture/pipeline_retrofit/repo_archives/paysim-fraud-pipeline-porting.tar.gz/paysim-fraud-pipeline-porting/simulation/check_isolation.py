#!/usr/bin/env python3
"""Isolation guard for the Paysim simulation lab (simulation/).

Ported from creative_intelligence_lab's simulation/check_isolation.py (pipeline-retrofit
effort, via home-credit's and olist's patterns). Proves the sim lab cannot touch the real
PySpark/Delta/dbt/Snowflake pipeline, so fault-injection / optimization drills can never
corrupt canonical data or models. Deterministic, no Databricks/Snowflake connection. Run
before every sim session AND before committing sim work:

    python simulation/check_isolation.py

Exit 0 = isolated (safe to break things). Exit 1 = a boundary was crossed (STOP). Enforces
R1/R2/R3 of ISOLATION_CONTRACT.md; R4/R5 stay partly human.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SIM = ROOT / "simulation"
REAL_DBT = ROOT / "gold" / "dbt_project.yml"
SIM_DBT = SIM / "sim_dbt" / "dbt_project.yml"
SIM_PREFIX = "/sim/"


def project_name(p: Path) -> str | None:
    if not p.exists():
        return None
    m = re.search(r"^\s*name:\s*['\"]?([\w-]+)", p.read_text(errors="ignore"), re.M)
    return m.group(1) if m else None


def main() -> int:
    failures: list[str] = []
    notes: list[str] = []

    # R2 — sim dbt project name must differ from the real one.
    real_name = project_name(REAL_DBT)
    sim_name = project_name(SIM_DBT)
    if sim_name is None:
        notes.append("R2: simulation/sim_dbt/dbt_project.yml not present yet — name check skipped")
    elif real_name and sim_name == real_name:
        failures.append(f"R2: sim dbt project name '{sim_name}' equals real '{real_name}' — must differ")

    # R3 — no sim SQL may ref() a real model.
    real_models = {p.stem for p in (ROOT / "gold" / "models").rglob("*.sql")} \
        if (ROOT / "gold" / "models").exists() else set()
    ref_re = re.compile(r"\bref\(\s*['\"]([a-zA-Z0-9_]+)['\"]")
    for f in SIM.rglob("*.sql"):
        text = f.read_text(errors="ignore")
        for name in ref_re.findall(text):
            if name in real_models:
                failures.append(f"R3: {f.relative_to(ROOT)} ref()s real model '{name}' — sim must use its own fixtures")

    # R1 — every s3a:// literal in a sim file must contain /sim/. Skip this script itself
    # (its own regex source text contains an "s3a://" pattern fragment, not a real path).
    s3_re = re.compile(r"s3a://[^\s'\"`\[\]]+")
    for f in SIM.rglob("*"):
        if f.is_dir() or f.suffix not in (".py", ".sql", ".yml", ".yaml", ".md"):
            continue
        if f == Path(__file__):
            continue
        text = f.read_text(errors="ignore")
        for literal in s3_re.findall(text):
            if SIM_PREFIX not in literal:
                failures.append(f"R1: {f.relative_to(ROOT)} references '{literal}' — missing required '/sim/' segment")

    for n in notes:
        print(f"  note: {n}")

    if failures:
        print(f"\n❌ ISOLATION CONTRACT FAILED — {len(failures)} violation(s):")
        for fail in failures:
            print(f"   • {fail}")
        print("\n   See ISOLATION_CONTRACT.md. Fix before running/committing sim work.")
        return 1

    print("✅ isolation contract OK — sim lab cannot touch the real pipeline")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
