# SIM Spec — Bronze Partition Migration Drill

> Isolation-contracted (ISOLATION_CONTRACT.md R1-R5). Run on a `drill/*` branch.

## Scenario
The real `bronze/bronze_pipeline.py` partitions Bronze by `transaction_day` (`CEIL(step/24)`).
Migrate the SIM lab's Bronze fixture from an unpartitioned single-file layout to the same
`transaction_day` partitioning scheme, WITHOUT touching the real `bronze/` code or any real
S3 path — sim fixtures and `s3a://<bucket>/sim/<scenario>/bronze/` only (R1).

## Pedagogy
Migration mode (CIL CURRICULUM convention): plan the migration in writing before executing.
1. Read `bronze/bronze_pipeline.py`'s partitioning logic — reason about WHY `transaction_day`
   (not raw `step`) is the partition key (744 steps vs 31 days — partition cardinality matters
   for file count / small-file problems on S3).
2. Write the migration plan: old layout → new layout, rollback step, validation query.
3. Execute against sim fixtures only.
4. Validate: row count before == row count after (zero data loss), confirmed via
   `check_isolation.py` passing throughout (sim never touched the real Bronze table).

## Acceptance
Owner can explain why a partition migration on a live pipeline needs a written rollback step
BEFORE execution, and can point at the real `bronze_pipeline.py` partition expression from
memory (`CEIL(step / 24)`).
