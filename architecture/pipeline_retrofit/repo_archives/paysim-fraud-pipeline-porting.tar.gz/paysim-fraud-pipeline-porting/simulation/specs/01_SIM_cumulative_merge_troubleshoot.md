# SIM Spec — Cumulative MERGE Idempotency Troubleshoot Drill

> Isolation-contracted (ISOLATION_CONTRACT.md R1-R5). Run on a `drill/*` branch.

## Scenario
Inject F02 (`simulation/faults/inject.py F02`) — `_merge_day` is modified to compute running
totals from the MATCHED row (today's already-written values) instead of yesterday's row,
so re-running the same day's MERGE silently doubles `running_txn_total`/`running_fraud_total`/
etc.

## Pedagogy
Troubleshooting mode (CIL CURRICULUM convention): hypothesis-log BEFORE running anything.
1. Write `hypothesis → test → predicted output` before touching the sim.
2. Observe (sim fixtures — a 3-day synthetic customer-transaction sample run through the
   faulted MERGE twice for the same day; compare `running_txn_total` before/after the 2nd run).
3. Root-cause: tie back to `silver/cumulative_pipeline.py`'s docstring ("running_* totals
   computed from yesterday_row (NOT from the MATCHED row)") and `tests/identity_contract.py`
   ID1 — which rule would have caught this statically?
4. Fix in the sim only; `faults/reset.py` to return to clean baseline.

## Acceptance
Owner can explain, unaided, why "compute from yesterday's row, never the matched row" is the
idempotency invariant, and point at the exact line in `_merge_day` where `prev.prev_running_*`
(not `target.running_*`) feeds the new running totals.
