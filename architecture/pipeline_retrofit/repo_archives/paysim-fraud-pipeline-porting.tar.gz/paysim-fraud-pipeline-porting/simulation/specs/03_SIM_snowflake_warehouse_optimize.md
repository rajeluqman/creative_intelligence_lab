# SIM Spec — Snowflake Warehouse Sizing Optimization Drill

> Isolation-contracted (ISOLATION_CONTRACT.md R1-R5). Run on a `drill/*` branch.

## Scenario
The real pipeline runs Gold `dbt build` on an XS Snowflake warehouse
(`gold/profiles.yml`) and `silver/databricks_to_snowflake.py` explicitly suspends the
warehouse after load. In the SIM lab, reproduce a "warehouse left running" cost scenario
against the sim's OWN warehouse/schema (`PAYSIM_FRAUD_SIM`, never `STAGING`/`DEV`/`PROD`) and
practice diagnosing + fixing it.

## Pedagogy
Optimization mode (CIL CURRICULUM convention): baseline → hypothesis → change → re-measure.
1. Baseline: simulate (in the sim's cost-estimate fixture, not a real Snowflake bill) the
   credit burn of an XS warehouse left running for N hours vs. auto-suspended after each load.
2. Hypothesis: where would you add the suspend call if `databricks_to_snowflake.py`'s
   `ALTER WAREHOUSE ... SUSPEND` line were missing?
3. Change: write the fix against the sim's copy of the bridge script logic only.
4. Re-measure: recompute the estimated credit burn with the fix applied.

## Acceptance
Owner can explain why @finops-agent flags "warehouse left running" as the single biggest
portfolio-project cost leak, and can point at the real suspend call's location in
`silver/databricks_to_snowflake.py`.
