# Fault Catalog — Paysim Simulation Lab

Named, reversible faults for troubleshooting drills. `inject.py <fault_id>` applies one;
`reset.py` rebuilds clean sim state from sim fixtures (never hand-patched).

| ID | Fault | Mirrors a real risk from |
|---|---|---|
| F01 | Bronze Delta partition corrupted (malformed Parquet footer in one ingest batch) | `bronze/bronze_pipeline.py`, `docs/ARCHITECTURE.md` Bronze ACID/time-travel claims |
| F02 | Cumulative MERGE idempotency broken — running totals computed from the MATCHED row instead of yesterday's row, causing double-counting on re-run | `silver/cumulative_pipeline.py` `_merge_day`, `tests/identity_contract.py` ID1 |
| F03 | RULE 1 fraud-type constraint silently disabled (a Silver transform change lets `is_fraud=1` slip onto a non-eligible type without tripping the suite) | `silver/silver_pipeline.py`, `data_quality/run_silver_suite.py` `rule1_type_constraint` |
| F04 | Checkpoint file corrupted mid-run (cumulative MERGE checkpoint.json unreadable) | `silver/cumulative_pipeline.py` `_read_checkpoint` (intentionally raises, not defaults to 0) |

Catalog entries (full repro steps) live in `simulation/faults/catalog/`.
