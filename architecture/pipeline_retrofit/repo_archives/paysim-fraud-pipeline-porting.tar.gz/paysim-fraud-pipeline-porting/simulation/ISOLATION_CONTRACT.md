# Isolation Contract — Paysim Simulation Lab

> **Purpose:** guarantee the sim lab can never corrupt the real PySpark/Delta/dbt/Snowflake
> pipeline. This is what makes deliberate fault-injection and optimization drills safe — break
> the sim all you want, `main` is untouchable. Enforced by `python simulation/check_isolation.py`
> (deterministic, no Databricks/Snowflake connection needed). Run it before every sim session
> AND before committing any sim work. PASS required.

Ported from `creative_intelligence_lab`'s simulation isolation contract (pipeline-retrofit
effort, via home-credit's and olist's patterns), retargeted to this repo's real stack: an
`s3a://.../sim/` prefix convention instead of CIL's DuckDB catalog or olist's ADLS Gen2
`abfss://` prefix.

## The rules

**R1 — Own S3 prefix.** Everything the sim reads or writes lives under
`s3a://<bucket>/sim/<scenario>/...`. The sim must never reference the real `landing/`,
`bronze/`, `silver/` paths. *Guard:* every `s3a://` literal in a sim file must contain `/sim/`.

**R2 — Own Snowflake schema + dbt project.** The sim has its own dbt project at
`simulation/sim_dbt/` (project name `sim_paysim_fraud`, profile target `sim`, schema
`PAYSIM_FRAUD_SIM` — never `STAGING`/`DEV`/`PROD`). *Guard:* sim `dbt_project.yml` `name` !=
the real `gold/dbt_project.yml` `name`.

**R3 — No cross-refs.** No sim model may `ref()` a real `gold/models/**` model, and no sim
file may read a real Bronze/Silver Delta table by path. The sim's "legacy source" is synthetic
dev data (small CSV/Parquet fixtures under `simulation/`, pointed at sim paths only).
*Guard:* no `ref('<real model>')` appears in any `simulation/**/*.sql`.

**R4 — Real tree is read-only.** `bronze/`, `silver/`, `gold/`, `docs/`, `airflow/dags/`,
`tests/` are reference-only for the sim — read them to learn the patterns, never edit them
from a sim task.

**R5 — Faults stay in the lab, and reset is total.** Fault injection happens only inside
`simulation/`. The clean state must be fully rebuildable from sim fixtures
(`faults/reset.py` = re-seed + re-build sim), never hand-patched.

## What the guard checks
`check_isolation.py` statically enforces R1, R2, R3. R4/R5 stay partly human discipline.

## If a rule and a task conflict
STOP and surface it (same as the main project's STOP-GATE in CLAUDE.md). Do not point the sim
at the real Snowflake schema, the real S3 bucket, or the real Databricks workspace "just this
once."
