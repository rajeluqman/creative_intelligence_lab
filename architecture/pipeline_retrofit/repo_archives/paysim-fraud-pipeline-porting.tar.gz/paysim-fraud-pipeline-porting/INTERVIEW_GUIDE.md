# Interview Guide — Paysim Fraud Pipeline

> Owned jointly by @business-analyst (evidence) and @documentation-sherpa (structure).
> Every resume bullet traces to `file:line` evidence below, or is flagged unsupported.
> "(unverified)" means checked-but-not-confirmed this turn (e.g. no live Databricks/Snowflake
> session available); never silently upgraded to "confirmed" without re-running the check.

## Resume Claim ↔ Repo Evidence

| # | Claim | Status | Evidence |
|---|---|---|---|
| 1 | "Silver GX 14/15 (1 WARN)" | ✅ Confirmed + attributed (this retrofit) | README.md "Stack" table states "Silver 14/15 (1 WARN documented)" without naming the check. Traced to `data_quality/run_silver_suite.py`'s `merchant_balance_null` check (the only one of the 3 WARN-capable checks — `merchant_balance_null`, `drain_pct_range`, `fraud_rate_check` — matching `docs/DQD.md`'s documented expected anomaly "Merchant balance = 0 → by design"). Formally accepted, not fixed: `docs/ADR/ADR-002-silver-warn-acceptance.md`. **Action: cite ADR-002 + `merchant_balance_null` by name in the interview narrative, don't leave "1 WARN" unattributed.** |
| 2 | Hybrid data model — Kimball + Cumulative Table | ✅ Confirmed | `gold/models/marts/mart_fraud_summary.sql` (Kimball, `int_transactions_enriched` source) + `gold/models/marts/mart_customer_risk.sql` (cumulative-table grain, `int_cumulative_customer_balance` source). `docs/ADR/ADR-001-hybrid-paradigm.md`. Gated by `tests/identity_contract.py` (passes). |
| 3 | Delta Lake MERGE for cumulative running totals, idempotent | ✅ Confirmed | `silver/cumulative_pipeline.py`'s `_merge_day` — running totals computed from yesterday's row (`prev_running_*` columns), not the matched row, so a re-run can't double-count (see its module docstring). Checkpoint-resume logic intentionally raises rather than silently restarting from Day 1 on an unreadable checkpoint (`_read_checkpoint`). |
| 4 | PySpark + Delta Lake on Databricks for Bronze/Silver | ✅ Confirmed, with nuance — README corrected (this retrofit) | `bronze/bronze_pipeline.py`, `silver/silver_pipeline.py`, `silver/cumulative_pipeline.py` are plain PySpark+Delta (`local[*]` or `s3a://` paths) — runnable locally OR on Databricks. README's "Stack" table previously overstated Silver as "Databricks SQL Warehouse (Serverless Starter) — SQL CTAS + window functions"; **fixed 2026-06-29** to say PySpark+Delta Lake, local or Databricks (`docs/ARCHITECTURE.md` already had this right). The actual full-scale (6.3M row) staging run was executed via `silver/databricks_notebook.py` (manual, cell-by-cell, on a Databricks Trial workspace) — be ready to explain this is a SEPARATE execution path from the Airflow DAG, which runs the same modules as local PySpark, not via a Databricks job submission API. |
| 5 | Two Snowflake-load bridge paths | ✅ Confirmed | `silver/export_to_s3_parquet.py` (S3 Parquet → Snowflake COPY INTO — the path wired into `airflow/dags/paysim_fraud_pipeline.py`) and `silver/databricks_to_snowflake.py` (Databricks SQL Warehouse Arrow batch → `write_pandas()`, an alternate/manual path, not in the DAG). Both exist in the repo; only the Parquet path is automated. |
| 6 | dbt Core Gold layer, staging → intermediate → marts | ✅ Confirmed | `gold/models/{staging,intermediate,marts}/` — 2 staging + 3 intermediate + 2 mart models, `dbt-snowflake` adapter (`gold/profiles.yml`, `requirements.txt`) |
| 7 | Apache Airflow orchestration, full chain | ✅ Confirmed | `airflow/dags/paysim_fraud_pipeline.py` — bronze → bronze_dq → silver → silver_cumulative_merge → silver_dq → silver_export_parquet → snowflake_copy_into → gold_dbt_run → gold_dbt_test, `@daily` |
| 8 | Slack alerting on pipeline success/failure | ✅ Confirmed | `airflow/dags/paysim_fraud_pipeline.py` `slack_success`/`slack_failure` via `SlackWebhookOperator`, wired as `on_success_callback`/`on_failure_callback` in the DAG decorator — was ALREADY working before this retrofit (kept as-is, no backfill needed, unlike olist/Volve in this retrofit effort) |
| 9 | RULE 1 fraud-type constraint enforced as a hard quality gate | ✅ Confirmed | `data_quality/run_silver_suite.py`'s `rule1_type_constraint` check — `is_fraud=1 AND type NOT IN (TRANSFER, CASH-OUT)` is CRITICAL, blocks Gold. Matches `docs/DQD.md`'s "Known Expected Anomalies: Fraud HANYA dalam TRANSFER + CASH-OUT". |
| 10 | Power BI as the BI/serving consumer | ✅ Confirmed | README.md "Stack" + "Screenshots" section (Power BI artifact itself is external to the repo — expected, BI tools aren't typically version-controlled) |

## Repo quirk surfaced during retrofit — now resolved (not a resume claim, mention if asked)
`bronze/download_dataset.py` previously contained an `upload_to_adls()` function (optional
Azure ADLS upload, gated by a `CLOUD` env var) alongside the documented S3 path. It was
**never invoked** by the Airflow DAG or any other automated path in this repo — production
behavior is S3-only per `docs/ARCHITECTURE.md`. **Resolved 2026-06-29: the function and the
`CLOUD`/`elif cloud == "azure"` branching were removed** — `main()` now uploads to S3
unconditionally for staging/prod. See `DECISION_LOG.md`.

## Interview Q&A drills (answer from the artifact, not memory)
1. **"Walk me through the cumulative MERGE idempotency guarantee."** → `silver/cumulative_pipeline.py`'s
   module docstring + `_merge_day` — running totals are derived from `prev_running_*` (the
   day-before row), never from the row being matched/updated. Re-running the same day's MERGE
   twice yields the same absolute values. Gated statically by `tests/identity_contract.py`.
2. **"Why hybrid — Kimball AND cumulative, not one paradigm?"** → `docs/ADR/ADR-001-hybrid-paradigm.md`
   — fraud KPI aggregation wants star-schema GROUP BY/joins; account-drain detection wants
   pre-computed running totals without a full scan every query. Pure Kimball makes running
   totals expensive; pure cumulative makes aggregate fraud reporting messy.
3. **"What's the 1 Silver WARN, specifically?"** → `merchant_balance_null` —
   `docs/ADR/ADR-002-silver-warn-acceptance.md`. Don't say "I don't know, README just says 1
   WARN" — that's the exact gap this ADR closes.
4. **"Is your staging run automated end-to-end?"** → Mostly: the Airflow DAG automates
   Bronze→Gold on local/any-PySpark-capable worker. The ONE manual step was the original
   6.3M-row staging-promote run, executed via the Databricks notebook
   (`silver/databricks_notebook.py`) rather than the DAG — be upfront about this distinction
   rather than implying full automation end-to-end at full scale.
5. **"What happens if the checkpoint file is unreadable mid-run?"** → It raises
   (`_read_checkpoint`'s `RuntimeError`), intentionally — restarting from Day 1 without
   verifying the last completed day would double-count running totals. This is a deliberate
   fail-loud design choice, not an oversight.
