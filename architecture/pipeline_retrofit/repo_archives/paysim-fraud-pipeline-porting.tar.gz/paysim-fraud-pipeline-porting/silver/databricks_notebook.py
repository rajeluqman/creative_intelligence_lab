# Databricks notebook source
# paysim-fraud-pipeline — Silver + Cumulative Staging Run
# Platform : Databricks Trial workspace
# ENV      : staging (full 6.3M rows from S3)
# Run order: Cell by cell top-to-bottom. Do NOT run all at once.
# Owner    : DPE

# COMMAND ----------

# MAGIC %pip install delta-spark==3.0.0 python-dotenv boto3 great-expectations==0.18.0

# COMMAND ----------

import os, sys

# ── Credentials via Databricks Secrets ──────────────────────────────────────
# Setup once: databricks secrets create-scope --scope paysim
#             databricks secrets put --scope paysim --key <key>
os.environ["ENV"]                   = "staging"
os.environ["CLOUD"]                 = "aws"
os.environ["AWS_ACCESS_KEY_ID"]     = dbutils.secrets.get("paysim", "aws_access_key_id")
os.environ["AWS_SECRET_ACCESS_KEY"] = dbutils.secrets.get("paysim", "aws_secret_access_key")
os.environ["AWS_REGION"]            = dbutils.secrets.get("paysim", "aws_region")
os.environ["S3_BUCKET_STAGING"]     = dbutils.secrets.get("paysim", "s3_bucket_staging")

# COMMAND ----------

# ── Add project root to sys.path ─────────────────────────────────────────────
# Clone repo first: Repos → Add Repo → https://github.com/<user>/paysim-fraud-pipeline
# Then update path below to match your Databricks username.
_REPO_PATH = "/Workspace/Repos/raja.luqman/paysim-fraud-pipeline"
if _REPO_PATH not in sys.path:
    sys.path.insert(0, _REPO_PATH)

# Smoke-test import
import bronze.bronze_pipeline as _bp
print("✅ Imports OK — repo path correct")

# COMMAND ----------

# ═════════════════════════════════════════════════════════════════════════════
# CELL 1 — BRONZE  (S3 landing CSV → S3 Delta Bronze)
# Input : s3://bucket/landing/PS_...csv
# Output: s3://bucket/bronze/transactions/ (Delta, partitioned by transaction_day)
# Note  : Only run if bronze hasn't been written yet for this batch.
# ═════════════════════════════════════════════════════════════════════════════

import bronze.bronze_pipeline as bronze_pipeline

result = bronze_pipeline.run()
print(f"\nBronze complete: {result}")
assert result["status"] == "success", f"Bronze FAILED: {result}"

# COMMAND ----------

# ═════════════════════════════════════════════════════════════════════════════
# CELL 2 — SILVER TRANSFORM  (S3 Delta Bronze → S3 Delta Silver)
# Input : s3://bucket/bronze/transactions/
# Output: s3://bucket/silver/transactions/ (Delta, partitioned by transaction_day)
#         s3://bucket/silver/quarantine/   (Delta — rejected rows)
# ═════════════════════════════════════════════════════════════════════════════

import silver.silver_pipeline as silver_pipeline

result = silver_pipeline.run()
print(f"\nSilver complete: {result}")
assert result["status"] == "success", f"Silver FAILED: {result}"
assert result["retention_pct"] >= 99.0, (
    f"Row retention {result['retention_pct']:.2f}% < 99% — STOP, investigate quarantine"
)

# COMMAND ----------

# ═════════════════════════════════════════════════════════════════════════════
# CELL 3 — CUMULATIVE MERGE  (S3 Delta Silver → S3 Delta customer_daily_balance)
# Input : s3://bucket/silver/transactions/
# Output: s3://bucket/silver/customer_daily_balance/ (Delta MERGE, 31 days)
#
# CHECKPOINT RESUME:
#   - After each day's MERGE, checkpoint.json is written to S3.
#   - If cluster terminates mid-run, rerun this cell — it skips completed days.
#   - NEVER delete checkpoint.json and restart from Day 1 unless you wipe the
#     cumulative table first. Double-processing = wrong running totals.
#
# MEMORY GUIDANCE (Databricks Trial standard node ~15GB driver):
#   - MERGE peak ~5.5GB. Standard_DS3_v2 (14GB) or r4.large (15.3GB) sufficient.
#   - If OOM: scale cluster up (Standard_DS4_v2 / r4.xlarge) before retrying.
# ═════════════════════════════════════════════════════════════════════════════

import silver.cumulative_pipeline as cumulative_pipeline

result = cumulative_pipeline.run()
print(f"\nCumulative complete: {result}")
assert result["status"] == "success", f"Cumulative MERGE FAILED: {result}"
print(f"Days merged : {result['days_merged']}")
print(f"Total rows  : {result['total_rows']:,}")

# COMMAND ----------

# ═════════════════════════════════════════════════════════════════════════════
# CELL 4 — ROW COUNT VERIFICATION
# Quick sanity check before export.
# ═════════════════════════════════════════════════════════════════════════════

from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip

spark = (
    configure_spark_with_delta_pip(
        SparkSession.builder
        .appName("paysim-verify")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
    ).getOrCreate()
)
spark.sparkContext.setLogLevel("WARN")

bucket = os.environ["S3_BUCKET_STAGING"]

bronze_count = spark.read.format("delta").load(f"s3a://{bucket}/bronze/transactions").count()
silver_count = spark.read.format("delta").load(f"s3a://{bucket}/silver/transactions").count()
cumul_count  = spark.read.format("delta").load(f"s3a://{bucket}/silver/customer_daily_balance").count()

print(f"Bronze rows  : {bronze_count:>10,}")
print(f"Silver rows  : {silver_count:>10,}  (retention: {silver_count/bronze_count*100:.3f}%)")
print(f"Cumulative   : {cumul_count:>10,}  (unique customer-day pairs)")
assert 6_200_000 <= silver_count <= 6_400_000, f"Silver count {silver_count:,} outside expected range 6.2M–6.4M"

# COMMAND ----------

# ═════════════════════════════════════════════════════════════════════════════
# CELL 5 — SILVER EXPORT (Delta → S3 Parquet — Snowflake ingestion prep)
# Output: s3://bucket/silver_parquet/transactions/
#         s3://bucket/silver_parquet/customer_daily_balance/
# ═════════════════════════════════════════════════════════════════════════════

import silver.export_to_s3_parquet as export

result = export.export_parquet()
print(f"\nParquet export complete: {result}")
assert result["status"] == "success"

# COMMAND ----------

# ═════════════════════════════════════════════════════════════════════════════
# CELL 6 — SNOWFLAKE COPY INTO
# Loads S3 Parquet into Snowflake STAGING schema.
# Requires Snowflake credentials in Databricks secrets scope "paysim".
# ═════════════════════════════════════════════════════════════════════════════

os.environ["SNOWFLAKE_ACCOUNT"]          = dbutils.secrets.get("paysim", "snowflake_account")
os.environ["SNOWFLAKE_USER"]             = dbutils.secrets.get("paysim", "snowflake_user")
os.environ["SNOWFLAKE_PASSWORD"]         = dbutils.secrets.get("paysim", "snowflake_password")
os.environ["SNOWFLAKE_DATABASE"]         = dbutils.secrets.get("paysim", "snowflake_database")
os.environ["SNOWFLAKE_SCHEMA_STAGING"]   = "STAGING"
os.environ["SNOWFLAKE_WAREHOUSE"]        = dbutils.secrets.get("paysim", "snowflake_warehouse")
os.environ["SNOWFLAKE_ROLE"]             = dbutils.secrets.get("paysim", "snowflake_role")

result = export.copy_into_snowflake()
print(f"\nSnowflake COPY INTO complete: {result}")
assert result["status"] == "success"

# COMMAND ----------

print("=" * 60)
print("✅  Phase 4b Staging Run COMPLETE")
print(f"   Bronze  : {bronze_count:,} rows")
print(f"   Silver  : {silver_count:,} rows")
print(f"   Cumul   : {cumul_count:,} customer-day rows")
print("   Parquet export → S3  : ✅")
print("   Snowflake COPY INTO  : ✅")
print()
print("Next: run  dbt run --target staging  locally")
print("      then dbt test --target staging")
print("=" * 60)
