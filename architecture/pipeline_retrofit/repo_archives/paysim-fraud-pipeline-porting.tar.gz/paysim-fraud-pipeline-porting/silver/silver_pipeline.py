"""
Silver transform: bronze.transactions → silver.transactions
Dev     : data/bronze/transactions → data/silver/transactions (PySpark local)
Staging : s3a://bucket/bronze/ → s3a://bucket/silver/transactions/

Steps per PIPELINE_SPEC:
  1. Deduplicate — keep latest ingestion_ts per (nameOrig, step, amount)
  2. Type cast   — step INT, amount DOUBLE, isFraud INT, isFlaggedFraud INT
  3. NULL handle — critical columns: reject rows, store in quarantine
  4. Derived     — transaction_id, datetime cols, balance metrics, discrepancy flags
  5. Rename      — PaySim source names → semantic names
  6. Validate    — dq_flag bitmask (0=clean)

dq_flag bitmask:
  Bit 0 (1) — isFraud not in (0,1)
  Bit 1 (2) — type not in valid PaySim types
  Bit 2 (4) — RULE 1: isFraud=1 AND type NOT IN (TRANSFER, CASH-OUT)
  Bit 3 (8) — material balance discrepancy on originator side (|disc| > 0.01 AND > 0)
"""

import os
import logging
from pathlib import Path
from datetime import datetime

from dotenv import load_dotenv

log = logging.getLogger(__name__)

VALID_TYPES = {"CASH-IN", "CASH-OUT", "DEBIT", "PAYMENT", "TRANSFER"}
FRAUD_ELIGIBLE_TYPES = {"TRANSFER", "CASH-OUT"}
BASE_DATETIME = "2024-01-01 00:00:00"


def _load_env():
    env = os.getenv("ENV", "dev")
    env_file = f".env.{env}"
    if Path(env_file).exists():
        load_dotenv(env_file)
    elif Path(".env").exists():
        load_dotenv(".env")
    return env


def _get_spark(env: str):
    from pyspark.sql import SparkSession
    from delta import configure_spark_with_delta_pip

    builder = (
        SparkSession.builder
        .appName("paysim-silver-transform")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .master("local[*]")
    )

    if env in ("staging", "prod"):
        aws_key = os.getenv("AWS_ACCESS_KEY_ID", "")
        aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY", "")
        region = os.getenv("AWS_REGION", "ap-southeast-1")
        builder = (
            builder
            .config("spark.hadoop.fs.s3a.access.key", aws_key)
            .config("spark.hadoop.fs.s3a.secret.key", aws_secret)
            .config("spark.hadoop.fs.s3a.endpoint", f"s3.{region}.amazonaws.com")
            .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        )

    return configure_spark_with_delta_pip(builder).getOrCreate()


def _get_paths(env: str) -> tuple[str, str, str]:
    if env == "dev":
        return "data/bronze/transactions", "data/silver/transactions", "data/silver/quarantine"
    bucket = os.getenv(f"S3_BUCKET_{env.upper()}")
    if not bucket:
        raise EnvironmentError(f"S3_BUCKET_{env.upper()} not set in env")
    return (
        f"s3a://{bucket}/bronze/transactions",
        f"s3a://{bucket}/silver/transactions",
        f"s3a://{bucket}/silver/quarantine",
    )


def transform(df, batch_id: str):
    """Apply all Silver transforms. Returns (clean_df, quarantine_df)."""
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window

    # ── 1. Deduplicate — keep latest ingestion_ts per (nameOrig, step, amount) ──
    w = Window.partitionBy("nameOrig", "step", "amount").orderBy(F.desc("ingestion_ts"))
    df = df.withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1).drop("_rn")

    # ── 2. Type cast + normalize ──────────────────────────────────────────────────
    # Source dataset uses CASH_IN / CASH_OUT (underscore). Documented schema uses
    # CASH-IN / CASH-OUT (hyphen). Normalize here so Silver and all downstream
    # match the documented schema. Other types (DEBIT, PAYMENT, TRANSFER) unaffected.
    df = (
        df
        .withColumn("step",            F.col("step").cast("int"))
        .withColumn("amount",          F.col("amount").cast("double"))
        .withColumn("oldbalanceOrg",   F.col("oldbalanceOrg").cast("double"))
        .withColumn("newbalanceOrig",  F.col("newbalanceOrig").cast("double"))
        .withColumn("oldbalanceDest",  F.col("oldbalanceDest").cast("double"))
        .withColumn("newbalanceDest",  F.col("newbalanceDest").cast("double"))
        .withColumn("isFraud",         F.col("isFraud").cast("int"))
        .withColumn("isFlaggedFraud",  F.col("isFlaggedFraud").cast("int"))
        .withColumn("type",            F.regexp_replace(F.col("type"), "_", "-"))
    )

    # ── 3. NULL handling — reject critical nulls to quarantine ────────────────────
    critical_null_filter = (
        F.col("nameOrig").isNull() |
        F.col("nameDest").isNull() |
        F.col("type").isNull() |
        F.col("amount").isNull()
    )
    quarantine_df = df.filter(critical_null_filter).withColumn("reject_reason", F.lit("null_critical_column"))
    df = df.filter(~critical_null_filter)

    # Merchant receiver balance → NULL (by design, not error)
    df = df.withColumn(
        "oldbalanceDest",
        F.when(F.col("nameDest").startswith("M"), F.lit(None).cast("double"))
         .otherwise(F.col("oldbalanceDest"))
    ).withColumn(
        "newbalanceDest",
        F.when(F.col("nameDest").startswith("M"), F.lit(None).cast("double"))
         .otherwise(F.col("newbalanceDest"))
    )

    # ── 4. Derived columns ────────────────────────────────────────────────────────
    # transaction_id — MD5(nameOrig|step|type|amount) — pipe-separated, type included
    df = df.withColumn(
        "transaction_id",
        F.md5(F.concat_ws(
            "|",
            F.col("nameOrig"),
            F.col("step").cast("string"),
            F.col("type"),
            F.col("amount").cast("string"),
        ))
    )

    # Time columns
    df = (
        df
        .withColumn("transaction_day",      F.ceil(F.col("step") / 24).cast("int"))
        .withColumn("transaction_hour",     ((F.col("step") - 1) % 24).cast("int"))
        .withColumn("transaction_datetime",
                    F.expr(f"TIMESTAMP('{BASE_DATETIME}') + MAKE_INTERVAL(0,0,0,0,step-1,0,0)"))
    )

    # Destination flags
    df = df.withColumn("is_merchant_dest",
                       F.when(F.col("nameDest").startswith("M"), F.lit(1)).otherwise(F.lit(0)))

    # Balance metrics
    df = df.withColumn(
        "balance_drain_pct",
        F.when(F.col("oldbalanceOrg") > 0,
               (F.col("amount") / F.col("oldbalanceOrg") * 100))
         .otherwise(F.lit(None).cast("double"))
    )
    df = df.withColumn(
        "is_zero_out",
        F.when(
            (F.col("newbalanceOrig") == 0) &
            (F.col("amount") > 0) &
            (F.col("oldbalanceOrg") > 0),
            F.lit(1)
        ).otherwise(F.lit(0))
    )

    # Balance discrepancy — SIGNED, not ABS
    df = df.withColumn(
        "balance_disc_orig",
        (F.col("oldbalanceOrg") - F.col("amount")) - F.col("newbalanceOrig")
    )
    df = df.withColumn(
        "balance_disc_dest",
        F.when(
            F.col("is_merchant_dest") == 0,
            (F.col("oldbalanceDest") + F.col("amount")) - F.col("newbalanceDest")
        ).otherwise(F.lit(None).cast("double"))
    )

    # Flagged-fraud discrepancy (heuristic mismatch)
    df = df.withColumn(
        "flagged_fraud_discrepancy",
        F.when(F.col("isFlaggedFraud") != F.col("isFraud"), F.lit(1)).otherwise(F.lit(0))
    )

    # ── 5. dq_flag bitmask ────────────────────────────────────────────────────────
    valid_types_list = list(VALID_TYPES)
    fraud_types_list = list(FRAUD_ELIGIBLE_TYPES)

    # Bits are disjoint (1, 2, 4, 8) so + is equivalent to bitwise OR and avoids
    # Spark's BINARY_OP_WRONG_TYPE error when using | between INT columns.
    df = df.withColumn(
        "dq_flag",
        (
            F.when(~F.col("isFraud").isin(0, 1), F.lit(1)).otherwise(F.lit(0)) +
            F.when(~F.col("type").isin(valid_types_list), F.lit(2)).otherwise(F.lit(0)) +
            F.when(
                (F.col("isFraud") == 1) & ~F.col("type").isin(fraud_types_list),
                F.lit(4)
            ).otherwise(F.lit(0)) +
            F.when(F.abs(F.col("balance_disc_orig")) > 0.01, F.lit(8)).otherwise(F.lit(0))
        ).cast("int")
    )

    # ── 6. Rename — PaySim source → semantic names ────────────────────────────────
    df = (
        df
        .withColumnRenamed("nameOrig",        "sender_id")
        .withColumnRenamed("nameDest",         "receiver_id")
        .withColumnRenamed("oldbalanceOrg",    "sender_balance_before")
        .withColumnRenamed("newbalanceOrig",   "sender_balance_after")
        .withColumnRenamed("oldbalanceDest",   "receiver_balance_before")
        .withColumnRenamed("newbalanceDest",   "receiver_balance_after")
        .withColumnRenamed("isFraud",          "is_fraud")
        .withColumnRenamed("isFlaggedFraud",   "is_flagged_fraud")
    )

    # Add pipeline metadata
    df = df.withColumn("batch_id", F.lit(batch_id))

    return df, quarantine_df


def run():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    env = _load_env()
    batch_id = os.getenv("AIRFLOW_CTX_DAG_RUN_ID",
                         datetime.utcnow().strftime("manual_%Y%m%d_%H%M%S"))

    bronze_path, silver_path, quarantine_path = _get_paths(env)
    log.info(f"[Silver] env={env} | bronze={bronze_path} | silver={silver_path}")

    spark = _get_spark(env)
    spark.sparkContext.setLogLevel("WARN")

    try:
        bronze_df = spark.read.format("delta").load(bronze_path)
        bronze_count = bronze_df.count()
        log.info(f"[Silver] Bronze rows loaded: {bronze_count:,}")

        silver_df, quarantine_df = transform(bronze_df, batch_id)

        # Write quarantine first (usually small / empty)
        q_count = quarantine_df.count()
        if q_count > 0:
            log.warning(f"[Silver] Quarantine rows: {q_count:,} — writing to {quarantine_path}")
            quarantine_df.write.format("delta").mode("append").save(quarantine_path)

        silver_df.write.format("delta").mode("overwrite").partitionBy("transaction_day").save(silver_path)
        silver_count = silver_df.count()
        log.info(f"[Silver] Written {silver_count:,} rows → {silver_path}")

        # Verify row retention >= 99% (Bronze → Silver reconciliation)
        retention_pct = silver_count / bronze_count * 100 if bronze_count > 0 else 0
        if retention_pct < 99.0:
            log.warning(
                f"[Silver] Row retention {retention_pct:.2f}% < 99% threshold. "
                f"Bronze={bronze_count:,} Silver={silver_count:,} Quarantine={q_count:,}"
            )

        return {
            "status": "success",
            "bronze_count": bronze_count,
            "silver_count": silver_count,
            "quarantine_count": q_count,
            "retention_pct": round(retention_pct, 4),
        }

    finally:
        spark.stop()


if __name__ == "__main__":
    result = run()
    print(f"\nSilver transform complete: {result}")
