"""
Silver → S3 Parquet → Snowflake COPY INTO
Phase: 4b cloud promote — Silver/Snowflake bridge

Pipeline SPEC reference: silver_export_parquet → snowflake_copy_into → dbt_run

export_parquet()    : Read Silver Delta (S3) → Write Parquet to S3 export prefix
copy_into_snowflake(): CREATE tables if not exists → COPY INTO from S3 Parquet
run()               : Calls both in sequence (used by Airflow)
"""

import os
import logging
from pathlib import Path
from datetime import datetime

from dotenv import load_dotenv

log = logging.getLogger(__name__)

# Snowflake column definitions matching silver_pipeline.py transform output.
# Kept here to avoid runtime schema introspection — explicit is safer for COPY INTO.
_DDL_TRANSACTIONS = """
CREATE TABLE IF NOT EXISTS {schema}.TRANSACTIONS (
    transaction_id        VARCHAR,
    step                  INTEGER,
    type                  VARCHAR,
    amount                DOUBLE,
    sender_id             VARCHAR,
    sender_balance_before DOUBLE,
    sender_balance_after  DOUBLE,
    receiver_id           VARCHAR,
    receiver_balance_before DOUBLE,
    receiver_balance_after  DOUBLE,
    is_merchant_dest      INTEGER,
    is_fraud              INTEGER,
    is_flagged_fraud      INTEGER,
    transaction_day       INTEGER,
    transaction_hour      INTEGER,
    transaction_datetime  TIMESTAMP_NTZ,
    balance_drain_pct     DOUBLE,
    is_zero_out           INTEGER,
    balance_disc_orig     DOUBLE,
    balance_disc_dest     DOUBLE,
    flagged_fraud_discrepancy INTEGER,
    dq_flag               INTEGER,
    batch_id              VARCHAR,
    ingestion_ts          TIMESTAMP_NTZ,
    source_system         VARCHAR,
    source_file           VARCHAR
)
"""

_DDL_CUSTOMER_DAILY = """
CREATE TABLE IF NOT EXISTS {schema}.CUSTOMER_DAILY_BALANCE (
    customer_id              VARCHAR,
    balance_date             DATE,
    daily_sent_amount        DOUBLE,
    daily_received_amount    DOUBLE,
    daily_txn_count          INTEGER,
    daily_fraud_count        INTEGER,
    daily_zero_out_count     INTEGER,
    max_daily_drain_pct      DOUBLE,
    running_txn_total        BIGINT,
    running_fraud_total      INTEGER,
    running_fraud_amount     DOUBLE,
    running_sent_total       DOUBLE,
    is_high_risk_today       INTEGER,
    ingestion_ts             TIMESTAMP_NTZ,
    batch_id                 VARCHAR
)
"""


def _load_env():
    env = os.getenv("ENV", "dev")
    env_file = f".env.{env}"
    if Path(env_file).exists():
        load_dotenv(env_file)
    elif Path(".env").exists():
        load_dotenv(".env")
    return env


def _get_spark(env: str):
    from pyspark.sql import SparkSession
    from delta import configure_spark_with_delta_pip

    builder = (
        SparkSession.builder
        .appName("paysim-silver-export")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .master("local[*]")
    )

    if env in ("staging", "prod"):
        aws_key    = os.getenv("AWS_ACCESS_KEY_ID", "")
        aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY", "")
        region     = os.getenv("AWS_REGION", "ap-southeast-1")
        builder = (
            builder
            .config("spark.hadoop.fs.s3a.access.key", aws_key)
            .config("spark.hadoop.fs.s3a.secret.key", aws_secret)
            .config("spark.hadoop.fs.s3a.endpoint", f"s3.{region}.amazonaws.com")
            .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        )

    return configure_spark_with_delta_pip(builder).getOrCreate()


def _get_paths(env: str) -> dict:
    if env == "dev":
        return {
            "silver_txn":    "data/silver/transactions",
            "silver_cumul":  "data/silver/customer_daily_balance",
            "parquet_txn":   "data/silver_parquet/transactions",
            "parquet_cumul": "data/silver_parquet/customer_daily_balance",
        }
    bucket = os.getenv(f"S3_BUCKET_{env.upper()}")
    if not bucket:
        raise EnvironmentError(f"S3_BUCKET_{env.upper()} not set")
    return {
        "silver_txn":    f"s3a://{bucket}/silver/transactions",
        "silver_cumul":  f"s3a://{bucket}/silver/customer_daily_balance",
        "parquet_txn":   f"s3a://{bucket}/silver_parquet/transactions",
        "parquet_cumul": f"s3a://{bucket}/silver_parquet/customer_daily_balance",
        "bucket":        bucket,
    }


def export_parquet(env: str | None = None, spark=None) -> dict:
    """Read Silver Delta tables → write Parquet to S3 export prefix."""
    if env is None:
        env = _load_env()

    paths = _get_paths(env)
    log.info(f"[Export] env={env} | silver → parquet")

    _spark_owned = spark is None
    if _spark_owned:
        spark = _get_spark(env)
        spark.sparkContext.setLogLevel("WARN")

    try:
        txn_df = spark.read.format("delta").load(paths["silver_txn"])
        txn_count = txn_df.count()
        (
            txn_df.write
            .format("parquet")
            .mode("overwrite")
            .partitionBy("transaction_day")
            .save(paths["parquet_txn"])
        )
        log.info(f"[Export] transactions → {paths['parquet_txn']}  ({txn_count:,} rows)")

        cumul_df = spark.read.format("delta").load(paths["silver_cumul"])
        cumul_count = cumul_df.count()
        (
            cumul_df.write
            .format("parquet")
            .mode("overwrite")
            .partitionBy("balance_date")
            .save(paths["parquet_cumul"])
        )
        log.info(f"[Export] customer_daily_balance → {paths['parquet_cumul']}  ({cumul_count:,} rows)")

        return {
            "status": "success",
            "txn_count": txn_count,
            "cumul_count": cumul_count,
            "parquet_txn_path": paths["parquet_txn"],
            "parquet_cumul_path": paths["parquet_cumul"],
        }

    finally:
        if _spark_owned:
            spark.stop()


def copy_into_snowflake(env: str | None = None) -> dict:
    """
    CREATE tables (if not exists) → COPY INTO from S3 Parquet.
    Truncates before loading — idempotent, safe to rerun.
    """
    import snowflake.connector

    if env is None:
        env = _load_env()

    schema   = os.getenv(f"SNOWFLAKE_SCHEMA_{env.upper()}", env.upper())
    bucket   = os.getenv(f"S3_BUCKET_{env.upper()}", "")
    region   = os.getenv("AWS_REGION", "ap-southeast-1")
    aws_key  = os.getenv("AWS_ACCESS_KEY_ID", "")
    aws_sec  = os.getenv("AWS_SECRET_ACCESS_KEY", "")

    conn = snowflake.connector.connect(
        account   = os.getenv("SNOWFLAKE_ACCOUNT"),
        user      = os.getenv("SNOWFLAKE_USER"),
        password  = os.getenv("SNOWFLAKE_PASSWORD"),
        database  = os.getenv("SNOWFLAKE_DATABASE"),
        schema    = schema,
        warehouse = os.getenv("SNOWFLAKE_WAREHOUSE"),
        role      = os.getenv("SNOWFLAKE_ROLE", "SYSADMIN"),
    )

    results = {}

    try:
        cur = conn.cursor()

        # Ensure schema exists
        cur.execute(f"CREATE SCHEMA IF NOT EXISTS {schema}")

        for table_ddl, table_name, s3_prefix in [
            (_DDL_TRANSACTIONS,   "TRANSACTIONS",          f"silver_parquet/transactions/"),
            (_DDL_CUSTOMER_DAILY, "CUSTOMER_DAILY_BALANCE", f"silver_parquet/customer_daily_balance/"),
        ]:
            # Create table
            cur.execute(table_ddl.format(schema=schema))

            # Truncate before reload (idempotent — staging is always full replace)
            cur.execute(f"TRUNCATE TABLE IF EXISTS {schema}.{table_name}")

            s3_url = f"s3://{bucket}/{s3_prefix}"
            copy_sql = f"""
                COPY INTO {schema}.{table_name}
                FROM '{s3_url}'
                CREDENTIALS = (
                    AWS_KEY_ID='{aws_key}'
                    AWS_SECRET_KEY='{aws_sec}'
                )
                FILE_FORMAT = (
                    TYPE = 'PARQUET'
                    SNAPPY_COMPRESSION = TRUE
                )
                MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
                PURGE = FALSE
            """
            cur.execute(copy_sql)
            row_count = cur.fetchone()
            log.info(f"[COPY INTO] {schema}.{table_name}  result={row_count}")
            results[table_name] = row_count

        # Suspend warehouse after load — preserve Snowflake credit
        warehouse = os.getenv("SNOWFLAKE_WAREHOUSE", "COMPUTE_WH")
        cur.execute(f"ALTER WAREHOUSE {warehouse} SUSPEND")
        log.info(f"[Snowflake] Warehouse {warehouse} suspended")

    finally:
        conn.close()

    return {"status": "success", "copy_results": results}


def run():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    env = _load_env()

    export_result = export_parquet(env=env)
    copy_result   = copy_into_snowflake(env=env)

    return {**export_result, **copy_result}


if __name__ == "__main__":
    result = run()
    print(f"\nSilver export + Snowflake COPY INTO complete: {result}")
