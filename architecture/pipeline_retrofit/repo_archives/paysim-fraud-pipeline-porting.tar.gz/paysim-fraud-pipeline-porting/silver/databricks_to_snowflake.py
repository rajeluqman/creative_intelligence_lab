"""
Databricks SQL Warehouse → Snowflake STAGING
Phase: 4b cloud promote — SQL Warehouse path (no S3 Parquet intermediate)

Flow:
  paysim_fraud.silver.transactions          → STAGING.TRANSACTIONS
  paysim_fraud.silver.customer_daily_balance → STAGING.CUSTOMER_DAILY_BALANCE

Method:
  - Read from Databricks SQL Warehouse in Arrow batches (500K rows each)
  - write_pandas() per chunk → Snowflake internal stage → COPY INTO (auto)
  - Maintains COPY INTO semantics without needing S3 external location

Usage:
  ENV=staging python silver/databricks_to_snowflake.py
"""

import os
import logging
import time
from pathlib import Path

import pandas as pd
import pyarrow as pa
import databricks.sql as dbsql
import snowflake.connector
from snowflake.connector.pandas_tools import write_pandas
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

CHUNK_SIZE = 500_000


def _load_env():
    env = os.getenv("ENV", "dev")
    env_file = f".env.{env}"
    if Path(env_file).exists():
        load_dotenv(env_file)
    elif Path(".env").exists():
        load_dotenv(".env")
    return env


def _databricks_conn():
    return dbsql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=os.environ["DATABRICKS_TOKEN"],
    )


def _snowflake_conn(schema: str):
    return snowflake.connector.connect(
        account=os.environ["SNOWFLAKE_ACCOUNT"],
        user=os.environ["SNOWFLAKE_USER"],
        password=os.environ["SNOWFLAKE_PASSWORD"],
        database=os.environ["SNOWFLAKE_DATABASE"],
        schema=schema,
        warehouse=os.environ["SNOWFLAKE_WAREHOUSE"],
        role=os.environ.get("SNOWFLAKE_ROLE", "SYSADMIN"),
    )


def _create_snowflake_tables(sf_conn, schema: str):
    cur = sf_conn.cursor()
    cur.execute(f"CREATE SCHEMA IF NOT EXISTS {schema}")

    cur.execute(f"""
    CREATE TABLE IF NOT EXISTS {schema}.TRANSACTIONS (
        transaction_id          VARCHAR,
        step                    INTEGER,
        type                    VARCHAR,
        amount                  DOUBLE,
        sender_id               VARCHAR,
        receiver_id             VARCHAR,
        sender_balance_before   DOUBLE,
        sender_balance_after    DOUBLE,
        receiver_balance_before DOUBLE,
        receiver_balance_after  DOUBLE,
        is_fraud                INTEGER,
        is_flagged_fraud        INTEGER,
        transaction_day         INTEGER,
        transaction_hour        INTEGER,
        transaction_datetime    TIMESTAMP_NTZ,
        is_merchant_dest        INTEGER,
        balance_drain_pct       DOUBLE,
        is_zero_out             INTEGER,
        balance_disc_orig       DOUBLE,
        balance_disc_dest       DOUBLE,
        flagged_fraud_discrepancy INTEGER,
        dq_flag                 INTEGER,
        ingestion_ts            TIMESTAMP_NTZ,
        batch_id                VARCHAR
    )
    """)
    cur.execute(f"TRUNCATE TABLE IF EXISTS {schema}.TRANSACTIONS")
    log.info(f"[Snowflake] {schema}.TRANSACTIONS ready (truncated)")

    cur.execute(f"""
    CREATE TABLE IF NOT EXISTS {schema}.CUSTOMER_DAILY_BALANCE (
        customer_id              VARCHAR,
        balance_date             DATE,
        daily_sent_amount        DOUBLE,
        daily_received_amount    DOUBLE,
        daily_txn_count          BIGINT,
        daily_fraud_count        BIGINT,
        daily_zero_out_count     BIGINT,
        max_daily_drain_pct      DOUBLE,
        running_txn_total        BIGINT,
        running_fraud_total      BIGINT,
        running_fraud_amount     DOUBLE,
        running_sent_total       DOUBLE,
        is_high_risk_today       INTEGER,
        ingestion_ts             TIMESTAMP_NTZ,
        batch_id                 VARCHAR
    )
    """)
    cur.execute(f"TRUNCATE TABLE IF EXISTS {schema}.CUSTOMER_DAILY_BALANCE")
    log.info(f"[Snowflake] {schema}.CUSTOMER_DAILY_BALANCE ready (truncated)")
    cur.close()


def _stream_to_snowflake(databricks_table: str, sf_conn, sf_table: str, total_rows: int):
    """Stream Databricks Delta table → Snowflake via Arrow batch + write_pandas()."""
    start = time.time()
    loaded = 0
    chunk_num = 0

    with _databricks_conn() as db_conn:
        with db_conn.cursor() as cur:
            cur.execute(f"SELECT * FROM {databricks_table}")

            while True:
                arrow_batch = cur.fetchmany_arrow(CHUNK_SIZE)
                if arrow_batch is None or arrow_batch.num_rows == 0:
                    break

                df = arrow_batch.to_pandas()
                # Uppercase column names — Snowflake default is uppercase
                df.columns = [c.upper() for c in df.columns]

                is_first = chunk_num == 0
                success, n_chunks, n_rows, _ = write_pandas(
                    conn=sf_conn,
                    df=df,
                    table_name=sf_table,
                    overwrite=False,
                    auto_create_table=False,
                    quote_identifiers=False,
                )

                loaded += len(df)
                chunk_num += 1
                elapsed = time.time() - start
                pct = loaded / total_rows * 100 if total_rows > 0 else 0
                log.info(
                    f"[{sf_table}] chunk {chunk_num}: {len(df):,} rows | "
                    f"total={loaded:,}/{total_rows:,} ({pct:.1f}%) | {elapsed:.0f}s"
                )

    elapsed = time.time() - start
    log.info(f"[{sf_table}] Complete — {loaded:,} rows in {elapsed:.0f}s ({loaded/elapsed:.0f} rows/s)")
    return loaded


def run():
    env = _load_env()
    schema = os.environ.get(f"SNOWFLAKE_SCHEMA_{env.upper()}", env.upper())

    log.info(f"=== Databricks → Snowflake | env={env} | schema={schema} ===")

    sf_conn = _snowflake_conn(schema)

    try:
        _create_snowflake_tables(sf_conn, schema)

        # Row counts for progress tracking
        with _databricks_conn() as db_conn:
            with db_conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) FROM paysim_fraud.silver.transactions")
                txn_total = cur.fetchone()[0]
                cur.execute("SELECT COUNT(*) FROM paysim_fraud.silver.customer_daily_balance")
                cumul_total = cur.fetchone()[0]

        log.info(f"[Databricks] transactions: {txn_total:,} | customer_daily_balance: {cumul_total:,}")

        # Stream transactions
        log.info("=== Streaming silver.transactions → Snowflake STAGING.TRANSACTIONS ===")
        txn_loaded = _stream_to_snowflake(
            "paysim_fraud.silver.transactions",
            sf_conn, "TRANSACTIONS", txn_total
        )

        # Stream cumulative
        log.info("=== Streaming silver.customer_daily_balance → Snowflake STAGING.CUSTOMER_DAILY_BALANCE ===")
        cumul_loaded = _stream_to_snowflake(
            "paysim_fraud.silver.customer_daily_balance",
            sf_conn, "CUSTOMER_DAILY_BALANCE", cumul_total
        )

        # Suspend warehouse
        cur = sf_conn.cursor()
        warehouse = os.environ.get("SNOWFLAKE_WAREHOUSE", "COMPUTE_WH")
        cur.execute(f"ALTER WAREHOUSE {warehouse} SUSPEND")
        log.info(f"[Snowflake] Warehouse {warehouse} suspended")
        cur.close()

        log.info("=" * 60)
        log.info("✅ Databricks → Snowflake complete")
        log.info(f"   TRANSACTIONS          : {txn_loaded:,} rows")
        log.info(f"   CUSTOMER_DAILY_BALANCE: {cumul_loaded:,} rows")
        log.info("=" * 60)

        return {
            "status": "success",
            "txn_loaded": txn_loaded,
            "cumul_loaded": cumul_loaded,
        }

    finally:
        sf_conn.close()


if __name__ == "__main__":
    result = run()
    print(f"\nResult: {result}")
