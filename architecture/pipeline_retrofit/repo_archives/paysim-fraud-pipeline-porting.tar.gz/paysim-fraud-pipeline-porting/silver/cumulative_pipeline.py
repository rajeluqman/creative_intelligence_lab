"""
Cumulative table pipeline: silver.transactions → silver.customer_daily_balance
Pattern : Delta Lake MERGE per simulated day (PIPELINE_SPEC §Silver §customer_daily_balance)

Idempotency guarantee:
  running_* totals computed from yesterday_row (NOT from the MATCHED row).
  If MERGE runs twice for same day → same yesterday_row → same absolute values → no double-count.

Gap-day behaviour:
  No transactions on a given day → no row inserted. Running totals carry from last active day.

VACUUM: run try/finally after all MERGEs. Without VACUUM, 31 daily Delta versions → ~7.75GB S3.

Checkpoint (staging/prod only):
  After each day's MERGE, write checkpoint.json to S3. On retry, resume from checkpoint.
  Dev: no checkpoint (1000 rows, single run).
"""

import os
import json
import logging
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv

log = logging.getLogger(__name__)


def _load_env():
    env = os.getenv("ENV", "dev")
    env_file = f".env.{env}"
    if Path(env_file).exists():
        load_dotenv(env_file)
    elif Path(".env").exists():
        load_dotenv(".env")
    return env


def _get_spark(env: str):
    from pyspark.sql import SparkSession
    from delta import configure_spark_with_delta_pip

    builder = (
        SparkSession.builder
        .appName("paysim-silver-cumulative-merge")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .master("local[*]")
    )

    if env in ("staging", "prod"):
        aws_key = os.getenv("AWS_ACCESS_KEY_ID", "")
        aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY", "")
        region = os.getenv("AWS_REGION", "ap-southeast-1")
        builder = (
            builder
            .config("spark.hadoop.fs.s3a.access.key", aws_key)
            .config("spark.hadoop.fs.s3a.secret.key", aws_secret)
            .config("spark.hadoop.fs.s3a.endpoint", f"s3.{region}.amazonaws.com")
            .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        )

    return configure_spark_with_delta_pip(builder).getOrCreate()


def _get_paths(env: str) -> tuple[str, str, str]:
    if env == "dev":
        return (
            "data/silver/transactions",
            "data/silver/customer_daily_balance",
            None,  # no checkpoint in dev
        )
    bucket = os.getenv(f"S3_BUCKET_{env.upper()}")
    if not bucket:
        raise EnvironmentError(f"S3_BUCKET_{env.upper()} not set in env")
    return (
        f"s3a://{bucket}/silver/transactions",
        f"s3a://{bucket}/silver/customer_daily_balance",
        f"s3a://{bucket}/checkpoints/silver_merge_checkpoint.json",
    )


def _read_checkpoint(spark, checkpoint_path: str | None) -> int:
    """Return last completed day from checkpoint. Returns 0 if no checkpoint."""
    if not checkpoint_path:
        return 0
    try:
        content = spark.sparkContext.textFile(checkpoint_path).collect()
        data = json.loads("\n".join(content))
        last_day = int(data.get("last_completed_day", 0))
        log.info(f"[Cumulative] Checkpoint found — resuming from day {last_day + 1}")
        return last_day
    except Exception as e:
        log.warning(f"[Cumulative] Checkpoint read failed ({e}). Starting from day 1.")
        # DO NOT default to 0 silently in staging/prod — raise to prevent data loss
        raise RuntimeError(
            f"Checkpoint at {checkpoint_path} unreadable — manual investigation required. "
            "Do not restart from Day 1 without verifying last completed day."
        ) from e


def _write_checkpoint(spark, checkpoint_path: str | None, day: int, batch_id: str):
    if not checkpoint_path:
        return
    data = {
        "last_completed_day": day,
        "session_id": batch_id,
        "timestamp": datetime.utcnow().isoformat(),
    }
    # Write via boto3 (simpler than Spark for single small JSON)
    import boto3
    import re
    match = re.match(r"s3a://([^/]+)/(.+)", checkpoint_path)
    if not match:
        return
    bucket, key = match.group(1), match.group(2)
    boto3.client("s3").put_object(
        Bucket=bucket, Key=key, Body=json.dumps(data).encode()
    )
    log.info(f"[Cumulative] Checkpoint written — day {day}")


def _build_daily_summary(silver_df, day: int):
    """Aggregate silver.transactions for a single simulated day."""
    from pyspark.sql import functions as F

    return (
        silver_df
        .filter(F.col("transaction_day") == day)
        .groupBy("sender_id", "transaction_day")
        .agg(
            F.sum("amount").alias("daily_sent_amount"),
            # incoming: amount where current customer is the receiver (customer dest only)
            F.sum(
                F.when((F.col("receiver_id") == F.col("sender_id")) & (F.col("is_merchant_dest") == 0),
                       F.col("amount")).otherwise(F.lit(0.0))
            ).alias("daily_received_amount"),
            F.count("*").alias("daily_txn_count"),
            F.sum("is_fraud").alias("daily_fraud_count"),
            F.sum("is_zero_out").alias("daily_zero_out_count"),
            F.max("balance_drain_pct").alias("max_daily_drain_pct"),
        )
        .withColumn("balance_date", F.to_date(
            F.expr(f"TIMESTAMP('2024-01-01') + MAKE_INTERVAL(0,0,{day - 1},0,0,0,0)")
        ))
    )


def _merge_day(spark, cumulative_path: str, daily_df, batch_id: str, ingestion_ts):
    """Delta Lake MERGE for one day's data into customer_daily_balance."""
    from delta.tables import DeltaTable
    from pyspark.sql import functions as F

    daily_df = daily_df.withColumn("ingestion_ts", F.lit(ingestion_ts)).withColumn("batch_id", F.lit(batch_id))
    daily_df.createOrReplaceTempView("_daily_summary")

    # Check if target table exists yet
    target_exists = Path(cumulative_path).exists() if cumulative_path.startswith("data/") else True

    if not target_exists or not _delta_table_has_data(spark, cumulative_path):
        # First day — no MERGE needed, INSERT directly with running_ = daily_ values
        first_day_df = daily_df.select(
            F.col("sender_id").alias("customer_id"),
            F.col("balance_date"),
            F.col("daily_sent_amount"),
            F.col("daily_received_amount"),
            F.col("daily_txn_count"),
            F.col("daily_fraud_count"),
            F.col("daily_zero_out_count"),
            F.col("max_daily_drain_pct"),
            F.col("daily_txn_count").cast("bigint").alias("running_txn_total"),
            F.col("daily_fraud_count").alias("running_fraud_total"),
            F.col("daily_sent_amount").alias("running_fraud_amount"),
            F.col("daily_sent_amount").alias("running_sent_total"),
            F.when(
                (F.col("daily_zero_out_count") > 0) | (F.col("max_daily_drain_pct") > 95),
                F.lit(1)
            ).otherwise(F.lit(0)).alias("is_high_risk_today"),
            F.col("ingestion_ts"),
            F.col("batch_id"),
        )
        first_day_df.write.format("delta").mode("overwrite").partitionBy("balance_date").save(cumulative_path)
        return

    delta_table = DeltaTable.forPath(spark, cumulative_path)

    # yesterday_row — used for idempotent running total computation
    yesterday_df = (
        delta_table.toDF()
        .join(
            daily_df.select("sender_id", "balance_date"),
            (delta_table.toDF()["customer_id"] == daily_df["sender_id"]) &
            (delta_table.toDF()["balance_date"] == F.date_sub(daily_df["balance_date"], 1)),
            "right"
        )
        .select(
            daily_df["sender_id"],
            delta_table.toDF()["running_txn_total"].alias("prev_running_txn_total"),
            delta_table.toDF()["running_fraud_total"].alias("prev_running_fraud_total"),
            delta_table.toDF()["running_fraud_amount"].alias("prev_running_fraud_amount"),
            delta_table.toDF()["running_sent_total"].alias("prev_running_sent_total"),
        )
    )

    # Enrich daily_df with yesterday running totals
    enriched = (
        daily_df.alias("new")
        .join(yesterday_df.alias("prev"), "sender_id", "left")
        .select(
            F.col("new.sender_id").alias("customer_id"),
            F.col("new.balance_date"),
            F.col("new.daily_sent_amount"),
            F.col("new.daily_received_amount"),
            F.col("new.daily_txn_count"),
            F.col("new.daily_fraud_count"),
            F.col("new.daily_zero_out_count"),
            F.col("new.max_daily_drain_pct"),
            # running totals = yesterday_row + today (absolute, idempotent)
            (F.coalesce(F.col("prev.prev_running_txn_total"), F.lit(0)) +
             F.col("new.daily_txn_count")).cast("bigint").alias("running_txn_total"),
            (F.coalesce(F.col("prev.prev_running_fraud_total"), F.lit(0)) +
             F.col("new.daily_fraud_count")).alias("running_fraud_total"),
            (F.coalesce(F.col("prev.prev_running_fraud_amount"), F.lit(0.0)) +
             F.col("new.daily_sent_amount")).alias("running_fraud_amount"),
            (F.coalesce(F.col("prev.prev_running_sent_total"), F.lit(0.0)) +
             F.col("new.daily_sent_amount")).alias("running_sent_total"),
            F.when(
                (F.col("new.daily_zero_out_count") > 0) | (F.col("new.max_daily_drain_pct") > 95),
                F.lit(1)
            ).otherwise(F.lit(0)).alias("is_high_risk_today"),
            F.col("new.ingestion_ts"),
            F.col("new.batch_id"),
        )
    )

    (
        delta_table.alias("target")
        .merge(
            enriched.alias("src"),
            "target.customer_id = src.customer_id AND target.balance_date = src.balance_date"
        )
        .whenMatchedUpdate(set={
            "daily_sent_amount":    "src.daily_sent_amount",
            "daily_received_amount": "src.daily_received_amount",
            "daily_txn_count":      "src.daily_txn_count",
            "daily_fraud_count":    "src.daily_fraud_count",
            "daily_zero_out_count": "src.daily_zero_out_count",
            "max_daily_drain_pct":  "src.max_daily_drain_pct",
            "running_txn_total":    "src.running_txn_total",
            "running_fraud_total":  "src.running_fraud_total",
            "running_fraud_amount": "src.running_fraud_amount",
            "running_sent_total":   "src.running_sent_total",
            "is_high_risk_today":   "src.is_high_risk_today",
            "ingestion_ts":         "src.ingestion_ts",
            "batch_id":             "src.batch_id",
        })
        .whenNotMatchedInsertAll()
        .execute()
    )


def _delta_table_has_data(spark, path: str) -> bool:
    try:
        return spark.read.format("delta").load(path).limit(1).count() > 0
    except Exception:
        return False


def run():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    env = _load_env()
    batch_id = os.getenv("AIRFLOW_CTX_DAG_RUN_ID",
                         datetime.utcnow().strftime("manual_%Y%m%d_%H%M%S"))
    ingestion_ts = datetime.utcnow().isoformat()

    silver_path, cumulative_path, checkpoint_path = _get_paths(env)
    log.info(f"[Cumulative] env={env} | silver={silver_path} | output={cumulative_path}")

    spark = _get_spark(env)
    spark.sparkContext.setLogLevel("WARN")

    try:
        silver_df = spark.read.format("delta").load(silver_path)
        silver_df.cache()

        days = sorted([
            row["transaction_day"]
            for row in silver_df.select("transaction_day").distinct().collect()
        ])
        log.info(f"[Cumulative] Days to process: {days}")

        # Checkpoint — skip already-processed days (staging/prod only)
        last_completed = 0
        if env != "dev" and checkpoint_path:
            last_completed = _read_checkpoint(spark, checkpoint_path)

        merged_count = 0
        for day in days:
            if day <= last_completed:
                log.info(f"[Cumulative] Day {day} already processed — skip")
                continue

            log.info(f"[Cumulative] Processing day {day}...")
            daily_df = _build_daily_summary(silver_df, day)
            _merge_day(spark, cumulative_path, daily_df, batch_id, ingestion_ts)
            merged_count += 1

            if env != "dev" and checkpoint_path:
                _write_checkpoint(spark, checkpoint_path, day, batch_id)

        silver_df.unpersist()
        spark.catalog.clearCache()

        # VACUUM — mandatory to prevent S3 5GB breach (try/finally: run even if MERGE had issues)
        try:
            from delta.tables import DeltaTable
            log.info("[Cumulative] Running VACUUM RETAIN 7 DAYS...")
            DeltaTable.forPath(spark, cumulative_path).vacuum(retentionHours=168)
            log.info("[Cumulative] VACUUM complete")
        except Exception as vacuum_err:
            log.error(f"[Cumulative] VACUUM failed — CRITICAL, S3 breach risk: {vacuum_err}")

        total_rows = spark.read.format("delta").load(cumulative_path).count()
        log.info(f"[Cumulative] Total cumulative rows: {total_rows:,} | Days merged: {merged_count}")

        return {"status": "success", "days_merged": merged_count, "total_rows": total_rows}

    finally:
        spark.stop()


if __name__ == "__main__":
    result = run()
    print(f"\nCumulative MERGE complete: {result}")
