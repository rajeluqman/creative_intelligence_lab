"""
Silver GX validation suite — runs selepas Silver transform, sebelum Gold.
Suite: silver_suite

Rules (DQD §Silver Suite):
  - transaction_id NOT NULL, UNIQUE
  - sender_id NOT NULL, regex ^C[0-9]+$
  - receiver_id NOT NULL, regex ^[CM][0-9]+$
  - type IN valid types
  - amount > 0
  - transaction_day BETWEEN 1 AND 31
  - is_fraud IN (0, 1)
  - is_flagged_fraud IN (0, 1)
  - flagged_fraud_discrepancy IN (0, 1)
  - RULE 1 cross-type: COUNT(is_fraud=1 WHERE type NOT IN fraud-eligible) = 0  → CRITICAL, block Gold
  - balance_drain_pct >= 0 OR NULL (flag > 200% as HIGH)
  - dq_flag BETWEEN 0 AND 15, NOT NULL
  - fraud_rate_actual BETWEEN 0.10% AND 0.20% (staging/prod full only — HIGH alert only)
  - row_count vs Bronze >= 99%
  - receiver_balance_before IS NULL WHERE is_merchant_dest=1
"""

import os
import logging
from pathlib import Path
from dotenv import load_dotenv

log = logging.getLogger(__name__)

VALID_TYPES = ["CASH-IN", "CASH-OUT", "DEBIT", "PAYMENT", "TRANSFER"]
FRAUD_ELIGIBLE_TYPES = ["TRANSFER", "CASH-OUT"]
FRAUD_RATE_LOW = 0.10
FRAUD_RATE_HIGH = 0.20


def _load_env():
    env = os.getenv("ENV", "dev")
    env_file = f".env.{env}"
    if Path(env_file).exists():
        load_dotenv(env_file)
    elif Path(".env").exists():
        load_dotenv(".env")
    return env


def _get_paths(env: str) -> tuple[str, str]:
    if env == "dev":
        return "data/silver/transactions", "data/bronze/transactions"
    bucket = os.getenv(f"S3_BUCKET_{env.upper()}")
    if not bucket:
        raise EnvironmentError(f"S3_BUCKET_{env.upper()} not set")
    return f"s3a://{bucket}/silver/transactions", f"s3a://{bucket}/bronze/transactions"


def _get_spark(env: str):
    from pyspark.sql import SparkSession
    from delta import configure_spark_with_delta_pip

    builder = (
        SparkSession.builder
        .appName("paysim-silver-gx")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .master("local[*]")
    )
    if env in ("staging", "prod"):
        builder = builder \
            .config("spark.hadoop.fs.s3a.access.key", os.getenv("AWS_ACCESS_KEY_ID", "")) \
            .config("spark.hadoop.fs.s3a.secret.key", os.getenv("AWS_SECRET_ACCESS_KEY", "")) \
            .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")

    return configure_spark_with_delta_pip(builder).getOrCreate()


def run_suite(df, bronze_count: int, env: str) -> dict:
    """Run Silver validation rules. Raises RuntimeError on CRITICAL failure."""
    from pyspark.sql import functions as F

    failures = []
    warnings = []
    results = {}

    total_rows = df.count()
    results["total_rows"] = total_rows

    # transaction_id NOT NULL + UNIQUE
    null_txn_id = df.filter(F.col("transaction_id").isNull()).count()
    if null_txn_id > 0:
        failures.append(f"TRANSACTION_ID NULL: {null_txn_id:,} rows — CRITICAL")
    dup_txn_id = total_rows - df.select("transaction_id").distinct().count()
    if dup_txn_id > 0:
        failures.append(f"TRANSACTION_ID DUPLICATE: {dup_txn_id:,} duplicates — CRITICAL")
    results["transaction_id_not_null"] = "PASS" if null_txn_id == 0 else "FAIL"
    results["transaction_id_unique"] = "PASS" if dup_txn_id == 0 else "FAIL"

    # sender_id NOT NULL, regex ^C[0-9]+$
    bad_sender = df.filter(
        F.col("sender_id").isNull() | ~F.col("sender_id").rlike(r"^C[0-9]+$")
    ).count()
    if bad_sender > 0:
        failures.append(f"SENDER_ID: {bad_sender:,} null/invalid — CRITICAL")
    results["sender_id_regex"] = "PASS" if bad_sender == 0 else "FAIL"

    # receiver_id NOT NULL, regex ^[CM][0-9]+$
    bad_receiver = df.filter(
        F.col("receiver_id").isNull() | ~F.col("receiver_id").rlike(r"^[CM][0-9]+$")
    ).count()
    if bad_receiver > 0:
        failures.append(f"RECEIVER_ID: {bad_receiver:,} null/invalid — CRITICAL")
    results["receiver_id_regex"] = "PASS" if bad_receiver == 0 else "FAIL"

    # type IN valid list
    bad_type = df.filter(~F.col("type").isin(VALID_TYPES)).count()
    if bad_type > 0:
        failures.append(f"TYPE: {bad_type:,} invalid — CRITICAL")
    results["type_values"] = "PASS" if bad_type == 0 else "FAIL"

    # amount > 0
    bad_amount = df.filter(~(F.col("amount") > 0)).count()
    if bad_amount > 0:
        failures.append(f"AMOUNT: {bad_amount:,} not > 0 — CRITICAL")
    results["amount_positive"] = "PASS" if bad_amount == 0 else "FAIL"

    # transaction_day BETWEEN 1 AND 31
    bad_day = df.filter(~F.col("transaction_day").between(1, 31)).count()
    if bad_day > 0:
        failures.append(f"TRANSACTION_DAY: {bad_day:,} outside 1–31 — CRITICAL")
    results["transaction_day_range"] = "PASS" if bad_day == 0 else "FAIL"

    # is_fraud IN (0, 1)
    bad_fraud = df.filter(~F.col("is_fraud").isin(0, 1)).count()
    if bad_fraud > 0:
        failures.append(f"IS_FRAUD: {bad_fraud:,} not in (0,1) — CRITICAL")
    results["is_fraud_values"] = "PASS" if bad_fraud == 0 else "FAIL"

    # is_flagged_fraud IN (0, 1)
    bad_flagged = df.filter(~F.col("is_flagged_fraud").isin(0, 1)).count()
    if bad_flagged > 0:
        failures.append(f"IS_FLAGGED_FRAUD: {bad_flagged:,} not in (0,1) — CRITICAL")
    results["is_flagged_fraud_values"] = "PASS" if bad_flagged == 0 else "FAIL"

    # flagged_fraud_discrepancy IN (0, 1)
    bad_disc = df.filter(~F.col("flagged_fraud_discrepancy").isin(0, 1)).count()
    if bad_disc > 0:
        failures.append(f"FLAGGED_DISCREPANCY: {bad_disc:,} not in (0,1) — CRITICAL")
    results["flagged_discrepancy_values"] = "PASS" if bad_disc == 0 else "FAIL"

    # RULE 1: is_fraud=1 AND type NOT IN fraud-eligible MUST = 0
    rule1_violations = df.filter(
        (F.col("is_fraud") == 1) & ~F.col("type").isin(FRAUD_ELIGIBLE_TYPES)
    ).count()
    if rule1_violations > 0:
        failures.append(
            f"RULE1 VIOLATION: {rule1_violations:,} fraud txns on non-eligible types — CRITICAL, block Gold"
        )
    results["rule1_type_constraint"] = "PASS" if rule1_violations == 0 else "FAIL"

    # dq_flag BETWEEN 0 AND 15, NOT NULL
    bad_dq = df.filter(F.col("dq_flag").isNull() | ~F.col("dq_flag").between(0, 15)).count()
    if bad_dq > 0:
        failures.append(f"DQ_FLAG: {bad_dq:,} null or out-of-range — CRITICAL")
    results["dq_flag_range"] = "PASS" if bad_dq == 0 else "FAIL"

    # receiver_balance_before IS NULL WHERE is_merchant_dest=1
    bad_merchant_bal = df.filter(
        (F.col("is_merchant_dest") == 1) & F.col("receiver_balance_before").isNotNull()
    ).count()
    if bad_merchant_bal > 0:
        warnings.append(
            f"MERCHANT_BALANCE: {bad_merchant_bal:,} merchant rows have non-NULL receiver_balance_before — MEDIUM"
        )
    results["merchant_balance_null"] = "PASS" if bad_merchant_bal == 0 else "WARN"

    # balance_drain_pct >= 0 or NULL (flag if > 200%)
    drain_over_200 = df.filter(F.col("balance_drain_pct") > 200).count()
    if drain_over_200 > 0:
        warnings.append(
            f"DRAIN_PCT: {drain_over_200:,} rows with balance_drain_pct > 200% — HIGH, review"
        )
    results["drain_pct_range"] = "PASS" if drain_over_200 == 0 else "WARN"

    # row_count vs Bronze >= 99%
    retention_pct = total_rows / bronze_count * 100 if bronze_count > 0 else 0
    if retention_pct < 99.0:
        failures.append(
            f"ROW_COUNT vs BRONZE: {retention_pct:.2f}% < 99% threshold — CRITICAL, block Gold"
        )
    results["row_count_vs_bronze"] = "PASS" if retention_pct >= 99.0 else "FAIL"
    results["retention_pct"] = round(retention_pct, 4)

    # fraud_rate_actual (staging/prod full dataset only — skip dev 1000-row mode)
    if env != "dev":
        fraud_count = df.filter(F.col("is_fraud") == 1).count()
        fraud_rate = fraud_count / total_rows * 100 if total_rows > 0 else 0
        results["fraud_rate_pct"] = round(fraud_rate, 4)
        if not (FRAUD_RATE_LOW <= fraud_rate <= FRAUD_RATE_HIGH):
            warnings.append(
                f"FRAUD_RATE: {fraud_rate:.4f}% outside expected 0.10%–0.20% range — HIGH alert"
            )
        results["fraud_rate_check"] = (
            "PASS" if FRAUD_RATE_LOW <= fraud_rate <= FRAUD_RATE_HIGH else "WARN"
        )

    # Summary
    pass_count = sum(1 for v in results.values() if v == "PASS")
    total_checks = sum(1 for v in results.values() if v in ("PASS", "FAIL", "WARN"))
    results["summary"] = f"{pass_count}/{total_checks} checks passed"
    results["status"] = "PASS" if not failures else "FAIL"
    results["failures"] = failures
    results["warnings"] = warnings

    for w in warnings:
        log.warning(f"[Silver GX] ⚠ {w}")

    if failures:
        log.error(f"[Silver GX] SUITE FAIL — {len(failures)} CRITICAL failures:")
        for f in failures:
            log.error(f"  ✗ {f}")
        raise RuntimeError(
            f"Silver GX suite FAILED — {len(failures)} CRITICAL checks. Gold blocked.\n"
            + "\n".join(failures)
        )

    log.info(f"[Silver GX] SUITE PASS — {results['summary']}")
    return results


def run():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    env = _load_env()
    silver_path, bronze_path = _get_paths(env)
    log.info(f"[Silver GX] env={env} | silver={silver_path}")

    spark = _get_spark(env)
    spark.sparkContext.setLogLevel("WARN")

    try:
        silver_df = spark.read.format("delta").load(silver_path)
        bronze_count = spark.read.format("delta").load(bronze_path).count()

        results = run_suite(silver_df, bronze_count, env)
        log.info(f"[Silver GX] Results: {results}")
        return results
    finally:
        spark.stop()


if __name__ == "__main__":
    result = run()
    print(f"\nSilver GX: {result['status']} — {result['summary']}")
