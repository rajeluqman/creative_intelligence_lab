"""
Bronze GX validation suite — runs sebelum Silver.
Suite: bronze_suite

Rules (DQD §Bronze Suite):
  - row_count  : Source CSV count = Bronze Delta count (exact)
  - ingestion_ts NOT NULL
  - step BETWEEN 1 AND 744
  - type IN (CASH-IN, CASH-OUT, DEBIT, PAYMENT, TRANSFER)
  - amount > 0
  - nameOrig NOT NULL, regex ^C[0-9]+$
  - nameDest NOT NULL, regex ^[CM][0-9]+$
  - oldbalanceOrg >= 0
  - newbalanceOrig >= 0
  - isFraud IN (0, 1)
  - isFlaggedFraud IN (0, 1)

Severity: All CRITICAL — failure blocks Silver.
"""

import os
import logging
from pathlib import Path
from dotenv import load_dotenv

log = logging.getLogger(__name__)

# Source dataset uses CASH_IN/CASH_OUT (underscore). Bronze validates raw source format.
# Silver normalizes to CASH-IN/CASH-OUT (hyphen) per documented schema.
VALID_TYPES = ["CASH-IN", "CASH-OUT", "CASH_IN", "CASH_OUT", "DEBIT", "PAYMENT", "TRANSFER"]


def _load_env():
    env = os.getenv("ENV", "dev")
    env_file = f".env.{env}"
    if Path(env_file).exists():
        load_dotenv(env_file)
    elif Path(".env").exists():
        load_dotenv(".env")
    return env


def _get_bronze_path(env: str) -> str:
    if env == "dev":
        return "data/bronze/transactions"
    bucket = os.getenv(f"S3_BUCKET_{env.upper()}")
    if not bucket:
        raise EnvironmentError(f"S3_BUCKET_{env.upper()} not set")
    return f"s3a://{bucket}/bronze/transactions"


def _get_spark(env: str):
    from pyspark.sql import SparkSession
    from delta import configure_spark_with_delta_pip

    builder = (
        SparkSession.builder
        .appName("paysim-bronze-gx")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .master("local[*]")
    )
    if env in ("staging", "prod"):
        builder = builder \
            .config("spark.hadoop.fs.s3a.access.key", os.getenv("AWS_ACCESS_KEY_ID", "")) \
            .config("spark.hadoop.fs.s3a.secret.key", os.getenv("AWS_SECRET_ACCESS_KEY", "")) \
            .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")

    return configure_spark_with_delta_pip(builder).getOrCreate()


def run_suite(df, source_count: int | None = None) -> dict:
    """
    Run Bronze validation rules. Returns result dict with pass/fail per check.
    Raises RuntimeError on any CRITICAL failure — blocks Silver.
    """
    from pyspark.sql import functions as F

    failures = []
    results = {}

    total_rows = df.count()
    results["total_rows"] = total_rows

    # Row count check (only if source_count provided)
    if source_count is not None:
        if total_rows != source_count:
            failures.append(
                f"ROW_COUNT: Bronze {total_rows:,} ≠ Source {source_count:,} — exact match required"
            )
        results["row_count_check"] = "PASS" if total_rows == source_count else "FAIL"

    # ingestion_ts NOT NULL
    null_ts = df.filter(F.col("ingestion_ts").isNull()).count()
    if null_ts > 0:
        failures.append(f"INGESTION_TS: {null_ts:,} NULL values — CRITICAL")
    results["ingestion_ts_not_null"] = "PASS" if null_ts == 0 else "FAIL"

    # step BETWEEN 1 AND 744
    bad_step = df.filter(~F.col("step").between(1, 744)).count()
    if bad_step > 0:
        failures.append(f"STEP: {bad_step:,} rows outside 1–744 range — CRITICAL")
    results["step_range"] = "PASS" if bad_step == 0 else "FAIL"

    # type IN valid list
    bad_type = df.filter(~F.col("type").isin(VALID_TYPES)).count()
    if bad_type > 0:
        failures.append(f"TYPE: {bad_type:,} invalid values — CRITICAL")
    results["type_values"] = "PASS" if bad_type == 0 else "FAIL"

    # amount > 0
    bad_amount = df.filter(~(F.col("amount").cast("double") > 0)).count()
    if bad_amount > 0:
        failures.append(f"AMOUNT: {bad_amount:,} rows not > 0 — CRITICAL")
    results["amount_positive"] = "PASS" if bad_amount == 0 else "FAIL"

    # nameOrig NOT NULL, regex ^C[0-9]+$
    bad_orig = df.filter(
        F.col("nameOrig").isNull() | ~F.col("nameOrig").rlike(r"^C[0-9]+$")
    ).count()
    if bad_orig > 0:
        failures.append(f"NAMEORIG: {bad_orig:,} rows null or invalid prefix — CRITICAL")
    results["nameOrig_regex"] = "PASS" if bad_orig == 0 else "FAIL"

    # nameDest NOT NULL, regex ^[CM][0-9]+$
    bad_dest = df.filter(
        F.col("nameDest").isNull() | ~F.col("nameDest").rlike(r"^[CM][0-9]+$")
    ).count()
    if bad_dest > 0:
        failures.append(f"NAMEDEST: {bad_dest:,} rows null or invalid prefix — CRITICAL")
    results["nameDest_regex"] = "PASS" if bad_dest == 0 else "FAIL"

    # oldbalanceOrg >= 0
    bad_bal_orig = df.filter(F.col("oldbalanceOrg").cast("double") < 0).count()
    if bad_bal_orig > 0:
        failures.append(f"OLDBALANCEORG: {bad_bal_orig:,} rows negative — CRITICAL")
    results["oldbalanceOrg_nonneg"] = "PASS" if bad_bal_orig == 0 else "FAIL"

    # newbalanceOrig >= 0
    bad_new_orig = df.filter(F.col("newbalanceOrig").cast("double") < 0).count()
    if bad_new_orig > 0:
        failures.append(f"NEWBALANCEORIG: {bad_new_orig:,} rows negative — CRITICAL")
    results["newbalanceOrig_nonneg"] = "PASS" if bad_new_orig == 0 else "FAIL"

    # isFraud IN (0, 1)
    bad_fraud = df.filter(~F.col("isFraud").cast("int").isin(0, 1)).count()
    if bad_fraud > 0:
        failures.append(f"ISFRAUD: {bad_fraud:,} rows not in (0,1) — CRITICAL")
    results["isFraud_values"] = "PASS" if bad_fraud == 0 else "FAIL"

    # isFlaggedFraud IN (0, 1)
    bad_flagged = df.filter(~F.col("isFlaggedFraud").cast("int").isin(0, 1)).count()
    if bad_flagged > 0:
        failures.append(f"ISFLAGGEDFRAUD: {bad_flagged:,} rows not in (0,1) — CRITICAL")
    results["isFlaggedFraud_values"] = "PASS" if bad_flagged == 0 else "FAIL"

    # Summary
    pass_count = sum(1 for v in results.values() if v == "PASS")
    total_checks = sum(1 for v in results.values() if v in ("PASS", "FAIL"))
    results["summary"] = f"{pass_count}/{total_checks} checks passed"
    results["status"] = "PASS" if not failures else "FAIL"
    results["failures"] = failures

    if failures:
        log.error(f"[Bronze GX] SUITE FAIL — {len(failures)} CRITICAL failures:")
        for f in failures:
            log.error(f"  ✗ {f}")
        raise RuntimeError(
            f"Bronze GX suite FAILED — {len(failures)} CRITICAL checks. Silver blocked.\n"
            + "\n".join(failures)
        )

    log.info(f"[Bronze GX] SUITE PASS — {results['summary']}")
    return results


def run():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    env = _load_env()
    bronze_path = _get_bronze_path(env)
    log.info(f"[Bronze GX] env={env} | path={bronze_path}")

    spark = _get_spark(env)
    spark.sparkContext.setLogLevel("WARN")

    try:
        df = spark.read.format("delta").load(bronze_path)
        results = run_suite(df)
        log.info(f"[Bronze GX] Results: {results}")
        return results
    finally:
        spark.stop()


if __name__ == "__main__":
    result = run()
    print(f"\nBronze GX: {result['status']} — {result['summary']}")
