import os

# PySpark 3.5.x uses Java internal reflection APIs (sun.misc.Unsafe, module access)
# restricted/removed in Java 25. Java 21 LTS is the last version PySpark 3.5.x supports.
# Set JAVA_HOME before any test or PySpark import happens. Owner: DPE.
_java21 = "/usr/local/sdkman/candidates/java/21.0.10-ms"
if os.path.exists(_java21):
    os.environ["JAVA_HOME"] = _java21
