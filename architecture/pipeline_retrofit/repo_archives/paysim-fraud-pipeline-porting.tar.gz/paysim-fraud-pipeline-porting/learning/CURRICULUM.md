# Learning Curriculum — Paysim Fraud Pipeline

> Owned by @cikgu. The learning PATH for this project: each module pairs a concept with the
> real artifact that embodies it, the WHY-before-HOW questions you must answer first, and a DIY
> build task. Teach in order; close each module with a `LEARNING_LOG.md` entry.
> Run @cikgu as a MAIN session (not a subagent) for actual teaching. English-first per CIL's
> ADR-011 addendum (Manglish only if explicitly requested in-session).

**Score:** start 100. Track in `LEARNING_LOG.md`. Hint = -5. < 60 forces a docs break.

| # | Module | You must be able to answer (WHY) | Artifact (read AFTER you've tried) | DIY |
|---|--------|----------------------------------|-------------------------------------|-----|
| **M0** | The domain & the goal | Why is fraud detection on 0.13% of 6.3M rows a class-imbalance problem before it's a modelling problem? What 3 KPIs does the Gold layer need to serve (fraud rate, detection rate, false-positive rate)? | `README.md` "Problem Statement" | — |
| **M1** | Kaggle → S3 landing | Why land the raw 471MB CSV in S3 before any transform? What does the `ENV` (dev/staging/prod) split buy you — why does dev use a 1,000-row sample, not the full file? | `bronze/download_dataset.py`, `docs/ARCHITECTURE.md` "Environments" | explain why dev/staging/prod need different row counts in 3 sentences |
| **M2** | Bronze Delta ingest | Why Delta Lake over a plain Parquet dump for Bronze? What does `transaction_day = CEIL(step/24)` partitioning buy you downstream? | `bronze/bronze_pipeline.py` | trace one CSV row's path from S3 landing to a queryable Bronze Delta row, citing the script |
| **M3** | Silver dq_flag bitmask + RULE 1 | Why a bitmask (not 4 boolean columns) for `dq_flag`? Walk through RULE 1 by reasoning BEFORE reading the code: why must `is_fraud=1` be impossible outside TRANSFER/CASH-OUT, and what does violating it actually mean about your upstream data? | `silver/silver_pipeline.py` (dq_flag bits, RULE 1), `docs/DQD.md` | derive the 4 dq_flag bit meanings from the docstring alone, then check against the real `VALID_TYPES`/`FRAUD_ELIGIBLE_TYPES` constants |
| **M4** | Cumulative table + Delta MERGE | Why is `fact_customer_daily_balance` a SEPARATE grain from `fact_transactions`, not just a GROUP BY view? Walk through the idempotency guarantee by reasoning BEFORE reading the code: if a MERGE for "day 5" runs twice, why don't running totals double? | `silver/cumulative_pipeline.py` `_merge_day`, `docs/ADR/ADR-001-hybrid-paradigm.md` | build the MERGE-from-yesterday's-row pseudocode from scratch DIY, then diff vs the real function |
| **M5** | Silver GX suite + the documented WARN | Why is `merchant_balance_null` a WARN, not a FAIL — what's the actual business reason a merchant-destination row is "supposed" to look different from a customer-destination row? | `data_quality/run_silver_suite.py`, `docs/ADR/ADR-002-silver-warn-acceptance.md` | pick one other Silver check (not RULE 1, not merchant_balance_null) and explain the bad row it's designed to catch |
| **M6** | Bridge to Snowflake — two paths | Why does this repo have TWO bridge methods (S3 Parquet+COPY INTO vs Databricks SQL Warehouse Arrow+`write_pandas()`) but only wire ONE into the DAG? | `silver/export_to_s3_parquet.py`, `silver/databricks_to_snowflake.py`, `airflow/dags/paysim_fraud_pipeline.py` | trace one row's path from Silver Delta to a Snowflake STAGING table via the DAG's actual wired path, citing each script |
| **M7** | dbt Gold — hybrid marts | Why does `mart_customer_risk.sql` ref() `int_cumulative_customer_balance` while `mart_fraud_summary.sql` ref()s `int_transactions_enriched` — what breaks if you swap them? | `docs/ADR/ADR-001-hybrid-paradigm.md`, the `gold/models/` tree | build a synthetic 5-row DIY version of `int_customer_daily_aggregates.sql`'s join logic, diff vs the real model |
| **M8** | Airflow orchestration + Slack | Why ONE chained DAG (bronze → ... → gold_dbt_test) instead of splitting Bronze/Silver/Gold into 3 DAGs? Why does this DAG alert on BOTH success and failure, unlike olist's failure-only pattern — what's different about a fraud pipeline's stakeholder needs? | `airflow/dags/paysim_fraud_pipeline.py` | DIY a parse-clean single-task DAG from scratch with both `on_success_callback`/`on_failure_callback`; verify with DagBag (no import errors) |
| **M9** | CI/CD & static gates | Why does this repo's CI run static gates ($0, no cloud creds) instead of a full Databricks/Snowflake run on every push? What does the identity contract's dual-grain check actually catch that a single-grain check would miss? | `.github/workflows/ci.yml`, `tests/*_contract.py` | DIY: add a new static gate (e.g. assert `mart_customer_risk.sql` never ref()s `int_transactions_enriched` directly) and make it green |
| **M10** | Portfolio framing & resume reconciliation | What makes a hybrid Kimball+Cumulative model distinct in an interview from "just ran dbt on a CSV"? Defend ADR-001 and ADR-002; reconcile the "Silver 14/15" claim honestly. | both ADRs, `INTERVIEW_GUIDE.md` | draft 5 resume bullets → @business-analyst honesty check against `file:line` evidence |

## How a module runs (the ritual)
1. @cikgu poses the WHY questions. You answer from reasoning — NO reading yet.
2. You sketch the solution shape (mental model first, syntax last).
3. THEN you open the artifact and compare to your reasoning.
4. For DIY modules: @cikgu writes a `learning/diy/TICKET_<name>.md`; you build in
   `learning/diy/`; diff vs the real model line-by-line; quiz WHY on every gap.
5. LEARNING_LOG entry + score update.

## Suggested order
M0 → M1 → M2 → M3 → M4 (the resume-proof centerpiece — cumulative MERGE) → M5 → M6 → M7 →
M9 (lock CI early) → M8 → M10.
