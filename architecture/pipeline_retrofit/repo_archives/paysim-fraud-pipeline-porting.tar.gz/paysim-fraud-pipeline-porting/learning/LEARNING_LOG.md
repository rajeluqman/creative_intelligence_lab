# Learning Log — Paysim Fraud Pipeline

> @cikgu's memory + the user's progress record. Newest entries at the TOP.
> On resume, @cikgu reads the last 3 entries + the current module in `CURRICULUM.md`.

**Current score:** 100/100
**Current module:** M0 — not started
**Next step when resuming:** start M0 (the domain & the goal) — `@cikgu teach me Module 0`

---

[2026-06-29 — setup]
Module: —
Concept: Curriculum + cikgu apparatus created for paysim (repo 3 of 4 in the pipeline-retrofit
effort, after home-credit and olist). 11 modules (M0-M10) mapped to real PySpark/Delta/dbt/
Snowflake/Airflow artifacts, with M4 (cumulative MERGE idempotency) as the resume-proof
centerpiece — this is the one concept unique to paysim among the 4 repos.
Hint level: —
Refs: learning/CURRICULUM.md, .claude/agents/cikgu.md
Score impact: 0
Next step when resuming: begin M0. The build artifacts already exist (Phases 0-5 are done,
they are the answer key); the job is to RE-DERIVE them, not read them cold. Start by answering
"why is 0.13% fraud a class-imbalance problem before it's a modelling problem?" before opening
README.md.
