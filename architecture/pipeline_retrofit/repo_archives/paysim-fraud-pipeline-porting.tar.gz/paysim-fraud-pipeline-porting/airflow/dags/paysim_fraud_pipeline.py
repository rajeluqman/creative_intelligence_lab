"""
paysim-fraud-pipeline — Main Pipeline DAG
Domain   : fintech
Dataset  : PaySim1 — 6.3M rows, 11 columns
Modelling: Hybrid — Kimball + Cumulative Table
Grain 1  : 1 row = 1 transaksi (fact_transactions)
Grain 2  : 1 row = 1 customer per hari (fact_customer_daily_balance)
Schedule : @daily (manual trigger untuk demo)
"""

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'raja-luqman',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
}

def slack_success(context):
    SlackWebhookOperator(
        task_id='slack_success',
        slack_webhook_conn_id='slack_webhook',
        message=f"✅ *paysim-fraud-pipeline* — Pipeline success | {context['ds']}",
    ).execute(context)

def slack_failure(context):
    SlackWebhookOperator(
        task_id='slack_failure',
        slack_webhook_conn_id='slack_webhook',
        message=f"❌ *paysim-fraud-pipeline* — FAILED: {context['task_instance'].task_id} | {context['ds']}",
    ).execute(context)

with DAG(
    dag_id='paysim_fraud_pipeline',
    default_args=default_args,
    schedule_interval='@daily',
    catchup=False,
    on_success_callback=slack_success,
    on_failure_callback=slack_failure,
    tags=['fintech', 'fraud', 'hybrid', 'portfolio'],
) as dag:

    # Bronze — raw ingestion dari S3 ke Delta Lake
    bronze = PythonOperator(
        task_id='bronze_ingest',
        python_callable=lambda: __import__('bronze.bronze_pipeline', fromlist=['']).run(),
    )

    # Bronze GX validation
    bronze_dq = PythonOperator(
        task_id='bronze_dq_check',
        python_callable=lambda: __import__('data_quality.run_bronze_suite', fromlist=['']).run(),
    )

    # Silver — PySpark transforms + derived columns + dedup
    silver = PythonOperator(
        task_id='silver_transform',
        python_callable=lambda: __import__('silver.silver_pipeline', fromlist=['']).run(),
    )

    # Silver cumulative table — Delta Lake MERGE
    silver_cumulative = PythonOperator(
        task_id='silver_cumulative_merge',
        python_callable=lambda: __import__('silver.cumulative_pipeline', fromlist=['']).run(),
    )

    # Silver GX validation
    silver_dq = PythonOperator(
        task_id='silver_dq_check',
        python_callable=lambda: __import__('data_quality.run_silver_suite', fromlist=['']).run(),
    )

    # Silver export → S3 Parquet (bridge for Snowflake COPY INTO)
    silver_export = PythonOperator(
        task_id='silver_export_parquet',
        python_callable=lambda: __import__(
            'silver.export_to_s3_parquet', fromlist=['']
        ).export_parquet(),
        retries=1,  # overwrite is idempotent
    )

    # Snowflake COPY INTO from S3 Parquet
    snowflake_copy = PythonOperator(
        task_id='snowflake_copy_into',
        python_callable=lambda: __import__(
            'silver.export_to_s3_parquet', fromlist=['']
        ).copy_into_snowflake(),
    )

    # Gold — dbt run
    gold_run = BashOperator(
        task_id='gold_dbt_run',
        bash_command='dbt run --profiles-dir gold --project-dir gold --target ${ENV:-dev}',
    )

    # Gold — dbt test (FK checks, not_null, unique)
    gold_test = BashOperator(
        task_id='gold_dbt_test',
        bash_command='dbt test --profiles-dir gold --project-dir gold --target ${ENV:-dev}',
    )

    # DAG order — PIPELINE_SPEC §Silver→Snowflake Bridge
    (
        bronze >> bronze_dq
        >> silver >> silver_cumulative >> silver_dq
        >> silver_export >> snowflake_copy
        >> gold_run >> gold_test
    )
