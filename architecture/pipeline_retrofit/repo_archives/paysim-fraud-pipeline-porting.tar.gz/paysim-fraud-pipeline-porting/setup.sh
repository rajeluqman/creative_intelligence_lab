#!/bin/bash
# =============================================================================
# PAYSIM FRAUD PIPELINE — Scaffold v3.0
# Domain   : fintech
# Dataset  : PaySim1 — 6.3M rows, 11 columns
# Problem  : Fraud Intelligence + Account Drain Detection
# Model    : Hybrid — Kimball + Cumulative Table Design
# Cloud    : AWS (S3 + Glue)
# Run      : bash setup.sh
# =============================================================================

PROJECT_NAME="paysim-fraud-pipeline"
DOMAIN="fintech"
DATASET="PaySim1 Financial Transactions"
CLOUD="aws"
MODELLING="Hybrid"
GRAIN_FACT1="1 row = 1 transaksi"
GRAIN_FACT2="1 row = 1 customer per hari"

echo ""
echo "🚀 $PROJECT_NAME — scaffold start"
echo "   Domain    : $DOMAIN"
echo "   Dataset   : $DATASET"
echo "   Cloud     : $CLOUD"
echo "   Modelling : $MODELLING"
echo "   Grain 1   : $GRAIN_FACT1"
echo "   Grain 2   : $GRAIN_FACT2"
echo ""

# =============================================================================
# FOLDERS
# =============================================================================

mkdir -p docs/ADR
mkdir -p docs/screenshots
mkdir -p bronze
mkdir -p silver
mkdir -p gold/dbt_models/staging
mkdir -p gold/dbt_models/intermediate
mkdir -p gold/dbt_models/marts
mkdir -p data_quality/expectations
mkdir -p data_quality/checkpoints
mkdir -p airflow/dags
mkdir -p airflow/plugins
mkdir -p tests/unit
mkdir -p tests/integration
mkdir -p infrastructure/terraform
mkdir -p infrastructure/credentials
mkdir -p sign-offs
mkdir -p .claude/agents

echo "✅ Folders created"

# =============================================================================
# .claude/settings.json
# =============================================================================

cat > .claude/settings.json << 'EOF'
{
  "includeCoAuthoredBy": false
}
EOF

echo "✅ Co-authored-by disabled"

# =============================================================================
# .gitignore
# =============================================================================

cat > .gitignore << 'EOF'
# Claude — JANGAN COMMIT
CLAUDE.md
.claude/
**/HOW_IT_WORKS.txt
PROJECT_STATUS.md
COST_LOG.md
docs/JOURNEY_LOG.md
docs/INTERVIEW_GUIDE.md
sign-offs/

# Credentials
.env
.env.dev
.env.staging
.env.prod
*.env
credentials/
*.key
*.pem

# Data — PaySim dataset besar
*.parquet
*.csv
*.xlsx
*.json.gz
data/
raw/
PS_20174392719_1491204439457_log.csv

# Python
__pycache__/
*.pyc
.venv/
venv/
*.egg-info/

# dbt
.dbt/
dbt_packages/
target/

# Databricks
.databricks/

# Airflow
airflow/logs/
airflow.cfg
airflow.db
standalone_admin_password.txt

# Logs
logs/
*.log

# IDE
.vscode/settings.json
.idea/
.DS_Store
EOF

echo "✅ .gitignore created"

# =============================================================================
# .env.example
# =============================================================================

cat > .env.example << 'EOF'
# paysim-fraud-pipeline — Credential Template
# Copy ke .env.dev / .env.staging / .env.prod
# JANGAN commit mana-mana .env

ENV=dev

# AWS
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_REGION=ap-southeast-1
S3_BUCKET_DEV=paysim-fraud-pipeline-dev
S3_BUCKET_STAGING=paysim-fraud-pipeline-staging
S3_BUCKET_PROD=paysim-fraud-pipeline-prod
S3_PREFIX_LANDING=landing/paysim/
S3_PREFIX_BRONZE=bronze/transactions/
GLUE_JOB_NAME=paysim-fraud-pipeline-glue-job

# Databricks CE
DATABRICKS_HOST=https://community.cloud.databricks.com
DATABRICKS_TOKEN=
DATABRICKS_CLUSTER_ID=

# Snowflake
SNOWFLAKE_ACCOUNT=
SNOWFLAKE_USER=
SNOWFLAKE_PASSWORD=
SNOWFLAKE_DATABASE=PAYSIM_FRAUD
SNOWFLAKE_SCHEMA_DEV=DEV
SNOWFLAKE_SCHEMA_STAGING=STAGING
SNOWFLAKE_SCHEMA_PROD=PROD
SNOWFLAKE_WAREHOUSE=COMPUTE_WH
SNOWFLAKE_ROLE=SYSADMIN

# Airflow
AIRFLOW__CORE__FERNET_KEY=
AIRFLOW__WEBSERVER__SECRET_KEY=

# Alerts
SLACK_WEBHOOK_URL=
SLACK_CHANNEL=#paysim-fraud-alerts

# dbt
DBT_PROFILES_DIR=./gold

# PaySim Dataset
PAYSIM_SOURCE_PATH=data/PS_20174392719_1491204439457_log.csv
PAYSIM_DEV_ROWS=1000
EOF

echo "✅ .env.example created"

# =============================================================================
# .mcp.json
# =============================================================================

cat > .mcp.json << 'EOF'
{
  "mcpServers": {
    "snowflake": {
      "command": "uvx",
      "args": ["mcp-server-snowflake"],
      "env": {
        "SNOWFLAKE_ACCOUNT": "${SNOWFLAKE_ACCOUNT}",
        "SNOWFLAKE_USER": "${SNOWFLAKE_USER}",
        "SNOWFLAKE_PASSWORD": "${SNOWFLAKE_PASSWORD}",
        "SNOWFLAKE_DATABASE": "${SNOWFLAKE_DATABASE}",
        "SNOWFLAKE_WAREHOUSE": "${SNOWFLAKE_WAREHOUSE}"
      }
    },
    "databricks": {
      "command": "databricks",
      "args": ["mcp", "serve"],
      "env": {
        "DATABRICKS_HOST": "${DATABRICKS_HOST}",
        "DATABRICKS_TOKEN": "${DATABRICKS_TOKEN}"
      }
    },
    "aws-docs": {
      "command": "uvx",
      "args": ["awslabs.aws-documentation-mcp-server@latest"]
    },
    "dbt": {
      "command": "dbt-mcp",
      "args": [],
      "env": {
        "DBT_PROFILES_DIR": "${DBT_PROFILES_DIR}"
      }
    }
  }
}
EOF

echo "✅ .mcp.json created"

# =============================================================================
# docs/BRD.md
# =============================================================================

cat > docs/BRD.md << 'EOF'
# BRD: paysim-fraud-pipeline
> Status: DRAFT — Pending Phase 1 sign-off
> Domain: fintech | Dataset: PaySim1 — 6.3M mobile money transactions

## Business Context
PaySim simulates 30 hari mobile money transactions (~6.3M rows).
Fraud berlaku dalam TRANSFER dan CASH-OUT sahaja.
Fraud rate: 0.13% — high imbalance, high financial impact.

## Stakeholders
| Stakeholder | Role | Data Need |
|-------------|------|-----------|
| Risk & Compliance Team | Primary | Fraud transaction reporting, alert thresholds |
| Product Team | Secondary | Transaction behavior patterns, channel mix |
| Operations | Secondary | Pipeline health, SLA monitoring |

## Business Requirements
1. Detect dan report fraud transactions dalam near-real-time (batch hourly simulate)
2. Identify account drain patterns — balance zero-out events
3. Evaluate effectiveness of original fraud flagging system (isFlaggedFraud accuracy)
4. Segment transaction types untuk risk profiling

## KPIs
| KPI | Formula | Target | Frequency |
|-----|---------|--------|-----------|
| Fraud rate (%) | COUNT(isFraud=1) / COUNT(*) × 100 | Baseline: 0.13% | Daily |
| Fraud amount (RM) | SUM(amount WHERE isFraud=1) | Monitor trend | Daily |
| Fraud detection rate | COUNT(flagged AND fraud) / COUNT(fraud) × 100 | >80% | Daily |
| False positive rate | COUNT(flagged AND !fraud) / COUNT(flagged) × 100 | <20% | Daily |
| Zero-out events | COUNT(newbalanceOrig=0 AND amount>0) | Monitor threshold | Daily |
| Balance drain velocity | AVG(amount/oldbalanceOrg × 100) WHERE isFraud=1 | Baseline first | Daily |

## Business Definitions
- "Fraud transaction" = isFraud = 1 dalam source data
- "Flagged transaction" = isFlaggedFraud = 1 (original heuristic system)
- "Account drain" = newbalanceOrig = 0 after transaction (zero-out event)
- "Drain velocity" = amount / oldbalanceOrg × 100 (% of balance drained)
- "Suspicious sequence" = TRANSFER followed by CASH-OUT by same account within N steps
- "Merchant" = nameDest prefix "M" — no balance tracking available
- "Customer" = nameOrig atau nameDest prefix "C"

## Alert Thresholds
- Any fraud detected dalam batch → CRITICAL Slack alert
- Drain velocity > 95% AND amount > 10,000 → HIGH alert
- Silver row count drop > 1% dari Bronze → CRITICAL, block Gold
- isFlaggedFraud discrepancy > 10% → HIGH, flag untuk DQS review

## SLA
- Bronze available: T+5 minit dari ingestion trigger
- Silver available: T+20 minit
- Gold available: T+35 minit
- Power BI refresh: T+40 minit

## Out of Scope (Phase 1)
- ML model training untuk fraud prediction (Phase 2 — future)
- Real-time streaming (simulate batch sahaja)
- PII masking (synthetic data — no real PII)

## Sign-off Gate
| Agent | Status | Reason | Date |
|-------|--------|--------|------|
| BA | PENDING | - | - |
| PO | PENDING | - | - |
| PM | PENDING | - | - |
| DQS | PENDING | - | - |
EOF

# =============================================================================
# docs/DRD.md
# =============================================================================

cat > docs/DRD.md << 'EOF'
# DRD: paysim-fraud-pipeline
> Status: DRAFT — Pending Phase 2 sign-off

## Source Overview
| Attribute | Value |
|-----------|-------|
| Source | PaySim1 Kaggle Dataset |
| Format | CSV (PS_20174392719_1491204439457_log.csv) |
| Frequency | One-shot load — simulate daily batch ingestion |
| Volume | 6,362,620 rows, ~470MB CSV |
| Delivery | Manual download → S3 landing zone |
| Ingestion pattern | Snapshot (full load, partition by simulated date) |

## Schema (11 Columns — HARD LIMIT)
| Column | Type | Nullable | Business Term | Description |
|--------|------|----------|---------------|-------------|
| step | INT | N | Transaction Hour | 1 step = 1 hour, range 1–744 (30 days) |
| type | STRING | N | Transaction Type | CASH-IN, CASH-OUT, DEBIT, PAYMENT, TRANSFER |
| amount | DOUBLE | N | Transaction Amount | Amount in local currency |
| nameOrig | STRING | N | Sender ID | Customer ID, prefix C |
| oldbalanceOrg | DOUBLE | N | Sender Balance Before | Balance before transaction |
| newbalanceOrig | DOUBLE | N | Sender Balance After | Balance after transaction |
| nameDest | STRING | N | Receiver ID | Customer (C) or Merchant (M) |
| oldbalanceDest | DOUBLE | Y* | Receiver Balance Before | Empty for merchants (prefix M) |
| newbalanceDest | DOUBLE | Y* | Receiver Balance After | Empty for merchants (prefix M) |
| isFraud | INT | N | Fraud Label | 1 = fraud, 0 = legitimate |
| isFlaggedFraud | INT | N | System Flag | 1 = flagged by original heuristic |

*Y by design — merchant balance not tracked, bukan data error

## Entities Identified
| Entity | Type | Notes |
|--------|------|-------|
| Transaction | Fact | Grain: 1 row = 1 txn — natural fact table |
| Customer Daily Balance | Fact (Cumulative) | Grain: 1 customer per day — derived dari transactions |
| Customer | Dimension | nameOrig / nameDest prefix C |
| Merchant | Dimension | nameDest prefix M — static, no balance |
| Time | Dimension | Derived dari step column (step ÷ 24 = day) |
| Transaction Type | Dimension | 5 values — static lookup |

## Known Data Issues (flagged by DA + DQS)
| Issue | Observed | Impact | Strategy |
|-------|----------|--------|----------|
| Merchant balance = 0/null | oldbalanceDest=0, newbalanceDest=0 untuk prefix M | Expected by design — not an error | Document dalam DATA_DICTIONARY, filter dalam Silver |
| isFlaggedFraud ≠ isFraud | Heuristic miss — false pos/neg exist | Affects detection rate KPI | Keep both columns, compute discrepancy metric |
| Fraud HANYA dalam TRANSFER + CASH-OUT | type IN ('PAYMENT','CASH-IN','DEBIT') → isFraud always 0 | Model assumption — restrict fraud analysis scope | Filter dalam Silver fraud flag, document dalam SPEC |
| Class imbalance: 0.13% fraud | 8,213 fraud / 6.3M total | GX count check — jangan treat as anomaly | Set GX expected range 0.10%–0.20% |
| No timestamp — step only | step = integer hour count | No real datetime — kena derive | Silver: derive transaction_datetime dari step |

## Derived Columns (Silver layer)
| Column | Formula | Notes |
|--------|---------|-------|
| transaction_day | CEIL(step / 24) | Day 1–31 |
| transaction_hour | ((step - 1) % 24) + 1 | Hour 1–24 |
| transaction_datetime | TIMESTAMP '2024-01-01' + (step-1) HOURS | Synthetic base date |
| is_merchant_dest | CASE WHEN nameDest LIKE 'M%' THEN 1 ELSE 0 END | Route merchant vs customer |
| balance_drain_pct | CASE WHEN oldbalanceOrg > 0 THEN (amount / oldbalanceOrg * 100) ELSE NULL END | NULL kalau divide by zero |
| is_zero_out | CASE WHEN newbalanceOrig = 0 AND amount > 0 THEN 1 ELSE 0 END | Account drain flag |
| balance_discrepancy_orig | (oldbalanceOrg - amount) - newbalanceOrig | Detect balance mismatch |
| balance_discrepancy_dest | (oldbalanceDest + amount) - newbalanceDest | Detect destination mismatch |

## SLA
- Bronze: T+5 minit | Silver: T+20 minit | Gold: T+35 minit

## Retention
| Layer | Retention |
|-------|-----------|
| Bronze | 2 years (Delta time travel — backfill capability) |
| Silver | 1 year |
| Gold | 2 years (Snowflake — reporting history) |

## Sign-off Gate
| Agent | Status | Reason |
|-------|--------|--------|
| BA | PENDING | - |
| DA | PENDING | - |
| SDE | PENDING | - |
| DPE | PENDING | - |
| DQS | PENDING | - |
| PM | PENDING | - |

## Hard Blockers Before Phase 3
[ ] Grain defined untuk kedua-dua fact tables
[ ] DA + DPE sync — cumulative table memory feasibility confirmed
[ ] Merchant balance NULL strategy decided
[ ] isFlaggedFraud discrepancy strategy decided
[ ] Source pattern decided (Snapshot CSV)
EOF

# =============================================================================
# docs/DATA_DICTIONARY.md
# =============================================================================

cat > docs/DATA_DICTIONARY.md << 'EOF'
# Data Dictionary: paysim-fraud-pipeline
> Owner: DQS (Data Quality Steward)
> Updated: setiap kali schema berubah

## Business Terms
| Term | Definition | Example |
|------|-----------|---------|
| Fraud Transaction | Transaction where isFraud = 1 | TRANSFER of 181,161 flagged fraud |
| Account Drain | Zero-out event — newbalanceOrig = 0 after txn | Account C12345 drained to 0 |
| Drain Velocity | % of sender balance removed in single txn: amount/oldbalanceOrg × 100 | 95.5% drain |
| Suspicious Sequence | TRANSFER followed by CASH-OUT within same session (same nameOrig) | C99999: TRANSFER step 10, CASH-OUT step 11 |
| False Positive | isFlaggedFraud=1 BUT isFraud=0 | System flagged but not actual fraud |
| False Negative | isFraud=1 BUT isFlaggedFraud=0 | Actual fraud missed by system |
| Merchant | Transaction destination with prefix M — no balance data | M1234567 |
| Step | Unit of simulated time — 1 step = 1 hour of operation | step 24 = end of Day 1 |

## Source Table: transactions (Bronze)
| Column | Business Name | Type | Nullable | Rule | Example |
|--------|--------------|------|----------|------|---------|
| step | Transaction Hour | INT | N | Range 1–744 | 1 |
| type | Transaction Type | STRING | N | ENUM: CASH-IN, CASH-OUT, DEBIT, PAYMENT, TRANSFER | TRANSFER |
| amount | Transaction Amount | DOUBLE | N | > 0 | 181161.03 |
| nameOrig | Sender ID | STRING | N | Prefix C | C1231006815 |
| oldbalanceOrg | Sender Balance Before | DOUBLE | N | >= 0 | 181161.03 |
| newbalanceOrig | Sender Balance After | DOUBLE | N | >= 0 | 0.0 |
| nameDest | Receiver ID | STRING | N | Prefix C atau M | C1666544295 |
| oldbalanceDest | Receiver Balance Before | DOUBLE | Y* | 0 untuk prefix M | 0.0 |
| newbalanceDest | Receiver Balance After | DOUBLE | Y* | 0 untuk prefix M | 0.0 |
| isFraud | Fraud Label | INT | N | 0 atau 1 | 1 |
| isFlaggedFraud | System Fraud Flag | INT | N | 0 atau 1 | 0 |

*Nullable by design untuk merchants

## Silver Tables
### silver.transactions
| Column | Business Name | Type | Nullable | Derived From | Rule |
|--------|--------------|------|----------|-------------|------|
| transaction_id | Transaction ID | STRING | N | MD5(nameOrig+step+amount) | Surrogate key |
| step | Transaction Hour | INT | N | Source | As-is |
| transaction_day | Transaction Day | INT | N | CEIL(step/24) | Day 1–31 |
| transaction_hour | Hour of Day | INT | N | ((step-1)%24)+1 | Hour 1–24 |
| transaction_datetime | Transaction Datetime | TIMESTAMP | N | Base + step hours | Synthetic 2024-01-01 base |
| type | Transaction Type | STRING | N | Source | Validated ENUM |
| amount | Amount | DOUBLE | N | Source | > 0 |
| sender_id | Sender Customer ID | STRING | N | nameOrig | Prefix C |
| receiver_id | Receiver ID | STRING | N | nameDest | Prefix C atau M |
| is_merchant_dest | Merchant Flag | INT | N | nameDest LIKE 'M%' | 0 atau 1 |
| sender_balance_before | Sender Balance Before | DOUBLE | N | oldbalanceOrg | >= 0 |
| sender_balance_after | Sender Balance After | DOUBLE | N | newbalanceOrig | >= 0 |
| receiver_balance_before | Receiver Balance Before | DOUBLE | Y | oldbalanceDest | NULL untuk merchants |
| receiver_balance_after | Receiver Balance After | DOUBLE | Y | newbalanceDest | NULL untuk merchants |
| is_fraud | Fraud Label | INT | N | isFraud | 0 atau 1 |
| is_flagged_fraud | System Flag | INT | N | isFlaggedFraud | 0 atau 1 |
| balance_drain_pct | Drain Velocity % | DOUBLE | Y | amount/oldbalanceOrg×100 | NULL kalau oldbalanceOrg=0 |
| is_zero_out | Zero-Out Event | INT | N | newbalanceOrig=0 AND amount>0 | 0 atau 1 |
| balance_disc_orig | Sender Balance Discrepancy | DOUBLE | N | (oldbalanceOrg-amount)-newbalanceOrig | 0 = no discrepancy |
| dq_flag | Data Quality Flag | INT | N | GX validation result | 0 = clean |
| ingestion_ts | Ingestion Timestamp | TIMESTAMP | N | Pipeline runtime | Auto |
| batch_id | Batch ID | STRING | N | Airflow run_id | Traceability |

## Gold Tables (dbt Marts)
### mart_fraud_summary
| Column | Business Name | Type | KPI? | Formula | Notes |
|--------|--------------|------|------|---------|-------|
| summary_date | Report Date | DATE | N | transaction_day derived | Partition key |
| transaction_type | Transaction Type | STRING | N | dim_transaction_type | Group by |
| total_transactions | Total Txn Count | BIGINT | Y | COUNT(*) | |
| fraud_count | Fraud Count | BIGINT | Y | COUNT(is_fraud=1) | |
| fraud_rate_pct | Fraud Rate % | DOUBLE | Y | fraud_count/total×100 | |
| total_amount | Total Amount | DOUBLE | N | SUM(amount) | |
| fraud_amount | Fraud Amount | DOUBLE | Y | SUM(amount WHERE fraud) | |
| flagged_count | System Flagged Count | BIGINT | N | COUNT(is_flagged_fraud=1) | |
| true_positive | Correct Detections | BIGINT | Y | COUNT(flagged AND fraud) | |
| false_positive | False Alarms | BIGINT | Y | COUNT(flagged AND !fraud) | |
| detection_rate_pct | Detection Rate % | DOUBLE | Y | true_positive/fraud_count×100 | |
| false_positive_rate_pct | False Positive Rate % | DOUBLE | Y | false_positive/flagged×100 | |

### mart_customer_risk
| Column | Business Name | Type | KPI? | Formula | Notes |
|--------|--------------|------|------|---------|-------|
| customer_id | Customer ID | STRING | N | sender_id | PK |
| risk_date | Risk Date | DATE | N | transaction_day | |
| total_sent | Total Amount Sent | DOUBLE | N | SUM(amount) | |
| total_received | Total Amount Received | DOUBLE | N | SUM incoming | |
| transaction_count | Txn Count | INT | N | COUNT(*) | |
| zero_out_count | Zero-Out Events | INT | Y | SUM(is_zero_out) | |
| max_drain_velocity | Max Drain % | DOUBLE | Y | MAX(balance_drain_pct) | |
| fraud_txn_count | Fraud Txn Count | INT | Y | SUM(is_fraud) | |
| is_high_risk | High Risk Flag | INT | Y | zero_out OR max_drain>95% | |
| running_fraud_total | Cumulative Fraud Count | INT | Y | Cumulative sum | Dari cumulative table |
| running_fraud_amount | Cumulative Fraud Amount | DOUBLE | Y | Cumulative sum | Dari cumulative table |

## Dimension Tables
### dim_customer
| Column | Type | SCD? | Description |
|--------|------|------|-------------|
| customer_sk | INT | N | Surrogate key |
| customer_id | STRING | N | Natural key — nameOrig/nameDest prefix C |
| customer_type | STRING | N | 'SENDER' / 'RECEIVER' / 'BOTH' |
| first_seen_day | INT | N | First transaction day |
| last_seen_day | INT | N | Last transaction day |

### dim_merchant
| Column | Type | SCD? | Description |
|--------|------|------|-------------|
| merchant_sk | INT | N | Surrogate key |
| merchant_id | STRING | N | Natural key — nameDest prefix M |
| first_seen_day | INT | N | First transaction received day |

### dim_time
| Column | Type | Description |
|--------|------|-------------|
| step | INT | PK — source step value |
| transaction_day | INT | CEIL(step/24) |
| transaction_hour | INT | ((step-1)%24)+1 |
| transaction_datetime | TIMESTAMP | Synthetic datetime |
| day_of_week | STRING | Derived dari datetime |
| is_weekend | INT | 0 atau 1 |

### dim_transaction_type
| Column | Type | Description |
|--------|------|-------------|
| type_id | INT | PK |
| type_code | STRING | CASH-IN, CASH-OUT, DEBIT, PAYMENT, TRANSFER |
| type_category | STRING | 'INFLOW', 'OUTFLOW', 'NEUTRAL' |
| fraud_possible | INT | 1 = TRANSFER atau CASH-OUT sahaja |
EOF

# =============================================================================
# docs/DATA_MODEL.md
# =============================================================================

cat > docs/DATA_MODEL.md << 'EOF'
# Data Model: paysim-fraud-pipeline
> Owner: Data Architect
> Status: DRAFT — Pending Phase 3 sign-off
> Co-validated by: Data Platform Engineer (feasibility)

## Paradigm Decision
Chosen  : Hybrid — Kimball Star Schema + Cumulative Table Design
Reason  : Fraud reporting memerlukan Kimball (aggregate KPIs, dimension joins).
          Account drain detection memerlukan Cumulative (running totals, temporal patterns).
          Dua use case → dua paradigm dalam satu pipeline.

## Paradigm Tradeoff
| Factor | Decision |
|--------|----------|
| Storage | More — cumulative table duplikat data per hari, trade storage for compute |
| Compute | Less — no full scan untuk running totals, Delta Lake MERGE incremental |
| Join complexity | Medium — star schema joins untuk fraud mart, minimal untuk risk mart |
| Query pattern | Both — aggregate (fraud summary) + row-level (customer risk) |
| Free tier fit | Feasible — Databricks CE 15GB sufficient kalau cumulative tidak nested Array of Struct |

## Why Not Pure OBT
OBT rejected — Databricks CE 15GB insufficient untuk 6.3M rows dengan nested Array of Struct.
Cumulative table guna simple schema (1 row per customer per hari) — safe untuk CE memory.

## Why Not Pure Kimball
Pure Kimball rejected — temporal running totals (running_fraud_total, running_fraud_amount)
require full table scan setiap query. Cumulative table pre-compute ini dalam Silver layer.

## Fact Tables (Logical Layer)

### fact_transactions
- Grain   : 1 row = 1 transaksi (EXPLICIT)
- Source  : silver.transactions
- Pattern : Snapshot → Incremental append (partition by transaction_day)
- Partitioned by: transaction_day

| Column | Type | FK? | Description |
|--------|------|-----|-------------|
| transaction_sk | BIGINT | N | Surrogate key |
| transaction_id | STRING | N | Natural key (MD5) |
| step_fk | INT | Y | → dim_time.step |
| type_fk | INT | Y | → dim_transaction_type.type_id |
| sender_fk | INT | Y | → dim_customer.customer_sk |
| receiver_fk | INT | Y | → dim_customer.customer_sk (nullable) |
| merchant_fk | INT | Y | → dim_merchant.merchant_sk (nullable) |
| amount | DOUBLE | N | Transaction amount |
| sender_balance_before | DOUBLE | N | |
| sender_balance_after | DOUBLE | N | |
| receiver_balance_before | DOUBLE | Y | NULL untuk merchants |
| receiver_balance_after | DOUBLE | Y | NULL untuk merchants |
| balance_drain_pct | DOUBLE | Y | Derived measure |
| is_zero_out | INT | N | 0 atau 1 |
| is_fraud | INT | N | 0 atau 1 |
| is_flagged_fraud | INT | N | 0 atau 1 |
| balance_disc_orig | DOUBLE | N | Quality measure |
| transaction_day | INT | N | Partition key |
| ingestion_ts | TIMESTAMP | N | |
| batch_id | STRING | N | |

### fact_customer_daily_balance (Cumulative Table)
- Grain   : 1 row = 1 customer per hari (EXPLICIT)
- Source  : silver.transactions (aggregated per customer per day)
- Pattern : Cumulative — Delta Lake MERGE setiap hari
- Logic   : New day data + carry forward running totals
- Partitioned by: balance_date

| Column | Type | FK? | Description |
|--------|------|-----|-------------|
| customer_day_sk | BIGINT | N | Surrogate key |
| customer_fk | INT | Y | → dim_customer.customer_sk |
| balance_date | DATE | N | Partition key |
| daily_sent_amount | DOUBLE | N | SUM(amount) untuk hari ni |
| daily_received_amount | DOUBLE | N | SUM incoming hari ni |
| daily_txn_count | INT | N | COUNT(*) hari ni |
| daily_fraud_count | INT | N | COUNT(is_fraud=1) hari ni |
| daily_zero_out_count | INT | N | COUNT(is_zero_out=1) hari ni |
| max_daily_drain_pct | DOUBLE | Y | MAX(balance_drain_pct) hari ni |
| running_txn_total | BIGINT | N | Cumulative txn count sampai hari ni |
| running_fraud_total | INT | N | Cumulative fraud count sampai hari ni |
| running_fraud_amount | DOUBLE | N | Cumulative fraud amount sampai hari ni |
| running_sent_total | DOUBLE | N | Cumulative total sent |
| is_high_risk_today | INT | N | daily_zero_out > 0 OR max_drain > 95% |
| ingestion_ts | TIMESTAMP | N | |

## Dimension Tables (Logical Layer)

### dim_customer
- SCD Type: 1 (overwrite)
- Reason  : Synthetic data — customer attributes tidak berubah, ID sahaja yang penting
- Source  : Derived dari nameOrig + nameDest dalam transactions

### dim_merchant
- SCD Type: None (static)
- Reason  : Merchant = destination prefix M, no attributes berubah

### dim_time
- SCD Type: None (static, pre-populated)
- Reason  : Derived lookup table — 744 rows (744 steps)

### dim_transaction_type
- SCD Type: None (static, 5 rows)
- Reason  : Enum values — takkan berubah

## Cumulative Table MERGE Strategy
```
EVERY PIPELINE RUN:
1. Aggregate today's transactions → daily_summary
2. MERGE INTO fact_customer_daily_balance
   ON customer_fk = customer_fk AND balance_date = today
   WHEN MATCHED → UPDATE daily + running totals
   WHEN NOT MATCHED → INSERT new row with running totals
                      (carry forward from yesterday's row)
```

## Source Ingestion Pattern
| Table | Pattern | Reason |
|-------|---------|--------|
| transactions (raw) | Full Snapshot → S3 | CSV one-shot, partition by simulated day |
| fact_transactions | Incremental append | partition by transaction_day |
| fact_customer_daily_balance | Delta Lake MERGE | Cumulative pattern |

## dbt Model Structure
```
staging/
  staging__paysim_transactions.sql       → source cleaning, type cast, rename columns

intermediate/
  int_transactions_enriched.sql           → add derived columns (drain_pct, zero_out)
  int_customer_daily_aggregates.sql       → daily agg per customer
  int_cumulative_customer_balance.sql     → running totals logic

marts/
  mart_fraud_summary.sql                  → fraud KPIs by day + type
  mart_customer_risk.sql                  → customer risk profile + running totals
```

## Physical Layer Notes (validated by DPE)
| Check | Status | Notes |
|-------|--------|-------|
| Databricks CE 15GB fit | ✅ | Cumulative guna simple schema — no nested Array. Monitor 6.3M rows Silver |
| S3 5GB limit | ✅ | CSV ~470MB + Delta Lake overhead ~1.5GB staging. Under limit |
| Delta Lake MERGE support | ✅ | CE support MERGE operation — cumulative pattern feasible |
| Snowflake credit sustainable | ✅ | Gold only — 2 marts, XS warehouse. Est. <$5 untuk full run |

## Sign-off Gate
| Agent | Status | Reason |
|-------|--------|--------|
| DA | PENDING | - |
| DPE | PENDING | - |
| SDE | PENDING | - |
| AE | PENDING | - |
| PM | PENDING | - |

## Hard Blockers Before Phase 4
[ ] Grain locked — explicit, agreed
[ ] SCD Type 1 confirmed untuk semua dimensions
[ ] Cumulative MERGE strategy documented
[ ] DA + DPE feasibility sync confirmed
[ ] Paradigm ADR written (Hybrid justification)
EOF

# =============================================================================
# docs/ADR/ADR-001-hybrid-paradigm.md
# =============================================================================

cat > docs/ADR/ADR-001-hybrid-paradigm.md << 'EOF'
# ADR-001: Data Modelling Paradigm — Hybrid (Kimball + Cumulative Table)

Status: Accepted
Date  : 2026-05-11
Owner : Data Architect + Data Platform Engineer

## Context
Dataset: PaySim1 — 6.3M mobile money transactions, 30 hari simulasi.
Two distinct analytical requirements:
1. Fraud reporting — aggregate KPIs, dimension joins, daily summaries
2. Account drain detection — temporal running totals, behavioral patterns

## Decision
Paradigm: Hybrid — Kimball Star Schema + Cumulative Table Design

fact_transactions    → Kimball grain — 1 row = 1 txn
                       Standard star schema joins
                       Partition by transaction_day

fact_customer_daily_balance → Cumulative grain — 1 row = 1 customer per hari
                               Delta Lake MERGE incremental
                               Running totals pre-computed

## Consequences
(+) Fraud KPIs queryable dengan standard GROUP BY — Power BI friendly
(+) Running totals available tanpa full table scan setiap query
(+) Delta Lake MERGE fit perfectly untuk cumulative pattern
(+) Dua paradigm dalam portfolio — tunjuk breadth of modelling knowledge
(-) More storage — cumulative duplikate daily data
(-) MERGE logic lebih complex dari pure append
(-) Dua fact tables — AE perlu faham dua grain

## Alternatives Rejected
- Pure Kimball: rejected — running totals require expensive full scan setiap query
- Pure OBT: rejected — Databricks CE 15GB RAM insufficient untuk 6.3M rows nested Array of Struct
- Pure Cumulative: rejected — aggregate fraud KPIs messy tanpa proper star schema

## DPE Feasibility Validation
[✅] Databricks CE 15GB — simple cumulative schema (no nested) = feasible
[✅] Delta Lake MERGE — CE supported
[✅] S3 5GB — CSV 470MB + Delta overhead ~1.5GB = under limit
[✅] Snowflake $400 — 2 marts XS warehouse = sustainable
EOF

# =============================================================================
# Airflow DAG
# =============================================================================

cat > airflow/dags/paysim_fraud_pipeline.py << 'EOF'
"""
paysim-fraud-pipeline — Main Pipeline DAG
Domain   : fintech
Dataset  : PaySim1 — 6.3M rows, 11 columns
Modelling: Hybrid — Kimball + Cumulative Table
Grain 1  : 1 row = 1 transaksi (fact_transactions)
Grain 2  : 1 row = 1 customer per hari (fact_customer_daily_balance)
Schedule : @daily (manual trigger untuk demo)
"""

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'raja-luqman',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
}

def slack_success(context):
    SlackWebhookOperator(
        task_id='slack_success',
        slack_webhook_conn_id='slack_webhook',
        message=f"✅ *paysim-fraud-pipeline* — Pipeline success | {context['ds']}",
    ).execute(context)

def slack_failure(context):
    SlackWebhookOperator(
        task_id='slack_failure',
        slack_webhook_conn_id='slack_webhook',
        message=f"❌ *paysim-fraud-pipeline* — FAILED: {context['task_instance'].task_id} | {context['ds']}",
    ).execute(context)

with DAG(
    dag_id='paysim_fraud_pipeline',
    default_args=default_args,
    schedule_interval='@daily',
    catchup=False,
    on_success_callback=slack_success,
    on_failure_callback=slack_failure,
    tags=['fintech', 'fraud', 'hybrid', 'portfolio'],
) as dag:

    # Bronze — raw ingestion dari S3 ke Delta Lake
    bronze = PythonOperator(
        task_id='bronze_ingest',
        python_callable=lambda: __import__('bronze.bronze_pipeline', fromlist=['']).run(),
    )

    # Bronze GX validation
    bronze_dq = PythonOperator(
        task_id='bronze_dq_check',
        python_callable=lambda: __import__('data_quality.run_bronze_suite', fromlist=['']).run(),
    )

    # Silver — PySpark transforms + derived columns + dedup
    silver = PythonOperator(
        task_id='silver_transform',
        python_callable=lambda: __import__('silver.silver_pipeline', fromlist=['']).run(),
    )

    # Silver cumulative table — Delta Lake MERGE
    silver_cumulative = PythonOperator(
        task_id='silver_cumulative_merge',
        python_callable=lambda: __import__('silver.cumulative_pipeline', fromlist=['']).run(),
    )

    # Silver GX validation
    silver_dq = PythonOperator(
        task_id='silver_dq_check',
        python_callable=lambda: __import__('data_quality.run_silver_suite', fromlist=['']).run(),
    )

    # Gold — dbt run
    gold_run = BashOperator(
        task_id='gold_dbt_run',
        bash_command='dbt run --profiles-dir gold --project-dir gold',
    )

    # Gold — dbt test (FK checks, not_null, unique)
    gold_test = BashOperator(
        task_id='gold_dbt_test',
        bash_command='dbt test --profiles-dir gold --project-dir gold',
    )

    # DAG order
    bronze >> bronze_dq >> silver >> silver_cumulative >> silver_dq >> gold_run >> gold_test
EOF

# =============================================================================
# dbt profiles
# =============================================================================

cat > gold/profiles.yml << 'EOF'
paysim-fraud-pipeline:
  target: dev
  outputs:
    dev:
      type: snowflake
      account: "{{ env_var('SNOWFLAKE_ACCOUNT') }}"
      user: "{{ env_var('SNOWFLAKE_USER') }}"
      password: "{{ env_var('SNOWFLAKE_PASSWORD') }}"
      role: "{{ env_var('SNOWFLAKE_ROLE', 'SYSADMIN') }}"
      database: "{{ env_var('SNOWFLAKE_DATABASE') }}"
      warehouse: "{{ env_var('SNOWFLAKE_WAREHOUSE') }}"
      schema: "{{ env_var('SNOWFLAKE_SCHEMA_DEV') }}"
      threads: 4
    staging:
      type: snowflake
      account: "{{ env_var('SNOWFLAKE_ACCOUNT') }}"
      user: "{{ env_var('SNOWFLAKE_USER') }}"
      password: "{{ env_var('SNOWFLAKE_PASSWORD') }}"
      role: "{{ env_var('SNOWFLAKE_ROLE', 'SYSADMIN') }}"
      database: "{{ env_var('SNOWFLAKE_DATABASE') }}"
      warehouse: "{{ env_var('SNOWFLAKE_WAREHOUSE') }}"
      schema: "{{ env_var('SNOWFLAKE_SCHEMA_STAGING') }}"
      threads: 4
    prod:
      type: snowflake
      account: "{{ env_var('SNOWFLAKE_ACCOUNT') }}"
      user: "{{ env_var('SNOWFLAKE_USER') }}"
      password: "{{ env_var('SNOWFLAKE_PASSWORD') }}"
      role: "{{ env_var('SNOWFLAKE_ROLE', 'SYSADMIN') }}"
      database: "{{ env_var('SNOWFLAKE_DATABASE') }}"
      warehouse: "{{ env_var('SNOWFLAKE_WAREHOUSE') }}"
      schema: "{{ env_var('SNOWFLAKE_SCHEMA_PROD') }}"
      threads: 4
EOF

# =============================================================================
# docs/ARCHITECTURE.md
# =============================================================================

cat > docs/ARCHITECTURE.md << 'EOF'
# Architecture: paysim-fraud-pipeline
> Status: DRAFT — Pending Phase 3 sign-off

## Data Flow
```
PaySim1 CSV (6.3M rows)
    ↓ Python (boto3)
AWS S3 Landing Zone (paysim-fraud-pipeline-dev)
    ↓ Python → Delta Lake
Bronze Layer (Delta Lake on S3)
    → bronze.transactions (raw, as-is + metadata)
    ↓ PySpark (Databricks CE)
Silver Layer (Delta Lake)
    → silver.transactions (enriched, cleaned, derived columns)
    → silver.customer_daily_balance (cumulative — Delta MERGE)
    ↓ dbt Core (Snowflake)
Gold Layer (Snowflake)
    → mart_fraud_summary (Kimball — fraud KPIs by day + type)
    → mart_customer_risk (Cumulative — customer risk profile)
    ↓
Power BI (Fraud Intelligence Dashboard)
```

## Stack
| Layer | Tool | Free Tier | Justification |
|-------|------|-----------|---------------|
| Landing | AWS S3 | 5GB | CSV 470MB — under limit |
| Bronze | Delta Lake on S3 | Included | ACID, time travel, raw preserve |
| Silver | PySpark + Databricks CE | Free | Managed Spark, MERGE support |
| Gold | dbt Core + Snowflake | $400 credit | Semantic layer, SQL transforms |
| Orchestration | Airflow standalone | Free (pip) | localhost:8080 |
| Quality | Great Expectations | Free | Suite per layer, HTML report |
| BI | Power BI | Free tier | Gold consumer |

## Data Modelling — Hybrid
See docs/DATA_MODEL.md
See docs/ADR/ADR-001-hybrid-paradigm.md

fact_transactions           → Kimball grain — 1 row = 1 txn
fact_customer_daily_balance → Cumulative grain — 1 row = 1 customer per hari

## Environments
| Env | Purpose | Data | Trigger |
|-----|---------|------|---------|
| dev | Develop + unit test | 1000 rows | Manual |
| staging | Full test + validation | 6.3M rows | Airflow scheduled |
| prod | Screenshot evidence | 6.3M rows | Manual once |

## Non-Functional
| Requirement | Target |
|-------------|--------|
| Pipeline reliability | >95% successful runs |
| Data freshness | Gold by T+35 minit |
| Recovery | Delta Lake time travel backfill |
| Fraud alert latency | Slack dalam 1 minit selepas Gold ready |

## ADRs
- ADR-001: Hybrid paradigm decision
EOF

# =============================================================================
# docs/DQD.md
# =============================================================================

cat > docs/DQD.md << 'EOF'
# DQD: paysim-fraud-pipeline
> Status: DRAFT — Pending Phase 5 sign-off
> Owner: DQS

## Bronze Suite
Suite: bronze_suite | Run: Sebelum Silver

| Check | Rule | Severity | Action |
|-------|------|----------|--------|
| Row count | Source = Bronze EXACT | CRITICAL | Block + alert |
| ingestion_ts | NOT NULL | CRITICAL | Reject |
| step | BETWEEN 1 AND 744 | CRITICAL | Reject |
| type | IN (CASH-IN, CASH-OUT, DEBIT, PAYMENT, TRANSFER) | CRITICAL | Reject |
| amount | > 0 | CRITICAL | Reject |
| nameOrig | NOT NULL, LIKE 'C%' | CRITICAL | Reject |
| nameDest | NOT NULL, LIKE 'C%' OR LIKE 'M%' | CRITICAL | Reject |
| isFraud | IN (0, 1) | CRITICAL | Reject |
| isFlaggedFraud | IN (0, 1) | CRITICAL | Reject |

## Silver Suite
Suite: silver_suite | Run: Selepas Silver transform

| Column | Rule | Severity | Action |
|--------|------|----------|--------|
| transaction_id | NOT NULL, UNIQUE | CRITICAL | Reject duplicates |
| sender_id | NOT NULL | CRITICAL | Reject |
| amount | > 0 | CRITICAL | Reject |
| transaction_day | BETWEEN 1 AND 31 | CRITICAL | Reject |
| balance_drain_pct | BETWEEN 0 AND 100 OR NULL | HIGH | Quarantine |
| fraud_rate_actual | BETWEEN 0.10% AND 0.20% | HIGH | Alert DQS — class imbalance check |
| row_count | BETWEEN 6,200,000 AND 6,400,000 | CRITICAL | Block Gold |
| is_fraud | IN (0, 1) | CRITICAL | Reject |
| merchant balance | oldbalanceDest=0 FOR prefix M | MEDIUM | Log — expected pattern |

## Gold Suite (dbt tests)
Suite: gold_suite | Run: Selepas dbt run

| Check | Rule | Severity |
|-------|------|----------|
| fact_transactions.transaction_sk | NOT NULL, UNIQUE | CRITICAL |
| fact_transactions.step_fk | IN dim_time.step | CRITICAL |
| fact_transactions.type_fk | IN dim_transaction_type.type_id | CRITICAL |
| mart_fraud_summary.fraud_rate_pct | NOT NULL, >= 0 | CRITICAL |
| mart_customer_risk.running_fraud_total | NOT NULL, >= 0 | CRITICAL |
| All dbt tests | Pass | CRITICAL |

## Referential Integrity
| FK Column | References | Action if Fail |
|-----------|-----------|----------------|
| fact_transactions.step_fk | dim_time.step | Quarantine + flag |
| fact_transactions.type_fk | dim_transaction_type.type_id | Reject |
| fact_transactions.sender_fk | dim_customer.customer_sk | Quarantine |
| fact_customer_daily_balance.customer_fk | dim_customer.customer_sk | Reject |

## Reconciliation
| Check | Tolerance |
|-------|-----------|
| Source CSV → Bronze | 0 (exact row count) |
| Bronze → Silver | <0.01% (dedup hanya duplicate ingestion, bukan source) |
| Silver → Gold fact | Exact match on transaction_id count |
| Silver fraud count → Gold fraud KPI | Exact match |

## Known Expected Anomalies (jangan flag as error)
- Merchant balance = 0 → by design
- Fraud rate 0.13% → expected, bukan anomaly
- Fraud HANYA dalam TRANSFER + CASH-OUT → expected behavior
- isFlaggedFraud ≠ isFraud → expected discrepancy, KPI metric

## Action on Failure
| Severity | Action |
|----------|--------|
| CRITICAL | Block downstream + Slack CRITICAL alert |
| HIGH | Quarantine bad rows + continue clean data + Slack HIGH alert |
| MEDIUM | dq_flag=True + log + continue |
EOF

# =============================================================================
# docs/PIPELINE_SPEC.md
# =============================================================================

cat > docs/PIPELINE_SPEC.md << 'EOF'
# Pipeline SPEC: paysim-fraud-pipeline
> Status: DRAFT — Pending Phase 3 sign-off

## Data Flow
Source CSV → Bronze (Delta Lake + S3) → Silver (PySpark + Databricks) → Gold (dbt + Snowflake) → Power BI

## Bronze Layer
Input     : PaySim1 CSV dari S3 landing zone
Output    : bronze.transactions (Delta Lake)
Pattern   : Full Snapshot → partition by simulated day
Logic     : Store as-is + ingestion_ts, source_system, batch_id
Partition : transaction_day (derived dari step)

Columns added:
- ingestion_ts    : TIMESTAMP pipeline runtime
- source_system   : 'paysim1_kaggle'
- batch_id        : Airflow run_id
- source_file     : S3 path

## Silver Layer

### silver.transactions
Input  : bronze.transactions
Output : silver.transactions (Delta Lake)

Steps:
1. DEDUPLICATE  : Keep latest ingestion_ts per (nameOrig, step, amount)
2. TYPE CAST    : step→INT, amount→DOUBLE, isFraud→INT, isFlaggedFraud→INT
3. NULL HANDLE  : nameOrig, nameDest, type, amount NULL → REJECT
                  oldbalanceDest NULL pour prefix M → ACCEPTABLE, replace 0
4. DERIVED      :
   - transaction_id     = MD5(nameOrig + CAST(step AS STRING) + CAST(amount AS STRING))
   - transaction_day    = CEIL(step / 24)
   - transaction_hour   = ((step - 1) % 24) + 1
   - transaction_datetime = TIMESTAMP('2024-01-01') + INTERVAL (step-1) HOURS
   - is_merchant_dest   = CASE WHEN nameDest LIKE 'M%' THEN 1 ELSE 0 END
   - balance_drain_pct  = CASE WHEN oldbalanceOrg > 0 THEN (amount/oldbalanceOrg*100) ELSE NULL END
   - is_zero_out        = CASE WHEN newbalanceOrig = 0 AND amount > 0 THEN 1 ELSE 0 END
   - balance_disc_orig  = ABS((oldbalanceOrg - amount) - newbalanceOrig)
   - balance_disc_dest  = CASE WHEN is_merchant_dest=0 THEN ABS((oldbalanceDest + amount) - newbalanceDest) ELSE NULL END
5. RENAME       : nameOrig→sender_id, nameDest→receiver_id, oldbalanceOrg→sender_balance_before, etc.
6. VALIDATE     : isFraud IN (0,1), type IN valid_types → else dq_flag=1

### silver.customer_daily_balance (Cumulative)
Input  : silver.transactions (aggregated per sender_id per transaction_day)
Output : silver.customer_daily_balance (Delta Lake — MERGE)

Logic:
1. Aggregate today's data:
   daily_summary = silver.transactions
     GROUP BY sender_id, transaction_day
     AGG: SUM(amount) as daily_sent, COUNT(*) as daily_count,
          SUM(is_fraud) as daily_fraud, SUM(is_zero_out) as daily_zero_out,
          MAX(balance_drain_pct) as max_daily_drain

2. Delta Lake MERGE:
   ON (customer_id = daily_summary.sender_id AND balance_date = daily_summary.transaction_day)
   WHEN MATCHED → UPDATE daily columns + recalculate running totals
   WHEN NOT MATCHED → INSERT new row:
     running_txn_total   = yesterday.running_txn_total + daily_txn_count
     running_fraud_total = yesterday.running_fraud_total + daily_fraud_count
     running_fraud_amount = yesterday.running_fraud_amount + daily_fraud_amount
     (first appearance: running = daily values sahaja)

## Gold Layer (dbt)

### staging__paysim_transactions.sql
Input  : silver.transactions
Output : Clean source layer, rename, type confirm

### int_transactions_enriched.sql
Input  : staging__paysim_transactions
Logic  : Join dim_time, dim_transaction_type
Output : fact_transactions ready (with FKs)

### int_customer_daily_aggregates.sql
Input  : silver.customer_daily_balance
Logic  : Join dim_customer
Output : fact_customer_daily_balance ready

### mart_fraud_summary.sql
Input  : int_transactions_enriched + dim tables
Grain  : 1 row = 1 day + 1 transaction type
KPIs   : fraud_rate, fraud_amount, detection_rate, false_positive_rate

### mart_customer_risk.sql
Input  : int_customer_daily_aggregates
Grain  : 1 row = 1 customer per hari
KPIs   : zero_out_count, max_drain_velocity, running_fraud_total, is_high_risk

## Business Rules
- RULE 1 : Fraud HANYA valid untuk type IN ('TRANSFER', 'CASH-OUT')
           isFraud = 1 untuk PAYMENT/DEBIT/CASH-IN = data anomaly, flag sebagai dq_issue
- RULE 2 : balance_drain_pct = NULL kalau oldbalanceOrg = 0 (avoid divide by zero)
- RULE 3 : running totals carry forward dari previous hari — MERGE strategy
- RULE 4 : Merchant destination → receiver balance columns = NULL (not error)
- RULE 5 : is_high_risk = 1 BILA daily_zero_out_count > 0 OR max_daily_drain_pct > 95

## Error Handling
- NULL critical column → REJECT + quarantine + CRITICAL alert
- Divide by zero (balance_drain) → NULL, bukan error
- Duplicate transaction → keep latest ingestion_ts
- FK violation → quarantine + flag untuk DQS
- isFraud = 1 dalam non-TRANSFER/CASH-OUT → dq_flag = 1, INCLUDE in fact, flag untuk review
EOF

# =============================================================================
# docs/OPS_RUNBOOK.md
# =============================================================================

cat > docs/OPS_RUNBOOK.md << 'EOF'
# OPS Runbook: paysim-fraud-pipeline
> Status: DRAFT — Pending Phase 5 sign-off

## Monitoring
| Tool | Where |
|------|-------|
| Airflow | localhost:8080 |
| GX Report | docs/screenshots/gx_report.html |
| Snowflake | Snowflake UI → PAYSIM_FRAUD database |
| Slack | #paysim-fraud-alerts |
| Logs | airflow/logs/ |

## Alert SLAs
| Severity | Response |
|----------|----------|
| CRITICAL | 15 minit |
| HIGH | 1 jam |
| MEDIUM | Hari bekerja |

## Session Start Checklist
[ ] Databricks cluster running (CE — restart kalau terminated)
[ ] Airflow standalone running (airflow standalone)
[ ] .env loaded (source .env.dev)
[ ] S3 bucket accessible (aws s3 ls)
[ ] Snowflake connection OK (dbt debug)
[ ] PaySim CSV ada dalam data/ folder (dev: 1000 rows)

## Common Scenarios

### Bronze job fail
Symptom : bronze_ingest = FAILED
Check   : airflow/logs/paysim_fraud_pipeline/bronze_ingest/
Fix 1   : CSV missing → check data/ folder atau S3 path
Fix 2   : S3 permission → check AWS credentials .env
Rerun   : Airflow UI → Clear task → Trigger DAG

### Silver GX CRITICAL fail (row count)
Symptom : silver_dq_check = FAILED, row count mismatch
Check   : docs/screenshots/gx_report.html
Fix 1   : Bronze corrupt → rerun bronze dari CSV
Fix 2   : PySpark OOM → Databricks CE memory issue, reduce partition size
Decision: Rerun dengan smaller chunk kalau memory issue

### Cumulative MERGE fail
Symptom : silver_cumulative_merge = FAILED
Check   : Delta Lake transaction log
Fix 1   : Concurrent write conflict → retry once
Fix 2   : Schema mismatch → check silver.transactions schema berubah
Fix 3   : CE cluster terminated mid-run → restart cluster, rerun dari silver_cumulative_merge

### Databricks cluster terminated (auto-terminate 2 jam)
Symptom : Silver/Gold fail mid-run
Fix     : CE UI → restart cluster → rerun task dari Airflow
Prevent : Monitor job duration, checkpoint setiap 30 minit

### dbt test fail (FK violation)
Symptom : gold_dbt_test = FAILED
Check   : dbt test output dalam Airflow logs
Fix 1   : dim tables tak populate → rerun int_ models dulu
Fix 2   : Silver quarantine ada rows → check data_quality/quarantine table
Fix 3   : Merchant FK NULL → confirm is_merchant_dest logic correct

## Backfill Procedure
1. Identify affected transaction_day range
2. Delete Silver partition: DELETE FROM silver.transactions WHERE transaction_day = X
3. Rerun: bronze_ingest → silver_transform → silver_cumulative_merge → silver_dq_check → gold
4. Verify reconciliation: Bronze count = Silver count (excluding quarantine)
5. Log dalam JOURNEY_LOG.md

## PaySim-Specific Notes
- Fraud HANYA berlaku dalam TRANSFER dan CASH-OUT — kalau fraud dalam type lain, flag sebagai data issue bukan pipeline issue
- Merchant balance = 0 adalah EXPECTED — jangan alert
- Class imbalance 0.13% adalah EXPECTED — GX configured untuk accept ini
- step column = simulated time, bukan real timestamp
EOF

# =============================================================================
# PROJECT_STATUS.md
# =============================================================================

cat > PROJECT_STATUS.md << EOF
# PROJECT_STATUS.md — paysim-fraud-pipeline
Last updated : $(date +%Y-%m-%d)
Current phase: Phase 0 — Setup Complete
Modelling    : Hybrid (Kimball + Cumulative) | Domain: fintech

---

## Phase Overview
| Phase | Document | Status | Sign-off Date |
|-------|----------|--------|---------------|
| 0 | Setup | ✅ Done | $(date +%Y-%m-%d) |
| 1 | BRD | ⏳ | - |
| 2 | DRD + Data Dictionary + Data Model (Conceptual) | ⏳ | - |
| 3 | Architecture + SPEC + Data Model (Logical) | ⏳ | - |
| 4a | CODE — local dev | ⏳ | - |
| 4b | CODE — cloud promote | ⏳ | - |
| 5 | DQD + OPS | ⏳ | - |

---

## Next Step When Resuming
1. Prompt: "Baca CLAUDE.md dan PROJECT_STATUS.md. Start Phase 1 — BRD."
2. Agents: BA, PO, PM, DQS
3. Deliverable: docs/BRD.md signed off

---

## Hard Blockers Tracker
| Blocker | Phase | Resolved? |
|---------|-------|-----------|
| Grain fact_transactions defined | 2→3 | ✅ Done — 1 row = 1 txn |
| Grain fact_customer_daily_balance defined | 2→3 | ✅ Done — 1 row = 1 customer per hari |
| DA + DPE sync cumulative feasibility | 2→3 | ✅ Done — CE 15GB feasible (simple schema) |
| DATA_MODEL.md signed off | 3→4 | ⏳ |
| SCD Type 1 confirmed all dims | 3→4 | ⏳ |
| Unit tests pass | 4a→4b | ⏳ |

---

## Decisions Made (Phase 0)
| Decision | Reason |
|----------|--------|
| Modelling: Hybrid | Kimball untuk fraud KPIs + Cumulative untuk running totals |
| Cloud: AWS | Resume alignment — S3 + Glue dalam stack |
| SCD: Type 1 semua | Synthetic data — customer attributes tak berubah |
| Cumulative strategy: Delta MERGE | Platform-native, no complex Array of Struct |
| Fraud scope: TRANSFER + CASH-OUT only | PaySim domain knowledge — fraud pattern specific |

---

## Known Pre-Flagged Issues (DQS pre-phase)
| Issue | Decision |
|-------|----------|
| Merchant balance = 0 | Expected — document sahaja |
| isFlaggedFraud ≠ isFraud | KPI metric — compute discrepancy |
| Class imbalance 0.13% | GX range 0.10%–0.20% configured |
| Fraud hanya TRANSFER + CASH-OUT | Filter dalam Silver, document dalam SPEC |
EOF

echo "✅ All docs created"

# =============================================================================
# COST_LOG.md
# =============================================================================

cat > COST_LOG.md << 'EOF'
# Cost Log: paysim-fraud-pipeline
> Updated by FinOps setiap phase.

## Token Usage
| Phase | Sonnet | Haiku | Est. Cost |
|-------|--------|-------|-----------|
| 0 — Setup | 1 session | - | ~$0.05 |
| 1 — BRD | - | - | $0.00 |
| 2 — DRD | - | - | $0.00 |
| 3 — Architecture | - | - | $0.00 |
| 4 — CODE | - | - | $0.00 |
| 5 — DQD+OPS | - | - | $0.00 |
| Total | | | ~$0.05 |

## Cloud Usage
| Service | Used | Limit | Remaining |
|---------|------|-------|-----------|
| S3 | 0 GB | 5 GB | 5 GB |
| Glue DPU | 0 | 1M | 1M |
| Databricks CE | 0 hrs | Free | - |
| Snowflake | $0 | $400 | $400 |

## Flags
- [ ] S3 >4GB → cleanup dev files
- [ ] Glue >800K DPU → monitor closely
- [ ] Snowflake <$50 remaining → alert
- [ ] Databricks idle >30min → terminate cluster
- [ ] PaySim CSV 470MB → upload ke staging S3 sahaja bila ready
EOF

# =============================================================================
# sign-offs/SIGN_OFF_LOG.md
# =============================================================================

cat > sign-offs/SIGN_OFF_LOG.md << 'EOF'
# Sign-off Log: paysim-fraud-pipeline

## Phase 0 — Setup
Date: 2026-05-11 | Status: ✅ DONE
- Scaffold complete
- CLAUDE.md filled dengan PaySim context
- setup.sh generated
- All placeholder docs created
- Pre-flagged data issues documented

## Phase 1 — BRD
Date: | Status: PENDING
| Agent | Decision | Reason |
|-------|----------|--------|
| BA | PENDING | - |
| PO | PENDING | - |
| PM | PENDING | - |
| DQS | PENDING | - |

## Phase 2 — DRD + Data Dictionary + Data Model (Conceptual)
Date: | Status: PENDING
Hard Blockers:
[✅] Grain fact_transactions: 1 row = 1 txn
[✅] Grain fact_customer_daily_balance: 1 row = 1 customer per hari
[ ] DA + DPE formal sync sign-off
[ ] Upstream data issues strategy confirmed

## Phase 3 — Architecture + Data Model (Logical)
Date: | Status: PENDING
Hard Blockers:
[ ] DATA_MODEL.md signed off
[ ] SCD Type 1 confirmed
[ ] Cumulative MERGE strategy confirmed
[ ] Paradigm ADR approved (ADR-001)

## Phase 4a — CODE local
Date: | Status: PENDING

## Phase 4b — Cloud promote
Date: | Status: PENDING

## Phase 5 — DQD + OPS
Date: | Status: PENDING
EOF

# =============================================================================
# requirements.txt
# =============================================================================

cat > requirements.txt << 'EOF'
# paysim-fraud-pipeline dependencies

# Core
pyspark==3.5.0
pandas==2.1.0
python-dotenv==1.0.0
delta-spark==3.0.0

# Quality
great-expectations==0.18.0

# Airflow
apache-airflow==2.8.0
apache-airflow-providers-slack==8.0.0
apache-airflow-providers-amazon==8.0.0
apache-airflow-providers-databricks==6.0.0
apache-airflow-providers-snowflake==5.0.0

# Snowflake
snowflake-connector-python==3.6.0
snowflake-sqlalchemy==1.5.0

# dbt
dbt-core==1.7.0
dbt-snowflake==1.7.0

# AWS
boto3==1.34.0

# Testing
pytest==7.4.0
pytest-cov==4.1.0

# Utils
PyYAML==6.0.1
hashlib2==1.0.0
EOF

# =============================================================================
# README.md
# =============================================================================

cat > README.md << 'EOF'
# paysim-fraud-pipeline

Fintech data engineering portfolio pipeline — PaySim1 Fraud Detection.

Mendetect fraud transactions dan account drain patterns dari 6.3 juta mobile money transactions menggunakan end-to-end medallion architecture.

## Problem Statement
- **Fraud Intelligence**: Detect, report, dan quantify fraud transactions (0.13% dari 6.3M txn)
- **Account Drain Detection**: Identify suspicious zero-out events dan balance drain patterns
- **System Evaluation**: Assess accuracy original fraud flagging heuristic vs actual fraud labels

## Data Model — Hybrid
| Table | Paradigm | Grain |
|-------|----------|-------|
| fact_transactions | Kimball Star Schema | 1 row = 1 transaksi |
| fact_customer_daily_balance | Cumulative Table | 1 row = 1 customer per hari |

## Tech Stack
| Layer | Tool |
|-------|------|
| Storage | AWS S3 + Delta Lake |
| Silver | PySpark + Databricks CE |
| Gold | dbt Core + Snowflake |
| Orchestration | Apache Airflow |
| Quality | Great Expectations |
| BI | Power BI |

## Architecture
```
PaySim1 CSV (6.3M rows, ~470MB)
    ↓ Python + boto3
AWS S3 Landing Zone
    ↓ Delta Lake
Bronze (raw + metadata)
    ↓ PySpark + Databricks
Silver (enriched + cumulative MERGE)
    ↓ dbt Core
Gold (Snowflake: mart_fraud_summary + mart_customer_risk)
    ↓
Power BI Fraud Dashboard
```

## Key KPIs
- Fraud rate: COUNT(isFraud=1) / COUNT(*) × 100
- Fraud detection rate: Flagged-and-fraud / Total fraud
- Balance drain velocity: amount / oldbalanceOrg × 100
- Running cumulative fraud total per customer

## Progress
| Phase | Document | Status |
|-------|----------|--------|
| 0 | Setup | ✅ |
| 1 | BRD | ⏳ |
| 2 | DRD + Data Model | ⏳ |
| 3 | Architecture + SPEC | ⏳ |
| 4 | CODE + Evidence | ⏳ |
| 5 | DQD + OPS | ⏳ |

## Pipeline Evidence
*(Updated Phase 4b)*

### Airflow DAG
![airflow](docs/screenshots/airflow_dag_success.png)

### GX Validation Report
![gx](docs/screenshots/gx_validation_report.png)

### Snowflake Gold Layer
![snowflake](docs/screenshots/snowflake_gold_table.png)

### Slack Alert
![slack](docs/screenshots/slack_alert_success.png)

## Project Structure
```
paysim-fraud-pipeline/
├── docs/
│   ├── BRD.md
│   ├── DRD.md
│   ├── DATA_DICTIONARY.md
│   ├── DATA_MODEL.md
│   ├── ARCHITECTURE.md
│   ├── PIPELINE_SPEC.md
│   ├── DQD.md
│   ├── OPS_RUNBOOK.md
│   ├── ADR/
│   │   └── ADR-001-hybrid-paradigm.md
│   └── screenshots/
├── bronze/
├── silver/
├── gold/
│   ├── dbt_models/
│   │   ├── staging/
│   │   ├── intermediate/
│   │   └── marts/
│   └── profiles.yml
├── data_quality/
├── airflow/dags/
│   └── paysim_fraud_pipeline.py
├── tests/
└── infrastructure/
```

---
*Stack: Resume Raja Ahmad Luqman — fintech portfolio*
EOF

# =============================================================================
# Git init + initial commit
# =============================================================================

git init

git add \
  .gitignore \
  .env.example \
  .mcp.json \
  docs/BRD.md \
  docs/DRD.md \
  docs/DATA_DICTIONARY.md \
  docs/DATA_MODEL.md \
  docs/PIPELINE_SPEC.md \
  docs/ARCHITECTURE.md \
  docs/DQD.md \
  docs/OPS_RUNBOOK.md \
  docs/ADR/ \
  airflow/dags/paysim_fraud_pipeline.py \
  gold/profiles.yml \
  README.md \
  requirements.txt

git commit -m "[Phase 0] paysim-fraud-pipeline — fintech fraud detection initialized | Hybrid (Kimball + Cumulative) | AWS"

echo ""
echo "=========================================="
echo "✅ paysim-fraud-pipeline — scaffold complete!"
echo "=========================================="
echo ""
echo "Domain    : fintech"
echo "Dataset   : PaySim1 — 6.3M rows"
echo "Modelling : Hybrid — Kimball + Cumulative Table"
echo "Cloud     : AWS (S3 + Glue)"
echo "Docs      : 9 placeholder files (pre-filled untuk PaySim)"
echo "ADR       : ADR-001 Hybrid paradigm decision"
echo ""
echo "Next steps:"
echo "  1. cp CLAUDE.md [project folder]/"
echo "  2. Fill .env.example → cp .env.example .env.dev"
echo "  3. Download PaySim1 CSV dari Kaggle → data/"
echo "  4. code ."
echo "  5. Claude Code: 'Baca CLAUDE.md dan PROJECT_STATUS.md. Start Phase 1 — BRD.'"
echo ""
