"""
Bronze ingestion: PaySim1 CSV → Delta Lake
dev     : local CSV → data/bronze/transactions/ (PySpark local mode)
staging : S3 CSV → s3a://bucket/bronze/transactions/
prod    : S3 CSV → s3a://bucket/bronze/transactions/

Adds metadata columns: ingestion_ts, source_system, batch_id, source_file
Partitions by: transaction_day = CEIL(step / 24)
"""

import os
import logging
from pathlib import Path
from datetime import datetime

from dotenv import load_dotenv

log = logging.getLogger(__name__)


def _load_env():
    env = os.getenv("ENV", "dev")
    env_file = f".env.{env}"
    if Path(env_file).exists():
        load_dotenv(env_file)
    elif Path(".env").exists():
        load_dotenv(".env")
    return env


def _get_spark(env: str):
    from pyspark.sql import SparkSession
    from delta import configure_spark_with_delta_pip

    builder = (
        SparkSession.builder
        .appName("paysim-bronze-ingest")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .master("local[*]")
    )

    if env in ("staging", "prod"):
        aws_key = os.getenv("AWS_ACCESS_KEY_ID", "")
        aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY", "")
        region = os.getenv("AWS_REGION", "ap-southeast-1")
        builder = (
            builder
            .config("spark.hadoop.fs.s3a.access.key", aws_key)
            .config("spark.hadoop.fs.s3a.secret.key", aws_secret)
            .config("spark.hadoop.fs.s3a.endpoint", f"s3.{region}.amazonaws.com")
            .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        )

    return configure_spark_with_delta_pip(builder).getOrCreate()


def _get_paths(env: str, source_path: str) -> tuple[str, str]:
    if env == "dev":
        return source_path, "data/bronze/transactions"
    bucket = os.getenv(f"S3_BUCKET_{env.upper()}")
    if not bucket:
        raise EnvironmentError(f"S3_BUCKET_{env.upper()} not set in env")
    return source_path, f"s3a://{bucket}/bronze/transactions"


def run():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    env = _load_env()
    source_path = os.getenv("DATASET_SOURCE_PATH")
    if not source_path:
        raise EnvironmentError(
            "DATASET_SOURCE_PATH not set — run: python bronze/download_dataset.py --env dev"
        )

    batch_id = os.getenv("AIRFLOW_CTX_DAG_RUN_ID",
                         datetime.utcnow().strftime("manual_%Y%m%d_%H%M%S"))

    src, bronze_path = _get_paths(env, source_path)
    log.info(f"[Bronze] env={env} | source={src} | output={bronze_path}")

    spark = _get_spark(env)
    spark.sparkContext.setLogLevel("WARN")

    try:
        from pyspark.sql import functions as F

        df = (
            spark.read
            .option("header", "true")
            .option("inferSchema", "true")
            .csv(src)
        )
        source_count = df.count()
        log.info(f"[Bronze] Source rows: {source_count:,}")

        df = (
            df
            .withColumn("ingestion_ts", F.current_timestamp())
            .withColumn("source_system", F.lit("paysim1_kaggle"))
            .withColumn("batch_id", F.lit(batch_id))
            .withColumn("source_file", F.lit(src))
            .withColumn("transaction_day", F.ceil(F.col("step").cast("int") / 24).cast("int"))
        )

        (
            df.write
            .format("delta")
            .mode("overwrite")
            .partitionBy("transaction_day")
            .save(bronze_path)
        )

        log.info(f"[Bronze] Written {source_count:,} rows → {bronze_path}")
        return {"status": "success", "source_count": source_count, "output_path": bronze_path}

    finally:
        spark.stop()


if __name__ == "__main__":
    result = run()
    print(f"\nBronze ingest complete: {result}")
