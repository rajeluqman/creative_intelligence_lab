"""
WHAT : Download dataset dari Kaggle API ikut environment
WHY  : Automate dataset acquisition — tak perlu manual download
WHEN : Run sekali sebelum pipeline start

Environment behaviour:
  dev     → download → sample [DEV_SAMPLE_ROWS] rows → local data/ ONLY (no cloud)
  staging → download → full dataset → upload S3 landing zone
  prod    → download → full dataset → upload S3 prod

Stack boundary (docs/ARCHITECTURE.md, ADR-001): storage is AWS S3 only. An Azure ADLS upload
path (upload_to_adls, gated by a CLOUD=azure env var) existed here pre-retrofit but was never
invoked by the Airflow DAG or any other automated path — removed 2026-06-29 rather than kept
as unreachable dead code (DECISION_LOG.md).

Usage:
  python bronze/download_dataset.py --env dev
  python bronze/download_dataset.py --env dev --rows 5000
  python bronze/download_dataset.py --env staging
  python bronze/download_dataset.py --env prod
"""

import os
import argparse
import logging
from pathlib import Path
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


def load_env(env: str):
    """
    WHAT : Load .env file ikut environment
    WHY  : Setiap env ada credentials berbeza
    WHEN : First step sebelum any operation
    """
    env_file = f".env.{env}"
    if not Path(env_file).exists():
        if Path(".env").exists():
            load_dotenv(".env")
            log.warning(f"{env_file} tidak wujud — using .env instead")
            return
        raise FileNotFoundError(
            f"{env_file} tidak wujud.\n"
            f"Run: cp .env.example {env_file} dan fill in credentials."
        )
    load_dotenv(env_file)
    log.info(f"Loaded {env_file}")


def validate_kaggle_credentials():
    """
    WHAT : Validate KAGGLE_USERNAME dan KAGGLE_KEY ada dalam env
    WHY  : Fail fast — jangan proceed kalau credentials missing
    WHEN : Sebelum kaggle API call
    """
    username = os.getenv("KAGGLE_USERNAME")
    key = os.getenv("KAGGLE_KEY")
    if not username or not key:
        raise EnvironmentError(
            "KAGGLE_USERNAME dan KAGGLE_KEY mesti diset dalam .env.\n"
            "Setup: https://www.kaggle.com/settings → API → Create New Token"
        )
    os.environ["KAGGLE_USERNAME"] = username
    os.environ["KAGGLE_KEY"] = key
    log.info(f"Kaggle credentials validated — user: {username}")


def download_dataset(dest_dir: str = "data") -> str:
    """
    WHAT : Download dataset dari Kaggle
    WHY  : Single source — semua env download dari Kaggle
    WHEN : Run sekali, skip kalau file dah ada
    Returns: local path to downloaded CSV file
    """
    import kaggle

    dataset_slug = os.getenv("KAGGLE_DATASET")
    filename = os.getenv("KAGGLE_FILENAME")

    if not dataset_slug or not filename:
        raise EnvironmentError(
            "KAGGLE_DATASET dan KAGGLE_FILENAME mesti diset dalam .env.\n"
            "Contoh:\n  KAGGLE_DATASET=ealaxi/paysim1\n  KAGGLE_FILENAME=PS_log.csv"
        )

    dest_path = Path(dest_dir)
    dest_path.mkdir(parents=True, exist_ok=True)
    file_path = dest_path / filename

    if file_path.exists():
        size_mb = file_path.stat().st_size / (1024 * 1024)
        log.info(f"Dataset dah ada: {file_path} ({size_mb:.1f} MB) — skip download")
        return str(file_path)

    log.info(f"Downloading {dataset_slug} dari Kaggle...")
    kaggle.api.dataset_download_files(dataset_slug, path=str(dest_path), unzip=True)

    if not file_path.exists():
        raise FileNotFoundError(
            f"Download selesai tapi {filename} tidak dijumpai dalam {dest_path}.\n"
            "Check KAGGLE_FILENAME — mesti exact match dengan filename dalam dataset zip."
        )

    size_mb = file_path.stat().st_size / (1024 * 1024)
    log.info(f"Download complete — {file_path} ({size_mb:.1f} MB)")
    return str(file_path)


def sample_dev_data(source_path: str, rows: int) -> str:
    """
    WHAT : Sample N rows dari full dataset untuk dev
    WHY  : Full dataset terlalu besar untuk dev — sample cukup untuk unit test
    WHEN : Dev environment SAHAJA
    Returns: path to sampled CSV
    """
    import pandas as pd

    source = Path(source_path)
    sample_path = source.parent / f"{source.stem}_dev_{rows}rows.csv"

    if sample_path.exists():
        log.info(f"Dev sample dah ada: {sample_path} — skip sampling")
        return str(sample_path)

    log.info(f"Sampling {rows} rows dari {source}...")
    df = pd.read_csv(source, nrows=rows)
    df.to_csv(sample_path, index=False)
    log.info(f"Dev sample saved: {sample_path} ({len(df)} rows)")
    return str(sample_path)


def upload_to_s3(local_path: str, env: str) -> str:
    """
    WHAT : Upload dataset ke S3 landing zone
    WHY  : S3 = single source of truth untuk AWS staging/prod pipeline
    WHEN : Staging + prod environment dengan CLOUD=aws
    Returns: s3:// path
    """
    import boto3

    bucket = os.getenv(f"S3_BUCKET_{env.upper()}")
    region = os.getenv("AWS_REGION", "ap-southeast-1")

    if not bucket:
        raise EnvironmentError(f"S3_BUCKET_{env.upper()} tidak diset dalam .env.{env}")

    filename = Path(local_path).name
    s3_key = f"landing/{filename}"
    s3_path = f"s3://{bucket}/{s3_key}"

    s3 = boto3.client("s3", region_name=region)

    # Skip upload kalau file dah ada dengan same size — jimat S3 PUT cost
    try:
        response = s3.head_object(Bucket=bucket, Key=s3_key)
        if response["ContentLength"] == Path(local_path).stat().st_size:
            log.info(f"File dah ada dalam S3 dengan size sama — skip upload: {s3_path}")
            return s3_path
    except Exception:
        pass

    log.info(f"Uploading {local_path} → {s3_path}")
    s3.upload_file(local_path, bucket, s3_key)
    log.info(f"Upload complete → {s3_path}")
    return s3_path


def main():
    parser = argparse.ArgumentParser(
        description="Download dataset dari Kaggle ikut environment",
        epilog="dev=local sample only | staging/prod=full dataset → S3"
    )
    parser.add_argument("--env", default="dev", choices=["dev", "staging", "prod"])
    parser.add_argument("--rows", type=int, default=None,
                        help="Override sample rows untuk dev (default: DEV_SAMPLE_ROWS dari .env)")
    args = parser.parse_args()

    log.info(f"=== Dataset Acquisition — env: {args.env} ===")

    load_env(args.env)
    validate_kaggle_credentials()

    csv_path = download_dataset(dest_dir="data/raw")

    if args.env == "dev":
        # Dev = local sample sahaja, NO cloud storage
        dev_rows = args.rows or int(os.getenv("DEV_SAMPLE_ROWS", "1000"))
        log.info(f"Dev mode — sampling {dev_rows} rows, local only (no cloud)")
        Path("data/dev").mkdir(parents=True, exist_ok=True)
        csv_path = sample_dev_data(csv_path, rows=dev_rows)
        log.info(f"=== Done — dev dataset: {csv_path} ===")
        log.info(f"Set DATASET_SOURCE_PATH={csv_path} dalam .env.dev")
    else:
        # Staging/prod = full dataset → S3 (the locked stack — docs/ARCHITECTURE.md)
        log.info(f"{args.env} mode — full dataset, uploading ke S3...")
        cloud_path = upload_to_s3(csv_path, env=args.env)
        log.info(f"=== Done — {args.env} dataset: {cloud_path} ===")
        log.info(f"Set DATASET_SOURCE_PATH={cloud_path} dalam .env.{args.env}")


if __name__ == "__main__":
    main()
