# Cost Log — Paysim Fraud Pipeline

> Estimates only. Never commit real account-linked $ figures or billing exports.

## AWS S3
| Resource | Free-tier allowance | This repo's usage pattern | Risk |
|---|---|---|---|
| S3 storage | 5 GB (free tier, per `docs/ARCHITECTURE.md`) | Landing CSV (~470MB) + Bronze Delta (`bronze.transactions`) + Silver Delta (`silver.transactions`, `silver.customer_daily_balance`) + Parquet bridge export | Moderate — full 6.3M-row dataset's Delta overhead estimated ~1.5GB staging; cumulative table un-VACUUMed could reach ~7.75GB (31 daily versions) — `silver/cumulative_pipeline.py`'s mandatory `VACUUM RETAIN 7 DAYS` is the mitigation, watch its try/finally log line |

## Databricks
| Resource | Tier | Usage | Risk |
|---|---|---|---|
| Compute | Databricks Trial workspace, ~15GB driver (Standard_DS3_v2/r4.large class) | Staging-promote run via `silver/databricks_notebook.py` — Bronze ingest, Silver transform, cumulative Delta MERGE (peak ~5.5GB per the notebook's memory guidance) | The Airflow DAG's automated path runs the SAME `silver/*.py` modules as local PySpark, not via Databricks job submission — Databricks cost is only incurred during the manual staging-promote notebook run, not on every `@daily` DAG tick |

## Snowflake
| Resource | Tier | Usage | Risk |
|---|---|---|---|
| Compute | XS warehouse (`gold/profiles.yml` target) | `dbt build` staging → intermediate → marts (2 facts: Kimball `fact_transactions` + cumulative `fact_customer_daily_balance`) | `silver/databricks_to_snowflake.py` explicitly calls `ALTER WAREHOUSE ... SUSPEND` after load — confirm this still runs on every bridge invocation, since a warehouse left running is the single biggest portfolio-project cost leak (README estimates <$5 for a full run) |

## Status
Pipeline is **finished** (Phases 0–5 ✅ per README.md "Phase Completion", staging run evidence
2026-05-12) — this log documents the allowance ceilings the stack was sized against, not live
billing data (no real account-linked cost export exists in this repo and none should be
committed here).
