#!/usr/bin/env python3
"""Governance hook — makes Claude check governed docs/ADRs BEFORE and AFTER touching governed
files. Ported from creative_intelligence_lab / home-credit-pipeline / olist-ecommerce-pipeline's
hook of the same name (pipeline-retrofit effort); retargeted to THIS repo's real files
(PySpark/Delta Lake + dbt/Snowflake hybrid grain, not Glue/DuckDB or ADLS/Databricks-only).

Wired in .claude/settings.json for Edit|Write|MultiEdit:
  • PreToolUse  → inject a "STOP, read these docs first" reminder when the target file is
                  under governance (non-blocking context nudge).
  • PostToolUse → auto-run the matching contract test(s) after the edit; exit 2 with the
                  failure so Claude is FORCED to see and fix it (hard block).

Three contracts, two owners (CLAUDE.md governance axes):
  - tests/identity_contract.py  — @data-architect, dual-grain fidelity (Kimball
                                   fact_transactions + cumulative-table fact_customer_daily_balance)
  - tests/boundary_contract.py  — @scope-guardian (PySpark/Delta on local-or-Databricks,
                                   Snowflake-only Gold, no new ingestion connectors)
  - tests/doc_reference_contract.py — @documentation-sherpa (no model/path drift in docs/ADR)

Stdlib only. Never crashes the tool call on its own bug (any internal error → exit 0).
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent.parent

IDENTITY_MSG = (
    "fact_transactions = Kimball grain (transaction_id, 1 row = 1 txn); "
    "fact_customer_daily_balance = cumulative-table grain (customer_id + balance_date), built "
    "by idempotent Delta MERGE in silver/cumulative_pipeline.py — running totals from "
    "yesterday's row, never the matched row (ADR-001 + docs/DATA_MODEL.md)."
)
BOUNDARY_MSG = (
    "Bronze/Silver compute = PySpark + Delta Lake (local or Databricks) only; Gold compute = "
    "Snowflake/dbt only (no DuckDB/BigQuery/Postgres adapter); no new ingestion connector "
    "beyond the Kaggle API (docs/ARCHITECTURE.md)."
)
ERD_MSG = "Hybrid doctrine: 1 table = 1 grain = 1 entity, two grains locked side by side (ADR-001)."
WARN_MSG = (
    "Silver suite is 14/15 with 1 documented WARN (merchant_balance_null — expected anomaly, "
    "ADR-002). Don't silently flip this to 15/15 or leave it unattributed."
)

# (path substring, docs to cite, reminder message, contract scripts to run post-edit)
RULES: list[tuple[str, str, str, tuple[str, ...]]] = [
    ("gold/models/marts/", "ADR-001 + docs/DATA_MODEL.md (.claude/agents/data-architect.md)", ERD_MSG, ("identity_contract.py", "doc_reference_contract.py")),
    ("silver/cumulative_pipeline.py", "ADR-001 + docs/DATA_MODEL.md (MERGE idempotency)", IDENTITY_MSG, ("identity_contract.py",)),
    ("data_quality/run_silver_suite.py", "ADR-002 + docs/DQD.md", WARN_MSG, ("doc_reference_contract.py",)),
    ("gold/profiles.yml", "docs/ARCHITECTURE.md — Snowflake is the sole Gold compute target", BOUNDARY_MSG, ("boundary_contract.py",)),
    ("gold/dbt_project.yml", "docs/ARCHITECTURE.md stack boundary", BOUNDARY_MSG, ("boundary_contract.py",)),
    ("airflow/dags/", "docs/ARCHITECTURE.md + docs/PIPELINE_SPEC.md (DAG chaining)", BOUNDARY_MSG, ("boundary_contract.py",)),
    ("requirements.txt", "docs/ARCHITECTURE.md stack boundary (no compute outside PySpark/Databricks, no non-Snowflake dbt adapter)", BOUNDARY_MSG, ("boundary_contract.py",)),
    ("docs/ADR/", "ADR numbering + docs/DATA_MODEL.md cross-references", ERD_MSG, ("doc_reference_contract.py",)),
    ("docs/DATA_MODEL.md", "ADR-001 grain doctrine", ERD_MSG, ("doc_reference_contract.py",)),
]


def _rel(path: str) -> str:
    try:
        return str(Path(path).resolve().relative_to(REPO))
    except (ValueError, OSError):
        return path or ""


def _matches(rel: str) -> list[tuple[str, str, str, tuple[str, ...]]]:
    return [r for r in RULES if r[0] in rel]


def main() -> int:
    try:
        data = json.load(sys.stdin)
    except (json.JSONDecodeError, ValueError):
        return 0

    event = data.get("hook_event_name", "")
    rel = _rel((data.get("tool_input") or {}).get("file_path", ""))
    matches = _matches(rel)
    if not matches:
        return 0

    if event == "PreToolUse":
        lines = [f"⚠️ GOVERNED FILE: {rel} is under governance. Before editing, confirm against:"]
        for _, docs, msg, _ in matches:
            lines.append(f"  - {docs}: {msg}")
        print(json.dumps({"hookSpecificOutput": {"hookEventName": "PreToolUse", "additionalContext": "\n".join(lines)}}))
        return 0

    if event == "PostToolUse":
        contracts: list[str] = []
        for _, _, _, scripts in matches:
            for s in scripts:
                if s not in contracts:
                    contracts.append(s)

        failures = []
        for script in contracts:
            proc = subprocess.run(
                [sys.executable, str(REPO / "tests" / script)],
                capture_output=True,
                text=True,
            )
            if proc.returncode != 0:
                failures.append(f"--- {script} ---\n{proc.stdout}{proc.stderr}")

        if failures:
            sys.stderr.write("Contract check FAILED after your edit — fix before continuing:\n" + "\n".join(failures))
            return 2  # feeds stderr back to Claude as a blocking error
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:  # never let a hook bug break the user's tool call
        raise SystemExit(0)
