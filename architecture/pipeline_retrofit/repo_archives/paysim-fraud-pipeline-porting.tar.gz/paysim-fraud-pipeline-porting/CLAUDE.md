# Paysim Fraud Pipeline — AI Context

> Auto-loaded by Claude Code every session. Governance framework ported from
> `creative_intelligence_lab` (CIL) per the pipeline-retrofit effort (repo 3 of 4, after
> home-credit-pipeline and olist-ecommerce-pipeline) — see `architecture/pipeline_retrofit/`
> in CIL for provenance. Stack is UNCHANGED by the retrofit: this file documents the repo as
> it actually is (verified by reading `bronze/`, `silver/`, `gold/`, `airflow/`,
> `data_quality/`, `requirements.txt`), not a stack swap.

## 🛑 STOP-GATE — read before ANY model/schema/identity work
This repo is governed. Before you edit a dbt mart model, the Silver cumulative MERGE transform,
a seed/source, or before you "proceed" past a grain/identity question — you MUST:
1. **Open the governing doc first.** Grain/hybrid paradigm → ADR-001-hybrid-paradigm.md +
   `docs/DATA_MODEL.md`. The Silver GX WARN decision → ADR-002-silver-warn-acceptance.md.
   Stack boundary (S3 + PySpark/Delta on Databricks, Snowflake Gold-only) → `docs/ARCHITECTURE.md`
   + `tests/boundary_contract.py`.
2. **Validate identity BEFORE building downstream.** This repo runs TWO grains side by side
   (ADR-001): `fact_transactions` is Kimball (1 row = 1 transaction, `transaction_id` =
   MD5(nameOrig+step+amount)); `fact_customer_daily_balance` is a **cumulative table**
   (1 row = 1 customer per simulated day, `customer_id + balance_date`), built by Delta Lake
   MERGE in `silver/cumulative_pipeline.py` and carried into
   `gold/models/intermediate/int_cumulative_customer_balance.sql` →
   `gold/models/marts/mart_customer_risk.sql`. Run `python tests/identity_contract.py` and
   `python tests/boundary_contract.py` before calling any Silver/mart change done — these are
   the binding checks, not your judgement.
3. **If a rule and the request conflict, STOP and surface it** — do not silently proceed.
   Mixed-grain dimension, compute outside Databricks/Snowflake, a non-Snowflake dbt target, a
   new ingestion connector beyond the Kaggle API → name it, cite the doc, and ask
   @data-architect / @scope-guardian before writing code.

Enforced three ways: this prompt (soft), `.claude/hooks/governance_guard.py` (blocks edits to
governed files without a context nudge), and CI (`tests/identity_contract.py` +
`tests/boundary_contract.py` + `tests/doc_reference_contract.py`, blocks the PR).

## 🔁 ANTI-SHORTCUT PROTOCOL — read-before-touch, reconcile-before-done
1. **Read-before-touch** — never edit or assert about a file from memory; read it THIS turn.
2. **Enumerate, don't sample** — for "all N models/checks" tasks, get N from `ls`/`grep` BEFORE
   acting (3 dbt layers → 2 staging + 3 intermediate + 2 marts models; Bronze GX 10 checks,
   Silver GX 15 checks — verify the count, don't recall it).
3. **Reconcile-before-done** — before saying done/fixed/green, restate the request as a
   numbered checklist with `file:line` evidence per item. No evidence = "unverified".
4. **Tag assumptions** — any unchecked load-bearing claim is marked "(unverified)"; any
   reconstructed rationale (no contemporaneous deliberation) is marked
   "(reconstructed — owner confirm)".

The machine half: `tests/doc_reference_contract.py` proves every model/path a doc references
actually exists. `scripts/gen_repo_map.py` generates `architecture/REPO_MAP.md` — a pointer
index, not a cache; it tells you which file to open, then you read that file fresh.

## Project Overview
**Domain**: Fintech / fraud detection.
**Problem**: Detect and quantify fraud in the PaySim1 synthetic dataset (6.3M mobile-money
transactions, 0.13% fraud) and evaluate the original `isFlaggedFraud` heuristic's detection
rate / false-positive rate, while also surfacing account-drain behavioral patterns
(TRANSFER→CASH-OUT sequences) per customer per day.
**Purpose**: Data Engineering portfolio project (single-dev, Raja Ahmad Luqman). This is a
**finished** pipeline (Phases 0–5 all ✅ per README.md "Phase Completion", staging run evidence
2026-05-12: 6,362,620 Bronze rows, dbt 49/49 tests) now getting a governance + learning layer
added — there is no further pipeline build scope here, only documentation/governance/learning
backfill.

## Stack (locked — unchanged by this retrofit, verified by reading the repo)
| Layer | Storage | Compute / engine | Notes |
|-------|---------|------------------|-------|
| Source | Kaggle API (PaySim1) | `bronze/download_dataset.py` | 6.3M rows, 471MB CSV, 11 columns |
| Landing | AWS S3 | — | free tier 5GB cap |
| Bronze | Delta Lake on S3 | PySpark local / on Databricks (`bronze/bronze_pipeline.py`) | ACID, time travel, `bronze.transactions` |
| Silver | Delta Lake on S3 | PySpark, same dual-mode (`silver/silver_pipeline.py`, `silver/cumulative_pipeline.py`) | dedup, type cast, derived cols, dq_flag bitmask, cumulative Delta MERGE (`fact_customer_daily_balance`) |
| Staging execution | — | **Databricks** (manual notebook, `silver/databricks_notebook.py`, cell-by-cell, full 6.3M rows) — separate from the Airflow path below | Airflow's `silver_transform`/`silver_cumulative_merge` tasks invoke the SAME `silver/*.py` modules directly as local PySpark; the Databricks notebook is the documented staging-promote run, not a second code path |
| Bridge | S3 Parquet **or** Databricks SQL Warehouse Arrow batch | `silver/export_to_s3_parquet.py` (Airflow DAG path) / `silver/databricks_to_snowflake.py` (alternate, `databricks-sql-connector` + `write_pandas()`) | two documented bridge methods — the DAG wires the Parquet+COPY INTO path |
| Gold/marts | Snowflake | dbt Core (`dbt-snowflake`), `gold/models/{staging,intermediate,marts}` | Hybrid: Kimball `fact_transactions` + Cumulative `fact_customer_daily_balance` |
| Quality | Great Expectations-style suites (hand-rolled PySpark checks) | `data_quality/run_bronze_suite.py` (10 checks), `data_quality/run_silver_suite.py` (15 checks, 14 PASS / 1 WARN — ADR-002) | per-layer gates, block Gold on CRITICAL |
| Orchestration | — | Apache Airflow standalone, `airflow/dags/paysim_fraud_pipeline.py` (`@daily`, full chain bronze→...→gold_dbt_test) | localhost:8080 |
| Alerting | Slack webhook | `airflow/dags/paysim_fraud_pipeline.py` `slack_success`/`slack_failure` callbacks (`SlackWebhookOperator`) | **already working — kept as-is, no backfill needed** (unlike olist/Volve) |
| Serving | reads Gold Snowflake | Power BI | Fraud Intelligence Dashboard |

⚠️ Stack boundary (ADR-001 + `docs/ARCHITECTURE.md`): **Bronze/Silver compute = PySpark + Delta
Lake, run locally or on Databricks** (`tests/boundary_contract.py` ST1 — no standalone Spark
cluster outside Databricks/local-dev). **Gold compute = Snowflake/dbt only** (no DuckDB/
BigQuery/Postgres dbt adapter, ST4). No Azure/ADLS, no MinIO, no dedicated vector DB, no new
ingestion connector beyond the Kaggle API (ST3).

## Architecture of Record
`docs/` — BRD.md, DRD.md, DATA_DICTIONARY.md, DATA_MODEL.md, ARCHITECTURE.md, PIPELINE_SPEC.md,
DQD.md, OPS_RUNBOOK.md, `ADR/` (ADR-001-hybrid-paradigm.md — sound, kept as-is; this retrofit
adds ADR-002-silver-warn-acceptance.md). `architecture/REPO_MAP.md` (generated, see above).

**Identity keys (dual-grain, ADR-001)**:
- `fact_transactions`: `transaction_id` = MD5(nameOrig + step + amount), Kimball grain, 1
  row = 1 transaction — `gold/models/staging/staging__paysim_transactions.sql` →
  `gold/models/intermediate/int_transactions_enriched.sql`.
- `fact_customer_daily_balance`: **cumulative-table grain**, 1 row = 1 customer per simulated
  day (`customer_id + balance_date`), built by idempotent Delta Lake MERGE in
  `silver/cumulative_pipeline.py` (`_merge_day`, running totals computed from yesterday's row,
  not the matched row — see its docstring for the idempotency guarantee), carried through
  `gold/models/intermediate/int_customer_daily_aggregates.sql` →
  `int_cumulative_customer_balance.sql` → `gold/models/marts/mart_customer_risk.sql`.

**Governance gate**: @data-architect holds veto on grain/model changes (hybrid paradigm
locked, ADR-001); @scope-guardian holds veto on stack/scope creep (no compute outside
PySpark-on-Databricks/Snowflake, no new ingestion connectors beyond the Kaggle API).

## Governed-file map
| Path | Governed by | Cite before editing |
|---|---|---|
| `gold/models/marts/` | @data-architect | ADR-001, `docs/DATA_MODEL.md` |
| `silver/cumulative_pipeline.py` (MERGE/idempotency logic) | @data-architect | ADR-001, `docs/DATA_MODEL.md` |
| `docs/DATA_MODEL.md` | @data-architect | grain/hybrid-paradigm doctrine |
| `docs/ADR/` | @data-architect + @documentation-sherpa | ADR numbering, cross-references |
| `gold/profiles.yml`, `gold/dbt_project.yml` | @scope-guardian | `docs/ARCHITECTURE.md` stack boundary |
| `airflow/dags/` | @scope-guardian + @data-platform-engineer | `docs/ARCHITECTURE.md`, `docs/PIPELINE_SPEC.md` |
| `requirements.txt` | @scope-guardian | stack boundary (no compute outside PySpark/Databricks, no non-Snowflake dbt adapter) |
| `data_quality/run_silver_suite.py` | @data-quality-steward | ADR-002 (the documented WARN), `docs/DQD.md` |

## Known resume↔repo mismatch (flagged, not silently fixed)
README states "Silver 14/15 (1 WARN documented)" without naming WHICH check is the WARN. Of
the three WARN-capable Silver checks (`merchant_balance_null`, `drain_pct_range`,
`fraud_rate_check`), `docs/DQD.md`'s "Known Expected Anomalies" section names "Merchant
balance = 0 → by design" as an expected, non-error pattern — this matches
`merchant_balance_null` (receiver-side balance fields are non-NULL-by-construction for
merchant destinations in the synthetic dataset, a MEDIUM-severity, log-only check per DQD).
ADR-002 formally accepts this as the documented WARN with written rationale rather than
fixing it (it is not a defect — see `data_quality/run_silver_suite.py`'s
`merchant_balance_null` check and ADR-002 for the full reasoning). See `INTERVIEW_GUIDE.md`
"Resume Claim ↔ Repo Evidence" for the reconciled wording.

## Cabinet (10 agents) — see `.claude/agents/`
**Veto holders**: @data-architect (Opus, grain/model) · @scope-guardian (Sonnet, stack/scope).
**Build**: @senior-data-engineer (dbt + Silver MERGE + Airflow, absorbs QA/orchestration) ·
@data-quality-steward (GX-style suites, owns the ADR-002 WARN decision) · @product-owner
(BRD/KPIs) · @business-analyst (DRD + resume-claim reconciliation) · @data-platform-engineer
(Airflow/Databricks/AWS infra, absorbs devops) · @documentation-sherpa (docs/ADR/REPO_MAP/
Confluence upkeep) · @finops-agent (Databricks CE + Snowflake $400 credit watch — same seat as
home-credit/Volve, paysim runs full 6.3M rows in staging so cost is a real concern).
**Teaching**: @cikgu (English-first, mental-model → ETL use-case → production bug → debug →
syntax LAST) — NOT a build agent; runs `learning/CURRICULUM.md` drills on `drill/*` branches,
never `main`.

Roster = 10 (per `01_OPUS_DECISIONS.md`: prior count 9 — no infra-reality-agent — +cikgu).

## What NOT to commit
`.env*`, `data/`, `*.parquet`/`*.csv` (except `gold/seeds/`), raw PaySim1 CSV, checkpoint.json,
`COST_LOG.md` if it ever contains real account IDs — keep cost figures estimate-only.

## Token Discipline
1. Checkpoint first: read `PROJECT_STATUS.md` "▶ RESUME HERE" before reading code.
2. Use `architecture/REPO_MAP.md` instead of re-grepping the whole repo for "where is X".
3. Read only files in the current module — max ~3 files/turn.
