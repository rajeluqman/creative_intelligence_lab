# paysim-fraud-pipeline

End-to-end fraud intelligence pipeline — PaySim1 synthetic dataset (6.3M mobile money transactions).

Built as a fintech data engineering portfolio project demonstrating **Hybrid Kimball + Cumulative Table** modelling across a full medallion architecture: Bronze → Silver → Gold → BI.

---

## Why This Pipeline Exists (Purpose)

A production-grade DE portfolio pipeline that turns the PaySim1 synthetic dataset (6.3M mobile
money transactions, fraud = 0.13%) into a **governed fraud-intelligence layer** a financial-crime
team could query — at a scale where query design actually matters.

- **Who consumes it:** a (simulated) **fraud / financial-crime analytics** team, via the BI layer
  over the Gold marts — not the raw 6.3M-row transaction log.
- **What decision it supports:** quantifying fraud by day × type, scoring **customer drain /
  TRANSFER→CASH-OUT risk**, and benchmarking the legacy `isFlaggedFraud` heuristic.
- **Why it's built this way:** a **hybrid grain** — Kimball `fact_transactions` for slice-and-dice
  + a **cumulative table** (`fact_customer_daily_balance`, idempotent Delta MERGE) so running
  customer risk totals are pre-computed instead of full-scanning 6.3M rows per query (ADR-001).

---

## Results & Evidence

> ⚠️ **Run-evidence partially captured.** The DQ pass counts below are real and documented; the
> ML/fraud-KPI outputs (detection rate, false-positive rate, mart row counts, BI screenshots) are
> **not yet captured in-repo** and are not fabricated here — they will be filled from a verified run.

What **is** verifiable today:

- **Scope:** PaySim1 — 6.3M transactions, 11 columns; fraud ≈ 0.13% of rows.
- **DQ (real, documented):** Bronze **10/10** pass; Silver **14/15** (1 WARN = `merchant_balance_null`,
  formally ACCEPTED in ADR-002 / `docs/DQD.md` as the "merchant balance = 0 by design" anomaly).
- **Model:** hybrid grain — `fact_transactions` (Kimball) + `fact_customer_daily_balance`
  (cumulative Delta MERGE), grains in `docs/DATA_MODEL.md`.

**Honesty note for reviewers:** the Silver "14/15 (1 WARN)" is attributed, not glossed over.
Full reconciliation: [`INTERVIEW_GUIDE.md`](INTERVIEW_GUIDE.md).

---

## Problem Statement

| Problem | Solution |
|---------|----------|
| Detect and quantify fraud transactions (0.13% of 6.3M rows) | `mart_fraud_summary` — fraud KPIs by day × transaction type |
| Identify account drain patterns and TRANSFER→CASH-OUT sequences | `mart_customer_risk` — cumulative customer risk profile |
| Evaluate original heuristic system (`isFlaggedFraud`) accuracy | Detection rate + false positive rate KPIs in Gold |

---

## Data Model — Hybrid Paradigm

| Table | Paradigm | Grain | Why |
|-------|----------|-------|-----|
| `fact_transactions` | Kimball Star Schema | 1 row = 1 transaction | Aggregate fraud KPIs — count, group, join dimensions |
| `fact_customer_daily_balance` | Cumulative Table (Delta MERGE) | 1 row = 1 customer per day | Running totals pre-computed — avoid full scan on 6.3M rows per query |

---

## Stack

| Layer | Tool | Note |
|-------|------|------|
| Dataset | PaySim1 (Kaggle API) | 6.3M synthetic transactions, 11 columns |
| Ingestion | Python (boto3) | CSV → S3 → Delta Lake |
| Storage | AWS S3 | Free tier 5GB — landing + Bronze |
| Bronze | Delta Lake on S3 | PySpark, local or Databricks — ACID, time travel, raw + metadata |
| Silver | Delta Lake on S3 | PySpark, local or Databricks — dedup/cast/derive/dq_flag + cumulative Delta MERGE — full 6.3M rows |
| Bridge | S3 Parquet → Snowflake COPY INTO (automated path) | alternate manual path: databricks-sql-connector + Snowflake write_pandas() (Arrow batch, no S3 intermediary) |
| Gold | dbt Core + Snowflake | staging → intermediate → marts |
| Orchestration | Apache Airflow standalone | localhost:8080, @daily schedule |
| Quality | Great Expectations | Bronze 10/10, Silver 14/15 (1 WARN documented) |
| Alerting | Slack webhook | CRITICAL fraud alert + pipeline pass/fail |
| BI | Power BI | Gold consumer |

---

## Architecture

```
PaySim1 CSV (6.3M rows, 471MB)
    ↓ Python + boto3
AWS S3 Landing Zone
    ↓ PySpark + Delta Lake (bronze_pipeline.py — local or Databricks)
Bronze — paysim_fraud.bronze.transactions (Delta Lake on S3)
    ↓ PySpark + Delta Lake (silver_pipeline.py + cumulative_pipeline.py — local or Databricks)
Silver — paysim_fraud.silver.transactions
       — paysim_fraud.silver.customer_daily_balance (cumulative, 31 days)
    ↓ S3 Parquet export → Snowflake COPY INTO
       (alternate manual path: databricks-sql-connector Arrow batch → write_pandas())
Snowflake PAYSIM_FRAUD (STAGING schema)
    ↓ dbt Core
Gold — mart_fraud_summary + mart_customer_risk
    ↓
Power BI Fraud Intelligence Dashboard
```

> Note: the full 6.3M-row staging run was executed via a manual Databricks notebook
> (`silver/databricks_notebook.py`, cell-by-cell) — a separate execution path from the
> automated Airflow DAG, which runs the same `bronze/`/`silver/` modules as local PySpark.
> See `docs/ARCHITECTURE.md` + `INTERVIEW_GUIDE.md`.

---

## Key KPIs

| KPI | Formula | Location |
|-----|---------|----------|
| Fraud rate (%) | `COUNT(isFraud=1) / COUNT(*) × 100` | mart_fraud_summary |
| Detection rate (%) | `COUNT(flagged ∩ fraud) / COUNT(fraud) × 100` | mart_fraud_summary |
| False positive rate (%) | `COUNT(flagged ∩ ¬fraud) / COUNT(flagged) × 100` | mart_fraud_summary |
| Balance drain velocity (%) | `amount / oldbalanceOrg × 100` | Silver (row-level) |
| Zero-out events | `COUNT(newBal=0 AND amt>0 AND oldBal>0)` | mart_customer_risk |
| Customer risk category | CONFIRMED_FRAUD / HIGH_RISK / ELEVATED_RISK / NORMAL | mart_customer_risk |

---

## Staging Run Evidence (2026-05-12)

| Step | Result |
|------|--------|
| S3 upload (471MB CSV) | ✅ 23s |
| Bronze — 6,362,620 rows | ✅ 15s |
| Silver — 6,362,620 rows, 100% retention | ✅ 11s |
| Cumulative — 6,362,047 rows, 31 days | ✅ 14s |
| Snowflake load | ✅ 7 min (Arrow CloudFetch) |
| dbt run | ✅ 7/7 models |
| dbt test | ✅ 49/49 PASS |
| Slack alert | ✅ CRITICAL + SUCCESS delivered |

### Screenshots

**1 — S3 Landing Zone (471MB CSV uploaded)**
<img width="1908" alt="S3 bucket listing" src="https://github.com/user-attachments/assets/b300497e-9cf5-4a1b-9a2b-e8fb0ed28184" />

**2 — Databricks Unity Catalog — Bronze table (6,362,620 rows)**
<img width="1875" alt="Databricks catalog Bronze" src="https://github.com/user-attachments/assets/fbb22ef4-4927-46c1-b228-60a8d4a46b5d" />

**3 — Databricks — Bronze + Silver row counts**
<img width="1905" alt="Databricks row counts" src="https://github.com/user-attachments/assets/e7f479b8-af06-4a86-8d38-a014e4c8fd6d" />

**4 — Snowflake STAGING — TRANSACTIONS + CUSTOMER_DAILY_BALANCE**
<img width="1907" alt="Snowflake STAGING table" src="https://github.com/user-attachments/assets/60f80175-21d3-477f-b4d0-82f1d8796304" />

**5 — dbt run — 7/7 models PASS**
<img width="1363" alt="dbt staging run" src="https://github.com/user-attachments/assets/e1fa0387-89e2-488e-81e5-4edbdbf3b02a" />

**6 — dbt test — 49/49 PASS**
<img width="1370" alt="dbt staging test" src="https://github.com/user-attachments/assets/609223bf-c324-42ef-ac42-a03d2b69267c" />

**7 — Slack alert — CRITICAL fraud alert + pipeline success**
<img width="1816" alt="Slack test alert" src="https://github.com/user-attachments/assets/f5e3e156-2fca-40ee-b7c4-f5a6617ddc2d" />

---

## Project Structure

```
paysim-fraud-pipeline/
├── bronze/
│   ├── bronze_pipeline.py      # CSV → Delta Lake (env-aware: dev local / staging S3)
│   └── download_dataset.py     # Kaggle API download + S3 upload
├── silver/
│   ├── silver_pipeline.py      # 6-step transform (dedup, cast, derive, dq_flag)
│   ├── cumulative_pipeline.py  # Per-day Delta MERGE + VACUUM (idempotent)
│   ├── databricks_notebook.py  # manual staging-promote run on Databricks (PySpark, full 6.3M rows)
│   └── databricks_to_snowflake.py  # Arrow batch → Snowflake write_pandas()
├── gold/
│   ├── dbt_project.yml
│   ├── models/
│   │   ├── sources.yml
│   │   ├── staging/            # dim_customer, stg_paysim_transactions
│   │   ├── intermediate/       # int_transactions_enriched, int_cumulative_customer_balance
│   │   └── marts/              # mart_fraud_summary, mart_customer_risk
│   ├── seeds/                  # dim_time (744 rows), dim_transaction_type (5 rows)
│   └── tests/                  # assert_fraud_identity_check.sql (singular test)
├── data_quality/
│   ├── run_bronze_suite.py     # GX Bronze — 10 checks (CRITICAL, block Silver)
│   └── run_silver_suite.py     # GX Silver — 15 checks (14 PASS, 1 WARN)
├── airflow/dags/
│   └── paysim_fraud_pipeline.py  # Main DAG — @daily, Slack alerts, retries
├── tests/
│   ├── test_bronze_ingest.py   # 4 unit tests (pytest + PySpark)
│   └── test_silver_transform.py  # 18 unit tests — derived columns, dq_flag, dedup
├── conftest.py                 # JAVA_HOME=Java 21 (PySpark 3.5.0 requirement)
├── setup.sh                    # Environment bootstrap
└── .env.example                # Credential template
```

---

## Phase Completion

| Phase | Deliverable | Status |
|-------|-------------|--------|
| 0 | Setup + scaffold | ✅ |
| 1 | BRD — business requirements + KPI formulas | ✅ |
| 2 | DRD + Data Dictionary + Data Model (conceptual) | ✅ |
| 3 | Architecture + PIPELINE_SPEC + Data Model (logical) | ✅ |
| 4a | Code — local dev (22/22 pytest, Bronze GX 10/10, Silver GX 14/15) | ✅ |
| 4b | Cloud promote — actual staging run (6.3M rows, dbt 49/49) | ✅ |
| 5 | DQD + OPS Runbook — signed off | ✅ |

---

## Running Locally (Dev — 1,000 rows)

```bash
# Setup
bash setup.sh
cp .env.example .env.dev
# Fill in KAGGLE_USERNAME, KAGGLE_KEY — others optional for dev

# Download sample
ENV=dev python bronze/download_dataset.py

# Run pipeline
ENV=dev python bronze/bronze_pipeline.py
ENV=dev python silver/silver_pipeline.py
ENV=dev python silver/cumulative_pipeline.py

# Validate
ENV=dev python data_quality/run_bronze_suite.py
ENV=dev python data_quality/run_silver_suite.py

# Unit tests
pytest tests/ -v
```

---

*Portfolio — Raja Ahmad Luqman | Analytics & Data Engineering*
