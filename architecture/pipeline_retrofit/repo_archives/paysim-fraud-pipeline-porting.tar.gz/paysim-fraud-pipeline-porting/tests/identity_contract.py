#!/usr/bin/env python3
"""Identity contract — deterministic gate over the dual grain (Kimball + cumulative table).

Ported from creative_intelligence_lab's tests/lineage_contract.py pattern (via home-credit's
"identity contract" rename, then olist's retarget) — this repo runs TWO grains side by side
per ADR-001:
  - fact_transactions: Kimball grain, 1 row = 1 transaction, transaction_id = MD5(nameOrig +
    step + amount) — gold/models/staging/staging__paysim_transactions.sql →
    gold/models/intermediate/int_transactions_enriched.sql
  - fact_customer_daily_balance: CUMULATIVE-TABLE grain, 1 row = 1 customer per simulated day
    (customer_id + balance_date), built by idempotent Delta Lake MERGE in
    silver/cumulative_pipeline.py, carried through
    gold/models/intermediate/int_customer_daily_aggregates.sql →
    int_cumulative_customer_balance.sql → gold/models/marts/mart_customer_risk.sql

Encodes @data-architect's grain guarantees statically, WITHOUT requiring a live Databricks/
Snowflake connection — it checks the dbt SOURCE + the Silver transform scripts, not warehouse
data. Run the real GX-style suites (`data_quality/run_*_suite.py`) / `dbt test` for the
runtime complement.

Stdlib only. Exit 0 = contract holds. Exit 1 = hard violation.

Rules:
  ID1  silver/cumulative_pipeline.py must define the per-day MERGE function and compute
       running totals from the PREVIOUS day's row (idempotency guarantee) — a refactor that
       starts computing running totals from the matched/current row would silently break
       re-run idempotency
  ID2  gold/models/intermediate/int_cumulative_customer_balance.sql and
       gold/models/marts/mart_customer_risk.sql must reference the cumulative-table grain
       columns (customer_id/customer_fk, balance_date, running_*) — a hand-rolled aggregate
       that bypasses the intermediate cumulative model would drift silently
  ID3  gold/models/marts/mart_fraud_summary.sql must reference fact_transactions' Kimball
       grain source (int_transactions_enriched) and the transaction_id natural key — catches
       a Kimball model accidentally built off the cumulative intermediate instead

Run:  python tests/identity_contract.py
"""

from __future__ import annotations

import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
CUMULATIVE_PIPELINE = REPO / "silver" / "cumulative_pipeline.py"
INT_DAILY_AGG = REPO / "gold" / "models" / "intermediate" / "int_customer_daily_aggregates.sql"
INT_CUMULATIVE = REPO / "gold" / "models" / "intermediate" / "int_cumulative_customer_balance.sql"
MART_CUSTOMER_RISK = REPO / "gold" / "models" / "marts" / "mart_customer_risk.sql"
MART_FRAUD_SUMMARY = REPO / "gold" / "models" / "marts" / "mart_fraud_summary.sql"

CUMULATIVE_GRAIN_COLS = ("customer_id", "balance_date", "running_")


def check() -> list[str]:
    errors: list[str] = []

    # ID1 — cumulative_pipeline.py preserves the "running totals from yesterday's row" guarantee
    if not CUMULATIVE_PIPELINE.exists():
        errors.append(f"ID1: {CUMULATIVE_PIPELINE.relative_to(REPO)} missing — cumulative MERGE transform not found")
    else:
        text = CUMULATIVE_PIPELINE.read_text()
        if "_merge_day" not in text:
            errors.append("ID1: _merge_day function not found in silver/cumulative_pipeline.py — cumulative MERGE missing")
        if "yesterday_df" not in text and "prev_running" not in text:
            errors.append(
                "ID1: no reference to a 'yesterday'/'prev_running' row in silver/cumulative_pipeline.py — "
                "the idempotent running-total derivation (from the PRIOR day, not the matched row) may have drifted"
            )
        for col in ("running_txn_total", "running_fraud_total", "running_fraud_amount", "running_sent_total"):
            if col not in text:
                errors.append(f"ID1: cumulative column '{col}' not found in silver/cumulative_pipeline.py — grain drift")

    # ID2 — the daily-aggregates model (where balance_date/running_* actually land first) and
    # mart select the cumulative-table grain columns; the cumulative intermediate model
    # (one layer downstream) must still chain back to it.
    for path, label in ((INT_DAILY_AGG, "int_customer_daily_aggregates.sql"), (MART_CUSTOMER_RISK, "mart_customer_risk.sql")):
        if not path.exists():
            errors.append(f"ID2: {path.relative_to(REPO)} missing — cumulative-grain model not found")
            continue
        text = path.read_text()
        for col in CUMULATIVE_GRAIN_COLS:
            if col not in text:
                errors.append(f"ID2: {label} does not reference '{col}' — cumulative-table grain may have drifted")

    if INT_CUMULATIVE.exists():
        text = INT_CUMULATIVE.read_text()
        if "int_customer_daily_aggregates" not in text:
            errors.append("ID2: int_cumulative_customer_balance.sql does not ref() int_customer_daily_aggregates — grain source broken")
    else:
        errors.append(f"ID2: {INT_CUMULATIVE.relative_to(REPO)} missing — cumulative-grain model not found")

    if MART_CUSTOMER_RISK.exists():
        text = MART_CUSTOMER_RISK.read_text()
        if "int_cumulative_customer_balance" not in text:
            errors.append("ID2: mart_customer_risk.sql does not ref() int_cumulative_customer_balance — grain source broken")

    # ID3 — fraud summary mart stays on the Kimball (per-transaction) grain
    if not MART_FRAUD_SUMMARY.exists():
        errors.append(f"ID3: {MART_FRAUD_SUMMARY.relative_to(REPO)} missing — Kimball fraud mart not found")
    else:
        text = MART_FRAUD_SUMMARY.read_text()
        if "int_transactions_enriched" not in text:
            errors.append("ID3: mart_fraud_summary.sql does not ref() int_transactions_enriched — Kimball grain source broken")
        if "int_cumulative_customer_balance" in text:
            errors.append("ID3: mart_fraud_summary.sql references the cumulative intermediate model — grain mixing, Kimball mart must stay transaction-grain")

    return errors


def main() -> int:
    errors = check()
    if errors:
        print(f"\n❌ IDENTITY CONTRACT FAILED — {len(errors)} violation(s):", file=sys.stderr)
        for e in errors:
            print(f"   • {e}", file=sys.stderr)
        print("\n   See docs/DATA_MODEL.md + docs/ADR/ADR-001-hybrid-paradigm.md. Fix before proceeding.",
              file=sys.stderr)
        return 1
    print("✅ identity contract OK (Kimball transaction grain + cumulative-table customer-day grain)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
