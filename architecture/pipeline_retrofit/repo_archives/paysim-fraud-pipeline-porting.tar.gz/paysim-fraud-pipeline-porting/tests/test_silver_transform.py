"""
Unit tests for silver/silver_pipeline.py — transform logic.

Uses PySpark local mode with a minimal 10-row fixture.
Validates every derived column + rename + dq_flag bitmask.
"""

import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


@pytest.fixture(scope="module")
def spark():
    """PySpark session in local mode with Delta Lake."""
    from pyspark.sql import SparkSession
    from delta import configure_spark_with_delta_pip

    builder = (
        SparkSession.builder
        .appName("paysim-test-silver")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .config("spark.driver.memory", "1g")
        .master("local[1]")
    )
    spark = configure_spark_with_delta_pip(builder).getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    yield spark
    spark.stop()


def _make_df(spark, rows):
    """Create a test DataFrame matching Bronze schema."""
    from pyspark.sql.types import (
        StructType, StructField, IntegerType, StringType,
        DoubleType, LongType, TimestampType
    )
    from datetime import datetime

    schema = StructType([
        StructField("step",            IntegerType(), True),
        StructField("type",            StringType(),  True),
        StructField("amount",          DoubleType(),  True),
        StructField("nameOrig",        StringType(),  True),
        StructField("oldbalanceOrg",   DoubleType(),  True),
        StructField("newbalanceOrig",  DoubleType(),  True),
        StructField("nameDest",        StringType(),  True),
        StructField("oldbalanceDest",  DoubleType(),  True),
        StructField("newbalanceDest",  DoubleType(),  True),
        StructField("isFraud",         IntegerType(), True),
        StructField("isFlaggedFraud",  IntegerType(), True),
        StructField("ingestion_ts",    TimestampType(), True),
        StructField("source_system",   StringType(),  True),
        StructField("batch_id",        StringType(),  True),
        StructField("source_file",     StringType(),  True),
        StructField("transaction_day", IntegerType(), True),
    ])
    ts = datetime(2024, 1, 1, 0, 0, 0)
    return spark.createDataFrame(
        [(r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10],
          ts, "paysim1_kaggle", "batch_001", "s3://bucket/file.csv",
          max(1, -(-r[0] // 24)))   # transaction_day = ceil(step/24)
         for r in rows],
        schema=schema
    )


# ── Fixtures ──────────────────────────────────────────────────────────────────

NORMAL_ROW       = (1,   "TRANSFER",  1000.0,  "C123", 5000.0, 4000.0,  "C456",  200.0,  1200.0, 0, 0)
FRAUD_TRANSFER   = (2,   "TRANSFER",  2000.0,  "C789", 2000.0, 0.0,     "C111",  0.0,    0.0,    1, 1)
FRAUD_CASHOUT    = (3,   "CASH-OUT",  500.0,   "C222", 500.0,  0.0,     "M001",  0.0,    0.0,    1, 0)
MERCHANT_DEST    = (4,   "PAYMENT",   300.0,   "C333", 1000.0, 700.0,   "M002",  0.0,    0.0,    0, 0)
ZERO_BAL_ORIG    = (5,   "CASH-IN",   100.0,   "C444", 0.0,    100.0,   "C555",  50.0,   150.0,  0, 0)
RULE1_VIOLATION  = (6,   "PAYMENT",   400.0,   "C666", 800.0,  400.0,   "M003",  0.0,    0.0,    1, 0)  # isFraud=1 on PAYMENT
FLAGGED_DISC     = (7,   "TRANSFER",  100.0,   "C777", 500.0,  400.0,   "C888",  0.0,    100.0,  0, 1)  # flagged but not fraud
ZERO_OUT         = (8,   "CASH-OUT",  800.0,   "C999", 800.0,  0.0,     "M004",  0.0,    0.0,    0, 0)
NULL_CRITICAL    = (9,   "TRANSFER",  100.0,   None,   100.0,  0.0,     "C000",  0.0,    100.0,  0, 0)   # NULL nameOrig
DUPLICATE        = (1,   "TRANSFER",  1000.0,  "C123", 5000.0, 4000.0,  "C456",  200.0,  1200.0, 0, 0)   # dup of NORMAL_ROW


class TestDeduplication:
    def test_duplicate_rows_removed(self, spark):
        from silver.silver_pipeline import transform
        df = _make_df(spark, [NORMAL_ROW, DUPLICATE])
        clean, quarantine = transform(df, "test_batch")
        assert clean.count() == 1

    def test_unique_rows_all_kept(self, spark):
        from silver.silver_pipeline import transform
        df = _make_df(spark, [NORMAL_ROW, FRAUD_TRANSFER])
        clean, quarantine = transform(df, "test_batch")
        assert clean.count() == 2


class TestNullHandling:
    def test_null_nameOrig_quarantined(self, spark):
        from silver.silver_pipeline import transform
        df = _make_df(spark, [NULL_CRITICAL])
        clean, quarantine = transform(df, "test_batch")
        assert clean.count() == 0
        assert quarantine.count() == 1

    def test_valid_rows_not_quarantined(self, spark):
        from silver.silver_pipeline import transform
        df = _make_df(spark, [NORMAL_ROW, FRAUD_TRANSFER])
        clean, quarantine = transform(df, "test_batch")
        assert quarantine.count() == 0


class TestMerchantBalance:
    def test_merchant_dest_balance_is_null(self, spark):
        from silver.silver_pipeline import transform
        from pyspark.sql import functions as F

        df = _make_df(spark, [MERCHANT_DEST])
        clean, _ = transform(df, "test_batch")
        row = clean.filter(F.col("receiver_id") == "M002").first()
        assert row is not None
        assert row["receiver_balance_before"] is None
        assert row["receiver_balance_after"] is None

    def test_customer_dest_balance_preserved(self, spark):
        from silver.silver_pipeline import transform
        from pyspark.sql import functions as F

        df = _make_df(spark, [NORMAL_ROW])
        clean, _ = transform(df, "test_batch")
        row = clean.filter(F.col("receiver_id") == "C456").first()
        assert row["receiver_balance_before"] == 200.0


class TestDerivedColumns:
    def test_balance_drain_pct_calculated(self, spark):
        from silver.silver_pipeline import transform
        from pyspark.sql import functions as F

        df = _make_df(spark, [NORMAL_ROW])  # amount=1000, oldbalanceOrg=5000 → 20%
        clean, _ = transform(df, "test_batch")
        row = clean.first()
        assert abs(row["balance_drain_pct"] - 20.0) < 0.001

    def test_balance_drain_pct_null_when_zero_balance(self, spark):
        from silver.silver_pipeline import transform

        df = _make_df(spark, [ZERO_BAL_ORIG])  # oldbalanceOrg=0 → NULL
        clean, _ = transform(df, "test_batch")
        assert clean.first()["balance_drain_pct"] is None

    def test_is_zero_out_detected(self, spark):
        from silver.silver_pipeline import transform

        df = _make_df(spark, [ZERO_OUT])  # newbalanceOrig=0, amount=800, oldbalanceOrg=800
        clean, _ = transform(df, "test_batch")
        assert clean.first()["is_zero_out"] == 1

    def test_is_zero_out_not_triggered_on_already_zero(self, spark):
        from silver.silver_pipeline import transform

        df = _make_df(spark, [ZERO_BAL_ORIG])  # oldbalanceOrg=0 → guard prevents false flag
        clean, _ = transform(df, "test_batch")
        assert clean.first()["is_zero_out"] == 0

    def test_flagged_fraud_discrepancy(self, spark):
        from silver.silver_pipeline import transform

        df = _make_df(spark, [FLAGGED_DISC])  # isFlaggedFraud=1, isFraud=0 → discrepancy=1
        clean, _ = transform(df, "test_batch")
        assert clean.first()["flagged_fraud_discrepancy"] == 1

    def test_no_discrepancy_when_aligned(self, spark):
        from silver.silver_pipeline import transform

        df = _make_df(spark, [FRAUD_TRANSFER])  # isFlaggedFraud=1, isFraud=1 → discrepancy=0
        clean, _ = transform(df, "test_batch")
        assert clean.first()["flagged_fraud_discrepancy"] == 0

    def test_transaction_id_not_null(self, spark):
        from silver.silver_pipeline import transform

        df = _make_df(spark, [NORMAL_ROW])
        clean, _ = transform(df, "test_batch")
        assert clean.first()["transaction_id"] is not None
        assert len(clean.first()["transaction_id"]) == 32  # MD5 hex length

    def test_transaction_hour_range(self, spark):
        from silver.silver_pipeline import transform

        rows = [(step, "CASH-IN", 100.0, "C001", 500.0, 400.0, "C002", 0.0, 100.0, 0, 0)
                for step in [1, 12, 24, 25, 48]]
        df = _make_df(spark, rows)
        clean, _ = transform(df, "test_batch")
        hours = {r["transaction_hour"] for r in clean.collect()}
        assert all(0 <= h <= 23 for h in hours)


class TestColumnRenaming:
    def test_source_columns_renamed(self, spark):
        from silver.silver_pipeline import transform

        df = _make_df(spark, [NORMAL_ROW])
        clean, _ = transform(df, "test_batch")
        columns = clean.columns

        assert "sender_id" in columns
        assert "receiver_id" in columns
        assert "sender_balance_before" in columns
        assert "sender_balance_after" in columns
        assert "is_fraud" in columns
        assert "is_flagged_fraud" in columns

        # Source names must NOT exist after rename
        assert "nameOrig" not in columns
        assert "nameDest" not in columns
        assert "oldbalanceOrg" not in columns
        assert "isFraud" not in columns


class TestDqFlagBitmask:
    def test_clean_row_has_dq_flag_zero(self, spark):
        from silver.silver_pipeline import transform

        df = _make_df(spark, [NORMAL_ROW])
        clean, _ = transform(df, "test_batch")
        # Normal row has some balance discrepancy due to test values — check bit 0-2 only
        dq = clean.first()["dq_flag"]
        assert dq is not None
        assert 0 <= dq <= 15

    def test_rule1_violation_sets_bit2(self, spark):
        from silver.silver_pipeline import transform

        df = _make_df(spark, [RULE1_VIOLATION])  # PAYMENT + isFraud=1 → bit 2 (4)
        clean, _ = transform(df, "test_batch")
        dq = clean.first()["dq_flag"]
        assert dq & 4 == 4  # bit 2 must be set

    def test_fraud_eligible_type_no_rule1_violation(self, spark):
        from silver.silver_pipeline import transform

        df = _make_df(spark, [FRAUD_TRANSFER])  # TRANSFER + isFraud=1 → no RULE 1 violation
        clean, _ = transform(df, "test_batch")
        dq = clean.first()["dq_flag"]
        assert dq & 4 == 0  # bit 2 must NOT be set
