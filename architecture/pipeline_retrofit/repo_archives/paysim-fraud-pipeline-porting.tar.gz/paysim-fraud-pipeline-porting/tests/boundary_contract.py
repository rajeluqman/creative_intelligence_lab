#!/usr/bin/env python3
"""Stack + scope boundary contract — deterministic gate over this repo's locked stack.

Ported from creative_intelligence_lab's tests/boundary_contract.py pattern (via home-credit's
and olist's retargets), retargeted to THIS repo's real rejected-tech axis (docs/ARCHITECTURE.md
+ docs/ADR/ADR-001-hybrid-paradigm.md):
  - Bronze/Silver compute is PySpark + Delta Lake, run locally (dev) or on Databricks
    (staging/prod, `silver/databricks_notebook.py`) — sanctioned in `bronze/`, `silver/`,
    `tests/unit/` only, never as a standalone Spark cluster elsewhere (no EMR/Glue)
  - Gold compute is Snowflake/dbt only — `gold/profiles.yml` adapter `type:` must stay
    `snowflake` (never duckdb/bigquery/postgres)
  - Storage is AWS S3 (`bronze/bronze_pipeline.py`'s `s3a://` paths, `boto3` for checkpoints) —
    no Azure/ADLS, no MinIO
  - No new ingestion connector beyond the Kaggle Competition API (no Fivetran/Airbyte/ADF)

Stdlib only ($0, no deps). Exit 0 = contract holds. Exit 1 = hard violation.

Rules:
  ST1  no `pyspark` import outside bronze/, silver/, tests/unit/ (Spark is sanctioned only on
       those two execution surfaces, local-dev or Databricks)
  ST2  no Azure (`azure.storage`) or MinIO SDK import anywhere — storage is AWS S3, not ADLS
  ST3  no Fivetran/Airbyte/azure-data-factory-mgmt dependency (Kaggle API is the sole
       ingestion path)
  ST4  dbt profile adapter `type:` must be `snowflake` (Gold compute is locked to Snowflake)

Run:  python tests/boundary_contract.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent

PY_GLOBS_ALL = ["airflow/dags/*.py"]
# Spark is sanctioned wherever PySpark/Delta is the actual compute target in this repo
# (local-dev or Databricks staging notebook execution), AND in data_quality/ which runs its
# GX-style suites directly against the same Delta tables, AND in tests/unit/ which unit-tests
# those same Bronze/Silver modules (pytest fixtures build a local SparkSession).
PY_GLOBS_SPARK_OK = ["silver/*.py", "bronze/*.py", "data_quality/*.py", "tests/unit/*.py", "conftest.py"]
REQUIREMENTS_FILES = ["requirements.txt"]
PROFILE_FILES = ["gold/profiles.yml"]

# Pre-existing repo code carrying a documented, reasoned exception — NOT a dumping ground.
# (bronze/download_dataset.py's optional CLOUD=azure upload_to_adls() path was removed
# 2026-06-29 rather than kept as an exception here — see DECISION_LOG.md. Empty by design;
# the mechanism stays in case a future repo in this retrofit needs a real reasoned exception.)
ALLOW_LINES: dict[str, str] = {}

IMPORT_RE = re.compile(r"^\s*(?:import|from)\s+([A-Za-z0-9_.]+)")
REQ_LINE_RE = re.compile(r"^([A-Za-z0-9_.-]+)")

ALWAYS_DENY: dict[str, str] = {
    "azure": "docs/ARCHITECTURE.md — storage is AWS S3, not Azure/ADLS",
    "fivetran": "no ingestion connector beyond the Kaggle Competition API",
    "airbyte": "no ingestion connector beyond the Kaggle Competition API",
    "minio": "docs/ARCHITECTURE.md — storage is AWS S3, no MinIO",
    "pyspark.context": None,  # placeholder, never triggers — keep dict typing simple
}
del ALWAYS_DENY["pyspark.context"]

PYSPARK_OUTSIDE_DENY: dict[str, str] = {
    "pyspark": "docs/ARCHITECTURE.md — Bronze/Silver compute is PySpark+Delta on bronze/silver only (local-dev or Databricks)",
}


def _hits(module: str, deny: dict[str, str]) -> str | None:
    parts = module.lower().split(".")
    for i in range(1, len(parts) + 1):
        prefix = ".".join(parts[:i])
        if prefix in deny:
            return deny[prefix]
    return None


def _scan_python(path: Path, errors: list[str], deny: dict[str, str]) -> None:
    rel = path.relative_to(REPO)
    current_fn = None
    for lineno, line in enumerate(path.read_text(errors="ignore").splitlines(), start=1):
        fn_m = re.match(r"\s*def\s+(\w+)\s*\(", line)
        if fn_m:
            current_fn = fn_m.group(1)
        m = IMPORT_RE.match(line)
        if not m:
            continue
        reason = _hits(m.group(1), deny)
        if reason:
            allow_key = f"{rel}:{current_fn}"
            allow_reason = ALLOW_LINES.get(allow_key)
            if allow_reason:
                continue  # documented, reasoned exception — see ALLOW_LINES
            errors.append(f"{rel}:{lineno}: banned import '{m.group(1)}' — {reason}")


def _scan_requirements(path: Path, errors: list[str]) -> None:
    rel = path.relative_to(REPO)
    for lineno, line in enumerate(path.read_text(errors="ignore").splitlines(), start=1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = REQ_LINE_RE.match(line)
        if not m:
            continue
        pkg = m.group(1).lower().replace("-", "_")
        reason = ALWAYS_DENY.get(pkg)
        if reason:
            errors.append(f"{rel}:{lineno}: banned dependency '{m.group(1)}' — {reason}")


def _scan_profile_adapter(path: Path, errors: list[str]) -> None:
    rel = path.relative_to(REPO)
    type_re = re.compile(r"^\s*type:\s*(\S+)")
    for lineno, line in enumerate(path.read_text(errors="ignore").splitlines(), start=1):
        m = type_re.match(line)
        if m and m.group(1) != "snowflake":
            errors.append(
                f"{rel}:{lineno}: dbt profile adapter type '{m.group(1)}' != 'snowflake' — "
                "this repo's Gold compute is locked to Snowflake"
            )


def check() -> list[str]:
    errors: list[str] = []

    for pattern in PY_GLOBS_ALL:
        for path in REPO.glob(pattern):
            _scan_python(path, errors, {**PYSPARK_OUTSIDE_DENY, **ALWAYS_DENY})

    for pattern in PY_GLOBS_SPARK_OK:
        for path in REPO.glob(pattern):
            _scan_python(path, errors, ALWAYS_DENY)  # pyspark IS allowed here

    for name in REQUIREMENTS_FILES:
        path = REPO / name
        if path.exists():
            _scan_requirements(path, errors)

    for name in PROFILE_FILES:
        path = REPO / name
        if path.exists():
            _scan_profile_adapter(path, errors)

    return errors


def main() -> int:
    errors = check()
    if errors:
        print(f"\n❌ BOUNDARY CONTRACT FAILED — {len(errors)} violation(s):", file=sys.stderr)
        for e in sorted(set(errors)):
            print(f"   • {e}", file=sys.stderr)
        print("\n   See docs/ARCHITECTURE.md. Fix before proceeding.", file=sys.stderr)
        return 1
    print("✅ boundary contract OK (PySpark+Delta on bronze/silver only, Snowflake-locked Gold, S3-only storage)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
