"""
Unit tests for bronze/bronze_pipeline.py
Tests do not require Spark — validate path resolution and env logic.
"""

import os
import sys
import pytest
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


class TestGetPaths:
    def test_dev_returns_local_paths(self):
        from bronze.bronze_pipeline import _get_paths
        src, out = _get_paths("dev", "data/dev/sample.csv")
        assert src == "data/dev/sample.csv"
        assert out == "data/bronze/transactions"

    def test_staging_returns_s3_path(self):
        from bronze.bronze_pipeline import _get_paths
        with patch.dict(os.environ, {"S3_BUCKET_STAGING": "my-bucket"}):
            src, out = _get_paths("staging", "s3a://my-bucket/landing/data.csv")
        assert out == "s3a://my-bucket/bronze/transactions"

    def test_staging_missing_bucket_raises(self):
        from bronze.bronze_pipeline import _get_paths
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("S3_BUCKET_STAGING", None)
            with pytest.raises(EnvironmentError, match="S3_BUCKET_STAGING"):
                _get_paths("staging", "some/path")


class TestGetSpark:
    def test_dev_spark_config_no_aws(self):
        """Dev mode should NOT set AWS S3A keys — inspect source, no live Spark needed."""
        import inspect
        from bronze.bronze_pipeline import _get_spark

        source = inspect.getsource(_get_spark)
        # S3A config must only be set inside the staging/prod branch
        # Simplest assertion: the s3a lines must appear AFTER `if env in ("staging", "prod")`
        staging_block_start = source.find('if env in ("staging", "prod")')
        s3a_first_occurrence = source.find("s3a")
        assert staging_block_start != -1, "_get_spark must have staging/prod branch"
        assert s3a_first_occurrence > staging_block_start, \
            "S3A keys must only be set inside the staging/prod branch, not for dev"
