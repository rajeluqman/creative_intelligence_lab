# DRD: paysim-fraud-pipeline
> Status: DRAFT — Pending Phase 2 sign-off

## Source Overview
| Attribute | Value |
|-----------|-------|
| Source | PaySim1 Kaggle Dataset |
| Format | CSV (PS_20174392719_1491204439457_log.csv) |
| Frequency | One-shot load — simulate daily batch ingestion |
| Volume | 6,362,620 rows, ~470MB CSV |
| Delivery | Manual download → S3 landing zone |
| Ingestion pattern | Snapshot (full load, partition by simulated date) |

## Schema (11 Columns — HARD LIMIT)
| Column | Type | Nullable | Business Term | Description |
|--------|------|----------|---------------|-------------|
| step | INT | N | Transaction Hour | 1 step = 1 hour, range 1–744 (30 days) |
| type | STRING | N | Transaction Type | CASH-IN, CASH-OUT, DEBIT, PAYMENT, TRANSFER |
| amount | DOUBLE | N | Transaction Amount | Amount in local currency |
| nameOrig | STRING | N | Sender ID | Customer ID, prefix C |
| oldbalanceOrg | DOUBLE | N | Sender Balance Before | Balance before transaction |
| newbalanceOrig | DOUBLE | N | Sender Balance After | Balance after transaction |
| nameDest | STRING | N | Receiver ID | Customer (C) or Merchant (M) |
| oldbalanceDest | DOUBLE | Y* | Receiver Balance Before | Empty for merchants (prefix M) |
| newbalanceDest | DOUBLE | Y* | Receiver Balance After | Empty for merchants (prefix M) |
| isFraud | INT | N | Fraud Label | 1 = fraud, 0 = legitimate |
| isFlaggedFraud | INT | N | System Flag | 1 = flagged by original heuristic |

*Y by design — merchant balance not tracked, bukan data error

## Entities Identified
| Entity | Type | Notes |
|--------|------|-------|
| Transaction | Fact | Grain: 1 row = 1 txn — natural fact table |
| Customer Daily Balance | Fact (Cumulative) | Grain: 1 customer per day — derived dari transactions |
| Customer | Dimension | nameOrig / nameDest prefix C |
| Merchant | Dimension | nameDest prefix M — static, no balance |
| Time | Dimension | Derived dari step column (step ÷ 24 = day) |
| Transaction Type | Dimension | 5 values — static lookup |

## Known Data Issues (flagged by DA + DQS)
| Issue | Observed | Impact | Strategy |
|-------|----------|--------|----------|
| Merchant balance = 0/null | oldbalanceDest=0, newbalanceDest=0 untuk prefix M | Expected by design — not an error | Document dalam DATA_DICTIONARY, filter dalam Silver |
| isFlaggedFraud ≠ isFraud | Heuristic miss — false pos/neg exist | Affects detection rate KPI | Keep both columns, compute discrepancy metric |
| Fraud HANYA dalam TRANSFER + CASH-OUT | type IN ('PAYMENT','CASH-IN','DEBIT') → isFraud always 0 | Model assumption — restrict fraud analysis scope | Filter dalam Silver fraud flag, document dalam SPEC |
| Class imbalance: 0.13% fraud | 8,213 fraud / 6.3M total | GX count check — jangan treat as anomaly | Set GX expected range 0.10%–0.20% |
| No timestamp — step only | step = integer hour count | No real datetime — kena derive | Silver: derive transaction_datetime dari step |

## Derived Columns (Silver layer)
| Column | Formula | Notes |
|--------|---------|-------|
| transaction_day | CEIL(step / 24) | Day 1–31 |
| transaction_hour | ((step - 1) % 24) + 1 | Hour 1–24 |
| transaction_datetime | TIMESTAMP '2024-01-01' + (step-1) HOURS | Synthetic base date |
| is_merchant_dest | CASE WHEN nameDest LIKE 'M%' THEN 1 ELSE 0 END | Route merchant vs customer |
| balance_drain_pct | CASE WHEN oldbalanceOrg > 0 THEN (amount / oldbalanceOrg * 100) ELSE NULL END | NULL kalau divide by zero |
| is_zero_out | CASE WHEN newbalanceOrig = 0 AND amount > 0 THEN 1 ELSE 0 END | Account drain flag |
| balance_discrepancy_orig | (oldbalanceOrg - amount) - newbalanceOrig | Detect balance mismatch |
| balance_discrepancy_dest | (oldbalanceDest + amount) - newbalanceDest | Detect destination mismatch |

## SLA
- Bronze: T+5 minit | Silver: T+20 minit | Gold: T+35 minit

## Retention
| Layer | Retention |
|-------|-----------|
| Bronze | 2 years (Delta time travel — backfill capability) |
| Silver | 1 year |
| Gold | 2 years (Snowflake — reporting history) |

## Sign-off Gate
| Agent | Status | Reason |
|-------|--------|--------|
| BA | PENDING | - |
| DA | PENDING | - |
| SDE | PENDING | - |
| DPE | PENDING | - |
| DQS | PENDING | - |
| PM | PENDING | - |

## Hard Blockers Before Phase 3
[ ] Grain defined untuk kedua-dua fact tables
[ ] DA + DPE sync — cumulative table memory feasibility confirmed
[ ] Merchant balance NULL strategy decided
[ ] isFlaggedFraud discrepancy strategy decided
[ ] Source pattern decided (Snapshot CSV)
