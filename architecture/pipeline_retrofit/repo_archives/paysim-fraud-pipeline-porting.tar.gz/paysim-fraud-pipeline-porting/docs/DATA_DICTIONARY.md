# Data Dictionary: paysim-fraud-pipeline
> Owner: DQS (Data Quality Steward)
> Updated: setiap kali schema berubah

## Business Terms
| Term | Definition | Example |
|------|-----------|---------|
| Fraud Transaction | Transaction where isFraud = 1 | TRANSFER of 181,161 flagged fraud |
| Account Drain | Zero-out event — newbalanceOrig = 0 after txn | Account C12345 drained to 0 |
| Drain Velocity | % of sender balance removed in single txn: amount/oldbalanceOrg × 100 | 95.5% drain |
| Suspicious Sequence | TRANSFER followed by CASH-OUT within same session (same nameOrig) | C99999: TRANSFER step 10, CASH-OUT step 11 |
| False Positive | isFlaggedFraud=1 BUT isFraud=0 | System flagged but not actual fraud |
| False Negative | isFraud=1 BUT isFlaggedFraud=0 | Actual fraud missed by system |
| Merchant | Transaction destination with prefix M — no balance data | M1234567 |
| Step | Unit of simulated time — 1 step = 1 hour of operation | step 24 = end of Day 1 |

## Source Table: transactions (Bronze)
| Column | Business Name | Type | Nullable | Rule | Example |
|--------|--------------|------|----------|------|---------|
| step | Transaction Hour | INT | N | Range 1–744 | 1 |
| type | Transaction Type | STRING | N | ENUM: CASH-IN, CASH-OUT, DEBIT, PAYMENT, TRANSFER | TRANSFER |
| amount | Transaction Amount | DOUBLE | N | > 0 | 181161.03 |
| nameOrig | Sender ID | STRING | N | Prefix C | C1231006815 |
| oldbalanceOrg | Sender Balance Before | DOUBLE | N | >= 0 | 181161.03 |
| newbalanceOrig | Sender Balance After | DOUBLE | N | >= 0 | 0.0 |
| nameDest | Receiver ID | STRING | N | Prefix C atau M | C1666544295 |
| oldbalanceDest | Receiver Balance Before | DOUBLE | Y* | 0 untuk prefix M | 0.0 |
| newbalanceDest | Receiver Balance After | DOUBLE | Y* | 0 untuk prefix M | 0.0 |
| isFraud | Fraud Label | INT | N | 0 atau 1 | 1 |
| isFlaggedFraud | System Fraud Flag | INT | N | 0 atau 1 | 0 |

*Nullable by design untuk merchants

## Silver Tables
### silver.transactions
| Column | Business Name | Type | Nullable | Derived From | Rule |
|--------|--------------|------|----------|-------------|------|
| transaction_id | Transaction ID | STRING | N | MD5(nameOrig+step+amount) | Surrogate key |
| step | Transaction Hour | INT | N | Source | As-is |
| transaction_day | Transaction Day | INT | N | CEIL(step/24) | Day 1–31 |
| transaction_hour | Hour of Day | INT | N | ((step-1)%24)+1 | Hour 1–24 |
| transaction_datetime | Transaction Datetime | TIMESTAMP | N | Base + step hours | Synthetic 2024-01-01 base |
| type | Transaction Type | STRING | N | Source | Validated ENUM |
| amount | Amount | DOUBLE | N | Source | > 0 |
| sender_id | Sender Customer ID | STRING | N | nameOrig | Prefix C |
| receiver_id | Receiver ID | STRING | N | nameDest | Prefix C atau M |
| is_merchant_dest | Merchant Flag | INT | N | nameDest LIKE 'M%' | 0 atau 1 |
| sender_balance_before | Sender Balance Before | DOUBLE | N | oldbalanceOrg | >= 0 |
| sender_balance_after | Sender Balance After | DOUBLE | N | newbalanceOrig | >= 0 |
| receiver_balance_before | Receiver Balance Before | DOUBLE | Y | oldbalanceDest | NULL untuk merchants |
| receiver_balance_after | Receiver Balance After | DOUBLE | Y | newbalanceDest | NULL untuk merchants |
| is_fraud | Fraud Label | INT | N | isFraud | 0 atau 1 |
| is_flagged_fraud | System Flag | INT | N | isFlaggedFraud | 0 atau 1 |
| balance_drain_pct | Drain Velocity % | DOUBLE | Y | amount/oldbalanceOrg×100 | NULL kalau oldbalanceOrg=0 |
| is_zero_out | Zero-Out Event | INT | N | newbalanceOrig=0 AND amount>0 | 0 atau 1 |
| balance_disc_orig | Sender Balance Discrepancy | DOUBLE | N | (oldbalanceOrg-amount)-newbalanceOrig | 0 = no discrepancy |
| dq_flag | Data Quality Flag | INT | N | GX validation result | 0 = clean |
| ingestion_ts | Ingestion Timestamp | TIMESTAMP | N | Pipeline runtime | Auto |
| batch_id | Batch ID | STRING | N | Airflow run_id | Traceability |

## Gold Tables (dbt Marts)
### mart_fraud_summary
| Column | Business Name | Type | KPI? | Formula | Notes |
|--------|--------------|------|------|---------|-------|
| summary_date | Report Date | DATE | N | transaction_day derived | Partition key |
| transaction_type | Transaction Type | STRING | N | dim_transaction_type | Group by |
| total_transactions | Total Txn Count | BIGINT | Y | COUNT(*) | |
| fraud_count | Fraud Count | BIGINT | Y | COUNT(is_fraud=1) | |
| fraud_rate_pct | Fraud Rate % | DOUBLE | Y | fraud_count/total×100 | |
| total_amount | Total Amount | DOUBLE | N | SUM(amount) | |
| fraud_amount | Fraud Amount | DOUBLE | Y | SUM(amount WHERE fraud) | |
| flagged_count | System Flagged Count | BIGINT | N | COUNT(is_flagged_fraud=1) | |
| true_positive | Correct Detections | BIGINT | Y | COUNT(flagged AND fraud) | |
| false_positive | False Alarms | BIGINT | Y | COUNT(flagged AND !fraud) | |
| detection_rate_pct | Detection Rate % | DOUBLE | Y | true_positive/fraud_count×100 | |
| false_positive_rate_pct | False Positive Rate % | DOUBLE | Y | false_positive/flagged×100 | |

### mart_customer_risk
| Column | Business Name | Type | KPI? | Formula | Notes |
|--------|--------------|------|------|---------|-------|
| customer_id | Customer ID | STRING | N | sender_id | PK |
| risk_date | Risk Date | DATE | N | transaction_day | |
| total_sent | Total Amount Sent | DOUBLE | N | SUM(amount) | |
| total_received | Total Amount Received | DOUBLE | N | SUM incoming | |
| transaction_count | Txn Count | INT | N | COUNT(*) | |
| zero_out_count | Zero-Out Events | INT | Y | SUM(is_zero_out) | |
| max_drain_velocity | Max Drain % | DOUBLE | Y | MAX(balance_drain_pct) | |
| fraud_txn_count | Fraud Txn Count | INT | Y | SUM(is_fraud) | |
| is_high_risk | High Risk Flag | INT | Y | zero_out OR max_drain>95% | |
| running_fraud_total | Cumulative Fraud Count | INT | Y | Cumulative sum | Dari cumulative table |
| running_fraud_amount | Cumulative Fraud Amount | DOUBLE | Y | Cumulative sum | Dari cumulative table |

## Dimension Tables
### dim_customer
| Column | Type | SCD? | Description |
|--------|------|------|-------------|
| customer_sk | INT | N | Surrogate key |
| customer_id | STRING | N | Natural key — nameOrig/nameDest prefix C |
| customer_type | STRING | N | 'SENDER' / 'RECEIVER' / 'BOTH' |
| first_seen_day | INT | N | First transaction day |
| last_seen_day | INT | N | Last transaction day |

### dim_merchant
| Column | Type | SCD? | Description |
|--------|------|------|-------------|
| merchant_sk | INT | N | Surrogate key |
| merchant_id | STRING | N | Natural key — nameDest prefix M |
| first_seen_day | INT | N | First transaction received day |

### dim_time
| Column | Type | Description |
|--------|------|-------------|
| step | INT | PK — source step value |
| transaction_day | INT | CEIL(step/24) |
| transaction_hour | INT | ((step-1)%24)+1 |
| transaction_datetime | TIMESTAMP | Synthetic datetime |
| day_of_week | STRING | Derived dari datetime |
| is_weekend | INT | 0 atau 1 |

### dim_transaction_type
| Column | Type | Description |
|--------|------|-------------|
| type_id | INT | PK |
| type_code | STRING | CASH-IN, CASH-OUT, DEBIT, PAYMENT, TRANSFER |
| type_category | STRING | 'INFLOW', 'OUTFLOW', 'NEUTRAL' |
| fraud_possible | INT | 1 = TRANSFER atau CASH-OUT sahaja |
