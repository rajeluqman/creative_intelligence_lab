# ADR-002: Silver GX Suite 14/15 — Accept the `merchant_balance_null` WARN

Status: Accepted
Date  : 2026-06-29
Owner : Data Quality Steward + Data Architect (pipeline-retrofit, repo 3/4)

## Context
README.md "Staging Run Evidence (2026-05-12)" and "Phase Completion" both state the Silver
GX suite ran **14/15** with "1 WARN" but name no specific check. This is the kind of
resume↔repo mismatch the retrofit's `business-analyst`/`documentation-sherpa` pair must close
with `file:line` evidence, not leave as an unattributed footnote (per
`01_OPUS_DECISIONS.md`: "paysim: GE 14/15 WARN ADR — fix OR formally accept with written
rationale").

`data_quality/run_silver_suite.py` has exactly 3 WARN-capable checks (the rest are CRITICAL,
block-Gold):
1. `merchant_balance_null` — `receiver_balance_before` non-NULL on `is_merchant_dest=1` rows
2. `drain_pct_range` — `balance_drain_pct > 200`
3. `fraud_rate_check` — fraud rate outside 0.10%–0.20% (staging/prod only)

`docs/DQD.md`'s "Known Expected Anomalies (jangan flag as error)" section lists exactly one
of these three as an explicitly expected pattern: **"Merchant balance = 0 → by design"** —
i.e. the synthetic PaySim1 dataset's merchant destination rows are expected to carry
non-zero/non-NULL balance metadata, which is precisely what `merchant_balance_null` flags.

## Decision
The documented "1 WARN" in the Silver 14/15 result is **`merchant_balance_null`**. It is
formally **ACCEPTED**, not a defect to fix:
- The PaySim1 simulator does not model real merchant account balances — `receiver_balance_*`
  fields for `M`-prefixed destinations carry placeholder/non-NULL values by construction, not
  by an upstream data-quality failure.
- `docs/DQD.md` already classifies this anomaly as MEDIUM severity, "Log — expected pattern",
  not CRITICAL or HIGH — consistent with a WARN, not a FAIL, in
  `data_quality/run_silver_suite.py`.
- Fixing it (e.g. force-nulling merchant balances in Silver) would fabricate data the source
  system never produced, which is worse than documenting the known anomaly.

## Consequences
(+) The "1 WARN" claim is now attributable to a specific check + a specific documented reason
    — defensible in an interview (see `INTERVIEW_GUIDE.md`).
(+) No code change required; the suite's existing severity classification (WARN, not FAIL)
    was already correct.
(-) Anyone reading only README.md without this ADR still sees an unattributed "1 WARN" —
    mitigated by `INTERVIEW_GUIDE.md`'s Resume Claim ↔ Repo Evidence table pointing here.

## Alternatives Rejected
- **Fix by nulling merchant balances in Silver**: rejected — would mask the simulator's real
  behavior, not represent a genuine data-quality improvement.
- **Promote to a hard FAIL**: rejected — DQD.md already classifies this as MEDIUM/expected;
  promoting it would block Gold on a non-issue.
- **Leave unattributed**: rejected — this is exactly the resume↔repo mismatch class this
  retrofit effort exists to close (see CIL's pipeline-retrofit plan, 01_OPUS_DECISIONS.md —
  lives in the `creative_intelligence_lab` repo, not this one).

## References
- `data_quality/run_silver_suite.py` — `merchant_balance_null` check
- `docs/DQD.md` — "Known Expected Anomalies"
- `docs/ADR/ADR-001-hybrid-paradigm.md` — the grain this suite validates
