# ADR-001: Data Modelling Paradigm — Hybrid (Kimball + Cumulative Table)

Status: Accepted
Date  : 2026-05-11
Owner : Data Architect + Data Platform Engineer

## Context
Dataset: PaySim1 — 6.3M mobile money transactions, 30 hari simulasi.
Two distinct analytical requirements:
1. Fraud reporting — aggregate KPIs, dimension joins, daily summaries
2. Account drain detection — temporal running totals, behavioral patterns

## Decision
Paradigm: Hybrid — Kimball Star Schema + Cumulative Table Design

fact_transactions    → Kimball grain — 1 row = 1 txn
                       Standard star schema joins
                       Partition by transaction_day

fact_customer_daily_balance → Cumulative grain — 1 row = 1 customer per hari
                               Delta Lake MERGE incremental
                               Running totals pre-computed

## Consequences
(+) Fraud KPIs queryable dengan standard GROUP BY — Power BI friendly
(+) Running totals available tanpa full table scan setiap query
(+) Delta Lake MERGE fit perfectly untuk cumulative pattern
(+) Dua paradigm dalam portfolio — tunjuk breadth of modelling knowledge
(-) More storage — cumulative duplikate daily data
(-) MERGE logic lebih complex dari pure append
(-) Dua fact tables — AE perlu faham dua grain

## Alternatives Rejected
- Pure Kimball: rejected — running totals require expensive full scan setiap query
- Pure OBT: rejected — Databricks CE 15GB RAM insufficient untuk 6.3M rows nested Array of Struct
- Pure Cumulative: rejected — aggregate fraud KPIs messy tanpa proper star schema

## DPE Feasibility Validation
[✅] Databricks CE 15GB — simple cumulative schema (no nested) = feasible
[✅] Delta Lake MERGE — CE supported
[✅] S3 5GB — CSV 470MB + Delta overhead ~1.5GB = under limit
[✅] Snowflake $400 — 2 marts XS warehouse = sustainable
