# BRD: paysim-fraud-pipeline
> Status: DRAFT — Pending Phase 1 sign-off
> Domain: fintech | Dataset: PaySim1 — 6.3M mobile money transactions

## Business Context
PaySim simulates 30 hari mobile money transactions (~6.3M rows).
Fraud berlaku dalam TRANSFER dan CASH-OUT sahaja.
Fraud rate: 0.13% — high imbalance, high financial impact.

## Stakeholders
| Stakeholder | Role | Data Need |
|-------------|------|-----------|
| Risk & Compliance Team | Primary | Fraud transaction reporting, alert thresholds |
| Product Team | Secondary | Transaction behavior patterns, channel mix |
| Operations | Secondary | Pipeline health, SLA monitoring |

## Business Requirements
1. Detect dan report fraud transactions dalam near-real-time (batch hourly simulate)
2. Identify account drain patterns — balance zero-out events
3. Evaluate effectiveness of original fraud flagging system (isFlaggedFraud accuracy)
4. Segment transaction types untuk risk profiling

## KPIs
| KPI | Formula | Target | Frequency |
|-----|---------|--------|-----------|
| Fraud rate (%) | COUNT(isFraud=1) / COUNT(*) × 100 | Baseline: 0.13% | Daily |
| Fraud amount (RM) | SUM(amount WHERE isFraud=1) | Monitor trend | Daily |
| Fraud detection rate | COUNT(flagged AND fraud) / COUNT(fraud) × 100 | >80% | Daily |
| False positive rate | COUNT(flagged AND !fraud) / COUNT(flagged) × 100 | <20% | Daily |
| Zero-out events | COUNT(newbalanceOrig=0 AND amount>0) | Monitor threshold | Daily |
| Balance drain velocity | AVG(amount/oldbalanceOrg × 100) WHERE isFraud=1 | Baseline first | Daily |

## Business Definitions
- "Fraud transaction" = isFraud = 1 dalam source data
- "Flagged transaction" = isFlaggedFraud = 1 (original heuristic system)
- "Account drain" = newbalanceOrig = 0 after transaction (zero-out event)
- "Drain velocity" = amount / oldbalanceOrg × 100 (% of balance drained)
- "Suspicious sequence" = TRANSFER followed by CASH-OUT by same account within N steps
- "Merchant" = nameDest prefix "M" — no balance tracking available
- "Customer" = nameOrig atau nameDest prefix "C"

## Alert Thresholds
- Any fraud detected dalam batch → CRITICAL Slack alert
- Drain velocity > 95% AND amount > 10,000 → HIGH alert
- Silver row count drop > 1% dari Bronze → CRITICAL, block Gold
- isFlaggedFraud discrepancy > 10% → HIGH, flag untuk DQS review

## SLA
- Bronze available: T+5 minit dari ingestion trigger
- Silver available: T+20 minit
- Gold available: T+35 minit
- Power BI refresh: T+40 minit

## Out of Scope (Phase 1)
- ML model training untuk fraud prediction (Phase 2 — future)
- Real-time streaming (simulate batch sahaja)
- PII masking (synthetic data — no real PII)

## Sign-off Gate
| Agent | Status | Reason | Date |
|-------|--------|--------|------|
| BA | PENDING | - | - |
| PO | PENDING | - | - |
| PM | PENDING | - | - |
| DQS | PENDING | - | - |
