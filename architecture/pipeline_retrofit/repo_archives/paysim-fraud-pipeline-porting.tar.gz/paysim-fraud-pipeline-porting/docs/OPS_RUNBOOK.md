# OPS Runbook: paysim-fraud-pipeline
> Status: DRAFT — Pending Phase 5 sign-off

## Monitoring
| Tool | Where |
|------|-------|
| Airflow | localhost:8080 |
| GX Report | docs/screenshots/gx_report.html |
| Snowflake | Snowflake UI → PAYSIM_FRAUD database |
| Slack | #paysim-fraud-alerts |
| Logs | airflow/logs/ |

## Alert SLAs
| Severity | Response |
|----------|----------|
| CRITICAL | 15 minit |
| HIGH | 1 jam |
| MEDIUM | Hari bekerja |

## Session Start Checklist
[ ] Databricks cluster running (CE — restart kalau terminated)
[ ] Airflow standalone running (airflow standalone)
[ ] .env loaded (source .env.dev)
[ ] S3 bucket accessible (aws s3 ls)
[ ] Snowflake connection OK (dbt debug)
[ ] PaySim CSV ada dalam data/ folder (dev: 1000 rows)

## Common Scenarios

### Bronze job fail
Symptom : bronze_ingest = FAILED
Check   : airflow/logs/paysim_fraud_pipeline/bronze_ingest/
Fix 1   : CSV missing → check data/ folder atau S3 path
Fix 2   : S3 permission → check AWS credentials .env
Rerun   : Airflow UI → Clear task → Trigger DAG

### Silver GX CRITICAL fail (row count)
Symptom : silver_dq_check = FAILED, row count mismatch
Check   : docs/screenshots/gx_report.html
Fix 1   : Bronze corrupt → rerun bronze dari CSV
Fix 2   : PySpark OOM → Databricks CE memory issue, reduce partition size
Decision: Rerun dengan smaller chunk kalau memory issue

### Cumulative MERGE fail
Symptom : silver_cumulative_merge = FAILED
Check   : Delta Lake transaction log
Fix 1   : Concurrent write conflict → retry once
Fix 2   : Schema mismatch → check silver.transactions schema berubah
Fix 3   : CE cluster terminated mid-run → restart cluster, rerun dari silver_cumulative_merge

### Databricks cluster terminated (auto-terminate 2 jam)
Symptom : Silver/Gold fail mid-run
Fix     : CE UI → restart cluster → rerun task dari Airflow
Prevent : Monitor job duration, checkpoint setiap 30 minit

### dbt test fail (FK violation)
Symptom : gold_dbt_test = FAILED
Check   : dbt test output dalam Airflow logs
Fix 1   : dim tables tak populate → rerun int_ models dulu
Fix 2   : Silver quarantine ada rows → check data_quality/quarantine table
Fix 3   : Merchant FK NULL → confirm is_merchant_dest logic correct

## Backfill Procedure
1. Identify affected transaction_day range
2. Delete Silver partition: DELETE FROM silver.transactions WHERE transaction_day = X
3. Rerun: bronze_ingest → silver_transform → silver_cumulative_merge → silver_dq_check → gold
4. Verify reconciliation: Bronze count = Silver count (excluding quarantine)
5. Log dalam JOURNEY_LOG.md

## PaySim-Specific Notes
- Fraud HANYA berlaku dalam TRANSFER dan CASH-OUT — kalau fraud dalam type lain, flag sebagai data issue bukan pipeline issue
- Merchant balance = 0 adalah EXPECTED — jangan alert
- Class imbalance 0.13% adalah EXPECTED — GX configured untuk accept ini
- step column = simulated time, bukan real timestamp
