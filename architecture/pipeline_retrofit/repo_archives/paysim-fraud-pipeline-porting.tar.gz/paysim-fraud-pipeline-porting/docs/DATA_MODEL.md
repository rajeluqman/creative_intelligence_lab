# Data Model: paysim-fraud-pipeline
> Owner: Data Architect
> Status: DRAFT — Pending Phase 3 sign-off
> Co-validated by: Data Platform Engineer (feasibility)

## Paradigm Decision
Chosen  : Hybrid — Kimball Star Schema + Cumulative Table Design
Reason  : Fraud reporting memerlukan Kimball (aggregate KPIs, dimension joins).
          Account drain detection memerlukan Cumulative (running totals, temporal patterns).
          Dua use case → dua paradigm dalam satu pipeline.

## Paradigm Tradeoff
| Factor | Decision |
|--------|----------|
| Storage | More — cumulative table duplikat data per hari, trade storage for compute |
| Compute | Less — no full scan untuk running totals, Delta Lake MERGE incremental |
| Join complexity | Medium — star schema joins untuk fraud mart, minimal untuk risk mart |
| Query pattern | Both — aggregate (fraud summary) + row-level (customer risk) |
| Free tier fit | Feasible — Databricks CE 15GB sufficient kalau cumulative tidak nested Array of Struct |

## Why Not Pure OBT
OBT rejected — Databricks CE 15GB insufficient untuk 6.3M rows dengan nested Array of Struct.
Cumulative table guna simple schema (1 row per customer per hari) — safe untuk CE memory.

## Why Not Pure Kimball
Pure Kimball rejected — temporal running totals (running_fraud_total, running_fraud_amount)
require full table scan setiap query. Cumulative table pre-compute ini dalam Silver layer.

## Fact Tables (Logical Layer)

### fact_transactions
- Grain   : 1 row = 1 transaksi (EXPLICIT)
- Source  : silver.transactions
- Pattern : Snapshot → Incremental append (partition by transaction_day)
- Partitioned by: transaction_day

| Column | Type | FK? | Description |
|--------|------|-----|-------------|
| transaction_sk | BIGINT | N | Surrogate key |
| transaction_id | STRING | N | Natural key (MD5) |
| step_fk | INT | Y | → dim_time.step |
| type_fk | INT | Y | → dim_transaction_type.type_id |
| sender_fk | INT | Y | → dim_customer.customer_sk |
| receiver_fk | INT | Y | → dim_customer.customer_sk (nullable) |
| merchant_fk | INT | Y | → dim_merchant.merchant_sk (nullable) |
| amount | DOUBLE | N | Transaction amount |
| sender_balance_before | DOUBLE | N | |
| sender_balance_after | DOUBLE | N | |
| receiver_balance_before | DOUBLE | Y | NULL untuk merchants |
| receiver_balance_after | DOUBLE | Y | NULL untuk merchants |
| balance_drain_pct | DOUBLE | Y | Derived measure |
| is_zero_out | INT | N | 0 atau 1 |
| is_fraud | INT | N | 0 atau 1 |
| is_flagged_fraud | INT | N | 0 atau 1 |
| balance_disc_orig | DOUBLE | N | Quality measure |
| transaction_day | INT | N | Partition key |
| ingestion_ts | TIMESTAMP | N | |
| batch_id | STRING | N | |

### fact_customer_daily_balance (Cumulative Table)
- Grain   : 1 row = 1 customer per hari (EXPLICIT)
- Source  : silver.transactions (aggregated per customer per day)
- Pattern : Cumulative — Delta Lake MERGE setiap hari
- Logic   : New day data + carry forward running totals
- Partitioned by: balance_date

| Column | Type | FK? | Description |
|--------|------|-----|-------------|
| customer_day_sk | BIGINT | N | Surrogate key |
| customer_fk | INT | Y | → dim_customer.customer_sk |
| balance_date | DATE | N | Partition key |
| daily_sent_amount | DOUBLE | N | SUM(amount) untuk hari ni |
| daily_received_amount | DOUBLE | N | SUM incoming hari ni |
| daily_txn_count | INT | N | COUNT(*) hari ni |
| daily_fraud_count | INT | N | COUNT(is_fraud=1) hari ni |
| daily_zero_out_count | INT | N | COUNT(is_zero_out=1) hari ni |
| max_daily_drain_pct | DOUBLE | Y | MAX(balance_drain_pct) hari ni |
| running_txn_total | BIGINT | N | Cumulative txn count sampai hari ni |
| running_fraud_total | INT | N | Cumulative fraud count sampai hari ni |
| running_fraud_amount | DOUBLE | N | Cumulative fraud amount sampai hari ni |
| running_sent_total | DOUBLE | N | Cumulative total sent |
| is_high_risk_today | INT | N | daily_zero_out > 0 OR max_drain > 95% |
| ingestion_ts | TIMESTAMP | N | |

## Dimension Tables (Logical Layer)

### dim_customer
- SCD Type: 1 (overwrite)
- Reason  : Synthetic data — customer attributes tidak berubah, ID sahaja yang penting
- Source  : Derived dari nameOrig + nameDest dalam transactions

### dim_merchant
- SCD Type: None (static)
- Reason  : Merchant = destination prefix M, no attributes berubah

### dim_time
- SCD Type: None (static, pre-populated)
- Reason  : Derived lookup table — 744 rows (744 steps)

### dim_transaction_type
- SCD Type: None (static, 5 rows)
- Reason  : Enum values — takkan berubah

## Cumulative Table MERGE Strategy
```
EVERY PIPELINE RUN:
1. Aggregate today's transactions → daily_summary
2. MERGE INTO fact_customer_daily_balance
   ON customer_fk = customer_fk AND balance_date = today
   WHEN MATCHED → UPDATE daily + running totals
   WHEN NOT MATCHED → INSERT new row with running totals
                      (carry forward from yesterday's row)
```

## Source Ingestion Pattern
| Table | Pattern | Reason |
|-------|---------|--------|
| transactions (raw) | Full Snapshot → S3 | CSV one-shot, partition by simulated day |
| fact_transactions | Incremental append | partition by transaction_day |
| fact_customer_daily_balance | Delta Lake MERGE | Cumulative pattern |

## dbt Model Structure
```
staging/
  staging__paysim_transactions.sql       → source cleaning, type cast, rename columns

intermediate/
  int_transactions_enriched.sql           → add derived columns (drain_pct, zero_out)
  int_customer_daily_aggregates.sql       → daily agg per customer
  int_cumulative_customer_balance.sql     → running totals logic

marts/
  mart_fraud_summary.sql                  → fraud KPIs by day + type
  mart_customer_risk.sql                  → customer risk profile + running totals
```

## Physical Layer Notes (validated by DPE)
| Check | Status | Notes |
|-------|--------|-------|
| Databricks CE 15GB fit | ✅ | Cumulative guna simple schema — no nested Array. Monitor 6.3M rows Silver |
| S3 5GB limit | ✅ | CSV ~470MB + Delta Lake overhead ~1.5GB staging. Under limit |
| Delta Lake MERGE support | ✅ | CE support MERGE operation — cumulative pattern feasible |
| Snowflake credit sustainable | ✅ | Gold only — 2 marts, XS warehouse. Est. <$5 untuk full run |

## Sign-off Gate
| Agent | Status | Reason |
|-------|--------|--------|
| DA | PENDING | - |
| DPE | PENDING | - |
| SDE | PENDING | - |
| AE | PENDING | - |
| PM | PENDING | - |

## Hard Blockers Before Phase 4
[ ] Grain locked — explicit, agreed
[ ] SCD Type 1 confirmed untuk semua dimensions
[ ] Cumulative MERGE strategy documented
[ ] DA + DPE feasibility sync confirmed
[ ] Paradigm ADR written (Hybrid justification)
