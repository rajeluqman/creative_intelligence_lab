# Pipeline SPEC: paysim-fraud-pipeline
> Status: DRAFT — Pending Phase 3 sign-off

## Data Flow
Source CSV → Bronze (Delta Lake + S3) → Silver (PySpark + Databricks) → Gold (dbt + Snowflake) → Power BI

## Bronze Layer
Input     : PaySim1 CSV dari S3 landing zone
Output    : bronze.transactions (Delta Lake)
Pattern   : Full Snapshot → partition by simulated day
Logic     : Store as-is + ingestion_ts, source_system, batch_id
Partition : transaction_day (derived dari step)

Columns added:
- ingestion_ts    : TIMESTAMP pipeline runtime
- source_system   : 'paysim1_kaggle'
- batch_id        : Airflow run_id
- source_file     : S3 path

## Silver Layer

### silver.transactions
Input  : bronze.transactions
Output : silver.transactions (Delta Lake)

Steps:
1. DEDUPLICATE  : Keep latest ingestion_ts per (nameOrig, step, amount)
2. TYPE CAST    : step→INT, amount→DOUBLE, isFraud→INT, isFlaggedFraud→INT
3. NULL HANDLE  : nameOrig, nameDest, type, amount NULL → REJECT
                  oldbalanceDest NULL pour prefix M → ACCEPTABLE, replace 0
4. DERIVED      :
   - transaction_id     = MD5(nameOrig + CAST(step AS STRING) + CAST(amount AS STRING))
   - transaction_day    = CEIL(step / 24)
   - transaction_hour   = ((step - 1) % 24) + 1
   - transaction_datetime = TIMESTAMP('2024-01-01') + INTERVAL (step-1) HOURS
   - is_merchant_dest   = CASE WHEN nameDest LIKE 'M%' THEN 1 ELSE 0 END
   - balance_drain_pct  = CASE WHEN oldbalanceOrg > 0 THEN (amount/oldbalanceOrg*100) ELSE NULL END
   - is_zero_out        = CASE WHEN newbalanceOrig = 0 AND amount > 0 THEN 1 ELSE 0 END
   - balance_disc_orig  = ABS((oldbalanceOrg - amount) - newbalanceOrig)
   - balance_disc_dest  = CASE WHEN is_merchant_dest=0 THEN ABS((oldbalanceDest + amount) - newbalanceDest) ELSE NULL END
5. RENAME       : nameOrig→sender_id, nameDest→receiver_id, oldbalanceOrg→sender_balance_before, etc.
6. VALIDATE     : isFraud IN (0,1), type IN valid_types → else dq_flag=1

### silver.customer_daily_balance (Cumulative)
Input  : silver.transactions (aggregated per sender_id per transaction_day)
Output : silver.customer_daily_balance (Delta Lake — MERGE)

Logic:
1. Aggregate today's data:
   daily_summary = silver.transactions
     GROUP BY sender_id, transaction_day
     AGG: SUM(amount) as daily_sent, COUNT(*) as daily_count,
          SUM(is_fraud) as daily_fraud, SUM(is_zero_out) as daily_zero_out,
          MAX(balance_drain_pct) as max_daily_drain

2. Delta Lake MERGE:
   ON (customer_id = daily_summary.sender_id AND balance_date = daily_summary.transaction_day)
   WHEN MATCHED → UPDATE daily columns + recalculate running totals
   WHEN NOT MATCHED → INSERT new row:
     running_txn_total   = yesterday.running_txn_total + daily_txn_count
     running_fraud_total = yesterday.running_fraud_total + daily_fraud_count
     running_fraud_amount = yesterday.running_fraud_amount + daily_fraud_amount
     (first appearance: running = daily values sahaja)

## Gold Layer (dbt)

### staging__paysim_transactions.sql
Input  : silver.transactions
Output : Clean source layer, rename, type confirm

### int_transactions_enriched.sql
Input  : staging__paysim_transactions
Logic  : Join dim_time, dim_transaction_type
Output : fact_transactions ready (with FKs)

### int_customer_daily_aggregates.sql
Input  : silver.customer_daily_balance
Logic  : Join dim_customer
Output : fact_customer_daily_balance ready

### mart_fraud_summary.sql
Input  : int_transactions_enriched + dim tables
Grain  : 1 row = 1 day + 1 transaction type
KPIs   : fraud_rate, fraud_amount, detection_rate, false_positive_rate

### mart_customer_risk.sql
Input  : int_customer_daily_aggregates
Grain  : 1 row = 1 customer per hari
KPIs   : zero_out_count, max_drain_velocity, running_fraud_total, is_high_risk

## Business Rules
- RULE 1 : Fraud HANYA valid untuk type IN ('TRANSFER', 'CASH-OUT')
           isFraud = 1 untuk PAYMENT/DEBIT/CASH-IN = data anomaly, flag sebagai dq_issue
- RULE 2 : balance_drain_pct = NULL kalau oldbalanceOrg = 0 (avoid divide by zero)
- RULE 3 : running totals carry forward dari previous hari — MERGE strategy
- RULE 4 : Merchant destination → receiver balance columns = NULL (not error)
- RULE 5 : is_high_risk = 1 BILA daily_zero_out_count > 0 OR max_daily_drain_pct > 95

## Error Handling
- NULL critical column → REJECT + quarantine + CRITICAL alert
- Divide by zero (balance_drain) → NULL, bukan error
- Duplicate transaction → keep latest ingestion_ts
- FK violation → quarantine + flag untuk DQS
- isFraud = 1 dalam non-TRANSFER/CASH-OUT → dq_flag = 1, INCLUDE in fact, flag untuk review
