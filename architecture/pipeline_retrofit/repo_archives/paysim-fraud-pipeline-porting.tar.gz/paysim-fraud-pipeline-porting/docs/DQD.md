# DQD: paysim-fraud-pipeline
> Status: DRAFT — Pending Phase 5 sign-off
> Owner: DQS

## Bronze Suite
Suite: bronze_suite | Run: Sebelum Silver

| Check | Rule | Severity | Action |
|-------|------|----------|--------|
| Row count | Source = Bronze EXACT | CRITICAL | Block + alert |
| ingestion_ts | NOT NULL | CRITICAL | Reject |
| step | BETWEEN 1 AND 744 | CRITICAL | Reject |
| type | IN (CASH-IN, CASH-OUT, DEBIT, PAYMENT, TRANSFER) | CRITICAL | Reject |
| amount | > 0 | CRITICAL | Reject |
| nameOrig | NOT NULL, LIKE 'C%' | CRITICAL | Reject |
| nameDest | NOT NULL, LIKE 'C%' OR LIKE 'M%' | CRITICAL | Reject |
| isFraud | IN (0, 1) | CRITICAL | Reject |
| isFlaggedFraud | IN (0, 1) | CRITICAL | Reject |

## Silver Suite
Suite: silver_suite | Run: Selepas Silver transform

| Column | Rule | Severity | Action |
|--------|------|----------|--------|
| transaction_id | NOT NULL, UNIQUE | CRITICAL | Reject duplicates |
| sender_id | NOT NULL | CRITICAL | Reject |
| amount | > 0 | CRITICAL | Reject |
| transaction_day | BETWEEN 1 AND 31 | CRITICAL | Reject |
| balance_drain_pct | BETWEEN 0 AND 100 OR NULL | HIGH | Quarantine |
| fraud_rate_actual | BETWEEN 0.10% AND 0.20% | HIGH | Alert DQS — class imbalance check |
| row_count | BETWEEN 6,200,000 AND 6,400,000 | CRITICAL | Block Gold |
| is_fraud | IN (0, 1) | CRITICAL | Reject |
| merchant balance | oldbalanceDest=0 FOR prefix M | MEDIUM | Log — expected pattern |

## Gold Suite (dbt tests)
Suite: gold_suite | Run: Selepas dbt run

| Check | Rule | Severity |
|-------|------|----------|
| fact_transactions.transaction_sk | NOT NULL, UNIQUE | CRITICAL |
| fact_transactions.step_fk | IN dim_time.step | CRITICAL |
| fact_transactions.type_fk | IN dim_transaction_type.type_id | CRITICAL |
| mart_fraud_summary.fraud_rate_pct | NOT NULL, >= 0 | CRITICAL |
| mart_customer_risk.running_fraud_total | NOT NULL, >= 0 | CRITICAL |
| All dbt tests | Pass | CRITICAL |

## Referential Integrity
| FK Column | References | Action if Fail |
|-----------|-----------|----------------|
| fact_transactions.step_fk | dim_time.step | Quarantine + flag |
| fact_transactions.type_fk | dim_transaction_type.type_id | Reject |
| fact_transactions.sender_fk | dim_customer.customer_sk | Quarantine |
| fact_customer_daily_balance.customer_fk | dim_customer.customer_sk | Reject |

## Reconciliation
| Check | Tolerance |
|-------|-----------|
| Source CSV → Bronze | 0 (exact row count) |
| Bronze → Silver | <0.01% (dedup hanya duplicate ingestion, bukan source) |
| Silver → Gold fact | Exact match on transaction_id count |
| Silver fraud count → Gold fraud KPI | Exact match |

## Known Expected Anomalies (jangan flag as error)
- Merchant balance = 0 → by design
- Fraud rate 0.13% → expected, bukan anomaly
- Fraud HANYA dalam TRANSFER + CASH-OUT → expected behavior
- isFlaggedFraud ≠ isFraud → expected discrepancy, KPI metric

## Action on Failure
| Severity | Action |
|----------|--------|
| CRITICAL | Block downstream + Slack CRITICAL alert |
| HIGH | Quarantine bad rows + continue clean data + Slack HIGH alert |
| MEDIUM | dq_flag=True + log + continue |
