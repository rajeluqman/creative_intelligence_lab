# Architecture: paysim-fraud-pipeline
> Status: DRAFT — Pending Phase 3 sign-off

## Data Flow
```
PaySim1 CSV (6.3M rows)
    ↓ Python (boto3)
AWS S3 Landing Zone (paysim-fraud-pipeline-dev)
    ↓ Python → Delta Lake
Bronze Layer (Delta Lake on S3)
    → bronze.transactions (raw, as-is + metadata)
    ↓ PySpark (Databricks CE)
Silver Layer (Delta Lake)
    → silver.transactions (enriched, cleaned, derived columns)
    → silver.customer_daily_balance (cumulative — Delta MERGE)
    ↓ dbt Core (Snowflake)
Gold Layer (Snowflake)
    → mart_fraud_summary (Kimball — fraud KPIs by day + type)
    → mart_customer_risk (Cumulative — customer risk profile)
    ↓
Power BI (Fraud Intelligence Dashboard)
```

## Stack
| Layer | Tool | Free Tier | Justification |
|-------|------|-----------|---------------|
| Landing | AWS S3 | 5GB | CSV 470MB — under limit |
| Bronze | Delta Lake on S3 | Included | ACID, time travel, raw preserve |
| Silver | PySpark + Databricks CE | Free | Managed Spark, MERGE support |
| Gold | dbt Core + Snowflake | $400 credit | Semantic layer, SQL transforms |
| Orchestration | Airflow standalone | Free (pip) | localhost:8080 |
| Quality | Great Expectations | Free | Suite per layer, HTML report |
| BI | Power BI | Free tier | Gold consumer |

## Data Modelling — Hybrid
See docs/DATA_MODEL.md
See docs/ADR/ADR-001-hybrid-paradigm.md

fact_transactions           → Kimball grain — 1 row = 1 txn
fact_customer_daily_balance → Cumulative grain — 1 row = 1 customer per hari

## Environments
| Env | Purpose | Data | Trigger |
|-----|---------|------|---------|
| dev | Develop + unit test | 1000 rows | Manual |
| staging | Full test + validation | 6.3M rows | Airflow scheduled |
| prod | Screenshot evidence | 6.3M rows | Manual once |

## Non-Functional
| Requirement | Target |
|-------------|--------|
| Pipeline reliability | >95% successful runs |
| Data freshness | Gold by T+35 minit |
| Recovery | Delta Lake time travel backfill |
| Fraud alert latency | Slack dalam 1 minit selepas Gold ready |

## ADRs
- ADR-001: Hybrid paradigm decision
