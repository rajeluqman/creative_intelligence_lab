# REPO_MAP — generated navigation index

> **GENERATED — do not hand-edit.** `python scripts/gen_repo_map.py` rebuilds it from
> ground truth; CI runs `--check` and fails if this file is stale. Purpose is extracted
> from each file's own docstring / first heading / leading comment; *Uses* and *Used by*
> are parsed (`ast` for Python, `ref()` for dbt), never authored.
>
> **This is a pointer, not a cache.** It tells you which file to open — then READ THAT
> FILE FRESH before you edit or assert about it (ANTI-SHORTCUT PROTOCOL, CLAUDE.md).

**80 files mapped.**

## Architecture Decision Records

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `docs/ADR/ADR-001-hybrid-paradigm.md` | ADR-001: Data Modelling Paradigm — Hybrid (Kimball + Cumulative Table) | — | — |
| `docs/ADR/ADR-002-silver-warn-acceptance.md` | ADR-002: Silver GX Suite 14/15 — Accept the merchant_balance_null WARN | — | — |

## Top-level docs

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `CLAUDE.md` | Paysim Fraud Pipeline — AI Context | — | — |
| `COST_LOG.md` | Cost Log — Paysim Fraud Pipeline | — | — |
| `DECISION_LOG.md` | Decision Log — Paysim Fraud Pipeline | — | — |
| `INTERVIEW_GUIDE.md` | Interview Guide — Paysim Fraud Pipeline | — | — |
| `PROJECT_STATUS.md` | Paysim Fraud Pipeline — Project Status | — | — |
| `README.md` | paysim-fraud-pipeline | — | — |
| `docs/ARCHITECTURE.md` | Architecture: paysim-fraud-pipeline | — | — |
| `docs/BRD.md` | BRD: paysim-fraud-pipeline | — | — |
| `docs/DATA_DICTIONARY.md` | Data Dictionary: paysim-fraud-pipeline | — | — |
| `docs/DATA_MODEL.md` | Data Model: paysim-fraud-pipeline | — | — |
| `docs/DQD.md` | DQD: paysim-fraud-pipeline | — | — |
| `docs/DRD.md` | DRD: paysim-fraud-pipeline | — | — |
| `docs/OPS_RUNBOOK.md` | OPS Runbook: paysim-fraud-pipeline | — | — |
| `docs/PIPELINE_SPEC.md` | Pipeline SPEC: paysim-fraud-pipeline | — | — |

## dbt — staging

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `gold/models/staging/dim_customer.sql` | (no leading -- comment) | — | int_customer_daily_aggregates.sql |
| `gold/models/staging/schema.yml` | — | — | — |
| `gold/models/staging/staging__paysim_transactions.sql` | (no leading -- comment) | — | int_transactions_enriched.sql |

## dbt — intermediate

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `gold/models/intermediate/int_cumulative_customer_balance.sql` | (no leading -- comment) | int_customer_daily_aggregates.sql, int_transactions_enriched.sql | mart_customer_risk.sql |
| `gold/models/intermediate/int_customer_daily_aggregates.sql` | (no leading -- comment) | dim_customer.sql | int_cumulative_customer_balance.sql |
| `gold/models/intermediate/int_transactions_enriched.sql` | (no leading -- comment) | staging__paysim_transactions.sql | int_cumulative_customer_balance.sql, mart_fraud_summary.sql |
| `gold/models/intermediate/schema.yml` | — | — | — |

## dbt — marts

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `gold/models/marts/mart_customer_risk.sql` | (no leading -- comment) | int_cumulative_customer_balance.sql | — |
| `gold/models/marts/mart_fraud_summary.sql` | (no leading -- comment) | int_transactions_enriched.sql | assert_fraud_identity_check.sql |
| `gold/models/marts/schema.yml` | — | — | — |

## dbt — tests

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `gold/tests/assert_fraud_identity_check.sql` | Singular test: true_positive + false_negative MUST equal fraud_count for every row. | mart_fraud_summary.sql | — |

## dbt — seeds

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `gold/seeds/generate_seeds.py` | Generate dbt seed CSV files for static dimension tables. | — | — |

## dbt — other

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `gold/.user.yml` | — | — | — |
| `gold/dbt_project.yml` | — | — | — |
| `gold/models/sources.yml` | — | — | — |
| `gold/package-lock.yml` | — | — | — |
| `gold/packages.yml` | — | — | — |

## Bronze ingestion

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `bronze/__init__.py` | (no module docstring) | — | — |
| `bronze/bronze_pipeline.py` | Bronze ingestion: PaySim1 CSV → Delta Lake | — | — |
| `bronze/download_dataset.py` | WHAT : Download dataset dari Kaggle API ikut environment | — | — |

## Silver transforms (incl. Databricks staging notebook)

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `silver/__init__.py` | (no module docstring) | — | — |
| `silver/cumulative_pipeline.py` | Cumulative table pipeline: silver.transactions → silver.customer_daily_balance | — | — |
| `silver/databricks_notebook.py` | (no module docstring) | — | — |
| `silver/databricks_to_snowflake.py` | Databricks SQL Warehouse → Snowflake STAGING | — | — |
| `silver/export_to_s3_parquet.py` | Silver → S3 Parquet → Snowflake COPY INTO | — | — |
| `silver/silver_pipeline.py` | Silver transform: bronze.transactions → silver.transactions | — | — |

## Airflow DAGs

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `airflow/dags/paysim_fraud_pipeline.py` | paysim-fraud-pipeline — Main Pipeline DAG | — | — |

## Data-quality suites

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `data_quality/__init__.py` | (no module docstring) | — | — |
| `data_quality/run_bronze_suite.py` | Bronze GX validation suite — runs sebelum Silver. | — | — |
| `data_quality/run_silver_suite.py` | Silver GX validation suite — runs selepas Silver transform, sebelum Gold. | — | — |

## Tests / contracts

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `tests/__init__.py` | (no module docstring) | — | — |
| `tests/boundary_contract.py` | Stack + scope boundary contract — deterministic gate over this repo's locked stack. | — | — |
| `tests/doc_reference_contract.py` | Doc-reference contract — deterministic gate against documentation drift. | — | — |
| `tests/identity_contract.py` | Identity contract — deterministic gate over the dual grain (Kimball + cumulative table). | — | — |
| `tests/test_bronze_ingest.py` | Unit tests for bronze/bronze_pipeline.py | — | — |
| `tests/test_silver_transform.py` | Unit tests for silver/silver_pipeline.py — transform logic. | — | — |

## Governance hooks

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `.claude/hooks/governance_guard.py` | Governance hook — makes Claude check governed docs/ADRs BEFORE and AFTER touching governed | — | — |

## Cabinet agents

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `.claude/agents/business-analyst.md` | name: business-analyst | — | — |
| `.claude/agents/cikgu.md` | name: cikgu | — | — |
| `.claude/agents/data-architect.md` | name: data-architect | — | — |
| `.claude/agents/data-platform-engineer.md` | name: data-platform-engineer | — | — |
| `.claude/agents/data-quality-steward.md` | name: data-quality-steward | — | — |
| `.claude/agents/documentation-sherpa.md` | name: documentation-sherpa | — | — |
| `.claude/agents/finops-agent.md` | name: finops-agent | — | — |
| `.claude/agents/product-owner.md` | name: product-owner | — | — |
| `.claude/agents/scope-guardian.md` | name: scope-guardian | — | — |
| `.claude/agents/senior-data-engineer.md` | name: senior-data-engineer | — | — |

## Learning

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `learning/CURRICULUM.md` | Learning Curriculum — Paysim Fraud Pipeline | — | — |
| `learning/LEARNING_LOG.md` | Learning Log — Paysim Fraud Pipeline | — | — |

## Simulation lab

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `simulation/ISOLATION_CONTRACT.md` | Isolation Contract — Paysim Simulation Lab | — | — |
| `simulation/check_isolation.py` | Isolation guard for the Paysim simulation lab (simulation/). | — | — |
| `simulation/faults/README.md` | Fault Catalog — Paysim Simulation Lab | — | — |
| `simulation/faults/inject.py` | Inject a named, reversible fault into the SIM lab only (never touches real models). | — | — |
| `simulation/faults/reset.py` | Reset the SIM lab to clean baseline — re-seed + re-build sim only. Never hand-patched. | — | — |
| `simulation/sim_dbt/dbt_project.yml` | Sim-only dbt project — name MUST differ from the real gold/dbt_project.yml ('paysim_fraud'). | — | — |
| `simulation/specs/01_SIM_cumulative_merge_troubleshoot.md` | SIM Spec — Cumulative MERGE Idempotency Troubleshoot Drill | — | — |
| `simulation/specs/02_SIM_bronze_partition_migration.md` | SIM Spec — Bronze Partition Migration Drill | — | — |
| `simulation/specs/03_SIM_snowflake_warehouse_optimize.md` | SIM Spec — Snowflake Warehouse Sizing Optimization Drill | — | — |

## Scripts

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `scripts/gen_repo_map.py` | Repo-map generator — the NAVIGATION half of the ANTI-SHORTCUT PROTOCOL (see CLAUDE.md). | — | — |
| `scripts/sync_docs_to_confluence.py` | Publish this repo's real docs/ set to Confluence as living documentation. | — | — |

## Confluence

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `confluence/00_START_HERE.md` | Start Here — Paysim Fraud Pipeline | — | — |

## Config

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `setup.sh` | — | — | — |

## Other

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `conftest.py` | (no module docstring) | — | — |
| `requirements.txt` | — | — | — |
