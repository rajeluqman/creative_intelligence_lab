# Paysim Fraud Pipeline — Project Status

> Resume-safe checkpoint. A fresh session reads "▶ RESUME HERE" first.
> Branch: `framework/governance-retrofit`. Retrofit source: `creative_intelligence_lab`
> (pipeline-retrofit effort, repo 3 of 4, after home-credit-pipeline and
> olist-ecommerce-pipeline — see `architecture/pipeline_retrofit/` in CIL for provenance).

## ▶ RESUME HERE
**Where we are:** Governance retrofit complete — CLAUDE.md, 10-agent roster (incl. cikgu +
finops-agent), governance hook, 3 contracts (all green, re-verified directly), repo-map
(generated, fresh, 66 files), 1 new ADR (the Silver-WARN acceptance), Confluence sync
adaptation, 3 logs (this file + COST_LOG.md + DECISION_LOG.md), learning layer, simulation
lab (isolation contract green), INTERVIEW_GUIDE.md, CI extension — built on
`framework/governance-retrofit`. NOT pushed, NOT a PR yet — owner reviews first.
**Stack preserved as-is**: Kaggle API → AWS S3 → PySpark/Delta Lake Bronze (local or
Databricks) → PySpark/Delta Lake Silver (dq_flag bitmask, RULE 1 fraud-type constraint,
**cumulative-table** Delta MERGE for `fact_customer_daily_balance`) → S3 Parquet/Databricks
SQL Warehouse bridge → Snowflake external stage → dbt Core Gold (Hybrid: Kimball
`fact_transactions` + cumulative `fact_customer_daily_balance`) → Power BI — verified by
reading the actual repo (bronze/, silver/, gold/, airflow/, data_quality/, requirements.txt),
not assumed from the retrofit brief.
**Next action:** owner review → push branch → open PR → then port the pattern (not a literal
copy — stacks differ, Volve has NO dbt and 0 pre-existing ADRs) onward to
Volve-Sensor-Production-Analytics-Pipeline (most work, last, per CIL's
`01_OPUS_DECISIONS.md` sequencing).
**Do NOT:** push or open the PR without owner sign-off; swap any tool in the stack; fabricate
resume claims beyond the one Silver-WARN attribution already reconciled.

## Build checklist (with evidence)
| Item | Status | Evidence |
|---|---|---|
| CLAUDE.md | ✅ | `CLAUDE.md` — real PySpark/Delta + Snowflake hybrid-grain stack table, governed-file map |
| .claude/agents/ ×10 | ✅ | `.claude/agents/*.md` — data-architect, scope-guardian, senior-data-engineer, data-quality-steward, product-owner, business-analyst, data-platform-engineer, documentation-sherpa, finops-agent, cikgu |
| .claude/settings.json + hooks/governance_guard.py | ✅ | retargeted to `gold/models/marts/`, `silver/cumulative_pipeline.py`, `docs/DATA_MODEL.md`, `docs/ADR/`, `data_quality/run_silver_suite.py` |
| tests/identity_contract.py | ✅ | `python tests/identity_contract.py` → OK (dual grain: Kimball `fact_transactions` + cumulative `fact_customer_daily_balance`) |
| tests/boundary_contract.py | ✅ | `python tests/boundary_contract.py` → OK (PySpark+Delta on bronze/silver only, Snowflake-locked Gold, S3-only) |
| tests/doc_reference_contract.py | ✅ | `python tests/doc_reference_contract.py` → OK, 10 docs |
| scripts/gen_repo_map.py + architecture/REPO_MAP.md | ✅ | `python scripts/gen_repo_map.py` → wrote 66 files; `--check` → OK |
| ADR-002 Silver-WARN acceptance | ✅ | `docs/ADR/ADR-002-silver-warn-acceptance.md` — traced "Silver 14/15 (1 WARN)" to `merchant_balance_null`, formally accepted (not fixed) with written rationale |
| Slack alerting | ✅ kept as-is | `airflow/dags/paysim_fraud_pipeline.py` `slack_success`/`slack_failure` — already working, no backfill needed (unlike olist/Volve) |
| Confluence sync | ✅ | `scripts/sync_docs_to_confluence.py` adapted from CIL/olist; `confluence/00_START_HERE.md` pointer |
| Logs (PROJECT_STATUS/COST_LOG/DECISION_LOG) | ✅ | this file + the 2 below |
| learning/CURRICULUM.md + LEARNING_LOG.md | ✅ | Kaggle→S3→PySpark Bronze→Silver dq_flag/cumulative MERGE→Snowflake Gold→Power BI module path, M4 = cumulative idempotency (the resume-proof centerpiece) |
| simulation/ | ✅ | `ISOLATION_CONTRACT.md`, `check_isolation.py` (passes), `faults/inject.py`+`reset.py`, 3 drill specs (troubleshoot/migration/optimization) |
| INTERVIEW_GUIDE.md | ✅ | resume↔repo evidence table, Silver-WARN attribution, Databricks-notebook-vs-DAG nuance flagged |
| .github/workflows/ci.yml | ✅ | wires the 3 contracts + repo-map --check + isolation check as static $0 gates |
| push branch + PR | ⬜ | blocked on owner review (explicit instruction — do not push) |

## Real findings during retrofit (verified by reading the repo, not assumed)
1. README's "Silver 14/15 (1 WARN documented)" named no specific check — traced to
   `merchant_balance_null` (matches `docs/DQD.md`'s documented "Merchant balance = 0 → by
   design" expected anomaly). Formally accepted via ADR-002, not silently left vague.
2. `bronze/download_dataset.py` contains a dual-cloud option — `upload_to_adls()` (Azure ADLS,
   gated by `CLOUD` env var) alongside the documented S3 path. Never invoked by the Airflow
   DAG. Flagged in `DECISION_LOG.md` + `tests/boundary_contract.py`'s `ALLOW_LINES`, not
   silently stripped or silently passed through the gate unexplained.
3. README's stack table says Silver = "Databricks SQL Warehouse — SQL CTAS + window
   functions", but the actual code (`silver/silver_pipeline.py`, `silver/cumulative_pipeline.py`)
   is plain PySpark + Delta Lake (`local[*]` or `s3a://`), runnable locally OR on Databricks —
   not literally Databricks SQL Warehouse SQL. The full 6.3M-row staging run was executed via
   the separate `silver/databricks_notebook.py` (manual, cell-by-cell). Documented in
   CLAUDE.md's stack table + `INTERVIEW_GUIDE.md` row 4, not silently corrected away.
4. Two Snowflake-bridge code paths exist (`silver/export_to_s3_parquet.py`, wired into the DAG;
   `silver/databricks_to_snowflake.py`, an alternate manual path) — both real, only one
   automated. Documented in `INTERVIEW_GUIDE.md` row 5.

## Token discipline note
This repo's stack (PySpark/Delta hybrid-grain Bronze/Silver, dbt/Snowflake Gold) differs from
both home-credit's (AWS Glue Bronze/Silver, single SCD2 grain) and olist's (Databricks-only
Bronze/Silver, dual-SCD-strategy grain) — the retrofit pattern was ported, not copied
literally; the identity contract had to be rebuilt around a DUAL fact-table grain (Kimball +
cumulative table), not a single SCD2 surrogate key. Every governed-path reference in
CLAUDE.md/hooks/contracts was re-verified against THIS repo's actual files before being
written (e.g. `gold/models/` not `gold/dbt_models/models/`).
