# Start Here — Paysim Fraud Pipeline

> Pointer page for newcomers landing on Confluence. The repo (not Confluence) is the source of
> truth — these pages are a synced read-only mirror, published via
> `scripts/sync_docs_to_confluence.py`.

## What this is
A finished fraud-intelligence analytics portfolio pipeline: PaySim1 synthetic CSV (Kaggle) →
AWS S3 → PySpark/Delta Lake Bronze (local or Databricks) → PySpark/Delta Lake Silver (dq_flag
bitmask, RULE 1 fraud-type constraint, **cumulative-table** Delta MERGE customer-day balances)
→ S3 Parquet / Databricks SQL Warehouse bridge → Snowflake external stage → dbt Core Gold
(Hybrid: Kimball `fact_transactions` + cumulative `fact_customer_daily_balance`) → Power BI.
Orchestrated by Apache Airflow with working Slack alerting; quality-gated by hand-rolled
Great Expectations-style suites (Bronze 10/10, Silver 14/15 — 1 documented WARN, ADR-002).

## Reading order
1. **README** — problem statement, hybrid data model, stack at a glance.
2. **AI Context (CLAUDE.md)** — governance framework, stop-gate, anti-shortcut protocol.
3. **ARCHITECTURE.md** — full layer-by-layer design.
4. **DATA_MODEL.md** — the dual grain (Kimball transaction grain + cumulative customer-day grain).
5. **BRD.md / DRD.md / DATA_DICTIONARY.md** — business + data requirements.
6. **PIPELINE_SPEC.md / DQD.md** — pipeline mechanics + quality gates.
7. **OPS_RUNBOOK.md** — how to run it.
8. **ADR-001/002** — the 2 binding architecture decisions (hybrid modelling paradigm, the
   Silver GX WARN acceptance).
9. **INTERVIEW_GUIDE.md** — resume-claim ↔ repo-evidence reconciliation (includes the "Silver
   14/15" WARN attribution).
10. **PROJECT_STATUS.md** — current build/retrofit status.

## What's deliberately NOT synced
The 10 `.claude/agents/` persona files, `tests/*_contract.py`, `scripts/gen_repo_map.py`,
`architecture/REPO_MAP.md`, and `learning/`/`simulation/` — these are AI-tooling and
dev-navigation artifacts, not onboarding documentation for a human stakeholder.
