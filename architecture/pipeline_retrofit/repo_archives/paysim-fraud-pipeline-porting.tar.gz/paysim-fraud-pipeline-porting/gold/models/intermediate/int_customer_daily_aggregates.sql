{{
  config(
    materialized = 'table',
    description  = 'Daily customer aggregates from silver.customer_daily_balance joined with dim_customer FK.'
  )
}}

with balance as (

    select * from {{ source('silver', 'customer_daily_balance') }}

),

/*
  dim_customer FK assignment:
  dim_customer is built by dbt snapshot from Silver transactions (sender_id DISTINCT).
  We join on customer_id (natural key) to get customer_sk (surrogate).
*/
dim_cust as (

    select
        customer_sk,
        customer_id
    from {{ ref('dim_customer') }}

),

joined as (

    select
        -- Surrogate key
        {{ dbt_utils.generate_surrogate_key(['b.customer_id', 'b.balance_date']) }} as customer_day_sk,

        -- FK
        dc.customer_sk                                     as customer_fk,
        b.customer_id,
        b.balance_date,

        -- Daily metrics
        b.daily_sent_amount,
        b.daily_received_amount,
        b.daily_txn_count,
        b.daily_fraud_count,
        b.daily_zero_out_count,
        b.max_daily_drain_pct,

        -- Running totals (pre-computed in Silver via MERGE)
        b.running_txn_total,
        b.running_fraud_total,
        b.running_fraud_amount,
        b.running_sent_total,

        -- Risk flag
        b.is_high_risk_today,

        -- Metadata
        b.ingestion_ts,
        b.batch_id

    from balance b
    left join dim_cust dc
           on b.customer_id = dc.customer_id

)

select * from joined
