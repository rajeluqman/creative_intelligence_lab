{{
  config(
    materialized = 'table',
    description  = 'Enriched cumulative customer balance with suspicious sequence detection (TRANSFER→CASH-OUT within 24-step window). Feeds mart_customer_risk.'
  )
}}

with daily as (

    select * from {{ ref('int_customer_daily_aggregates') }}

),

/*
  Suspicious sequence: TRANSFER → CASH-OUT by same sender within 24 steps (1 simulated day).
  Logic: count per customer how many distinct days had BOTH a TRANSFER and a CASH-OUT.
  Source: int_transactions_enriched (transaction grain, not day grain).
*/
transfer_cashout_by_day as (

    select
        sender_id,
        transaction_day,
        max(case when transaction_type = 'TRANSFER'  then 1 else 0 end) as had_transfer,
        max(case when transaction_type = 'CASH-OUT'  then 1 else 0 end) as had_cashout

    from {{ ref('int_transactions_enriched') }}
    group by sender_id, transaction_day

),

suspicious_sequence_counts as (

    select
        sender_id,
        count(*) as suspicious_sequence_count

    from transfer_cashout_by_day
    where had_transfer = 1 and had_cashout = 1

    group by sender_id

),

enriched as (

    select
        d.*,
        coalesce(s.suspicious_sequence_count, 0)           as suspicious_sequence_count

    from daily d
    left join suspicious_sequence_counts s
           on d.customer_id = s.sender_id

)

select * from enriched
