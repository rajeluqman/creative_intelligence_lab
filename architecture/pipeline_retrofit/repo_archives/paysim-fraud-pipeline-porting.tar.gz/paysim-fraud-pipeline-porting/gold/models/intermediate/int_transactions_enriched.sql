{{
  config(
    materialized = 'table',
    description  = 'fact_transactions ready — joins dim_time and dim_transaction_type FKs. Enforces RULE 1 cross-column assertion via dim_transaction_type.is_fraud_eligible.'
  )
}}

with transactions as (

    select * from {{ ref('staging__paysim_transactions') }}

),

dim_time as (

    select * from {{ ref('dim_time') }}

),

dim_type as (

    select * from {{ ref('dim_transaction_type') }}

),

enriched as (

    select
        -- Surrogate + natural keys
        {{ dbt_utils.generate_surrogate_key(['t.transaction_id']) }} as transaction_sk,
        t.transaction_id,

        -- Foreign keys
        dt.step                                             as step_fk,
        dty.type_id                                        as type_fk,

        -- Descriptive — sender/receiver (FK assignment to dim_customer done in Snowflake at load)
        t.sender_id,
        t.receiver_id,
        t.is_merchant_dest,

        -- Transaction attributes
        t.transaction_type,
        t.amount,
        t.transaction_day,
        t.transaction_hour,
        t.transaction_datetime,

        -- Balance metrics
        t.sender_balance_before,
        t.sender_balance_after,
        t.receiver_balance_before,
        t.receiver_balance_after,
        t.balance_drain_pct,
        t.is_zero_out,
        t.balance_disc_orig,
        t.balance_disc_dest,

        -- Fraud signals
        t.is_fraud,
        t.is_flagged_fraud,
        t.flagged_fraud_discrepancy,

        -- RULE 1 cross-check: isFraud=1 on non-eligible type = dq violation
        -- is_fraud_eligible sourced from dim_transaction_type (authoritative)
        dty.is_fraud_eligible,
        case
            when t.is_fraud = 1 and dty.is_fraud_eligible = 0 then 1
            else 0
        end                                                as rule1_violation,

        -- DQ
        t.dq_flag,

        -- Metadata
        t.ingestion_ts,
        t.batch_id

    from transactions t
    left join dim_time dt
           on t.step = dt.step
    left join dim_type dty
           on t.transaction_type = dty.type_name

)

select * from enriched
