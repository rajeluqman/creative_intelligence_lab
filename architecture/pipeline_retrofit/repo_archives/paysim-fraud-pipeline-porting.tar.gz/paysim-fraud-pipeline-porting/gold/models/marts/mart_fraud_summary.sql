{{
  config(
    materialized = 'table',
    description  = 'Fraud KPIs aggregated by simulated day + transaction type. Grain: 1 row = 1 day × 1 transaction type. Powers Power BI Fraud Intelligence dashboard.'
  )
}}

/*
  KPIs (BRD definitions):
    fraud_rate_pct           = COUNT(is_fraud=1) / COUNT(*) × 100
    fraud_amount_total       = SUM(amount WHERE is_fraud=1)
    detection_rate_pct       = COUNT(is_flagged AND is_fraud) / COUNT(is_fraud=1) × 100
    false_positive_rate_pct  = COUNT(is_flagged AND NOT is_fraud) / COUNT(is_flagged=1) × 100
    flagged_discrepancy_count = COUNT(flagged_fraud_discrepancy=1)

  Identity check (dbt singular test):
    true_positive + false_negative = fraud_count  [enforced in tests/]
*/

with txn as (

    select * from {{ ref('int_transactions_enriched') }}

),

aggregated as (

    select
        transaction_day,
        transaction_type,

        -- Volume
        count(*)                                                    as total_txn_count,
        sum(amount)                                                 as total_amount,

        -- Fraud counts
        sum(is_fraud)                                               as fraud_count,
        sum(case when is_fraud = 0 then 1 else 0 end)              as legit_count,
        sum(case when is_fraud = 1 then amount else 0 end)         as fraud_amount_total,

        -- Flagging system performance
        sum(case when is_flagged_fraud = 1 and is_fraud = 1
                 then 1 else 0 end)                                as true_positive_count,
        sum(case when is_flagged_fraud = 0 and is_fraud = 1
                 then 1 else 0 end)                                as false_negative_count,
        sum(case when is_flagged_fraud = 1 and is_fraud = 0
                 then 1 else 0 end)                                as false_positive_count,
        sum(case when is_flagged_fraud = 1
                 then 1 else 0 end)                                as total_flagged_count,

        -- Heuristic discrepancy (isFlaggedFraud ≠ isFraud)
        sum(flagged_fraud_discrepancy)                             as flagged_discrepancy_count,

        -- DQ tracking
        sum(case when dq_flag > 0 then 1 else 0 end)              as dq_flagged_count,
        sum(case when rule1_violation = 1 then 1 else 0 end)      as rule1_violation_count

    from txn
    group by transaction_day, transaction_type

),

with_rates as (

    select
        *,

        -- Fraud rate (%) — BRD KPI
        round(
            case when total_txn_count > 0
                 then cast(fraud_count as double) / total_txn_count * 100
                 else 0
            end, 4
        )                                                           as fraud_rate_pct,

        -- Detection rate (%) — BRD KPI
        round(
            case when fraud_count > 0
                 then cast(true_positive_count as double) / fraud_count * 100
                 else null
            end, 4
        )                                                           as detection_rate_pct,

        -- False positive rate (%) — BRD KPI
        round(
            case when total_flagged_count > 0
                 then cast(false_positive_count as double) / total_flagged_count * 100
                 else null
            end, 4
        )                                                           as false_positive_rate_pct,

        -- Average fraud transaction size
        round(
            case when fraud_count > 0
                 then fraud_amount_total / fraud_count
                 else null
            end, 2
        )                                                           as avg_fraud_amount

    from aggregated

)

select * from with_rates
order by transaction_day, transaction_type
