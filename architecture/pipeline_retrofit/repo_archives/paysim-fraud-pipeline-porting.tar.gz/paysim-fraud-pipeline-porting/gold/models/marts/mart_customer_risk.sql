{{
  config(
    materialized = 'table',
    description  = 'Customer risk profile — latest snapshot per customer. Grain: 1 row per customer. Combines cumulative running totals + account drain signals + suspicious sequence detection.'
  )
}}

/*
  KPIs (BRD definitions):
    balance_drain_velocity (%) = amount / oldbalanceOrg × 100  [pre-computed as max_daily_drain_pct]
    zero_out_events             = total is_zero_out across all days
    suspicious_sequence_count   = days with both TRANSFER + CASH-OUT (24-step window)
    is_high_risk_today          = 1 if last active day had zero-out OR drain > 95%

  NOTE on is_high_risk_today:
    Simplified rule accepted for portfolio (BRD dual-condition requires AND amount > 10K LCU,
    but 10K LCU threshold is PROVISIONAL — not yet calibrated). Document in mart column desc.
*/

with cumulative as (

    select * from {{ ref('int_cumulative_customer_balance') }}

),

/*
  Latest row per customer (last active day = highest balance_date per customer_id).
  Running totals on the latest row = lifetime cumulative totals.
*/
latest_per_customer as (

    select
        customer_fk,
        customer_id,
        balance_date                                        as last_active_date,
        daily_zero_out_count                               as last_day_zero_out_count,
        max_daily_drain_pct                                as last_day_max_drain_pct,
        running_txn_total,
        running_fraud_total,
        running_fraud_amount,
        running_sent_total,
        is_high_risk_today,
        suspicious_sequence_count,
        row_number() over (
            partition by customer_id
            order by balance_date desc
        )                                                   as _rn

    from cumulative

),

-- Lifetime totals (aggregated across all active days)
lifetime_totals as (

    select
        customer_id,
        count(distinct balance_date)                       as active_day_count,
        sum(daily_zero_out_count)                          as total_zero_out_events,
        max(max_daily_drain_pct)                           as max_ever_drain_pct,
        sum(daily_fraud_count)                             as total_fraud_txn_count,
        sum(daily_sent_amount)                             as total_lifetime_sent

    from cumulative
    group by customer_id

),

final as (

    select
        lpc.customer_fk,
        lpc.customer_id,
        lpc.last_active_date,
        lt.active_day_count,

        -- Fraud risk signals
        lpc.running_fraud_total                            as cumulative_fraud_count,
        lpc.running_fraud_amount                          as cumulative_fraud_amount,
        lt.total_fraud_txn_count,

        -- Account drain signals
        lt.total_zero_out_events                          as zero_out_events,
        lt.max_ever_drain_pct                             as max_drain_velocity_pct,
        lpc.last_day_max_drain_pct,

        -- Suspicious TRANSFER→CASH-OUT pattern
        lpc.suspicious_sequence_count,

        -- Running totals
        lpc.running_txn_total                             as cumulative_txn_count,
        lpc.running_sent_total                            as cumulative_sent_total,
        lt.total_lifetime_sent,

        -- Current risk flag (last active day)
        lpc.is_high_risk_today,

        -- Derived lifetime risk classification
        case
            when lpc.running_fraud_total > 0                    then 'CONFIRMED_FRAUD'
            when lpc.suspicious_sequence_count > 2              then 'HIGH_RISK'
            when lt.total_zero_out_events > 0
              or lt.max_ever_drain_pct > 95                     then 'ELEVATED_RISK'
            else 'NORMAL'
        end                                                as risk_category

    from latest_per_customer lpc
    inner join lifetime_totals lt
            on lpc.customer_id = lt.customer_id
    where lpc._rn = 1

)

select * from final
order by cumulative_fraud_count desc, suspicious_sequence_count desc
