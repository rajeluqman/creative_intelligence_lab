{{
  config(
    materialized = 'view',
    description  = 'Source cleaning layer — confirms types, renames nothing (already semantic from Silver). Gateway before intermediate models.'
  )
}}

with source as (

    select * from {{ source('silver', 'transactions') }}

),

validated as (

    select
        -- Identity
        transaction_id,
        sender_id,
        receiver_id,

        -- Transaction attributes
        type                                                as transaction_type,
        cast(step as integer)                              as step,
        cast(transaction_day as integer)                   as transaction_day,
        cast(transaction_hour as integer)                  as transaction_hour,
        cast(transaction_datetime as timestamp)            as transaction_datetime,
        cast(amount as double)                             as amount,

        -- Balance metrics
        cast(sender_balance_before as double)              as sender_balance_before,
        cast(sender_balance_after as double)               as sender_balance_after,
        cast(receiver_balance_before as double)            as receiver_balance_before,  -- NULL for merchants
        cast(receiver_balance_after as double)             as receiver_balance_after,   -- NULL for merchants

        -- Derived flags
        cast(is_merchant_dest as integer)                  as is_merchant_dest,
        cast(balance_drain_pct as double)                  as balance_drain_pct,        -- NULL if sender_balance_before = 0
        cast(is_zero_out as integer)                       as is_zero_out,
        cast(balance_disc_orig as double)                  as balance_disc_orig,
        cast(balance_disc_dest as double)                  as balance_disc_dest,

        -- Fraud signals
        cast(is_fraud as integer)                          as is_fraud,
        cast(is_flagged_fraud as integer)                  as is_flagged_fraud,
        cast(flagged_fraud_discrepancy as integer)         as flagged_fraud_discrepancy,

        -- Data quality
        cast(dq_flag as integer)                           as dq_flag,

        -- Pipeline metadata
        cast(ingestion_ts as timestamp)                    as ingestion_ts,
        batch_id

    from source

)

select * from validated
