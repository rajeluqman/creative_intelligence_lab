{{
  config(
    materialized = 'table',
    description  = 'dim_customer — SCD Type 1. One row per unique customer (sender). Surrogate key assigned here.'
  )
}}

with customers as (

    select distinct sender_id as customer_id
    from {{ source('silver', 'transactions') }}

)

select
    {{ dbt_utils.generate_surrogate_key(['customer_id']) }}  as customer_sk,
    customer_id,
    current_timestamp()                                       as created_at,
    current_timestamp()                                       as updated_at

from customers
