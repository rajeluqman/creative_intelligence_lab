-- Singular test: true_positive + false_negative MUST equal fraud_count for every row.
-- Returns rows where the identity fails — dbt expects 0 rows returned = test pass.

select
    transaction_day,
    transaction_type,
    fraud_count,
    true_positive_count,
    false_negative_count,
    (true_positive_count + false_negative_count) as tp_plus_fn

from {{ ref('mart_fraud_summary') }}

where true_positive_count + false_negative_count <> fraud_count
