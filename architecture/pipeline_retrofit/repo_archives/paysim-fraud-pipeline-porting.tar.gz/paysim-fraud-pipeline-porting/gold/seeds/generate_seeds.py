"""
Generate dbt seed CSV files for static dimension tables.
Run once at pipeline init:  python gold/seeds/generate_seeds.py

Outputs:
  gold/seeds/dim_time.csv             — 744 rows (step 1-744)
  gold/seeds/dim_transaction_type.csv — 5 rows (PaySim1 types)
"""

import csv
import math
from datetime import datetime, timedelta
from pathlib import Path

SEED_DIR = Path(__file__).parent


def generate_dim_time():
    base_dt = datetime(2024, 1, 1, 0, 0, 0)  # 2024-01-01 is a Monday

    rows = []
    for step in range(1, 745):  # 1–744 inclusive
        dt = base_dt + timedelta(hours=(step - 1))
        transaction_day = math.ceil(step / 24)
        transaction_hour = (step - 1) % 24
        day_of_week = dt.strftime("%A")
        is_weekend = 1 if dt.weekday() >= 5 else 0  # 5=Saturday, 6=Sunday
        week_number = math.ceil(transaction_day / 7)

        rows.append({
            "step": step,
            "transaction_day": transaction_day,
            "transaction_hour": transaction_hour,
            "transaction_datetime": dt.strftime("%Y-%m-%d %H:%M:%S"),
            "day_of_week": day_of_week,
            "is_weekend": is_weekend,
            "week_number": week_number,
        })

    out = SEED_DIR / "dim_time.csv"
    with open(out, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Generated {out} — {len(rows)} rows")


def generate_dim_transaction_type():
    rows = [
        {"type_id": 1, "type_name": "CASH-IN",   "is_fraud_eligible": 0,
         "description": "Customer deposits cash into mobile money account"},
        {"type_id": 2, "type_name": "CASH-OUT",  "is_fraud_eligible": 1,
         "description": "Customer withdraws cash from mobile money account via merchant"},
        {"type_id": 3, "type_name": "DEBIT",     "is_fraud_eligible": 0,
         "description": "Debit transaction — payment initiated by merchant"},
        {"type_id": 4, "type_name": "PAYMENT",   "is_fraud_eligible": 0,
         "description": "Customer pays merchant for goods or services"},
        {"type_id": 5, "type_name": "TRANSFER",  "is_fraud_eligible": 1,
         "description": "Customer transfers funds to another customer account"},
    ]

    out = SEED_DIR / "dim_transaction_type.csv"
    with open(out, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Generated {out} — {len(rows)} rows")


if __name__ == "__main__":
    generate_dim_time()
    generate_dim_transaction_type()
    print("Done.")
