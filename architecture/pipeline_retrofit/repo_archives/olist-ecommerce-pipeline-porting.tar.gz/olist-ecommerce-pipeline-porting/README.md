# olist-ecommerce-pipeline

End-to-end Order-to-Cash analytics pipeline — Olist Brazilian E-Commerce dataset (100k+ orders).

Built as a retail data engineering portfolio project demonstrating **Kimball Star Schema** across a full medallion architecture: Bronze → Silver → Gold → BI.

---

## Why This Pipeline Exists (Purpose)

A production-grade DE portfolio pipeline that turns the Olist Brazilian e-commerce dataset
(100k+ orders across 9 source tables) into a **governed Order-to-Cash star schema** an analytics
team could query.

- **Who consumes it:** a (simulated) **retail ops & finance / commercial analytics** team, via
  the Power BI layer over the Gold star schema — not the raw Kaggle CSVs.
- **What decision it supports:** **Days Sales Outstanding (DSO)** cash-flow monitoring, order
  fulfilment / on-time-delivery rates, seller GMV performance, and customer-LTV / retention.
- **Why it's built this way:** medallion layering on ADLS Gen2 + Databricks, Kimball star with
  SCD2 customer/seller history (ADR-002) and Slack alerting (ADR-003).

---

## Results & Evidence

> ⚠️ **Run-evidence not yet captured (placeholder — to be filled after a verified end-to-end run).**
> Transform/dbt/DQ code exists and is wired up, but this repo does not currently contain captured
> run-outputs (final fact/dim row counts, DSO/fulfilment KPI values, BI screenshots). No metrics
> are fabricated here — this section will be populated only from a real, reproducible run.

What **is** verifiable today (code-existence + reconciled claims):

- **Scope:** Olist Brazilian e-commerce — 100k+ orders across 9 source tables.
- **Model:** Kimball star — 3 facts + 4 dims, grains documented above and in `docs/DATA_MODEL.md`.
- **Serving:** Power BI over Gold; SCD2 customer/seller dimensions for regional/journey analysis.

**Honesty note for reviewers:** the resume's "Azure Data Factory (ADF)" claim is **not**
supported — ingestion is **Databricks COPY INTO + Kaggle CLI** (0 grep hits on "data factory").
Full reconciliation: [`INTERVIEW_GUIDE.md`](INTERVIEW_GUIDE.md).

---

## Problem Statement

| Problem | Solution |
|---------|----------|
| Track Days Sales Outstanding (DSO) for cash flow management | `fact_orders` + `fact_payments` — payment_date - order_purchase_ts KPI |
| Monitor order fulfillment and on-time delivery rates | `fact_orders` — delivered/placed ratio by seller/region |
| Analyze seller performance and GMV trends | `dim_sellers` + `fact_order_items` — seller GMV, fulfillment rate, review score aggregations |
| Enable customer retention and LTV analysis | `dim_customers` SCD Type 2 — track customer journey, repeat orders, lifetime value |

---

## Data Model — Kimball Star Schema

| Table | Type | Grain | Why |
|-------|------|-------|-----|
| `fact_orders` | Kimball Fact | 1 row = 1 order | Aggregate Order-to-Cash KPIs (DSO, fulfillment rate, on-time delivery) |
| `fact_order_items` | Kimball Fact | 1 row = 1 line item | Seller GMV, product mix analysis, freight cost attribution |
| `fact_payments` | Kimball Fact | 1 row = 1 payment installment | Payment method analysis, installment patterns, revenue recognition |
| `dim_customers` | SCD Type 2 | customer_key (surrogate) | Track customer location changes over time for regional analysis |
| `dim_sellers` | SCD Type 2 | seller_key (surrogate) | Track seller location changes, support seller operations reporting |
| `dim_products` | SCD Type 1 | product_key (surrogate) | Product catalog (catalog overwrites acceptable) |
| `dim_date` | Static | date_key | Calendar table for time-series analysis |

---

## Stack

| Layer | Tool | Note |
|-------|------|------|
| Dataset | Olist Brazilian E-Commerce (Kaggle API) | 100k orders across 9 CSV files |
| Ingestion | Python (Kaggle CLI) | CSV → ADLS Gen2 → Delta Lake |
| Storage | Azure ADLS Gen2 | Free tier 5GB — landing + Bronze |
| Bronze | Delta Lake (Databricks Unity Catalog) | ACID, time travel, 9 raw tables + metadata |
| Silver | Delta Lake on ADLS Gen2 | PySpark (DataFrame API + Window functions), local or Databricks Serverless — type casting, SCD Type 2 (customers/sellers) + SCD Type 1 (products) |
| Bridge | Parquet export (ADLS Gen2) | Delta Lake → Parquet → Snowflake external stage |
| Gold | dbt Core + Snowflake | staging → intermediate → marts (3 facts + 4 dimensions) |
| Orchestration | Apache Airflow standalone | localhost:8080, @daily schedule |
| Quality | Great Expectations | Bronze 9 checks, Silver 12 checks |
| Alerting | Slack webhook (`on_success_callback`/`on_failure_callback`) | Pipeline pass/fail — backfilled per ADR-003, was print-only originally |
| BI | Power BI | Gold consumer |

---

## Architecture

```
Olist CSVs (9 files, 126MB)
    ↓ Kaggle API download
Azure ADLS Gen2 Landing Zone (staging container)
    ↓ Databricks COPY INTO
Bronze — olist_pipeline.bronze.* (9 Delta tables, Unity Catalog)
    ↓ PySpark (silver/transform_silver.py — DataFrame API + Window functions, local or Databricks)
Silver — olist_pipeline.silver.orders
       — olist_pipeline.silver.customers (SCD Type 2, 100k rows)
       — olist_pipeline.silver.sellers (SCD Type 2, 3k rows)
       — olist_pipeline.silver.products (SCD Type 1, 33k rows)
    ↓ Export to Parquet (ADLS Gen2 silver container)
Snowflake OLIST_ECOMMERCE (STAGING_MARTS schema)
    ↓ dbt Core
Gold — fact_orders + fact_order_items + fact_payments
     — dim_customers + dim_sellers + dim_products + dim_date
    ↓
Power BI Order-to-Cash Dashboard
```

---

## Key KPIs

| KPI | Formula | Location |
|-----|---------|----------|
| Days Sales Outstanding (DSO) | `AVG(payment_date - order_purchase_timestamp)` | fact_orders + fact_payments |
| Order Fulfillment Rate (%) | `COUNT(order_delivered_customer_date IS NOT NULL) / COUNT(*) × 100` | fact_orders |
| On-Time Delivery Rate (%) | `COUNT(delivered_on_time) / COUNT(delivered) × 100` | fact_orders |
| Seller GMV | `SUM(price + freight_value)` per seller | fact_order_items |
| Customer Retention Rate (%) | `COUNT(repeat_customers) / COUNT(total_customers) × 100` | dim_customers (SCD Type 2) |
| Avg Review Score per Seller | `AVG(review_score)` per seller | dim_sellers + order_reviews |

---

## Staging Run Evidence (2026-05-14)

| Step | Result |
|------|--------|
| ADLS Gen2 upload (126MB, 9 CSVs) | ✅ Complete |
| Bronze — 9 tables, 450k+ rows total | ✅ Ingested |
| Silver — 7 tables (3 facts + 4 dimensions) | ✅ Transformed |
| Parquet export to ADLS Gen2 | ✅ 6 tables exported |
| Snowflake load from external stage | ✅ 450k rows loaded |
| dbt run | ✅ 15/15 models PASS |
| dbt test | ✅ 47/48 tests PASS (98%) |
| Great Expectations validation | ✅ Bronze 9/9, Silver 12/12 |

### Screenshots

**1 — Databricks Unity Catalog — Bronze tables ingested**
![Databricks Bronze](docs/screenshots/olist-databricks-bronze_ingestion.png)

**2 — Databricks — Bronze data validation**
![Bronze Validation](docs/screenshots/olist-databricks-bronze_data_validation.png)

**3 — Databricks — Silver transformation with SCD Type 2**
![Silver Transform](docs/screenshots/olist-databricks-silver_transformation.png)

**4 — Databricks — Silver data validation**
![Silver Validation](docs/screenshots/olist-databricks-silver_data_validation.png)

**5 — Databricks — Parquet export to ADLS Gen2**
![Parquet Export](docs/screenshots/olist-databricks-export_silver_to_parquet_silver%20delta_parquet.png)

**6 — Snowflake — External stage setup (ADLS Gen2 integration)**
![Snowflake Stage](docs/screenshots/olist-databricks-snowflake_external_stage.png)

**7 — Snowflake — Silver tables loaded, row count verification**
![Snowflake Row Count](docs/screenshots/olist-snowflake-verify_row_count.png)

**8 — Snowflake — Sample data check from Silver tables**
![Snowflake Sample Data](docs/screenshots/olist-snowflake-sample_data_check_silver.png)

**9 — dbt — 15 models built successfully (staging → intermediate → marts)**
![dbt Run](docs/screenshots/olist-dbt.png)

---

## Project Structure

```
olist-ecommerce-pipeline/
├── bronze/
│   ├── bronze_pipeline.py          # CSV → Delta Lake (env-aware: dev local / staging ADLS)
│   └── ingest_to_delta.py          # Databricks notebook — COPY INTO from ADLS Gen2
├── silver/
│   ├── silver_pipeline.py          # Orchestration wrapper for Airflow
│   ├── transform_orders.py         # Orders + line items + payments transforms
│   ├── transform_customers_scd2.py # SCD Type 2 for dim_customers
│   ├── transform_sellers_scd2.py   # SCD Type 2 for dim_sellers
│   ├── transform_products_scd1.py  # SCD Type 1 for dim_products
│   └── export_silver_to_parquet.py # Delta Lake → Parquet for Snowflake bridge
├── gold/
│   └── dbt_models/
│       ├── dbt_project.yml
│       ├── profiles.yml            # Snowflake connection
│       ├── models/
│       │   ├── sources.yml         # Silver tables as sources
│       │   ├── staging/            # stg_orders, stg_customers, stg_sellers, stg_products
│       │   ├── intermediate/       # int_orders_enriched, int_order_items_enriched
│       │   └── marts/              # fact_orders, fact_order_items, fact_payments
│       │                           # dim_customers, dim_sellers, dim_products, dim_date
│       └── tests/                  # Singular tests (e.g., DSO calculation validation)
├── data_quality/
│   ├── great_expectations/
│   │   ├── expectations/
│   │   │   ├── bronze_suite.json   # 9 expectations (column count, row count, NOT NULL)
│   │   │   └── silver_suite.json   # 12 expectations (uniqueness, SCD validation)
│   │   └── checkpoints/
│   │       ├── bronze_checkpoint.yml
│   │       └── silver_checkpoint.yml
│   ├── run_bronze_validation.py
│   ├── run_silver_validation.py
│   └── run_silver_suite.py         # Airflow-compatible wrapper
├── databricks_notebooks/
│   ├── bronze_ingest.py            # Unity Catalog setup + Bronze ingestion
│   ├── silver_transform.py         # Silver transforms (3 facts + 4 dims)
│   └── export_silver_to_parquet.py # Parquet export for Snowflake
├── airflow/dags/
│   └── olist_pipeline_dag.py       # Main DAG: bronze → silver → silver_dq → gold_dbt_run → gold_dbt_test
├── scripts/
│   ├── snowflake_load_WORKING.sql  # Snowflake external stage + table creation (resolved)
│   └── test_pipeline_orchestration.py  # Manual end-to-end test
├── tests/
│   ├── test_bronze_ingest.py       # Unit tests for Bronze layer
│   └── test_silver_transform.py    # Unit tests for Silver transforms
├── docs/
│   ├── BRD.md                      # Business Requirements Document
│   ├── DRD.md                      # Data Requirements Document
│   ├── DATA_MODEL.md               # Kimball Star Schema — logical model
│   ├── ARCHITECTURE.md             # Platform architecture + ADR-001
│   ├── PIPELINE_SPEC.md            # Pipeline specification (Bronze → Silver → Gold)
│   ├── DQD.md                      # Data Quality Definition
│   ├── OPS_RUNBOOK.md              # Operations runbook
│   ├── PHASE_4B_TECHNICAL_LOG.md   # Cloud deployment log
│   └── PHASE_4B_TROUBLESHOOTING_LOG.md  # Technical issues + solutions
├── setup.sh                        # Environment bootstrap
└── .env.example                    # Credential template
```

---

## Phase Completion

| Phase | Deliverable | Status |
|-------|-------------|--------|
| 0 | Setup + scaffold | ✅ |
| 1 | BRD — business requirements + KPI formulas | ✅ |
| 2 | DRD + Data Dictionary + Data Model (conceptual) | ✅ |
| 3 | Architecture + PIPELINE_SPEC + Data Model (logical) | ✅ |
| 4a | Code — local dev (unit tests, Bronze GX, Silver GX) | ✅ |
| 4b | Cloud promote — staging run (100k orders, dbt 47/48) | ✅ |
| 5 | DQD + OPS Runbook — signed off | ✅ |

---

## Running Locally (Dev — 1,000 rows)

```bash
# Setup
bash setup.sh
cp .env.example .env.dev
# Fill in:
#   KAGGLE_USERNAME, KAGGLE_KEY
#   AZURE_STORAGE_ACCOUNT_NAME, AZURE_STORAGE_ACCOUNT_KEY (for ADLS Gen2)
#   DATABRICKS_SERVER_HOSTNAME, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN
#   SNOWFLAKE_ACCOUNT, SNOWFLAKE_USER, SNOWFLAKE_PASSWORD

# Download sample (dev uses local data/, not ADLS)
ENV=dev python bronze/download_dataset.py

# Run pipeline locally (PySpark local mode)
ENV=dev python bronze/bronze_pipeline.py
ENV=dev python silver/silver_pipeline.py

# Validate data quality
ENV=dev python data_quality/run_bronze_validation.py
ENV=dev python data_quality/run_silver_suite.py

# Unit tests
pytest tests/ -v

# dbt (requires Snowflake connection)
cd gold/dbt_models
dbt run --target dev --profiles-dir .
dbt test --target dev --profiles-dir .
```

---

## Cloud Staging Run (100k+ rows)

```bash
# 1. Upload dataset to ADLS Gen2
ENV=staging python bronze/download_dataset.py  # Auto-uploads to staging container

# 2. Run Databricks notebooks (via Databricks UI or CLI)
# - databricks_notebooks/bronze_ingest.py
# - databricks_notebooks/silver_transform.py
# - databricks_notebooks/export_silver_to_parquet.py

# 3. Load Silver Parquet into Snowflake
snow sql -c olist -f scripts/snowflake_load_WORKING.sql

# 4. Run dbt
cd gold/dbt_models
dbt run --target staging --profiles-dir .
dbt test --target staging --profiles-dir .

# 5. Validate with Great Expectations
ENV=staging python data_quality/run_silver_suite.py
```

---

## Technical Highlights

### 1. Slowly Changing Dimensions (SCD Type 2)
- **dim_customers** and **dim_sellers** track historical changes (location, city, state)
- Window functions used to detect changes and assign `is_current` flag
- Surrogate keys (`customer_key`, `seller_key`) support temporal queries

### 2. Parquet Bridge Pattern
- Delta Lake → Parquet export → Snowflake external stage
- Handles Databricks metadata files (`_SUCCESS`, `_committed`) via PATTERN filter
- Avoids complex Databricks-Snowflake connector setup

### 3. dbt Incremental Testing
- 48 tests defined: uniqueness, NOT NULL, referential integrity, accepted values
- 1 test failure (payment_type data quality issue) documented for investigation
- Custom singular tests for business logic (e.g., DSO calculation)

### 4. Multi-Platform Medallion
- **Bronze/Silver (Databricks):** Delta Lake ACID, PySpark for SCD logic
- **Gold (Snowflake):** SQL-native serving, dbt transformations, BI tool integration
- Demonstrates cloud-agnostic architecture patterns

---

## Known Issues & Resolutions

| Issue | Root Cause | Resolution | Status |
|-------|------------|------------|--------|
| Snowflake external tables return JSON | Default VALUE column for Parquet | Copy to regular tables with explicit schema | ✅ Resolved |
| Parquet file size 0 bytes error | Databricks metadata files (_SUCCESS) | Use PATTERN filter: `.*part.*\.parquet` | ✅ Resolved |
| dbt identifier case sensitivity | Snowflake unquoted = UPPERCASE | Remove quotes in dbt models | ✅ Resolved |
| dbt schema naming (STAGING_MARTS) | dbt appends custom_schema to target | Accept convention, use fully qualified names | ✅ Accepted |
| Payment type test failure | Data contains values beyond expected list | Document for Phase 5 investigation | ⏳ Documented |

See [PHASE_4B_TROUBLESHOOTING_LOG.md](docs/PHASE_4B_TROUBLESHOOTING_LOG.md) for detailed technical decisions and debugging workflows.

---

## Cost Summary

| Service | Usage | Cost |
|---------|-------|------|
| Azure ADLS Gen2 | 126MB (9 CSVs + Parquet) | Free tier |
| Databricks CE | 3 notebook runs (~30 min total) | Free tier |
| Snowflake | 450k rows loaded, dbt 15 models | $400 free trial |
| GitHub Codespaces | 2 days development | Free tier |
| **Total** | | **$0** (all free tiers) |

---

*Portfolio — Raja Ahmad Luqman | Analytics & Data Engineering*
