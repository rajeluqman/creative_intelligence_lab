"""
transform_silver.py — Silver Layer Transformation
WHAT: Transform Bronze → Silver dengan type casting, business rules, SCD Type 2
WHY : Cleansed, strongly-typed data ready untuk Gold dimensional modelling
WHEN: Run selepas bronze/ingest_to_delta.py — Silver layer pipeline
"""

import os
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from delta.tables import DeltaTable


# =============================================================================
# SPARK SESSION
# =============================================================================

def get_spark_session(app_name: str = "silver_transformation") -> SparkSession:
    """Create SparkSession untuk local mode (PySpark standalone)"""
    spark = (
        SparkSession.builder
        .appName(app_name)
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .config("spark.driver.memory", "4g")
        .config("spark.executor.memory", "4g")
        .getOrCreate()
    )
    return spark


# =============================================================================
# SILVER TRANSFORMATIONS — FACT TABLES
# =============================================================================

def transform_orders(spark, bronze_path, silver_path):
    """
    Transform bronze.raw_orders → silver.orders

    Business Rules:
    - Type cast timestamps (STRING → TIMESTAMP)
    - Handle NULL order_approved_at (DQS Flag #1)
    - Derive is_delivered, is_on_time
    - Aggregate review_score per order
    - Deduplicate by order_id (keep latest ingestion_timestamp)
    """
    print("\n📦 Transforming bronze.raw_orders → silver.orders")

    # Read Bronze
    bronze_orders = spark.read.format("delta").load(f"{bronze_path}/raw_orders")
    bronze_reviews = spark.read.format("delta").load(f"{bronze_path}/raw_reviews")

    # Type casting
    silver_orders = bronze_orders \
        .withColumn("order_purchase_timestamp", F.to_timestamp("order_purchase_timestamp")) \
        .withColumn("order_approved_at", F.to_timestamp("order_approved_at")) \
        .withColumn("order_delivered_carrier_date", F.to_timestamp("order_delivered_carrier_date")) \
        .withColumn("order_delivered_customer_date", F.to_timestamp("order_delivered_customer_date")) \
        .withColumn("order_estimated_delivery_date", F.to_timestamp("order_estimated_delivery_date"))

    # Derived columns
    silver_orders = silver_orders \
        .withColumn("is_delivered",
                    (F.col("order_status") == "delivered") & F.col("order_delivered_customer_date").isNotNull()) \
        .withColumn("is_on_time",
                    F.when(F.col("is_delivered"),
                           F.col("order_delivered_customer_date") <= F.col("order_estimated_delivery_date"))
                     .otherwise(None)) \
        .withColumn("dq_approved_flag",
                    F.col("order_approved_at").isNotNull())

    # Join reviews for review_score aggregation
    avg_review = bronze_reviews.groupBy("order_id") \
        .agg(F.avg(F.col("review_score").cast("double")).cast("decimal(3,2)").alias("review_score"))

    silver_orders = silver_orders.join(avg_review, on="order_id", how="left")

    # Deduplication (keep latest by ingestion_timestamp)
    window = Window.partitionBy("order_id").orderBy(F.desc("ingestion_timestamp"))
    silver_orders = silver_orders \
        .withColumn("row_num", F.row_number().over(window)) \
        .filter(F.col("row_num") == 1) \
        .drop("row_num")

    # Metadata
    silver_orders = silver_orders \
        .withColumn("valid_from", F.current_timestamp()) \
        .withColumn("valid_to", F.lit(None).cast("timestamp")) \
        .withColumn("is_current", F.lit(True)) \
        .withColumn("source_batch_id", F.col("batch_id"))

    # Select final columns
    silver_orders = silver_orders.select(
        "order_id",
        "customer_id",
        "order_status",
        "order_purchase_timestamp",
        "order_approved_at",
        "order_delivered_carrier_date",
        "order_delivered_customer_date",
        "order_estimated_delivery_date",
        "is_delivered",
        "is_on_time",
        "review_score",
        "dq_approved_flag",
        "valid_from",
        "valid_to",
        "is_current",
        "source_batch_id"
    )

    # Write to Delta
    silver_orders.write.format("delta").mode("overwrite").save(f"{silver_path}/orders")
    row_count = silver_orders.count()
    print(f"  ✅ silver.orders: {row_count} rows written")

    return row_count


def transform_order_items(spark, bronze_path, silver_path):
    """
    Transform bronze.raw_order_items → silver.order_items

    Business Rules:
    - Type cast price, freight_value (STRING → DECIMAL)
    - Derive gmv = price + freight_value
    - Flag price = 0.00 anomaly (DQS Flag #2)
    - Deduplicate by (order_id, order_item_id)
    """
    print("\n📦 Transforming bronze.raw_order_items → silver.order_items")

    bronze_order_items = spark.read.format("delta").load(f"{bronze_path}/raw_order_items")

    silver_order_items = bronze_order_items \
        .withColumn("order_item_id", F.col("order_item_id").cast("int")) \
        .withColumn("price", F.col("price").cast("decimal(10,2)")) \
        .withColumn("freight_value", F.col("freight_value").cast("decimal(10,2)")) \
        .withColumn("shipping_limit_date", F.to_timestamp("shipping_limit_date")) \
        .withColumn("gmv", F.col("price") + F.col("freight_value")) \
        .withColumn("dq_zero_price_flag", F.col("price") == 0.00)

    # Deduplication
    window = Window.partitionBy("order_id", "order_item_id").orderBy(F.desc("ingestion_timestamp"))
    silver_order_items = silver_order_items \
        .withColumn("row_num", F.row_number().over(window)) \
        .filter(F.col("row_num") == 1) \
        .drop("row_num")

    # Metadata
    silver_order_items = silver_order_items \
        .withColumn("valid_from", F.current_timestamp()) \
        .withColumn("source_batch_id", F.col("batch_id"))

    # Select final columns
    silver_order_items = silver_order_items.select(
        "order_id",
        "order_item_id",
        "product_id",
        "seller_id",
        "shipping_limit_date",
        "price",
        "freight_value",
        "gmv",
        "dq_zero_price_flag",
        "valid_from",
        "source_batch_id"
    )

    silver_order_items.write.format("delta").mode("overwrite").save(f"{silver_path}/order_items")
    row_count = silver_order_items.count()
    print(f"  ✅ silver.order_items: {row_count} rows written")

    return row_count


def transform_payments(spark, bronze_path, silver_path):
    """
    Transform bronze.raw_payments → silver.payments

    Business Rules:
    - Type cast payment_value, payment_installments (STRING → DECIMAL, INT)
    - Validate payment_value > 0
    - Deduplicate by (order_id, payment_sequential)
    """
    print("\n📦 Transforming bronze.raw_payments → silver.payments")

    bronze_payments = spark.read.format("delta").load(f"{bronze_path}/raw_payments")

    silver_payments = bronze_payments \
        .withColumn("payment_sequential", F.col("payment_sequential").cast("int")) \
        .withColumn("payment_installments", F.col("payment_installments").cast("int")) \
        .withColumn("payment_value", F.col("payment_value").cast("decimal(10,2)"))

    # Deduplication
    window = Window.partitionBy("order_id", "payment_sequential").orderBy(F.desc("ingestion_timestamp"))
    silver_payments = silver_payments \
        .withColumn("row_num", F.row_number().over(window)) \
        .filter(F.col("row_num") == 1) \
        .drop("row_num")

    # Metadata
    silver_payments = silver_payments \
        .withColumn("valid_from", F.current_timestamp()) \
        .withColumn("source_batch_id", F.col("batch_id"))

    # Select final columns
    silver_payments = silver_payments.select(
        "order_id",
        "payment_sequential",
        "payment_type",
        "payment_installments",
        "payment_value",
        "valid_from",
        "source_batch_id"
    )

    silver_payments.write.format("delta").mode("overwrite").save(f"{silver_path}/payments")
    row_count = silver_payments.count()
    print(f"  ✅ silver.payments: {row_count} rows written")

    return row_count


# =============================================================================
# SILVER TRANSFORMATIONS — DIMENSIONS (SCD)
# =============================================================================

def transform_customers_scd2(spark, bronze_path, silver_path):
    """
    Transform bronze.raw_customers → silver.customers (SCD Type 2)

    Business Rules:
    - Track zip_code_prefix changes (SCD Type 2)
    - Generate surrogate key: customer_key (auto-increment)
    - Deduplicate by customer_unique_id (keep latest)

    SCD Type 2 Logic:
    1. Detect changes: zip_code_prefix changed
    2. Expire old record: set valid_to = current_timestamp, is_current = False
    3. Insert new record: assign new customer_key, valid_from = current_timestamp
    """
    print("\n📦 Transforming bronze.raw_customers → silver.customers (SCD Type 2)")

    bronze_customers = spark.read.format("delta").load(f"{bronze_path}/raw_customers")

    # Check if Silver table exists
    silver_table_path = f"{silver_path}/customers"
    table_exists = DeltaTable.isDeltaTable(spark, silver_table_path)

    if not table_exists:
        # Initial load: assign customer_key
        print("  🆕 Initial load — assigning customer_key")
        silver_customers = bronze_customers \
            .withColumn("customer_key", F.row_number().over(Window.orderBy("customer_unique_id"))) \
            .withColumn("valid_from", F.current_timestamp()) \
            .withColumn("valid_to", F.lit(None).cast("timestamp")) \
            .withColumn("is_current", F.lit(True)) \
            .withColumn("source_batch_id", F.col("batch_id"))

        silver_customers = silver_customers.select(
            "customer_key",
            "customer_unique_id",
            "customer_id",
            "customer_zip_code_prefix",
            "customer_city",
            "customer_state",
            "valid_from",
            "valid_to",
            "is_current",
            "source_batch_id"
        )

        silver_customers.write.format("delta").mode("overwrite").save(silver_table_path)
        row_count = silver_customers.count()
        print(f"  ✅ silver.customers: {row_count} rows written (initial load)")

    else:
        # SCD Type 2 MERGE logic
        print("  🔄 Incremental load — applying SCD Type 2 logic")

        existing = spark.read.format("delta").load(silver_table_path)
        max_key = existing.agg(F.max("customer_key")).collect()[0][0] or 0

        # Identify changes (zip_code_prefix changed or new customer)
        changes = bronze_customers.alias("new") \
            .join(
                existing.filter(F.col("is_current")).alias("old"),
                on="customer_unique_id",
                how="left"
            ) \
            .where(
                (F.col("new.customer_zip_code_prefix") != F.col("old.customer_zip_code_prefix")) |
                F.col("old.customer_key").isNull()
            ) \
            .select("new.*")

        changes_count = changes.count()
        print(f"  📊 Detected {changes_count} changes/new customers")

        if changes_count > 0:
            # Expire old records
            delta_table = DeltaTable.forPath(spark, silver_table_path)
            changed_ids = changes.select("customer_unique_id").distinct()

            delta_table.alias("target") \
                .merge(
                    changed_ids.alias("source"),
                    "target.customer_unique_id = source.customer_unique_id AND target.is_current = TRUE"
                ) \
                .whenMatchedUpdate(
                    set={
                        "valid_to": F.current_timestamp(),
                        "is_current": F.lit(False)
                    }
                ) \
                .execute()

            # Insert new records with new customer_key
            new_records = changes \
                .withColumn("customer_key", F.row_number().over(Window.orderBy("customer_unique_id")) + max_key) \
                .withColumn("valid_from", F.current_timestamp()) \
                .withColumn("valid_to", F.lit(None).cast("timestamp")) \
                .withColumn("is_current", F.lit(True)) \
                .withColumn("source_batch_id", F.col("batch_id"))

            new_records = new_records.select(
                "customer_key",
                "customer_unique_id",
                "customer_id",
                "customer_zip_code_prefix",
                "customer_city",
                "customer_state",
                "valid_from",
                "valid_to",
                "is_current",
                "source_batch_id"
            )

            new_records.write.format("delta").mode("append").save(silver_table_path)
            print(f"  ✅ silver.customers: {changes_count} new versions appended")

        else:
            print(f"  ℹ️  No changes detected — SCD Type 2 MERGE skipped")

        row_count = spark.read.format("delta").load(silver_table_path).count()

    print(f"  📊 Total rows in silver.customers: {row_count}")
    return row_count


def transform_sellers_scd2(spark, bronze_path, silver_path):
    """
    Transform bronze.raw_sellers → silver.sellers (SCD Type 2)

    Business Rules:
    - Track city/state changes (SCD Type 2)
    - Generate surrogate key: seller_key (auto-increment)
    """
    print("\n📦 Transforming bronze.raw_sellers → silver.sellers (SCD Type 2)")

    bronze_sellers = spark.read.format("delta").load(f"{bronze_path}/raw_sellers")

    silver_table_path = f"{silver_path}/sellers"
    table_exists = DeltaTable.isDeltaTable(spark, silver_table_path)

    if not table_exists:
        # Initial load
        print("  🆕 Initial load — assigning seller_key")
        silver_sellers = bronze_sellers \
            .withColumn("seller_key", F.row_number().over(Window.orderBy("seller_id"))) \
            .withColumn("valid_from", F.current_timestamp()) \
            .withColumn("valid_to", F.lit(None).cast("timestamp")) \
            .withColumn("is_current", F.lit(True)) \
            .withColumn("source_batch_id", F.col("batch_id"))

        silver_sellers = silver_sellers.select(
            "seller_key",
            "seller_id",
            "seller_zip_code_prefix",
            "seller_city",
            "seller_state",
            "valid_from",
            "valid_to",
            "is_current",
            "source_batch_id"
        )

        silver_sellers.write.format("delta").mode("overwrite").save(silver_table_path)
        row_count = silver_sellers.count()
        print(f"  ✅ silver.sellers: {row_count} rows written (initial load)")

    else:
        # SCD Type 2 MERGE logic
        print("  🔄 Incremental load — applying SCD Type 2 logic")

        existing = spark.read.format("delta").load(silver_table_path)
        max_key = existing.agg(F.max("seller_key")).collect()[0][0] or 0

        # Identify changes (city/state changed or new seller)
        changes = bronze_sellers.alias("new") \
            .join(
                existing.filter(F.col("is_current")).alias("old"),
                on="seller_id",
                how="left"
            ) \
            .where(
                (F.col("new.seller_city") != F.col("old.seller_city")) |
                (F.col("new.seller_state") != F.col("old.seller_state")) |
                F.col("old.seller_key").isNull()
            ) \
            .select("new.*")

        changes_count = changes.count()
        print(f"  📊 Detected {changes_count} changes/new sellers")

        if changes_count > 0:
            # Expire old records
            delta_table = DeltaTable.forPath(spark, silver_table_path)
            changed_ids = changes.select("seller_id").distinct()

            delta_table.alias("target") \
                .merge(
                    changed_ids.alias("source"),
                    "target.seller_id = source.seller_id AND target.is_current = TRUE"
                ) \
                .whenMatchedUpdate(
                    set={
                        "valid_to": F.current_timestamp(),
                        "is_current": F.lit(False)
                    }
                ) \
                .execute()

            # Insert new records
            new_records = changes \
                .withColumn("seller_key", F.row_number().over(Window.orderBy("seller_id")) + max_key) \
                .withColumn("valid_from", F.current_timestamp()) \
                .withColumn("valid_to", F.lit(None).cast("timestamp")) \
                .withColumn("is_current", F.lit(True)) \
                .withColumn("source_batch_id", F.col("batch_id"))

            new_records = new_records.select(
                "seller_key",
                "seller_id",
                "seller_zip_code_prefix",
                "seller_city",
                "seller_state",
                "valid_from",
                "valid_to",
                "is_current",
                "source_batch_id"
            )

            new_records.write.format("delta").mode("append").save(silver_table_path)
            print(f"  ✅ silver.sellers: {changes_count} new versions appended")

        else:
            print(f"  ℹ️  No changes detected — SCD Type 2 MERGE skipped")

        row_count = spark.read.format("delta").load(silver_table_path).count()

    print(f"  📊 Total rows in silver.sellers: {row_count}")
    return row_count


def transform_products_scd1(spark, bronze_path, silver_path):
    """
    Transform bronze.raw_products → silver.products (SCD Type 1)

    Business Rules:
    - JOIN translation table for English category name
    - Handle NULL category: replace with 'uncategorized'
    - Overwrite mode (SCD Type 1)
    - Generate surrogate key: product_key (INT)
    """
    print("\n📦 Transforming bronze.raw_products → silver.products (SCD Type 1)")

    bronze_products = spark.read.format("delta").load(f"{bronze_path}/raw_products")
    bronze_translation = spark.read.format("delta").load(f"{bronze_path}/raw_category_translation")

    # Join with translation table
    silver_products = bronze_products \
        .join(bronze_translation, on="product_category_name", how="left") \
        .withColumn("product_category_name_english",
                    F.coalesce(F.col("product_category_name_english"), F.lit("uncategorized")))

    # Type casting for numeric columns
    silver_products = silver_products \
        .withColumn("product_name_length", F.col("product_name_length").cast("int")) \
        .withColumn("product_description_length", F.col("product_description_length").cast("int")) \
        .withColumn("product_photos_qty", F.col("product_photos_qty").cast("int")) \
        .withColumn("product_weight_g", F.col("product_weight_g").cast("int")) \
        .withColumn("product_length_cm", F.col("product_length_cm").cast("int")) \
        .withColumn("product_height_cm", F.col("product_height_cm").cast("int")) \
        .withColumn("product_width_cm", F.col("product_width_cm").cast("int"))

    # Assign product_key
    silver_products = silver_products \
        .withColumn("product_key", F.row_number().over(Window.orderBy("product_id"))) \
        .withColumn("valid_from", F.current_timestamp()) \
        .withColumn("source_batch_id", F.col("batch_id"))

    # Select final columns
    silver_products = silver_products.select(
        "product_key",
        "product_id",
        "product_category_name",
        "product_category_name_english",
        "product_name_length",
        "product_description_length",
        "product_photos_qty",
        "product_weight_g",
        "product_length_cm",
        "product_height_cm",
        "product_width_cm",
        "valid_from",
        "source_batch_id"
    )

    # Overwrite mode (SCD Type 1)
    silver_products.write.format("delta").mode("overwrite").save(f"{silver_path}/products")
    row_count = silver_products.count()
    print(f"  ✅ silver.products: {row_count} rows written (SCD Type 1)")

    return row_count


def transform_geolocation(spark, bronze_path, silver_path):
    """
    Transform bronze.raw_geolocation → silver.geolocation (Reference table)
    """
    print("\n📦 Transforming bronze.raw_geolocation → silver.geolocation")

    bronze_geo = spark.read.format("delta").load(f"{bronze_path}/raw_geolocation")

    silver_geo = bronze_geo \
        .withColumn("geolocation_lat", F.col("geolocation_lat").cast("decimal(9,6)")) \
        .withColumn("geolocation_lng", F.col("geolocation_lng").cast("decimal(9,6)")) \
        .withColumn("valid_from", F.current_timestamp()) \
        .withColumn("source_batch_id", F.col("batch_id"))

    # Deduplicate by zip_code_prefix (keep first)
    window = Window.partitionBy("geolocation_zip_code_prefix").orderBy("ingestion_timestamp")
    silver_geo = silver_geo \
        .withColumn("row_num", F.row_number().over(window)) \
        .filter(F.col("row_num") == 1) \
        .drop("row_num")

    silver_geo = silver_geo.select(
        "geolocation_zip_code_prefix",
        "geolocation_lat",
        "geolocation_lng",
        "geolocation_city",
        "geolocation_state",
        "valid_from",
        "source_batch_id"
    )

    silver_geo.write.format("delta").mode("overwrite").save(f"{silver_path}/geolocation")
    row_count = silver_geo.count()
    print(f"  ✅ silver.geolocation: {row_count} rows written")

    return row_count


# =============================================================================
# MAIN ORCHESTRATION
# =============================================================================

def transform_to_silver(env: str = "dev"):
    """
    WHAT: Transform Bronze → Silver layer dengan type casting, business rules, SCD
    WHY : Per PIPELINE_SPEC — Silver layer implementation

    Steps:
    1. Load environment
    2. Transform fact tables (orders, order_items, payments)
    3. Transform dimension tables (customers SCD2, sellers SCD2, products SCD1, geolocation)
    4. Log summary
    """

    # Load environment
    env_file = f".env.{env}"
    load_dotenv(env_file)
    print(f"\n⚙️  transform_silver.py — env={env}")

    # Initialize Spark
    spark = get_spark_session()

    # Paths
    if env == "dev":
        bronze_path = "data/bronze"
        silver_path = "data/silver"
        Path(silver_path).mkdir(parents=True, exist_ok=True)
    else:
        account = os.environ["AZURE_STORAGE_ACCOUNT"]
        container = os.environ.get(f"ADLS_CONTAINER_{env.upper()}", f"olist-{env}")
        bronze_path = f"abfss://{container}@{account}.dfs.core.windows.net/bronze"
        silver_path = f"abfss://{container}@{account}.dfs.core.windows.net/silver"

    print(f"📂 Bronze path: {bronze_path}")
    print(f"📂 Silver path: {silver_path}")

    summary = {}

    # Transform fact tables
    summary["orders"] = transform_orders(spark, bronze_path, silver_path)
    summary["order_items"] = transform_order_items(spark, bronze_path, silver_path)
    summary["payments"] = transform_payments(spark, bronze_path, silver_path)

    # Transform dimension tables
    summary["customers"] = transform_customers_scd2(spark, bronze_path, silver_path)
    summary["sellers"] = transform_sellers_scd2(spark, bronze_path, silver_path)
    summary["products"] = transform_products_scd1(spark, bronze_path, silver_path)
    summary["geolocation"] = transform_geolocation(spark, bronze_path, silver_path)

    # Summary
    print("\n" + "="*60)
    print("✅ SILVER TRANSFORMATION COMPLETE")
    print("="*60)
    for table, count in summary.items():
        print(f"  silver.{table:<20} : {count:>8} rows")
    print("="*60)

    spark.stop()
    return summary


# =============================================================================
# CLI
# =============================================================================

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", choices=["dev", "staging", "prod"], default="dev")
    args = parser.parse_args()

    transform_to_silver(env=args.env)
