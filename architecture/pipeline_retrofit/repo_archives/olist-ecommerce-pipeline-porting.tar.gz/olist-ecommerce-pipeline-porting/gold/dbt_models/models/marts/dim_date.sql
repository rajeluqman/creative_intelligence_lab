{{
    config(
        materialized='table',
        schema='marts',
        unique_key='date_key'
    )
}}

-- dim_date.sql
-- Date dimension — static (pre-populated date spine)
-- Grain: 1 row = 1 calendar date
-- Range: 2016-01-01 to 2018-12-31 (covers Olist dataset)

WITH date_spine AS (
    {{ dbt_utils.date_spine(
        datepart="day",
        start_date="cast('2016-01-01' as date)",
        end_date="cast('2018-12-31' as date)"
    ) }}
),

date_attributes AS (
    SELECT
        TO_NUMBER(TO_CHAR(date_day, 'YYYYMMDD')) AS date_key,
        date_day AS date_actual,
        YEAR(date_day) AS year,
        QUARTER(date_day) AS quarter,
        MONTH(date_day) AS month,
        TO_CHAR(date_day, 'MMMM') AS month_name,
        WEEK(date_day) AS week,
        DAY(date_day) AS day_of_month,
        DAYOFWEEK(date_day) AS day_of_week,
        TO_CHAR(date_day, 'DY') AS day_name,
        CASE WHEN DAYOFWEEK(date_day) IN (6, 7) THEN TRUE ELSE FALSE END AS is_weekend,
        FALSE AS is_holiday  -- Placeholder — can enhance with holiday calendar
    FROM date_spine
)

SELECT * FROM date_attributes
