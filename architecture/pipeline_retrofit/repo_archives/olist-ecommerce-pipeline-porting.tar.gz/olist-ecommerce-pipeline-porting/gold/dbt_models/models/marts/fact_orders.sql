{{
    config(
        materialized='table',
        schema='marts',
        unique_key='order_id'
    )
}}

-- fact_orders.sql
-- Order fact table
-- Grain: 1 row = 1 order

WITH orders AS (
    SELECT * FROM {{ ref('stg_orders') }}
),

customers AS (
    SELECT * FROM {{ ref('dim_customers') }}
    WHERE is_current = TRUE
),

dates AS (
    SELECT * FROM {{ ref('dim_date') }}
),

joined AS (
    SELECT
        o.order_id,
        c.customer_key,
        d.date_key AS order_date_key,
        o.order_status,
        o.order_purchase_timestamp,
        o.order_approved_at,
        o.order_delivered_customer_date,
        o.order_estimated_delivery_date,
        o.is_delivered,
        o.is_on_time,
        o.review_score,
        o.dq_approved_flag
    FROM orders o
    INNER JOIN customers c
        ON o.customer_id = c.customer_id
    INNER JOIN dates d
        ON DATE(o.order_purchase_timestamp) = d.date_actual
)

SELECT * FROM joined
