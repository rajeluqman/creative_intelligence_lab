{{
    config(
        materialized='table',
        schema='marts',
        unique_key='customer_key'
    )
}}

-- dim_customers.sql
-- Customer dimension — SCD Type 2
-- Grain: 1 row = 1 customer version

WITH source AS (
    SELECT
        customer_key,
        customer_unique_id,
        customer_id,
        customer_zip_code_prefix,
        customer_city,
        customer_state,
        valid_from,
        valid_to,
        is_current
    FROM {{ ref('int_customers_scd2') }}
)

SELECT * FROM source
