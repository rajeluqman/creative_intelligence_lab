{{
    config(
        materialized='view',
        schema='staging'
    )
}}

WITH source AS (
    SELECT *
    FROM {{ source('silver', 'products') }}
),

renamed AS (
    SELECT
        product_key,
        product_id,
        product_category_name,
        product_category_name_english,
        product_name_length,
        product_description_length,
        product_photos_qty,
        product_weight_g,
        product_length_cm,
        product_height_cm,
        product_width_cm,
        valid_from,
        source_batch_id
    FROM source
)

SELECT * FROM renamed
