{{
    config(
        materialized='view',
        schema='staging'
    )
}}

WITH source AS (
    SELECT *
    FROM {{ source('silver', 'order_items') }}
),

renamed AS (
    SELECT
        order_id,
        order_item_id,
        product_id,
        seller_id,
        shipping_limit_date,
        price,
        freight_value,
        gmv,
        dq_zero_price_flag,
        valid_from,
        source_batch_id
    FROM source
)

SELECT * FROM renamed
