{{
    config(
        materialized='view',
        schema='staging'
    )
}}

-- stg_orders.sql
-- Source: Silver Delta Lake (via Snowflake external stage)
-- Grain: 1 row = 1 order (current version only)

WITH source AS (
    SELECT *
    FROM {{ source('silver', 'orders') }}
    WHERE is_current = TRUE
),

renamed AS (
    SELECT
        order_id,
        customer_id,
        order_status,
        order_purchase_timestamp,
        order_approved_at,
        order_delivered_carrier_date,
        order_delivered_customer_date,
        order_estimated_delivery_date,
        is_delivered,
        is_on_time,
        review_score,
        dq_approved_flag,
        valid_from,
        source_batch_id
    FROM source
)

SELECT * FROM renamed
