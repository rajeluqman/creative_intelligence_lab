{{
    config(
        materialized='table',
        schema='marts',
        unique_key=['order_id', 'payment_sequential']
    )
}}

-- fact_payments.sql
-- Payments fact table
-- Grain: 1 row = 1 payment installment

WITH payments AS (
    SELECT
        order_id,
        payment_sequential,
        payment_type,
        payment_installments,
        payment_value
    FROM {{ ref('stg_payments') }}
)

SELECT * FROM payments
