{{
    config(
        materialized='table',
        schema='marts',
        unique_key='seller_key'
    )
}}

-- dim_sellers.sql
-- Seller dimension — SCD Type 2
-- Grain: 1 row = 1 seller version

WITH source AS (
    SELECT
        seller_key,
        seller_id,
        seller_zip_code_prefix,
        seller_city,
        seller_state,
        valid_from,
        valid_to,
        is_current
    FROM {{ ref('int_sellers_scd2') }}
)

SELECT * FROM source
