{{
    config(
        materialized='view',
        schema='staging'
    )
}}

WITH source AS (
    SELECT *
    FROM {{ source('silver', 'customers') }}
),

renamed AS (
    SELECT
        customer_key,
        customer_unique_id,
        customer_id,
        customer_zip_code_prefix,
        customer_city,
        customer_state,
        valid_from,
        NULL as valid_to,  -- Not in Parquet, SCD handled in Silver
        is_current,
        source_batch_id
    FROM source
)

SELECT * FROM renamed
