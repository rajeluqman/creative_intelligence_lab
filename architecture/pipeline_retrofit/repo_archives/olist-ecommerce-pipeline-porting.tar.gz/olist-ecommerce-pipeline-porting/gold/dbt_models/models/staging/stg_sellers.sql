{{
    config(
        materialized='view',
        schema='staging'
    )
}}

WITH source AS (
    SELECT *
    FROM {{ source('silver', 'sellers') }}
),

renamed AS (
    SELECT
        seller_key,
        seller_id,
        seller_zip_code_prefix,
        seller_city,
        seller_state,
        valid_from,
        NULL as valid_to,  -- Not in Parquet, SCD handled in Silver
        is_current,
        source_batch_id
    FROM source
)

SELECT * FROM renamed
