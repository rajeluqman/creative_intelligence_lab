{{
    config(
        materialized='view',
        schema='intermediate'
    )
}}

-- int_sellers_scd2.sql
-- SCD Type 2 processing for sellers dimension
-- All versions included (not just current)

WITH source AS (
    SELECT
        seller_key,
        seller_id,
        seller_zip_code_prefix,
        seller_city,
        seller_state,
        valid_from,
        valid_to,
        is_current
    FROM {{ ref('stg_sellers') }}
)

SELECT * FROM source
