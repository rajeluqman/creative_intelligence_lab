{{
    config(
        materialized='view',
        schema='intermediate'
    )
}}

-- int_customers_scd2.sql
-- SCD Type 2 processing for customers dimension
-- All versions included (not just current)

WITH source AS (
    SELECT
        customer_key,
        customer_unique_id,
        customer_id,
        customer_zip_code_prefix,
        customer_city,
        customer_state,
        valid_from,
        valid_to,
        is_current
    FROM {{ ref('stg_customers') }}
)

SELECT * FROM source
