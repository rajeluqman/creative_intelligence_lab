{{
    config(
        materialized='table',
        schema='marts',
        unique_key=['order_id', 'order_item_id']
    )
}}

-- fact_order_items.sql
-- Order items fact table
-- Grain: 1 row = 1 line item in an order

WITH order_items AS (
    SELECT * FROM {{ ref('stg_order_items') }}
),

products AS (
    SELECT * FROM {{ ref('dim_products') }}
),

sellers AS (
    SELECT * FROM {{ ref('dim_sellers') }}
    WHERE is_current = TRUE
),

joined AS (
    SELECT
        oi.order_id,
        oi.order_item_id,
        p.product_key,
        s.seller_key,
        oi.shipping_limit_date,
        oi.price,
        oi.freight_value,
        oi.gmv,
        oi.dq_zero_price_flag
    FROM order_items oi
    INNER JOIN products p
        ON oi.product_id = p.product_id
    INNER JOIN sellers s
        ON oi.seller_id = s.seller_id
)

SELECT * FROM joined
