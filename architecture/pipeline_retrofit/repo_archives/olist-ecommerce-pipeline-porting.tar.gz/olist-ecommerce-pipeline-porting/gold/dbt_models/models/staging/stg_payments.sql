{{
    config(
        materialized='view',
        schema='staging'
    )
}}

WITH source AS (
    SELECT *
    FROM {{ source('silver', 'payments') }}
),

renamed AS (
    SELECT
        order_id,
        payment_sequential,
        payment_type,
        payment_installments,
        payment_value,
        valid_from,
        source_batch_id
    FROM source
)

SELECT * FROM renamed
