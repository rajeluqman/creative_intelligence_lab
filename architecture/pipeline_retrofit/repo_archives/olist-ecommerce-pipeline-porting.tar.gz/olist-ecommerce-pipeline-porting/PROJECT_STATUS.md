# Olist E-Commerce Pipeline — Project Status

> Resume-safe checkpoint. A fresh session reads "▶ RESUME HERE" first.
> Branch: `framework/governance-retrofit`. Retrofit source: `creative_intelligence_lab`
> (pipeline-retrofit effort, repo 2 of 4, after home-credit-pipeline — see
> `architecture/pipeline_retrofit/` in CIL for provenance).

## ▶ RESUME HERE
**Where we are:** Governance retrofit complete — CLAUDE.md, 9-agent roster, governance hook,
3 contracts (all green), repo-map (generated, fresh), 2 new ADRs, Confluence sync adaptation,
3 logs (this file + COST_LOG.md + DECISION_LOG.md), learning layer, simulation lab,
INTERVIEW_GUIDE.md, CI extension — built on `framework/governance-retrofit`. NOT pushed, NOT a
PR yet — owner reviews first.
**Stack preserved as-is**: Kaggle API → Azure ADLS Gen2 → Databricks COPY INTO Bronze (Delta
Lake/Unity Catalog) → Databricks SQL Warehouse Silver (SCD2 customers/sellers, SCD1 products)
→ Parquet export → Snowflake external stage → dbt Core Gold (Kimball star) → Power BI —
verified by reading the actual repo (bronze/, silver/, gold/, airflow/, data_quality/), not
assumed from the retrofit brief.
**Next action:** owner review → push branch → open PR → then port the pattern (not a literal
copy — stacks differ) onward to paysim → Volve (per CIL's `01_OPUS_DECISIONS.md` sequencing).
**Do NOT:** push or open the PR without owner sign-off; swap any tool in the stack; fabricate
resume claims beyond the one ADF mismatch already supplied.

## Build checklist (with evidence)
| Item | Status | Evidence |
|---|---|---|
| CLAUDE.md | ✅ | `CLAUDE.md` — real Databricks/Snowflake stack table, governed-file map |
| .claude/agents/ ×9 | ✅ | `.claude/agents/*.md` — data-architect, scope-guardian, senior-data-engineer, data-quality-steward, product-owner, business-analyst, data-platform-engineer, documentation-sherpa, cikgu |
| .claude/settings.json + hooks/governance_guard.py | ✅ | retargeted to `gold/dbt_models/models/marts/`, `silver/transform_silver.py`, `docs/DATA_MODEL.md`, `docs/ADR/` |
| tests/doc_reference_contract.py | ✅ | `python tests/doc_reference_contract.py` → OK, 14 docs (fixed 2 pre-existing path typos + 1 cross-repo reference found during verification) |
| tests/boundary_contract.py | ✅ | `python tests/boundary_contract.py` → OK |
| tests/identity_contract.py | ✅ | `python tests/identity_contract.py` → OK (customer_key/seller_key SCD2) |
| scripts/gen_repo_map.py + architecture/REPO_MAP.md | ✅ | `python scripts/gen_repo_map.py` → wrote 79 files; `--check` → OK |
| ADR-002 SCD strategy | ✅ | `docs/ADR/ADR-002-scd-strategy.md` (verified against `silver/transform_silver.py` — was already correct, not a stub) |
| ADR-003 Slack alerting | ✅ | `docs/ADR/ADR-003-slack-alerting.md` + `airflow/dags/olist_pipeline_dag.py` `_notify_slack_failure` (graceful no-op if `SLACK_WEBHOOK_URL` unset) |
| Confluence sync | ✅ | `scripts/sync_docs_to_confluence.py` adapted from CIL; `confluence/00_START_HERE.md` pointer |
| Logs (PROJECT_STATUS/COST_LOG/DECISION_LOG) | ✅ | this file + the 2 below |
| learning/CURRICULUM.md + LEARNING_LOG.md | ✅ | Kaggle→ADLS→Databricks Bronze→Silver SCD→Snowflake Gold→Power BI module path |
| simulation/ | ✅ | `ISOLATION_CONTRACT.md`, `check_isolation.py`, `faults/inject.py`+`reset.py`, drill specs |
| INTERVIEW_GUIDE.md | ✅ | resume↔repo evidence table, ADF mismatch flagged |
| .github/workflows/ci.yml | ✅ | extended with the 3 new contract gates |
| push branch + PR | ⬜ | blocked on owner review (explicit instruction — do not push) |

## Doc gaps found during retrofit (real findings, not assumed)
1. `docs/ARCHITECTURE.md` (lines 64, 191) said `gold/models/` — the real dbt project root is
   `gold/dbt_models/`. Fixed; was breaking `doc_reference_contract.py` C2.
2. `docs/PIPELINE_SPEC.md:115` said `tests/great_expectations/bronze_suite.json` — the real
   path is `data_quality/great_expectations/expectations/bronze_suite.json`. Fixed.
3. Resume claims "Azure Data Factory (ADF)" for ingestion; the repo actually uses Kaggle API +
   Databricks COPY INTO (`bronze/download_dataset.py`, `bronze/bronze_pipeline.py`). No ADF
   usage found anywhere in the codebase (`grep -ri "data factory\|adf" bronze/ silver/
   airflow/` → 0 hits in actual pipeline code; `docs/ARCHITECTURE.md:375` only mentions ADF as
   an *aspirational* cloud staging note, never implemented). Flagged in `INTERVIEW_GUIDE.md`;
   recommend correcting the resume claim, not fabricating ADF support in the repo.
4. Alerting was print-only (`docs/ARCHITECTURE.md` table: "Print-based callbacks ... Slack
   integration pending") despite `apache-airflow-providers-slack==8.0.0` already being in
   `requirements.txt` unused. Backfilled per ADR-003, on `on_failure_callback` only (failure
   channel, not success — see ADR-003 rationale).
5. **(2026-06-29, owner audit ahead of a Microsoft Fabric migration, missed in the 2026-06-28
   pass)** `README.md`/`CLAUDE.md`/`docs/ARCHITECTURE.md` overstated Silver as "Databricks SQL
   Warehouse (Serverless) — SQL CTAS + window functions". The real `silver/transform_silver.py`
   is plain PySpark DataFrame API (zero SQL CTAS in the file). **Fixed** in all 3 docs.
6. **(2026-06-29, same audit)** The Airflow DAG's `bronze_ingest`/`silver_transform`/
   `silver_dq_check` tasks (`bronze/bronze_pipeline.py`, `silver/silver_pipeline.py`,
   `data_quality/run_silver_validation.py`) are explicit print-stub wrappers ("Demo/Portfolio:
   Validates configuration and reports success" / "Skipping actual validation — Silver tables
   in Databricks (cloud)") — not live Databricks orchestration. Only `gold_dbt_run`/
   `gold_dbt_test` execute real work per scheduled run; the real Bronze/Silver execution
   happened once, manually, via the Databricks notebooks during Phase 4b. This was
   undocumented anywhere before this audit. **Documented** (not a code change — the stub is
   the repo's own intentional demo design) in `CLAUDE.md`'s "Automation gap" callout,
   `docs/ARCHITECTURE.md`, and `INTERVIEW_GUIDE.md` row 9 + drill 6.

## Token discipline note
This repo's stack (Databricks Bronze/Silver, dbt/Snowflake Gold) differs from home-credit's
(AWS Glue Bronze/Silver, dbt/Snowflake Gold) — the retrofit pattern was ported, not copied
literally; every governed-path reference in CLAUDE.md/hooks/contracts was re-verified against
THIS repo's actual files before being written.
