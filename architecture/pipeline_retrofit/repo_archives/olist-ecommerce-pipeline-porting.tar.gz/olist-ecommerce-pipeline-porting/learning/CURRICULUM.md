# Learning Curriculum — Olist E-Commerce Pipeline

> Owned by @cikgu. The learning PATH for this project: each module pairs a concept with the
> real artifact that embodies it, the WHY-before-HOW questions you must answer first, and a DIY
> build task. Teach in order; close each module with a `LEARNING_LOG.md` entry.
> Run @cikgu as a MAIN session (not a subagent) for actual teaching. English-first per CIL's
> ADR-011 addendum (Manglish only if explicitly requested in-session).

**Score:** start 100. Track in `LEARNING_LOG.md`. Hint = -5. < 60 forces a docs break.

| # | Module | You must be able to answer (WHY) | Artifact (read AFTER you've tried) | DIY |
|---|--------|----------------------------------|-------------------------------------|-----|
| **M0** | The domain & the goal | Why is this an Order-to-Cash analytics problem, not just "load CSVs into a warehouse"? What are the 4 KPIs the star schema must serve (DSO, fulfillment rate, GMV, retention)? | `README.md` "Problem Statement" | — |
| **M1** | Kaggle → ADLS landing | Why land raw CSVs in ADLS Gen2 before any transform? Why is the free-tier 5GB cap a real design constraint here, not a footnote? | `bronze/download_dataset.py`, `docs/ARCHITECTURE.md` "Landing" | explain the landing-zone rationale in 3 sentences |
| **M2** | Databricks COPY INTO Bronze | Why COPY INTO over a naive `spark.read.csv` + `.write`? What does Unity Catalog + Delta Lake buy you (ACID, time travel) that a plain Parquet dump doesn't? | `bronze/bronze_pipeline.py`, `bronze/ingest_to_delta.py`, `databricks_notebooks/01_bronze_ingestion.py` | trace one CSV's path from Kaggle file to a queryable Delta row, citing each script |
| **M3** | SCD Type 2 mechanics | Why SCD2 for `dim_customers`/`dim_sellers` but not `dim_products`? Walk through the MERGE-expire pattern by reasoning BEFORE reading the code: what 2 things must happen atomically when a customer's address changes? | `silver/transform_silver.py` `transform_customers_scd2`/`transform_sellers_scd2`, `docs/ADR/ADR-002-scd-strategy.md` | build the MERGE-expire pseudocode from scratch DIY, then diff vs the real function |
| **M4** | SCD Type 1 mechanics | Why is overwrite-mode acceptable for `dim_products` when it's not for customers/sellers? What's the actual risk being accepted? | `silver/transform_silver.py` `transform_products_scd1`, ADR-002 | name 2 cases where SCD1 on `dim_products` would silently lose information a stakeholder cares about |
| **M5** | Silver business rules | Why do type casting + business-rule validation happen in Silver, not Bronze or Gold? What breaks if you skip this layer? | `silver/transform_silver.py` (non-SCD transforms), `docs/DATA_MODEL.md` | pick one Silver validation rule and explain the bad row it's designed to catch |
| **M6** | Parquet bridge + Snowflake external stage | Why export Delta → Parquet → Snowflake external stage instead of querying Delta directly from Snowflake, or writing straight to Snowflake from Databricks? | `databricks_notebooks/03_export_silver_to_parquet.py`, `scripts/snowflake_setup*.sql`, `scripts/snowflake_load_*.sql` | trace one row's path from a Silver Delta table to a Snowflake stage table, citing each script |
| **M7** | dbt Gold — Kimball star | What is `ref()`/`source()`? Why staging → intermediate → marts (3 layers), and why do `int_customers_scd2.sql`/`int_sellers_scd2.sql` exist as a SEPARATE layer from the mart `dim_*.sql` files? | `docs/ADR/ADR-001-data-modelling-paradigm.md`, the `gold/dbt_models/models/` tree | build `gold/dbt_models/models/marts/dim_date.sql`-equivalent DIY for a synthetic 5-row sim, diff vs the real model's grain logic |
| **M8** | Airflow orchestration + Slack alerting | Why one chained DAG (bronze → silver → silver_dq → gold_dbt_run → gold_dbt_test) instead of 5 separate DAGs? Why is the Slack alert wired ONLY on `on_failure_callback`, not success? | `airflow/dags/olist_pipeline_dag.py`, `docs/ADR/ADR-003-slack-alerting.md` | DIY a parse-clean single-task DAG from scratch with a graceful-degrade `on_failure_callback`; verify with DagBag (no import errors) |
| **M9** | Great Expectations gates | What's the difference between a Bronze-layer GE check and a Silver-layer one — why does Bronze check file-level/schema things and Silver check business-rule things? | `data_quality/run_bronze_validation.py` (9 checks), `data_quality/run_silver_suite.py`/`run_silver_validation.py` (12 checks) | write one new GE expectation for `dim_customers` (e.g. exactly 1 `is_current=TRUE` per `customer_unique_id`) and explain why it complements, not duplicates, `tests/identity_contract.py` |
| **M10** | CI/CD & static gates | Why does this repo's CI run static gates ($0, no cloud creds) instead of a full Databricks/Snowflake run on every push? What does each new contract (`doc_reference_contract.py`, `boundary_contract.py`, `identity_contract.py`) actually catch that a human reviewer might miss? | `.github/workflows/ci.yml`, `tests/*_contract.py` | DIY: add a new static gate (e.g. assert every mart SQL file has a `-- Grain:` comment) and make it green |
| **M11** | Portfolio framing & resume reconciliation | What makes this pipeline distinct in an interview from a "just ran dbt on a Kaggle CSV" project? Defend each ADR decision; reconcile the ADF resume claim honestly. | all ADRs, `INTERVIEW_GUIDE.md` | draft 5 resume bullets → @business-analyst honesty check against `file:line` evidence |

## How a module runs (the ritual)
1. @cikgu poses the WHY questions. You answer from reasoning — NO reading yet.
2. You sketch the solution shape (mental model first, syntax last).
3. THEN you open the artifact and compare to your reasoning.
4. For DIY modules: @cikgu writes a `learning/diy/TICKET_<name>.md`; you build in
   `learning/diy/`; diff vs the real model line-by-line; quiz WHY on every gap.
5. LEARNING_LOG entry + score update.

## Suggested order
M0 → M1 → M2 → M3 → M4 → M5 → M6 → M7 (so you can run the full medallion conceptually) → M10
(lock CI early) → M8 → M9 → M11.
