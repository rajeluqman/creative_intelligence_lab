# Fault Catalog — Olist Simulation Lab

Named, reversible faults for troubleshooting drills. `inject.py <fault_id>` applies one;
`reset.py` rebuilds clean sim state from sim fixtures (never hand-patched).

| ID | Fault | Mirrors a real risk from |
|---|---|---|
| F01 | Delta Bronze table partition corrupted (malformed Parquet footer in one COPY INTO batch) | `bronze/ingest_to_delta.py`, `docs/ARCHITECTURE.md` Bronze ACID/time-travel claims |
| F02 | SCD2 effective-date broken — `valid_to`/`is_current` MERGE-expire step skipped, leaving 2 `is_current=TRUE` rows per `customer_unique_id` | `silver/transform_silver.py` `transform_customers_scd2`, `tests/identity_contract.py` ID1/ID2 |
| F03 | Snowflake external stage permission dropped (stage credential revoked, `dbt build` fails on `int_*_scd2` source read) | `gold/dbt_models/profiles.yml`, `scripts/snowflake_setup*.sql` |
| F04 | SCD1 product overwrite double-applied (re-run reassigns `product_key`, breaking FK continuity into `fact_order_items`) | `silver/transform_silver.py` `transform_products_scd1`, ADR-002 |

Catalog entries (full repro steps) live in `simulation/faults/catalog/`.
