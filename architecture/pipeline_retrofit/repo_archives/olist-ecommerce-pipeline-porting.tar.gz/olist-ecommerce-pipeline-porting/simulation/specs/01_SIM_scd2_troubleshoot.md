# SIM Spec — SCD2 Effective-Date Troubleshoot Drill

> Isolation-contracted (ISOLATION_CONTRACT.md R1-R5). Run on a `drill/*` branch.

## Scenario
Inject F02 (`simulation/faults/inject.py F02`) — the SCD2 MERGE-expire step in
`transform_customers_scd2` is skipped on a re-run, leaving 2 `is_current=TRUE` rows for the
same `customer_unique_id` in the sim schema.

## Pedagogy
Troubleshooting mode (CIL CURRICULUM convention): hypothesis-log BEFORE running anything.
1. Write `hypothesis → test → predicted output` before touching the sim.
2. Observe (sim dbt run output against `OLIST_ECOMMERCE_SIM` schema, or a static check against
   the sim fixtures if no live Snowflake session is available).
3. Root-cause: tie back to `silver/transform_silver.py`'s MERGE-expire pattern and
   `tests/identity_contract.py` ID1/ID2 — which rule would have caught this statically?
4. Fix in the sim only; `faults/reset.py` to return to clean baseline.

## Acceptance
Owner can explain, unaided, why "exactly 1 `is_current=TRUE` row per business key" is the
SCD2 invariant, and which line of `transform_customers_scd2` enforces it (the MERGE step that
sets `valid_to`/`is_current=False` on the old row BEFORE inserting the new one).
