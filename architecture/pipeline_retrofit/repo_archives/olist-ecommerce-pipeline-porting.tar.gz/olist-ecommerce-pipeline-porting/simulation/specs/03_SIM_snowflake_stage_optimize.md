# SIM Spec — Snowflake External Stage Permission Optimization Drill

> Isolation-contracted (ISOLATION_CONTRACT.md R1-R5). Run on a `drill/*` branch.

## Scenario
Inject F03 (`simulation/faults/inject.py F03`) — the sim's Snowflake external stage
credential is revoked, so `dbt build --target sim` fails reading the Parquet bridge files.
The drill is an **optimization**: once access is restored, identify and fix the slowest step
in the sim's staging → intermediate → marts build (e.g. an unnecessarily wide `SELECT *` in a
staging model materialized as a table instead of a view).

## Pedagogy
Optimization mode: measure BEFORE changing anything.
1. Run `dbt build --target sim` (or trace through `gold/dbt_models/models/staging/*.sql` if no
   live Snowflake session is available) and note materialization + column list per model.
2. Identify the highest-cost step relative to its actual downstream usage.
3. Propose ONE change (e.g. narrow the staging `SELECT`, or confirm view-not-table per CLAUDE.md
   "serving = view, never a duplicated physical table" doctrine if that pattern applies here).
4. Apply in the sim only; re-measure; reconcile improvement with evidence, not a guess.

## Acceptance
Owner can articulate the optimization in interview terms: which dbt materialization was wrong
and why, tied to the real `gold/dbt_models/models/staging/schema.yml` configuration.
