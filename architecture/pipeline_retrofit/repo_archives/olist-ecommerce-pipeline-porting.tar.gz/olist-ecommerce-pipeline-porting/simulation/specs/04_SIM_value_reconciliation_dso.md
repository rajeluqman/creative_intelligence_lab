# SIM Spec — DSO Value-Reconciliation Drill

> Isolation-contracted (ISOLATION_CONTRACT.md R1-R5). Run on a `drill/*` branch.

## Scenario
Using sim fixtures (synthetic `fact_orders` + `fact_payments` rows, never the real marts),
compute Days Sales Outstanding (DSO) two ways — (a) by hand from the raw sim rows, (b) via the
sim's own dbt model mirroring `fact_orders`/`fact_payments`'s join — and reconcile any
discrepancy to zero before declaring the metric trustworthy.

## Pedagogy
Reconcile-before-done (CLAUDE.md anti-shortcut protocol, applied to a metric instead of code):
1. State the DSO formula from the real `README.md` "Problem Statement" table
   (`payment_date - order_purchase_ts`) before computing anything.
2. Compute by hand on 3-5 sim rows.
3. Compute via the sim dbt model.
4. Diff. If nonzero, find the root cause (grain mismatch? NULL payment_date? timezone?) — do
   not average it away or call it "close enough."

## Acceptance
Owner can defend the DSO number to a stakeholder using only the artifact (the sim model SQL +
the by-hand check), not memory — and can name the one real-world failure mode (e.g. a
multi-installment payment row attached to the wrong order) that this drill is rehearsing for.
