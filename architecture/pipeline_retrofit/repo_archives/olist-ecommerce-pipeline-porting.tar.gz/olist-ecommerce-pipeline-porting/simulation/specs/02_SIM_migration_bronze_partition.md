# SIM Spec — Bronze Delta Partition Migration Drill

> Isolation-contracted (ISOLATION_CONTRACT.md R1-R5). Run on a `drill/*` branch.

## Scenario
Inject F01 (`simulation/faults/inject.py F01`) — one Bronze Delta table partition in the sim
has a malformed Parquet footer (simulating a partial/corrupt COPY INTO batch). The drill is a
**migration**: move the sim's Bronze layer to a re-partitioned, repaired Delta table without
losing rows, and prove row-count parity before/after.

## Pedagogy
Migration mode: plan BEFORE touching anything.
1. Snapshot the sim Bronze row count + a content hash of the affected partition.
2. Draft a migration plan (read `bronze/ingest_to_delta.py` for the real COPY INTO + Delta
   write pattern as the answer key — re-derive the repair step, don't copy blindly).
3. Execute the migration in the sim only.
4. Reconcile: row count before == row count after, partition hash differs only where expected.

## Acceptance
Owner can defend the migration plan in interview terms: why Delta time-travel (`DESCRIBE
HISTORY`, `RESTORE TABLE`) is the real-world tool for this, and why ACID guarantees make the
repair safe to retry idempotently (skip-existing identity, per `docs/ADR/ADR-001`).
