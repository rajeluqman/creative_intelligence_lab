-- snowflake_load_WORKING.sql
-- Load Parquet → Snowflake tables (WORKING VERSION with PATTERN)

USE ROLE SYSADMIN;
USE DATABASE olist_ecommerce;
USE SCHEMA silver_external;

-- Drop any existing tables
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS sellers;
DROP TABLE IF EXISTS products;

-- =====================================================
-- CREATE TABLES FROM PARQUET (with PATTERN to skip _SUCCESS files)
-- =====================================================

-- orders
CREATE TABLE orders AS
SELECT
  $1:order_id::STRING AS order_id,
  $1:customer_id::STRING AS customer_id,
  $1:order_status::STRING AS order_status,
  $1:order_purchase_timestamp::TIMESTAMP AS order_purchase_timestamp,
  $1:order_approved_at::TIMESTAMP AS order_approved_at,
  $1:order_delivered_carrier_date::TIMESTAMP AS order_delivered_carrier_date,
  $1:order_delivered_customer_date::TIMESTAMP AS order_delivered_customer_date,
  $1:order_estimated_delivery_date::TIMESTAMP AS order_estimated_delivery_date,
  $1:is_delivered::BOOLEAN AS is_delivered,
  $1:is_on_time::BOOLEAN AS is_on_time,
  $1:review_score::FLOAT AS review_score,
  $1:dq_approved_flag::BOOLEAN AS dq_approved_flag,
  $1:is_current::BOOLEAN AS is_current,
  $1:valid_from::TIMESTAMP AS valid_from,
  $1:source_batch_id::STRING AS source_batch_id
FROM @silver_stage/orders/ (PATTERN=>'.*part.*\.parquet');

SELECT 'orders', COUNT(*) FROM orders;

-- order_items
CREATE TABLE order_items AS
SELECT
  $1:order_id::STRING AS order_id,
  $1:order_item_id::INT AS order_item_id,
  $1:product_id::STRING AS product_id,
  $1:seller_id::STRING AS seller_id,
  $1:shipping_limit_date::TIMESTAMP AS shipping_limit_date,
  $1:price::FLOAT AS price,
  $1:freight_value::FLOAT AS freight_value,
  $1:gmv::FLOAT AS gmv,
  $1:dq_zero_price_flag::BOOLEAN AS dq_zero_price_flag,
  $1:valid_from::TIMESTAMP AS valid_from,
  $1:source_batch_id::STRING AS source_batch_id
FROM @silver_stage/order_items/ (PATTERN=>'.*part.*\.parquet');

SELECT 'order_items', COUNT(*) FROM order_items;

-- payments
CREATE TABLE payments AS
SELECT
  $1:order_id::STRING AS order_id,
  $1:payment_sequential::INT AS payment_sequential,
  $1:payment_type::STRING AS payment_type,
  $1:payment_installments::INT AS payment_installments,
  $1:payment_value::FLOAT AS payment_value,
  $1:valid_from::TIMESTAMP AS valid_from,
  $1:source_batch_id::STRING AS source_batch_id
FROM @silver_stage/payments/ (PATTERN=>'.*part.*\.parquet');

SELECT 'payments', COUNT(*) FROM payments;

-- customers
CREATE TABLE customers AS
SELECT
  $1:customer_key::INT AS customer_key,
  $1:customer_unique_id::STRING AS customer_unique_id,
  $1:customer_id::STRING AS customer_id,
  $1:customer_zip_code_prefix::STRING AS customer_zip_code_prefix,
  $1:customer_city::STRING AS customer_city,
  $1:customer_state::STRING AS customer_state,
  $1:is_current::BOOLEAN AS is_current,
  $1:valid_from::TIMESTAMP AS valid_from,
  $1:source_batch_id::STRING AS source_batch_id
FROM @silver_stage/customers/ (PATTERN=>'.*part.*\.parquet');

SELECT 'customers', COUNT(*) FROM customers;

-- sellers
CREATE TABLE sellers AS
SELECT
  $1:seller_key::INT AS seller_key,
  $1:seller_id::STRING AS seller_id,
  $1:seller_zip_code_prefix::STRING AS seller_zip_code_prefix,
  $1:seller_city::STRING AS seller_city,
  $1:seller_state::STRING AS seller_state,
  $1:is_current::BOOLEAN AS is_current,
  $1:valid_from::TIMESTAMP AS valid_from,
  $1:source_batch_id::STRING AS source_batch_id
FROM @silver_stage/sellers/ (PATTERN=>'.*part.*\.parquet');

SELECT 'sellers', COUNT(*) FROM sellers;

-- products
CREATE TABLE products AS
SELECT
  $1:product_key::INT AS product_key,
  $1:product_id::STRING AS product_id,
  $1:product_category_name::STRING AS product_category_name,
  $1:product_category_name_english::STRING AS product_category_name_english,
  $1:product_name_length::INT AS product_name_length,
  $1:product_description_length::INT AS product_description_length,
  $1:product_photos_qty::INT AS product_photos_qty,
  $1:product_weight_g::INT AS product_weight_g,
  $1:product_length_cm::INT AS product_length_cm,
  $1:product_height_cm::INT AS product_height_cm,
  $1:product_width_cm::INT AS product_width_cm,
  $1:valid_from::TIMESTAMP AS valid_from,
  $1:source_batch_id::STRING AS source_batch_id
FROM @silver_stage/products/ (PATTERN=>'.*part.*\.parquet');

SELECT 'products', COUNT(*) FROM products;

-- =====================================================
-- VERIFY
-- =====================================================

SHOW TABLES IN SCHEMA silver_external;

-- Row count summary
SELECT 'orders' AS table_name, COUNT(*) AS row_count FROM orders
UNION ALL
SELECT 'order_items', COUNT(*) FROM order_items
UNION ALL
SELECT 'payments', COUNT(*) FROM payments
UNION ALL
SELECT 'customers', COUNT(*) FROM customers
UNION ALL
SELECT 'sellers', COUNT(*) FROM sellers
UNION ALL
SELECT 'products', COUNT(*) FROM products;

-- Test queries
SELECT order_id, customer_id, order_status FROM orders LIMIT 3;
SELECT customer_key, customer_id FROM customers LIMIT 3;

-- ✅ ALL TABLES LOADED - Ready for dbt!
