-- snowflake_setup_READY.sql
-- Snowflake setup untuk Gold Layer — Phase 4b
-- Azure Tenant ID: 4c7869cb-1b01-4b9a-b821-d1ad275cae88
-- Ready to run - no placeholder replacements needed

-- =====================================================
-- SECTION 1: DATABASE & WAREHOUSE SETUP
-- =====================================================

USE ROLE SYSADMIN;

-- Create database
CREATE DATABASE IF NOT EXISTS olist_ecommerce
    COMMENT = 'Olist E-Commerce Pipeline — Gold Layer (dbt)';

-- Create schemas
CREATE SCHEMA IF NOT EXISTS olist_ecommerce.staging
    COMMENT = 'Staging layer — views dari Silver sources';

CREATE SCHEMA IF NOT EXISTS olist_ecommerce.intermediate
    COMMENT = 'Intermediate transformations (SCD views)';

CREATE SCHEMA IF NOT EXISTS olist_ecommerce.marts
    COMMENT = 'Gold marts — Star Schema (Kimball)';

CREATE SCHEMA IF NOT EXISTS olist_ecommerce.silver_external
    COMMENT = 'External tables reading Silver Parquet from ADLS Gen2';

-- Verify warehouse exists
SHOW WAREHOUSES LIKE 'COMPUTE_WH';

-- ✅ SECTION 1 COMPLETE
-- Next: Run SECTION 2

-- =====================================================
-- SECTION 2: STORAGE INTEGRATION (Azure ADLS Gen2)
-- =====================================================

-- Switch to ACCOUNTADMIN role (required for storage integration)
USE ROLE ACCOUNTADMIN;

CREATE OR REPLACE STORAGE INTEGRATION azure_olist_integration
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = 'AZURE'
  ENABLED = TRUE
  AZURE_TENANT_ID = '4c7869cb-1b01-4b9a-b821-d1ad275cae88'
  STORAGE_ALLOWED_LOCATIONS = (
    'azure://azolistpiepeline.blob.core.windows.net/olist-staging/silver_parquet/'
  );

-- Grant usage to SYSADMIN
GRANT USAGE ON INTEGRATION azure_olist_integration TO ROLE SYSADMIN;

-- Get Azure consent URL
DESC INTEGRATION azure_olist_integration;

-- ⚠️ IMPORTANT: After running DESC above
-- 1. Find row where property = 'AZURE_CONSENT_URL'
-- 2. Copy the URL value
-- 3. Open URL in browser
-- 4. Grant "Storage Blob Data Reader" permission in Azure
-- 5. WAIT 2-5 MINUTES for Azure propagation
-- 6. Then proceed to SECTION 3

-- ✅ SECTION 2 COMPLETE (after consent granted + wait)
-- Next: Run SECTION 3

-- =====================================================
-- SECTION 3: EXTERNAL STAGE (pointing to Silver Parquet)
-- =====================================================

USE ROLE SYSADMIN;
USE DATABASE olist_ecommerce;
USE SCHEMA silver_external;

CREATE OR REPLACE STAGE silver_stage
  STORAGE_INTEGRATION = azure_olist_integration
  URL = 'azure://azolistpiepeline.blob.core.windows.net/olist-staging/silver_parquet/'
  FILE_FORMAT = (TYPE = PARQUET);

-- Test stage access (should show 6 folders)
LIST @silver_stage;

-- Expected output:
-- silver_parquet/orders/
-- silver_parquet/order_items/
-- silver_parquet/payments/
-- silver_parquet/customers/
-- silver_parquet/sellers/
-- silver_parquet/products/

-- ✅ SECTION 3 COMPLETE (if LIST shows files)
-- Next: Run SECTION 4

-- =====================================================
-- SECTION 4: EXTERNAL TABLES (Silver sources for dbt)
-- =====================================================

-- orders
CREATE OR REPLACE EXTERNAL TABLE silver_external.orders
WITH LOCATION = @silver_stage/orders/
FILE_FORMAT = (TYPE = PARQUET)
AUTO_REFRESH = FALSE;

-- order_items
CREATE OR REPLACE EXTERNAL TABLE silver_external.order_items
WITH LOCATION = @silver_stage/order_items/
FILE_FORMAT = (TYPE = PARQUET)
AUTO_REFRESH = FALSE;

-- payments
CREATE OR REPLACE EXTERNAL TABLE silver_external.payments
WITH LOCATION = @silver_stage/payments/
FILE_FORMAT = (TYPE = PARQUET)
AUTO_REFRESH = FALSE;

-- customers
CREATE OR REPLACE EXTERNAL TABLE silver_external.customers
WITH LOCATION = @silver_stage/customers/
FILE_FORMAT = (TYPE = PARQUET)
AUTO_REFRESH = FALSE;

-- sellers
CREATE OR REPLACE EXTERNAL TABLE silver_external.sellers
WITH LOCATION = @silver_stage/sellers/
FILE_FORMAT = (TYPE = PARQUET)
AUTO_REFRESH = FALSE;

-- products
CREATE OR REPLACE EXTERNAL TABLE silver_external.products
WITH LOCATION = @silver_stage/products/
FILE_FORMAT = (TYPE = PARQUET)
AUTO_REFRESH = FALSE;

-- ✅ SECTION 4 COMPLETE
-- Next: Run SECTION 5 (verification)

-- =====================================================
-- SECTION 5: VERIFICATION QUERIES
-- =====================================================

-- Check external tables created
SHOW EXTERNAL TABLES IN SCHEMA silver_external;

-- Verify row counts (should match Databricks export)
SELECT 'orders' AS table_name, COUNT(*) AS row_count FROM silver_external.orders
UNION ALL
SELECT 'order_items', COUNT(*) FROM silver_external.order_items
UNION ALL
SELECT 'payments', COUNT(*) FROM silver_external.payments
UNION ALL
SELECT 'customers', COUNT(*) FROM silver_external.customers
UNION ALL
SELECT 'sellers', COUNT(*) FROM silver_external.sellers
UNION ALL
SELECT 'products', COUNT(*) FROM silver_external.products;

-- Sample data check
SELECT * FROM silver_external.orders LIMIT 5;

-- ✅ SECTION 5 COMPLETE (if row counts > 0)
-- Next: Run SECTION 6 (grants)

-- =====================================================
-- SECTION 6: GRANTS (for dbt user)
-- =====================================================

USE ROLE SECURITYADMIN;

-- Grant schema usage
GRANT USAGE ON DATABASE olist_ecommerce TO ROLE SYSADMIN;
GRANT USAGE ON SCHEMA olist_ecommerce.silver_external TO ROLE SYSADMIN;
GRANT USAGE ON SCHEMA olist_ecommerce.staging TO ROLE SYSADMIN;
GRANT USAGE ON SCHEMA olist_ecommerce.intermediate TO ROLE SYSADMIN;
GRANT USAGE ON SCHEMA olist_ecommerce.marts TO ROLE SYSADMIN;

-- Grant select on external tables
GRANT SELECT ON ALL EXTERNAL TABLES IN SCHEMA olist_ecommerce.silver_external TO ROLE SYSADMIN;

-- Grant create privileges for dbt
GRANT CREATE TABLE ON SCHEMA olist_ecommerce.staging TO ROLE SYSADMIN;
GRANT CREATE VIEW ON SCHEMA olist_ecommerce.staging TO ROLE SYSADMIN;
GRANT CREATE TABLE ON SCHEMA olist_ecommerce.intermediate TO ROLE SYSADMIN;
GRANT CREATE VIEW ON SCHEMA olist_ecommerce.intermediate TO ROLE SYSADMIN;
GRANT CREATE TABLE ON SCHEMA olist_ecommerce.marts TO ROLE SYSADMIN;
GRANT CREATE VIEW ON SCHEMA olist_ecommerce.marts TO ROLE SYSADMIN;

-- Grant warehouse usage
GRANT USAGE ON WAREHOUSE COMPUTE_WH TO ROLE SYSADMIN;

-- ✅ SECTION 6 COMPLETE
-- ✅ ALL SECTIONS COMPLETE - Ready for dbt!

-- =====================================================
-- SUMMARY
-- =====================================================

-- Setup complete. Verify:
SELECT 'Database' AS object_type, COUNT(*) AS count FROM (SHOW DATABASES LIKE 'olist_ecommerce')
UNION ALL
SELECT 'Schemas', COUNT(*) FROM (SHOW SCHEMAS IN DATABASE olist_ecommerce)
UNION ALL
SELECT 'External Tables', COUNT(*) FROM (SHOW EXTERNAL TABLES IN SCHEMA silver_external);

-- Expected:
-- Database: 1
-- Schemas: 4 (staging, intermediate, marts, silver_external)
-- External Tables: 6

-- Next step: Run dbt from Codespace
-- Command: ./scripts/run_dbt.sh
