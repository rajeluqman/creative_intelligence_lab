#!/bin/bash
# run_dbt.sh — Execute dbt Gold Layer
# Phase 4b — Owner: AE + DPE

set -e

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo "=========================================="
echo "dbt Gold Layer Execution — Phase 4b"
echo "=========================================="
echo ""

# 1. Check environment
if [ ! -f ".env.staging" ]; then
    echo -e "${RED}❌ .env.staging not found${NC}"
    exit 1
fi

# Load environment variables
export $(grep -v '^#' .env.staging | xargs)

echo -e "${GREEN}✅ Environment: ${ENV}${NC}"
echo "   Snowflake Account: ${SNOWFLAKE_ACCOUNT}"
echo "   Database: ${SNOWFLAKE_DATABASE}"
echo "   Schema: ${SNOWFLAKE_SCHEMA_STAGING}"
echo ""

# 2. Check dbt installed
if ! command -v dbt &> /dev/null; then
    echo -e "${RED}❌ dbt not found. Installing dbt-snowflake...${NC}"
    pip install dbt-snowflake==1.7.0 -q
    echo -e "${GREEN}✅ dbt-snowflake installed${NC}"
fi

echo -e "${YELLOW}dbt version:${NC}"
dbt --version
echo ""

# 3. Navigate to dbt project
cd gold/dbt_models

# 4. Test connection
echo "=========================================="
echo "Testing Snowflake Connection"
echo "=========================================="
dbt debug --profiles-dir .

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Connection test failed. Check credentials in .env.staging${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Snowflake connection successful${NC}"
echo ""

# 5. Install dbt dependencies (if packages.yml exists)
if [ -f "packages.yml" ]; then
    echo "Installing dbt packages..."
    dbt deps --profiles-dir .
fi

# 6. Run dbt (staging target)
echo "=========================================="
echo "Running dbt Models"
echo "=========================================="
dbt run --target staging --profiles-dir .

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ dbt run failed${NC}"
    exit 1
fi

echo -e "${GREEN}✅ dbt models executed${NC}"
echo ""

# 7. Run tests
echo "=========================================="
echo "Running dbt Tests"
echo "=========================================="
dbt test --target staging --profiles-dir .

if [ $? -ne 0 ]; then
    echo -e "${YELLOW}⚠️  Some tests failed. Check output above.${NC}"
else
    echo -e "${GREEN}✅ All tests passed${NC}"
fi

echo ""

# 8. Generate documentation (optional)
echo "=========================================="
echo "Generating dbt Docs"
echo "=========================================="
dbt docs generate --target staging --profiles-dir .

echo -e "${GREEN}✅ Documentation generated${NC}"
echo "   Run: dbt docs serve --profiles-dir . --port 8001"
echo ""

# 9. Summary
echo "=========================================="
echo "Summary"
echo "=========================================="
dbt run-operation log_run_results --target staging --profiles-dir . || true

echo ""
echo -e "${GREEN}✅ Phase 4b Gold Layer — dbt execution complete${NC}"
echo ""
echo "Next steps:"
echo "1. Verify tables in Snowflake: olist_ecommerce.marts.*"
echo "2. Run Great Expectations validation"
echo "3. Document costs in COST_LOG.md"
echo "4. Phase 4b sign-off"
