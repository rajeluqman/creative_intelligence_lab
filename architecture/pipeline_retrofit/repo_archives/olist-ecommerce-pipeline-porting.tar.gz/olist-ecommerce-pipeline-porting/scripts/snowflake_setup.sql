-- snowflake_setup.sql
-- Snowflake setup untuk Gold Layer — Phase 4b
-- Run via Snowflake UI atau snowsql CLI
-- Owner: DPE

-- =====================================================
-- 1. DATABASE & WAREHOUSE SETUP
-- =====================================================

USE ROLE SYSADMIN;

-- Create database (if not exists)
CREATE DATABASE IF NOT EXISTS olist_ecommerce
    COMMENT = 'Olist E-Commerce Pipeline — Gold Layer (dbt)';

-- Create schemas
CREATE SCHEMA IF NOT EXISTS olist_ecommerce.staging
    COMMENT = 'Staging layer — views dari Silver sources';

CREATE SCHEMA IF NOT EXISTS olist_ecommerce.intermediate
    COMMENT = 'Intermediate transformations (SCD views)';

CREATE SCHEMA IF NOT EXISTS olist_ecommerce.marts
    COMMENT = 'Gold marts — Star Schema (Kimball)';

CREATE SCHEMA IF NOT EXISTS olist_ecommerce.silver_external
    COMMENT = 'External tables reading Silver Parquet from ADLS Gen2';

-- Verify warehouse exists
SHOW WAREHOUSES LIKE 'COMPUTE_WH';

-- =====================================================
-- 2. STORAGE INTEGRATION (Azure ADLS Gen2)
-- =====================================================

-- Note: STORAGE INTEGRATION requires ACCOUNTADMIN role
-- If credential error, ask user to run this in Snowflake UI as ACCOUNTADMIN

USE ROLE ACCOUNTADMIN;

CREATE OR REPLACE STORAGE INTEGRATION azure_olist_integration
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = 'AZURE'
  ENABLED = TRUE
  AZURE_TENANT_ID = '<AZURE_TENANT_ID>'  -- User must replace
  STORAGE_ALLOWED_LOCATIONS = (
    'azure://azolistpiepeline.blob.core.windows.net/olist-staging/silver/'
  );

-- Grant usage to SYSADMIN
GRANT USAGE ON INTEGRATION azure_olist_integration TO ROLE SYSADMIN;

-- Get Azure consent URL (user must visit this)
DESC INTEGRATION azure_olist_integration;
-- AZURE_CONSENT_URL → user clicks → grant Storage Blob Data Reader role in Azure

-- =====================================================
-- 3. EXTERNAL STAGE (pointing to Silver Parquet)
-- =====================================================

USE ROLE SYSADMIN;
USE DATABASE olist_ecommerce;
USE SCHEMA silver_external;

CREATE OR REPLACE STAGE silver_stage
  STORAGE_INTEGRATION = azure_olist_integration
  URL = 'azure://azolistpiepeline.blob.core.windows.net/olist-staging/silver/'
  FILE_FORMAT = (TYPE = PARQUET);

-- Test stage access
LIST @silver_stage;

-- Expected output:
-- silver/orders/*.parquet
-- silver/order_items/*.parquet
-- silver/payments/*.parquet
-- silver/customers/*.parquet
-- silver/sellers/*.parquet
-- silver/products/*.parquet

-- =====================================================
-- 4. EXTERNAL TABLES (Silver sources for dbt)
-- =====================================================

-- orders
CREATE OR REPLACE EXTERNAL TABLE silver_external.orders
WITH LOCATION = @silver_stage/orders/
FILE_FORMAT = (TYPE = PARQUET)
AUTO_REFRESH = FALSE;

-- order_items
CREATE OR REPLACE EXTERNAL TABLE silver_external.order_items
WITH LOCATION = @silver_stage/order_items/
FILE_FORMAT = (TYPE = PARQUET)
AUTO_REFRESH = FALSE;

-- payments
CREATE OR REPLACE EXTERNAL TABLE silver_external.payments
WITH LOCATION = @silver_stage/payments/
FILE_FORMAT = (TYPE = PARQUET)
AUTO_REFRESH = FALSE;

-- customers
CREATE OR REPLACE EXTERNAL TABLE silver_external.customers
WITH LOCATION = @silver_stage/customers/
FILE_FORMAT = (TYPE = PARQUET)
AUTO_REFRESH = FALSE;

-- sellers
CREATE OR REPLACE EXTERNAL TABLE silver_external.sellers
WITH LOCATION = @silver_stage/sellers/
FILE_FORMAT = (TYPE = PARQUET)
AUTO_REFRESH = FALSE;

-- products
CREATE OR REPLACE EXTERNAL TABLE silver_external.products
WITH LOCATION = @silver_stage/products/
FILE_FORMAT = (TYPE = PARQUET)
AUTO_REFRESH = FALSE;

-- =====================================================
-- 5. VERIFICATION QUERIES
-- =====================================================

-- Check external tables created
SHOW EXTERNAL TABLES IN SCHEMA silver_external;

-- Verify row counts (sample)
SELECT COUNT(*) AS cnt FROM silver_external.orders;
SELECT COUNT(*) AS cnt FROM silver_external.order_items;
SELECT COUNT(*) AS cnt FROM silver_external.payments;
SELECT COUNT(*) AS cnt FROM silver_external.customers;
SELECT COUNT(*) AS cnt FROM silver_external.sellers;
SELECT COUNT(*) AS cnt FROM silver_external.products;

-- Sample query to verify data
SELECT * FROM silver_external.orders LIMIT 5;

-- =====================================================
-- 6. GRANTS (for dbt user)
-- =====================================================

USE ROLE SECURITYADMIN;

-- Grant schema usage
GRANT USAGE ON DATABASE olist_ecommerce TO ROLE SYSADMIN;
GRANT USAGE ON SCHEMA olist_ecommerce.silver_external TO ROLE SYSADMIN;
GRANT USAGE ON SCHEMA olist_ecommerce.staging TO ROLE SYSADMIN;
GRANT USAGE ON SCHEMA olist_ecommerce.intermediate TO ROLE SYSADMIN;
GRANT USAGE ON SCHEMA olist_ecommerce.marts TO ROLE SYSADMIN;

-- Grant select on external tables
GRANT SELECT ON ALL EXTERNAL TABLES IN SCHEMA olist_ecommerce.silver_external TO ROLE SYSADMIN;

-- Grant create privileges for dbt
GRANT CREATE TABLE ON SCHEMA olist_ecommerce.staging TO ROLE SYSADMIN;
GRANT CREATE VIEW ON SCHEMA olist_ecommerce.staging TO ROLE SYSADMIN;
GRANT CREATE TABLE ON SCHEMA olist_ecommerce.intermediate TO ROLE SYSADMIN;
GRANT CREATE VIEW ON SCHEMA olist_ecommerce.intermediate TO ROLE SYSADMIN;
GRANT CREATE TABLE ON SCHEMA olist_ecommerce.marts TO ROLE SYSADMIN;
GRANT CREATE VIEW ON SCHEMA olist_ecommerce.marts TO ROLE SYSADMIN;

-- Grant warehouse usage
GRANT USAGE ON WAREHOUSE COMPUTE_WH TO ROLE SYSADMIN;

-- =====================================================
-- NOTES
-- =====================================================

-- Prerequisites sebelum run script ni:
-- 1. Silver Parquet files MESTI exist di ADLS Gen2: azure://azolistpiepeline.blob.core.windows.net/olist-staging/silver/
-- 2. Parquet files format: silver/<table_name>/*.parquet (partition by table)
-- 3. Azure Tenant ID → get from Azure Portal → Azure AD
-- 4. Azure consent → DESC INTEGRATION azure_olist_integration → visit AZURE_CONSENT_URL
-- 5. Grant "Storage Blob Data Reader" role to Snowflake service principal in Azure

-- Expected exports dari Databricks:
-- - orders → silver/orders/part-00000.parquet, part-00001.parquet, ...
-- - order_items → silver/order_items/*.parquet
-- - payments → silver/payments/*.parquet
-- - customers → silver/customers/*.parquet
-- - sellers → silver/sellers/*.parquet
-- - products → silver/products/*.parquet

-- Troubleshooting:
-- - LIST @silver_stage fail → check Storage Integration + Azure permissions
-- - External table empty → check Parquet path + FILE_FORMAT
-- - Permission denied → check GRANTS section above
