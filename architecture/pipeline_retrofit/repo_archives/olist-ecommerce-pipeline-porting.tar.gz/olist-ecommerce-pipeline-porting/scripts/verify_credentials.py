#!/usr/bin/env python3
"""
Credential Verification Script — DPE owned
Verify connectivity untuk Azure, Databricks, Snowflake, Kaggle
Run sebelum Phase 3 architecture work
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Colors untuk output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
RESET = '\033[0m'

def print_status(service, status, message=""):
    """Print verification status dengan color coding"""
    icon = f"{GREEN}✅{RESET}" if status else f"{RED}❌{RESET}"
    print(f"{icon} {service:20} {message}")

def verify_azure():
    """Verify Azure ADLS Gen2 connectivity"""
    try:
        from azure.storage.filedatalake import DataLakeServiceClient

        account = os.getenv('AZURE_STORAGE_ACCOUNT')
        key = os.getenv('AZURE_STORAGE_KEY')
        container = os.getenv('ADLS_CONTAINER_DEV')

        if not all([account, key, container]):
            print_status("Azure ADLS Gen2", False, "Missing credentials in .env.dev")
            return False

        # Test connection
        service_client = DataLakeServiceClient(
            account_url=f"https://{account}.dfs.core.windows.net",
            credential=key
        )

        # Try to get container client (will fail if credentials wrong)
        file_system_client = service_client.get_file_system_client(container)

        # Test if container exists or accessible
        try:
            file_system_client.get_file_system_properties()
            print_status("Azure ADLS Gen2", True, f"Connected to {account}/{container}")
            return True
        except Exception as e:
            if "not found" in str(e).lower():
                print_status("Azure ADLS Gen2", True, f"Connected to {account} (container {container} not found — will create)")
                return True
            raise

    except ImportError:
        print_status("Azure ADLS Gen2", False, "azure-storage-file-datalake not installed")
        return False
    except Exception as e:
        print_status("Azure ADLS Gen2", False, f"Connection failed: {str(e)[:50]}")
        return False

def verify_databricks():
    """Verify Databricks connectivity"""
    try:
        from databricks import sql

        host = os.getenv('DATABRICKS_HOST')
        token = os.getenv('DATABRICKS_TOKEN')
        http_path = os.getenv('DATABRICKS_HTTP_PATH')

        if not all([host, token, http_path]):
            print_status("Databricks", False, "Missing credentials in .env.dev")
            return False

        # Remove https:// if present
        host = host.replace('https://', '').replace('http://', '')

        # Test connection
        connection = sql.connect(
            server_hostname=host,
            http_path=http_path,
            access_token=token
        )

        cursor = connection.cursor()
        cursor.execute("SELECT 1 as test")
        result = cursor.fetchone()
        cursor.close()
        connection.close()

        if result[0] == 1:
            print_status("Databricks", True, f"Connected to {host}")
            return True
        else:
            print_status("Databricks", False, "Unexpected query result")
            return False

    except ImportError:
        print_status("Databricks", False, "databricks-sql-connector not installed")
        return False
    except Exception as e:
        print_status("Databricks", False, f"Connection failed: {str(e)[:50]}")
        return False

def verify_snowflake():
    """Verify Snowflake connectivity"""
    try:
        import snowflake.connector

        account = os.getenv('SNOWFLAKE_ACCOUNT')
        user = os.getenv('SNOWFLAKE_USER')
        password = os.getenv('SNOWFLAKE_PASSWORD')
        warehouse = os.getenv('SNOWFLAKE_WAREHOUSE')

        if not all([account, user, password, warehouse]):
            print_status("Snowflake", False, "Missing credentials in .env.dev")
            return False

        # Test connection
        conn = snowflake.connector.connect(
            account=account,
            user=user,
            password=password,
            warehouse=warehouse
        )

        cursor = conn.cursor()
        cursor.execute("SELECT CURRENT_VERSION()")
        version = cursor.fetchone()[0]
        cursor.close()
        conn.close()

        print_status("Snowflake", True, f"Connected to {account} (version {version})")
        return True

    except ImportError:
        print_status("Snowflake", False, "snowflake-connector-python not installed")
        return False
    except Exception as e:
        print_status("Snowflake", False, f"Connection failed: {str(e)[:50]}")
        return False

def verify_kaggle():
    """Verify Kaggle API credentials"""
    try:
        import kaggle

        username = os.getenv('KAGGLE_USERNAME')
        key = os.getenv('KAGGLE_KEY')

        if not all([username, key]):
            print_status("Kaggle API", False, "Missing credentials in .env.dev")
            return False

        # Set kaggle credentials
        os.environ['KAGGLE_USERNAME'] = username
        os.environ['KAGGLE_KEY'] = key

        # Test by listing datasets (will fail if auth wrong)
        from kaggle.api.kaggle_api_extended import KaggleApi
        api = KaggleApi()
        api.authenticate()

        # Try to get dataset metadata
        dataset = os.getenv('KAGGLE_DATASET', 'olistbr/brazilian-ecommerce')
        try:
            api.dataset_list_files(dataset)
            print_status("Kaggle API", True, f"Authenticated as {username}")
            return True
        except Exception as e:
            if "404" in str(e):
                print_status("Kaggle API", True, f"Authenticated (dataset {dataset} check failed)")
                return True
            raise

    except ImportError:
        print_status("Kaggle API", False, "kaggle package not installed")
        return False
    except Exception as e:
        print_status("Kaggle API", False, f"Authentication failed: {str(e)[:50]}")
        return False

def verify_missing_vars():
    """Check missing environment variables"""
    missing = []

    if not os.getenv('AIRFLOW__CORE__FERNET_KEY'):
        missing.append('AIRFLOW__CORE__FERNET_KEY')
    if not os.getenv('AIRFLOW__WEBSERVER__SECRET_KEY'):
        missing.append('AIRFLOW__WEBSERVER__SECRET_KEY')
    if not os.getenv('SLACK_WEBHOOK_URL'):
        missing.append('SLACK_WEBHOOK_URL')
    if not os.getenv('DATASET_SOURCE_PATH'):
        missing.append('DATASET_SOURCE_PATH (auto-set after download)')

    if missing:
        print(f"\n{YELLOW}⚠️  Missing (optional for Phase 3):{RESET}")
        for var in missing:
            print(f"   - {var}")

    return missing

def main():
    """Run all credential verifications"""
    # Load .env.dev
    env_path = Path(__file__).parent.parent / '.env.dev'
    if not env_path.exists():
        print(f"{RED}❌ .env.dev not found at {env_path}{RESET}")
        sys.exit(1)

    load_dotenv(env_path)
    print(f"Loaded credentials from {env_path}\n")
    print("=" * 60)
    print("DPE — Credential Verification")
    print("=" * 60)

    results = {}
    results['azure'] = verify_azure()
    results['databricks'] = verify_databricks()
    results['snowflake'] = verify_snowflake()
    results['kaggle'] = verify_kaggle()

    # Check missing vars
    missing = verify_missing_vars()

    # Summary
    print("\n" + "=" * 60)
    passed = sum(1 for v in results.values() if v)
    total = len(results)

    if passed == total:
        print(f"{GREEN}✅ All critical credentials verified ({passed}/{total}){RESET}")
        print(f"{GREEN}✅ Ready for Phase 3 — Architecture work{RESET}")
        sys.exit(0)
    else:
        print(f"{RED}❌ Verification failed ({passed}/{total} passed){RESET}")
        print(f"{RED}❌ Fix credentials before Phase 3{RESET}")
        sys.exit(1)

if __name__ == '__main__':
    main()
