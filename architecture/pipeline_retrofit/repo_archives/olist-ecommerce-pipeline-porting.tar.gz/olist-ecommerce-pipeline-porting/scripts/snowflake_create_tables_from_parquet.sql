-- snowflake_create_tables_from_parquet.sql
-- Replace external tables with regular tables loaded from Parquet
-- Reason: External tables return JSON VALUE, difficult for dbt to query
-- Solution: Load Parquet into regular Snowflake tables

USE ROLE SYSADMIN;
USE DATABASE olist_ecommerce;
USE SCHEMA silver_external;

-- =====================================================
-- 1. DROP EXTERNAL TABLES
-- =====================================================

DROP EXTERNAL TABLE IF EXISTS orders;
DROP EXTERNAL TABLE IF EXISTS order_items;
DROP EXTERNAL TABLE IF EXISTS payments;
DROP EXTERNAL TABLE IF EXISTS customers;
DROP EXTERNAL TABLE IF EXISTS sellers;
DROP EXTERNAL TABLE IF EXISTS products;

-- =====================================================
-- 2. CREATE REGULAR TABLES FROM PARQUET
-- =====================================================

-- orders table
CREATE OR REPLACE TABLE orders AS
SELECT
  VALUE:order_id::STRING AS order_id,
  VALUE:customer_id::STRING AS customer_id,
  VALUE:order_status::STRING AS order_status,
  VALUE:order_purchase_timestamp::TIMESTAMP AS order_purchase_timestamp,
  VALUE:order_approved_at::TIMESTAMP AS order_approved_at,
  VALUE:order_delivered_carrier_date::TIMESTAMP AS order_delivered_carrier_date,
  VALUE:order_delivered_customer_date::TIMESTAMP AS order_delivered_customer_date,
  VALUE:order_estimated_delivery_date::TIMESTAMP AS order_estimated_delivery_date,
  VALUE:is_delivered::BOOLEAN AS is_delivered,
  VALUE:is_on_time::BOOLEAN AS is_on_time,
  VALUE:review_score::FLOAT AS review_score,
  VALUE:dq_approved_flag::BOOLEAN AS dq_approved_flag,
  VALUE:is_current::BOOLEAN AS is_current,
  VALUE:valid_from::TIMESTAMP AS valid_from,
  VALUE:source_batch_id::STRING AS source_batch_id
FROM @silver_stage/orders/ (FILE_FORMAT => (TYPE=PARQUET));

-- order_items table
CREATE OR REPLACE TABLE order_items AS
SELECT
  VALUE:order_id::STRING AS order_id,
  VALUE:order_item_id::INT AS order_item_id,
  VALUE:product_id::STRING AS product_id,
  VALUE:seller_id::STRING AS seller_id,
  VALUE:shipping_limit_date::TIMESTAMP AS shipping_limit_date,
  VALUE:price::FLOAT AS price,
  VALUE:freight_value::FLOAT AS freight_value,
  VALUE:gmv::FLOAT AS gmv,
  VALUE:dq_zero_price_flag::BOOLEAN AS dq_zero_price_flag,
  VALUE:valid_from::TIMESTAMP AS valid_from,
  VALUE:source_batch_id::STRING AS source_batch_id
FROM @silver_stage/order_items/ (FILE_FORMAT => (TYPE=PARQUET));

-- payments table
CREATE OR REPLACE TABLE payments AS
SELECT
  VALUE:order_id::STRING AS order_id,
  VALUE:payment_sequential::INT AS payment_sequential,
  VALUE:payment_type::STRING AS payment_type,
  VALUE:payment_installments::INT AS payment_installments,
  VALUE:payment_value::FLOAT AS payment_value,
  VALUE:valid_from::TIMESTAMP AS valid_from,
  VALUE:source_batch_id::STRING AS source_batch_id
FROM @silver_stage/payments/ (FILE_FORMAT => (TYPE=PARQUET));

-- customers table
CREATE OR REPLACE TABLE customers AS
SELECT
  VALUE:customer_key::INT AS customer_key,
  VALUE:customer_unique_id::STRING AS customer_unique_id,
  VALUE:customer_id::STRING AS customer_id,
  VALUE:customer_zip_code_prefix::STRING AS customer_zip_code_prefix,
  VALUE:customer_city::STRING AS customer_city,
  VALUE:customer_state::STRING AS customer_state,
  VALUE:is_current::BOOLEAN AS is_current,
  VALUE:valid_from::TIMESTAMP AS valid_from,
  VALUE:source_batch_id::STRING AS source_batch_id
FROM @silver_stage/customers/ (FILE_FORMAT => (TYPE=PARQUET));

-- sellers table
CREATE OR REPLACE TABLE sellers AS
SELECT
  VALUE:seller_key::INT AS seller_key,
  VALUE:seller_id::STRING AS seller_id,
  VALUE:seller_zip_code_prefix::STRING AS seller_zip_code_prefix,
  VALUE:seller_city::STRING AS seller_city,
  VALUE:seller_state::STRING AS seller_state,
  VALUE:is_current::BOOLEAN AS is_current,
  VALUE:valid_from::TIMESTAMP AS valid_from,
  VALUE:source_batch_id::STRING AS source_batch_id
FROM @silver_stage/sellers/ (FILE_FORMAT => (TYPE=PARQUET));

-- products table
CREATE OR REPLACE TABLE products AS
SELECT
  VALUE:product_key::INT AS product_key,
  VALUE:product_id::STRING AS product_id,
  VALUE:product_category_name::STRING AS product_category_name,
  VALUE:product_category_name_english::STRING AS product_category_name_english,
  VALUE:product_name_length::INT AS product_name_length,
  VALUE:product_description_length::INT AS product_description_length,
  VALUE:product_photos_qty::INT AS product_photos_qty,
  VALUE:product_weight_g::INT AS product_weight_g,
  VALUE:product_length_cm::INT AS product_length_cm,
  VALUE:product_height_cm::INT AS product_height_cm,
  VALUE:product_width_cm::INT AS product_width_cm,
  VALUE:valid_from::TIMESTAMP AS valid_from,
  VALUE:source_batch_id::STRING AS source_batch_id
FROM @silver_stage/products/ (FILE_FORMAT => (TYPE=PARQUET));

-- =====================================================
-- 3. VERIFY TABLES CREATED
-- =====================================================

-- Show tables (should be 6 regular tables now)
SHOW TABLES IN SCHEMA silver_external;

-- Check row counts
SELECT 'orders' AS table_name, COUNT(*) AS row_count FROM orders
UNION ALL
SELECT 'order_items', COUNT(*) FROM order_items
UNION ALL
SELECT 'payments', COUNT(*) FROM payments
UNION ALL
SELECT 'customers', COUNT(*) FROM customers
UNION ALL
SELECT 'sellers', COUNT(*) FROM sellers
UNION ALL
SELECT 'products', COUNT(*) FROM products;

-- Test column access (should work without quotes now)
SELECT order_id, customer_id, order_status FROM orders LIMIT 3;
SELECT customer_key, customer_id, customer_city FROM customers LIMIT 3;

-- ✅ Tables created successfully
-- Now dbt can query these regular tables without VALUE:column syntax
