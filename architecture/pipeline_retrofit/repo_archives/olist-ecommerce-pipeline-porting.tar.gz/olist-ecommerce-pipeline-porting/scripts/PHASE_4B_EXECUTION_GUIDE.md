# Phase 4b Execution Guide — Gold Layer (Snowflake + dbt)

## Status: Bronze/Silver ✅ Complete | Gold ⏳ Remaining

---

## Overview

**Completed:**
- ✅ Azure Databricks setup (Serverless + Unity Catalog)
- ✅ Bronze: 9 Delta tables ingested (126MB, 100k+ rows)
- ✅ Silver: 7 tables transformed (3 facts + 4 dimensions, SCD Type 2)

**Remaining:**
- ⏳ Export Silver Delta → Parquet (for Snowflake)
- ⏳ Snowflake external stage + external tables
- ⏳ dbt Gold marts (Kimball Star Schema)
- ⏳ Validation + testing
- ⏳ Documentation + sign-off

---

## Execution Steps

### Step 1: Export Silver Delta → Parquet (Databricks)

**Purpose:** Convert Silver Delta tables to Parquet format so Snowflake can read via external tables.

**Actions:**
1. Open Databricks workspace: https://adb-7405607208964681.1.azuredatabricks.net/
2. Import notebook: `databricks_notebooks/03_export_silver_to_parquet.py`
3. Attach to Serverless SQL Warehouse (or existing cluster)
4. Run all cells

**Expected output:**
```
✅ Success: 6/6 tables
📊 Total rows exported: ~250,000
Parquet files: azure://azolistpiepeline.blob.core.windows.net/olist-staging/silver_parquet/
```

**Verification:**
- ADLS Gen2 container `olist-staging` has folder `silver_parquet/`
- Subfolders: `orders/`, `order_items/`, `payments/`, `customers/`, `sellers/`, `products/`
- Each subfolder contains `*.parquet` files

---

### Step 2: Snowflake Setup (External Stage + Tables)

**Purpose:** Configure Snowflake to read Parquet files from ADLS Gen2.

**Actions:**
1. Login to Snowflake: https://app.snowflake.com/ (account: ke65194.ap-southeast-5.aws)
2. Open SQL worksheet
3. Copy-paste **ALL SQL** from `scripts/snowflake_setup.sql`
4. **IMPORTANT:** Replace `<AZURE_TENANT_ID>` in STORAGE INTEGRATION section
   - Get tenant ID: Azure Portal → Azure Active Directory → Overview → Tenant ID
5. Run SQL step-by-step (sections 1-6)

**Critical section — Storage Integration:**
```sql
CREATE OR REPLACE STORAGE INTEGRATION azure_olist_integration
  ...
  AZURE_TENANT_ID = '<YOUR_TENANT_ID>'  -- REPLACE THIS
  ...
```

**After creating integration:**
```sql
DESC INTEGRATION azure_olist_integration;
```
- Copy `AZURE_CONSENT_URL` from output
- Open URL in browser → Grant "Storage Blob Data Reader" permission
- Wait 2-5 minutes for Azure propagation

**Verification:**
```sql
-- Should list Parquet files
LIST @silver_stage;

-- Should return row counts
SELECT COUNT(*) FROM silver_external.orders;
SELECT COUNT(*) FROM silver_external.order_items;
```

**Expected row counts:**
- orders: ~99,000
- order_items: ~112,000
- payments: ~103,000
- customers: ~99,000
- sellers: ~3,000
- products: ~32,000

---

### Step 3: dbt Connection Test

**Purpose:** Verify dbt can connect to Snowflake.

**Actions:**
```bash
# From project root
cd gold/dbt_models

# Load environment
source ../../.env.staging

# Test connection
dbt debug --profiles-dir .
```

**Expected output:**
```
✅ Connection test: OK
✅ Required dependencies: OK
✅ Connection:
   - account: ke65194.ap-southeast-5.aws
   - user: RAJEMANG
   - database: olist_ecommerce
   - schema: STAGING
   - warehouse: COMPUTE_WH
```

**If connection fails:**
- Check Snowflake credentials in `.env.staging`
- Verify `COMPUTE_WH` warehouse is running (resume in Snowflake UI)
- Check user permissions (SYSADMIN role)

---

### Step 4: dbt Run (Gold Marts)

**Purpose:** Execute dbt models to build Gold layer Star Schema.

**Option A — Using Script (Recommended):**
```bash
# From project root
./scripts/run_dbt.sh
```

**Option B — Manual:**
```bash
cd gold/dbt_models
source ../../.env.staging

# Run models
dbt run --target staging --profiles-dir .

# Run tests
dbt test --target staging --profiles-dir .

# Generate docs
dbt docs generate --target staging --profiles-dir .
dbt docs serve --profiles-dir . --port 8001
```

**Expected output:**
```
Completed successfully

Done. PASS=15 WARN=0 ERROR=0 SKIP=0 TOTAL=15

Models executed:
  ✅ staging.stg_orders
  ✅ staging.stg_order_items
  ✅ staging.stg_payments
  ✅ staging.stg_customers
  ✅ staging.stg_sellers
  ✅ staging.stg_products
  ✅ intermediate.int_customers_scd2
  ✅ intermediate.int_sellers_scd2
  ✅ marts.dim_customers
  ✅ marts.dim_sellers
  ✅ marts.dim_products
  ✅ marts.dim_date
  ✅ marts.fact_orders
  ✅ marts.fact_order_items
  ✅ marts.fact_payments

Tests passed: 28/28
```

**Verification in Snowflake:**
```sql
-- Check schemas created
SHOW SCHEMAS IN DATABASE olist_ecommerce;

-- Check marts tables
SHOW TABLES IN SCHEMA olist_ecommerce.marts;

-- Verify row counts
SELECT 'fact_orders' AS table_name, COUNT(*) AS rows FROM marts.fact_orders
UNION ALL
SELECT 'fact_order_items', COUNT(*) FROM marts.fact_order_items
UNION ALL
SELECT 'fact_payments', COUNT(*) FROM marts.fact_payments
UNION ALL
SELECT 'dim_customers', COUNT(*) FROM marts.dim_customers
UNION ALL
SELECT 'dim_sellers', COUNT(*) FROM marts.dim_sellers
UNION ALL
SELECT 'dim_products', COUNT(*) FROM marts.dim_products;
```

**Expected mart sizes:**
- fact_orders: ~99,000 rows
- fact_order_items: ~112,000 rows
- fact_payments: ~103,000 rows
- dim_customers: ~99,000 rows (SCD Type 2)
- dim_sellers: ~3,000 rows (SCD Type 2)
- dim_products: ~32,000 rows (SCD Type 1)
- dim_date: ~800 rows (2016-2018 date range)

---

### Step 5: Validation & Testing

**Great Expectations (if time permits):**
```bash
pytest tests/test_end_to_end.py -v
```

**Manual validation queries:**
```sql
-- Test fact-dimension joins
SELECT
  fo.order_id,
  dc.customer_unique_id,
  ds.seller_id,
  dp.product_category_name,
  fo.order_status
FROM marts.fact_orders fo
JOIN marts.dim_customers dc ON fo.customer_key = dc.customer_key
JOIN marts.fact_order_items foi ON fo.order_id = foi.order_id
JOIN marts.dim_sellers ds ON foi.seller_key = ds.seller_key
JOIN marts.dim_products dp ON foi.product_key = dp.product_key
LIMIT 10;

-- KPI validation: DSO (Days Sales Outstanding)
SELECT
  AVG(DATEDIFF(day, order_purchase_timestamp, order_delivered_customer_date)) AS avg_dso_days
FROM marts.fact_orders
WHERE is_delivered = TRUE;
```

---

### Step 6: Cost & Performance Benchmarks

**Capture metrics:**
1. **Databricks:**
   - Export notebook execution time
   - Cluster compute units used
2. **Snowflake:**
   - Warehouse credits consumed (COMPUTE_WH)
   - Query execution times (dbt run)
   - Storage used (marts)
3. **dbt:**
   - Total models: 15
   - Execution time: ~2-5 minutes (expected)

**Document in COST_LOG.md:**
- Azure Databricks Serverless: $X
- Snowflake credits: $Y (out of $400 free trial)
- ADLS Gen2 storage: <1GB (within free tier)

---

### Step 7: Sign-off

**Checklist:**
- [ ] Parquet export complete (6 tables)
- [ ] Snowflake external tables accessible
- [ ] dbt run successful (15 models, 0 errors)
- [ ] dbt test passed (28/28 tests)
- [ ] Mart row counts validated
- [ ] Sample KPI queries executed
- [ ] Cost documented in COST_LOG.md
- [ ] Screenshots captured (Databricks tables, Snowflake marts, dbt output)

**Update files:**
- `PROJECT_STATUS.md` → Phase 4b ✅ COMPLETE
- `sign-offs/SIGN_OFF_LOG.md` → Add Phase 4b entry
- `docs/DEBATE_LOG_phase_4b.md` → Close any open debates

**Git commit:**
```bash
git add .
git commit -m "[Phase 4b] Gold Layer complete — dbt + Snowflake Star Schema"
git push origin main
```

---

## Troubleshooting

### Issue: Snowflake external table empty
**Cause:** Storage integration not configured or Azure permissions missing
**Fix:**
1. Run `DESC INTEGRATION azure_olist_integration;`
2. Visit `AZURE_CONSENT_URL`
3. Grant "Storage Blob Data Reader" to Snowflake service principal
4. Wait 5 minutes, then `ALTER EXTERNAL TABLE silver_external.orders REFRESH;`

### Issue: dbt connection timeout
**Cause:** Warehouse suspended
**Fix:**
1. Login to Snowflake UI
2. Warehouses → COMPUTE_WH → Resume
3. Retry `dbt run`

### Issue: dbt model fails with "source not found"
**Cause:** External tables not created
**Fix:**
1. Run `SHOW EXTERNAL TABLES IN SCHEMA silver_external;` in Snowflake
2. If empty, re-run sections 3-4 in `snowflake_setup.sql`
3. Verify `LIST @silver_stage;` returns Parquet files

### Issue: Row count mismatch
**Cause:** Parquet export incomplete or filtered data
**Fix:**
1. Re-run Databricks export notebook
2. Check `is_current = TRUE` filters in staging models (SCD Type 2)
3. Verify Bronze/Silver row counts in Databricks

---

## Next Phase

After Phase 4b sign-off → Phase 5: DQD + OPS
- Great Expectations validation suites
- Airflow orchestration (local standalone)
- Monitoring + alerting (Slack webhook)
- Production runbook

---

**Owner:** DPE + AE
**Last updated:** 2026-05-14
