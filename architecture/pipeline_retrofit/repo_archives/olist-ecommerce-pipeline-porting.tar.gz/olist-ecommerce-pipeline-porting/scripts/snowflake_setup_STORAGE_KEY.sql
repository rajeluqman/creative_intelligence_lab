-- snowflake_setup_STORAGE_KEY.sql
-- Alternative: Using Azure Storage Account Key (simpler than service principal)
-- For portfolio/dev projects - production should use managed identity

USE ROLE ACCOUNTADMIN;

-- Create storage integration with SAS token (simpler)
-- Or skip integration and use credentials directly in stage

USE ROLE SYSADMIN;
USE DATABASE olist_ecommerce;
USE SCHEMA silver_external;

-- Option 1: Stage with Azure Storage Account Key
CREATE OR REPLACE STAGE silver_stage
  URL = 'azure://azolistpiepeline.blob.core.windows.net/olist-staging/silver_parquet/'
  CREDENTIALS = (
    AZURE_SAS_TOKEN = '<YOUR_SAS_TOKEN_HERE>'
  )
  FILE_FORMAT = (TYPE = PARQUET);

-- To get SAS token:
-- 1. Azure Portal → Storage Account azolistpiepeline
-- 2. Security + networking → Shared access signature
-- 3. Allowed services: Blob
-- 4. Allowed resource types: Container, Object
-- 5. Permissions: Read, List
-- 6. Start/Expiry: Set dates (e.g., 1 year)
-- 7. Generate SAS and connection string
-- 8. Copy "SAS token" (starts with ?sv=...)

-- Test
LIST @silver_stage;
