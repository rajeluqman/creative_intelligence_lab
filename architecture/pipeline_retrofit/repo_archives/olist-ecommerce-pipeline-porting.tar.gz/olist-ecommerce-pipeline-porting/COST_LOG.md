# Cost Log — Olist E-Commerce Pipeline

> Estimates only. Never commit real account-linked $ figures or billing exports.

## Azure (ADLS Gen2)
| Resource | Free-tier allowance | This repo's usage pattern | Risk |
|---|---|---|---|
| ADLS Gen2 storage | 5 GB (free tier, per `docs/ARCHITECTURE.md`) | Landing (9 raw CSVs, ~126MB) + Bronze Delta (9 tables) + Parquet bridge export | Moderate — full 100k-order dataset fits comfortably under 5GB at this dataset's scale; risk only grows if the dataset is swapped for a larger Olist release |

## Databricks
| Resource | Tier | Usage | Risk |
|---|---|---|---|
| Compute | Databricks SQL Warehouse (Serverless) + Unity Catalog | Bronze COPY INTO (9 tables) + Silver SQL/PySpark SCD2/SCD1 transforms | Serverless auto-suspend keeps idle cost near zero; SCD2 MERGE-expire pattern (customers/sellers) and full Silver-table rewrites for SCD1 (products) are the main compute drivers per run |

## Snowflake
| Resource | Tier | Usage | Risk |
|---|---|---|---|
| Compute | `COMPUTE_WH` (dev target, per `gold/dbt_models/profiles.yml`) | `dbt build` staging → intermediate → marts (3 facts + 4 dims) | Monitor warehouse auto-suspend; external stage reads of Parquet bridge data are the main I/O cost, not compute |

## Status
Pipeline is **finished** (Phases 0–5 ✅ per README.md "Phase Completion") — this log
documents the allowance ceilings the stack was sized against, not live billing data (no real
account-linked cost export exists in this repo and none should be committed here).
