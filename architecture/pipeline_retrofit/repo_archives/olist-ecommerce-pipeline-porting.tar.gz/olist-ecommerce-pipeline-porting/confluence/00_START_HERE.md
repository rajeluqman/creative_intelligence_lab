# Start Here — Olist E-Commerce Pipeline

> Pointer page for newcomers landing on Confluence. The repo (not Confluence) is the source of
> truth — these pages are a synced read-only mirror, published via
> `scripts/sync_docs_to_confluence.py`.

## What this is
A finished Order-to-Cash analytics portfolio pipeline: Kaggle CSVs → Azure ADLS Gen2 →
Databricks COPY INTO Bronze (Delta Lake/Unity Catalog) → Databricks SQL Silver (SCD2
customers/sellers, SCD1 products) → Parquet export → Snowflake external stage → dbt Core Gold
(Kimball star: 3 facts + 4 dims) → Power BI. Orchestrated by Apache Airflow; quality-gated by
Great Expectations.

## Why it exists & what it answers
**Purpose:** turn 100k+ Olist orders into a governed Order-to-Cash star schema for a (simulated)
**retail ops & finance** team (consumes Power BI, not raw CSVs). **Business questions:**
(1) Days Sales Outstanding for cash flow, (2) order fulfilment / on-time-delivery rate,
(3) seller GMV performance, (4) customer LTV / retention.

**What's proven vs not:** model + transform code exists and is wired up; **run-evidence (KPI
values, row counts, BI screenshots) not yet captured** — no metrics fabricated (see README
"Results & Evidence"). Resume "ADF" claim is **unsupported** (real: Databricks COPY INTO +
Kaggle CLI) — see INTERVIEW_GUIDE.md.

## Reading order
1. **README** — problem statement, data model, stack at a glance.
2. **AI Context (CLAUDE.md)** — governance framework, stop-gate, anti-shortcut protocol.
3. **ARCHITECTURE.md** — full layer-by-layer design.
4. **DATA_MODEL.md** — grain, SCD strategy, the star schema.
5. **BRD.md / DRD.md / DATA_DICTIONARY.md** — business + data requirements.
6. **PIPELINE_SPEC.md / DQD.md** — pipeline mechanics + quality gates.
7. **OPS_RUNBOOK.md** — how to run it.
8. **ADR-001/002/003** — the 3 binding architecture decisions (data modelling paradigm, SCD
   strategy, Slack alerting).
9. **INTERVIEW_GUIDE.md** — resume-claim ↔ repo-evidence reconciliation (includes the known
   Azure Data Factory resume mismatch).
10. **PROJECT_STATUS.md** — current build/retrofit status.

## What's deliberately NOT synced
The 9 `.claude/agents/` persona files, `tests/*_contract.py`, `scripts/gen_repo_map.py`,
`architecture/REPO_MAP.md`, and `learning/`/`simulation/` — these are AI-tooling and
dev-navigation artifacts, not onboarding documentation for a human stakeholder.
