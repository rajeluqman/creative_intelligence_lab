"""
Airflow-compatible wrapper for Silver layer data quality validation
Called by: airflow/dags/olist_pipeline_dag.py
"""
from data_quality.run_silver_validation import run as run_validation


def run():
    """
    Run Silver layer Great Expectations validation suite
    Returns: True if validation passes, raises exception if fails
    """
    success = run_validation()

    if not success:
        raise RuntimeError("Silver layer data quality validation failed")

    return success


if __name__ == "__main__":
    run()
