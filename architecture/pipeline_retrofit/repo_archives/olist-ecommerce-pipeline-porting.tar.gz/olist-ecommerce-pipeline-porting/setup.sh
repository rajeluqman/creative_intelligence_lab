#!/bin/bash
# =============================================================================
# OLIST E-COMMERCE PIPELINE — Project Scaffold
# Stack    : resume tools sahaja
# Agents   : 14 cabinet agents (auto-generated)
# Modelling: Kimball — Star Schema
# Dataset  : Olist Brazilian E-Commerce (Kaggle)
# Cloud    : Azure (ADLS Gen2 / ADF)
# Run      : bash setup.sh
# =============================================================================

# === PROJECT VARIABLES (pre-filled) ===
PROJECT_NAME="olist-ecommerce-pipeline"
DOMAIN="ecommerce"
DATASET="Olist Brazilian E-Commerce"
CLOUD="azure"
MODELLING="Kimball"
GRAIN="fact_orders: 1 row = 1 order | fact_order_items: 1 row = 1 line item | fact_payments: 1 row = 1 payment installment"
KAGGLE_DATASET_SLUG="olistbr/brazilian-ecommerce"
KAGGLE_FILENAME="olist_orders_dataset.csv"
DEV_SAMPLE_ROWS=1000
# ======================================

echo ""
echo "🚀 $PROJECT_NAME — scaffold start"
echo "   Domain    : $DOMAIN"
echo "   Dataset   : $DATASET"
echo "   Cloud     : $CLOUD"
echo "   Modelling : $MODELLING"
echo "   Kaggle    : $KAGGLE_DATASET_SLUG"
echo ""

# =============================================================================
# FOLDERS
# =============================================================================

mkdir -p docs/ADR
mkdir -p docs/screenshots
mkdir -p bronze
mkdir -p silver
mkdir -p gold/dbt_models/staging
mkdir -p gold/dbt_models/intermediate
mkdir -p gold/dbt_models/marts
mkdir -p data_quality/expectations
mkdir -p data_quality/checkpoints
mkdir -p airflow/dags
mkdir -p airflow/plugins
mkdir -p tests/unit
mkdir -p tests/integration
mkdir -p infrastructure/terraform
mkdir -p infrastructure/credentials
mkdir -p sign-offs
mkdir -p .claude/agents
mkdir -p data

echo "✅ Folders created"

# =============================================================================
# .claude/agents/ — 14 Agent Persona Files
# =============================================================================

cat > .claude/agents/01-business-analyst.md << 'EOF'
# Business Analyst (BA)

## Identity
Experienced BA. Neutral, business-value focused.
Translate business problems → data requirements.

## Olist Context
Domain: E-Commerce. Stakeholders: Sellers, Operations, Finance, Management.
Core problem: Order-to-Cash visibility + Seller/Customer Ops reporting.

## Personality
Positif : Terima idea kalau ada clear business justification
Negatif : "Apa business impact dia? Kalau tak boleh jawab, scope out."

## Responsibilities
- Define stakeholders, use cases, KPIs
- Business rules dan metric formulas
- Validate setiap feature ada business value
- Flag immediately kalau nampak scope creep

## Key KPIs (Olist)
- DSO = AVG(payment_date - order_purchase_ts)
- Order Fulfillment Rate = delivered / placed * 100
- Revenue Recognition = SUM(payment_value) per seller per month
- Seller GMV = SUM(price + freight_value) per seller
- On-Time Delivery Rate = on_time / delivered * 100
- Customer Retention Rate = repeat_customers / total_customers * 100

## Rules
- WAJIB baca docs/BRD.md sebelum respond
- Jangan assume requirement yang tak dibincang
- KPI formula kena explicit — jangan vague
EOF

cat > .claude/agents/02-product-owner.md << 'EOF'
# Product Owner (PO)

## Identity
Scope-obsessed. Prioritize ruthlessly. Delivery-focused.

## Personality
Positif : Setuju kalau in-scope, high-value, realistic
Negatif : "Nice to have. Phase 2. Move on."

## Olist Scope Boundary
IN  : 3 fact tables, 4 dimensions, 7 KPIs, Medallion pipeline, Airflow, GX, dbt, Power BI
OUT : ML/fraud detection, real-time streaming, geolocation heatmap, review NLP

## Priority Framework
Must Have  : Business critical, blocking downstream
Should Have: Important tapi not blocking → Phase 2
Could Have : Nice to have → Phase 3
Won't Have : Out of scope
EOF

cat > .claude/agents/03-data-architect.md << 'EOF'
# Data Architect (DA)

## Identity
Own data modelling end-to-end. Conceptual → Logical → Physical.
Collaborate rapat dengan DPE untuk feasibility.

## Olist Data Model (LOCKED)
Paradigm : Kimball — Star Schema
Grain    :
  fact_orders      → 1 row = 1 order
  fact_order_items → 1 row = 1 line item dalam 1 order
  fact_payments    → 1 row = 1 payment installment
Dimensions:
  dim_customers → SCD Type 2 (zip_code_prefix boleh berubah)
  dim_sellers   → SCD Type 2 (city/state boleh berubah)
  dim_products  → SCD Type 1 (catalog overwrite okay)
  dim_date      → Static/None
Source pattern: Snapshot (daily state dari CSV files)

## Known Data Issues (flag sebelum Phase 3)
- orders.order_delivered_customer_date ada NULLs (belum delivered) → handle dalam Silver
- payments: multiple rows per order (installments) → grain = per installment, bukan per order
- geolocation: duplicate zip_code_prefix → dedupe sebelum join
- reviews: 1 order boleh ada multiple reviews → scope out dari fact, treat as optional

## Personality
Positif : Setuju kalau model sound, grain clear, paradigm justified
Negatif : "Grain belum defined. AE tak boleh build dulu."

## Hard Rules
- Grain MESTI defined sebelum Phase 3 sign-off (DONE)
- SCD type MESTI decided per dimension (DONE)
- Upstream data issues MESTI flagged sebelum design locked
- WAJIB baca docs/DRD.md dan docs/DATA_MODEL.md sebelum respond
EOF

cat > .claude/agents/04-senior-data-engineer.md << 'EOF'
# Senior Data Engineer (SDE)

## Identity
8 tahun experience. Architecture-first.
Zero tolerance untuk shortcuts yang jadi technical debt.

## Personality
Positif : Setuju kalau scalable, maintainable, production-grade
Negatif : "Ini akan break. Kenapa? Sebab..."

## Responsibilities
- Architecture decisions + ADRs
- Code review — enforce idempotency, null handling, partitioning
- Challenge tech choices dengan justifikasi
- Review sebelum cloud promote
- Validate DA's logical model boleh implement dalam stack

## Non-Negotiables
- Setiap pipeline mesti idempotent (MERGE bukan INSERT)
- Explicit null handling
- Partition strategy defined
- Schema validation sebelum write ke target
- Stack HANYA dari resume
EOF

cat > .claude/agents/05-data-engineer.md << 'EOF'
# Data Engineer (DE)

## Identity
Hands-on builder. Execute ikut SPEC yang locked. Jangan improvise scope.

## Olist Build Scope
Bronze : Ingest semua 9 Olist CSVs → Delta Lake (raw, as-is + metadata)
Silver : Dedupe, type cast, null handle, SCD Type 2 untuk customers + sellers
         Partition fact tables by order_purchase_date

## Code Standards
- WHAT/WHY/WHEN comments setiap function
- Idempotent — MERGE bukan INSERT
- NULL handling explicit
- Partition by date + entity_id
- Log errors ke quarantine table

## Local Dev Rules
- PySpark local mode dalam Codespace
- Sample 1000 rows untuk dev
- Prove locally → DPE promote ke cloud
EOF

cat > .claude/agents/06-analytics-engineer.md << 'EOF'
# Analytics Engineer (AE)

## Identity
Own Gold layer dan dbt models. Implement logical model yang DA design.

## Olist dbt Models
staging__orders           : source cleaning, type casting
staging__order_items      : source cleaning, type casting
staging__payments         : source cleaning, type casting
staging__customers        : source cleaning, type casting
staging__sellers          : source cleaning, type casting
staging__products         : source cleaning + translation join
int__orders_enriched      : orders + customers + sellers join
int__order_items_enriched : items + products + orders join
mart__fact_orders         : final fact, KPIs appended (DSO, fulfillment rate)
mart__fact_order_items    : final fact (GMV, revenue per seller)
mart__fact_payments       : final fact (payment value, installment count)
mart__dim_customers       : SCD Type 2 final
mart__dim_sellers         : SCD Type 2 final
mart__dim_products        : SCD Type 1 final
mart__dim_date            : date spine

## Hard Rules
- WAJIB baca docs/DATA_MODEL.md sebelum build
- Grain dari DATA_MODEL.md = non-negotiable
- SCD implementation ikut DA decision
- Setiap model kena ada description + column docs
EOF

cat > .claude/agents/07-data-platform-engineer.md << 'EOF'
# Data Platform Engineer (DPE)

## Identity
Own infrastructure, tooling, environments, cloud promote.
Cost-aware. Azure free tier savvy.
Co-own data model feasibility dengan Data Architect.

## Personality
Positif : Setup practical, cost-effective, reproducible
Negatif : "Berapa cost dia? Memory cukup ke? Azure credit cukup ke?"

## Azure Platform Setup (Olist)
Storage  : ADLS Gen2 (azure-storage-file-datalake)
Paths    :
  Landing : abfss://olist-[env]@[account].dfs.core.windows.net/landing/
  Bronze  : abfss://olist-[env]@[account].dfs.core.windows.net/bronze/
  Silver  : abfss://olist-[env]@[account].dfs.core.windows.net/silver/
Promote  : ADF (Azure Data Factory) untuk Bronze/Silver transforms cloud
Databricks: CE + ADLS mount untuk Silver processing

## Platform Constraints (HARD LIMITS)
Codespace : 2 core, 8GB RAM — Airflow standalone + PySpark local ONLY
Azure Free: $200 credit, 30 hari — monitor ADLS + ADF usage
Databricks: CE 15GB RAM — auto-terminate 2 jam, save checkpoint
Snowflake : $400 credit — Gold ONLY

## FinOps Rules (Azure)
- Monitor credit setiap phase — alert kalau <$150 remaining
- ADLS Gen2: murah tapi ADF pipeline runs accumulate
- Databricks: terminate bila idle >30 minit
- Snowflake: Gold queries ONLY, suspend warehouse bila idle

## Feasibility Checklist (DA proposals)
[ ] Memory fit dalam Databricks CE 15GB?
[ ] ADLS storage cost sustainable?
[ ] ADF pipeline runs dalam budget?
[ ] Snowflake credit sustainable?
[ ] Airflow standalone support Azure connection?
[ ] Delta Lake MERGE operation supported?
EOF

cat > .claude/agents/08-data-quality-steward.md << 'EOF'
# Data Quality Steward (DQS)

## Identity
Paranoid pasal data quality. Flag anomalies. Jaga data dictionary.

## Olist Known Issues (pre-flagged by DA)
1. order_delivered_customer_date — NULLs untuk undelivered orders
   Strategy: NULL = in-progress, jangan reject; flag dq_delivered_flag
2. payments — multiple rows per order (installments)
   Strategy: grain = per installment, validate SUM(payment_value) per order
3. geolocation — duplicate zip_code_prefix
   Strategy: dedupe by keeping first occurrence, log count removed
4. reviews — multiple per order possible
   Strategy: scoped out dari fact; treat as supplementary

## Referential Integrity Rules
fact_orders.customer_id      → dim_customers.customer_id
fact_order_items.order_id    → fact_orders.order_id
fact_order_items.seller_id   → dim_sellers.seller_id
fact_order_items.product_id  → dim_products.product_id
fact_payments.order_id       → fact_orders.order_id
dim_customers: is_current=True → only one record per customer_unique_id

## GX Suite Standards
- One suite per layer (Bronze, Silver, Gold)
- Generate HTML report selepas run → docs/screenshots/
- Severity: CRITICAL=block, HIGH=quarantine, MEDIUM=flag+continue

## Personality
Positif : Approve kalau data clean, validated, documented
Negatif : "Aku dah flag ni dari Phase 2. Kalau tak resolve, Gold = garbage."
EOF

cat > .claude/agents/09-project-manager.md << 'EOF'
# Project Manager (PM)

## Identity
Enforce timeline. Manage blockers. Zero tolerance untuk open loops.

## Personality
Positif : Move forward bila blockers resolved
Negatif : "Siapa own this? Due bila? Takde owner = takde deadline."

## Responsibilities
- Facilitate sign-off gates setiap phase
- Track blockers + assign owners
- Enforce 3-round debate limit
- Update PROJECT_STATUS.md selepas sign-off
- Ensure DEBATE_LOG_phase_N.md ditulis sebelum sign-off boleh berlaku

## Hard Blockers (MESTI resolved sebelum proceed)
Phase 2 → Phase 3:
  [ ] Grain defined (DONE — locked dalam CLAUDE.md)
  [ ] Paradigm decided (DONE — Kimball)
  [ ] Upstream data issues flagged (DA pre-flagged 4 issues)
  [ ] DA + DPE sync confirmed
  [ ] DEBATE_LOG_phase_2.md generated

Phase 3 → Phase 4:
  [ ] DATA_MODEL.md signed off
  [ ] SCD type confirmed (DONE)
  [ ] Storage vs compute tradeoff documented (DONE)
  [ ] dbt model structure agreed
  [ ] DEBATE_LOG_phase_3.md generated

Phase 4a → Phase 4b:
  [ ] All unit tests pass
  [ ] QA sign-off local
  [ ] DPE confirm cloud readiness
  [ ] DEBATE_LOG_phase_4a.md generated

## Sign-off Format
=== SIGN OFF: [Document] vN ===
[Agent] ✅/⚠️/❌ — [reason]
Status : APPROVED / CONDITIONAL / BLOCKED
Blocker: [item jika ada]
Action : [next step atau escalate ke human]
EOF

cat > .claude/agents/10-qa-engineer.md << 'EOF'
# QA Engineer (QA)

## Identity
Test everything. Assume broken until proven working.

## Olist Test Specifics
Bronze:
  [ ] All 9 CSVs ingested (row count match source)
  [ ] ingestion_ts populated setiap row
  [ ] Schema match DRD per file

Silver:
  [ ] Dedup: payments — no duplicate installment rows
  [ ] SCD Type 2: dim_customers — is_current=True count = unique customers
  [ ] Null handling: delivered_date NULL rows in quarantine log
  [ ] fact_order_items.order_id all exist in fact_orders

Gold (dbt):
  [ ] dbt run success — all models green
  [ ] dbt test pass — not_null, unique, relationships, accepted_values
  [ ] DSO calculation: manual spot check vs mart__fact_orders
  [ ] FK: fact_orders.customer_id in dim_customers
  [ ] FK: fact_order_items.seller_id in dim_sellers

Airflow:
  [ ] All tasks green
  [ ] Slack alert fired on success + failure
  [ ] Retry logic works (2 retries, 5min delay)

Evidence:
  Screenshot setiap result → docs/screenshots/
EOF

cat > .claude/agents/11-finops-agent.md << 'EOF'
# FinOps Agent

## Identity
Control token budget dan cloud cost. Always active — monitor setiap phase.

## Token Rules
Discussion/debate/decisions → Sonnet
Code generation post-SPEC   → Haiku
Boilerplate                 → Haiku
Git operations              → Haiku
QA checklists               → Haiku

## Azure Cost Rules (Olist)
ADLS Gen2  : Storage murah tapi monitor transactions
ADF        : Pipeline runs accumulate — batch pipeline runs sahaja, jangan trigger test banyak kali
Databricks : Terminate bila idle >30 minit
Snowflake  : Gold ONLY — jangan waste untuk Bronze/Silver queries
Azure Total: $200 credit, 30 hari — target spend <$50 untuk portfolio

## COST_LOG.md — Update setiap phase
Phase N: X Sonnet calls, Y Haiku calls — est. $0.0X
Cloud  : ADLS: XGB, ADF runs: X, Databricks: X hours, Snowflake: $X spent
         Azure credit remaining: $Y
EOF

cat > .claude/agents/12-scope-guardian.md << 'EOF'
# Scope Guardian

## Identity
VETO POWER. Monitor semua interactions. Bila intervene — semua STOP.
Always active — zero exception.

## Veto Triggers
1. Tools yang tak dalam resume
2. Column yang tak dalam DRD.md
3. Same topic >3 rounds tanpa resolution
4. Over-engineer untuk portfolio scope
5. DA propose model yang DPE belum validate
6. AE build tanpa grain locked

## Olist Scope — Explicitly OUT
- ML models / fraud detection
- Real-time streaming (Kafka)
- Geolocation heatmap / choropleth
- Review sentiment NLP
- dim_reviews as full fact table

## Intervention Format
SCOPE GUARDIAN VETO
Reason : [kenapa intervene]
Action : [STOP / Escalate human / Revert]
EOF

cat > .claude/agents/13-mcp-orchestrator.md << 'EOF'
# MCP Orchestrator

## Identity
Tahu semua tools dalam .mcp.json. Paksa agents guna MCP tools — jangan manual.
Always active — announce tools setiap phase start.

## Tool Assignments (Azure stack)
Snowflake  → mcp_snowflake  (query, schema, run SQL)
Databricks → mcp_databricks (run notebooks, clusters)
Azure      → mcp_azure-docs (documentation reference)
dbt        → mcp_dbt        (run, test, compile models)

## Announcement Format (start each phase)
MCP ORCHESTRATOR — Tools Available This Phase:
- mcp_snowflake   : [capability]
- mcp_databricks  : [capability]
- mcp_dbt         : [capability]
Guna tools ni. Jangan buat manually.
EOF

cat > .claude/agents/14-git-agent.md << 'EOF'
# Git Agent

## Identity
Handle version control. Jalan AUTOMATICALLY selepas sign-off approved.
Model: Haiku (boilerplate task).

## Hard Rules
1. JANGAN commit: CLAUDE.md, .claude/, HOW_IT_WORKS.txt,
   PROJECT_STATUS.md, COST_LOG.md, JOURNEY_LOG.md,
   INTERVIEW_GUIDE.md, sign-offs/, .env.*,
   docs/DEBATE_LOG_phase_*.md,
   data/, *.parquet, *.csv, *.xlsx
2. JANGAN ada Co-authored-by dalam commits
3. Commit format: [Phase X] [Document] — [summary]
4. Update README.md setiap phase
5. Push selepas setiap commit

## Files Per Phase
Phase 1 : docs/BRD.md
Phase 2 : docs/DRD.md, docs/DATA_DICTIONARY.md
Phase 3 : docs/ARCHITECTURE.md, docs/PIPELINE_SPEC.md,
          docs/DATA_MODEL.md, docs/ADR/
Phase 4a: bronze/, silver/, gold/, tests/, airflow/dags/
Phase 4b: docs/screenshots/
Phase 5 : docs/DQD.md, docs/OPS_RUNBOOK.md, data_quality/
EOF

echo "✅ All 14 agent personas created"

# =============================================================================
# .claude/settings.json
# =============================================================================

cat > .claude/settings.json << 'EOF'
{
  "includeCoAuthoredBy": false,
  "model": "claude-sonnet-4-5",
  "context": {
    "autoLoadFiles": [
      "CLAUDE.md",
      "PROJECT_STATUS.md"
    ]
  }
}
EOF

echo "✅ .claude/settings.json created"

# =============================================================================
# .gitignore
# =============================================================================

cat > .gitignore << 'EOF'
# Internal AI / Workflow Docs
CLAUDE.md
.claude/
HOW_IT_WORKS.txt
PROJECT_STATUS.md
COST_LOG.md
docs/JOURNEY_LOG.md
docs/INTERVIEW_GUIDE.md
docs/DEBATE_LOG_phase_*.md
sign-offs/

# Credentials
.env
.env.dev
.env.staging
.env.prod
*.env
credentials/
*.key
*.pem
kaggle.json

# Data
data/
*.parquet
*.csv
*.xlsx
*.json.gz
raw/

# Python
__pycache__/
*.pyc
.venv/
venv/
*.egg-info/

# dbt
.dbt/
dbt_packages/
target/

# Databricks
.databricks/

# Airflow
airflow/logs/
airflow.cfg
airflow.db
standalone_admin_password.txt

# Logs
logs/
*.log

# Spark / Delta Lake
spark-warehouse/
derby.log
metastore_db/
checkpoint/
_delta_log/

# IDE / OS
.vscode/settings.json
.idea/
.DS_Store
Thumbs.db
*.swp
.ipynb_checkpoints/
*.ipynb
EOF

echo "✅ .gitignore created"

# =============================================================================
# .env.example — Azure vars
# =============================================================================

cat > .env.example << 'EOF'
# olist-ecommerce-pipeline — Credential Template
# Copy ke .env.dev / .env.staging / .env.prod
# JANGAN commit mana-mana .env

ENV=dev
CLOUD=azure

# Azure ADLS Gen2
AZURE_STORAGE_ACCOUNT=
AZURE_STORAGE_KEY=
ADLS_CONTAINER_DEV=olist-dev
ADLS_CONTAINER_STAGING=olist-staging
ADLS_CONTAINER_PROD=olist-prod
ADF_RESOURCE_GROUP=
ADF_FACTORY_NAME=

# Databricks CE
DATABRICKS_HOST=https://community.cloud.databricks.com
DATABRICKS_TOKEN=
DATABRICKS_CLUSTER_ID=

# Snowflake
SNOWFLAKE_ACCOUNT=
SNOWFLAKE_USER=
SNOWFLAKE_PASSWORD=
SNOWFLAKE_DATABASE=olist_ecommerce
SNOWFLAKE_SCHEMA_DEV=DEV
SNOWFLAKE_SCHEMA_STAGING=STAGING
SNOWFLAKE_SCHEMA_PROD=PROD
SNOWFLAKE_WAREHOUSE=COMPUTE_WH
SNOWFLAKE_ROLE=SYSADMIN

# Airflow
AIRFLOW__CORE__FERNET_KEY=
AIRFLOW__WEBSERVER__SECRET_KEY=

# Alerts
SLACK_WEBHOOK_URL=
SLACK_CHANNEL=#olist-pipeline-alerts

# dbt
DBT_PROFILES_DIR=./gold

# Kaggle API
KAGGLE_USERNAME=
KAGGLE_KEY=
KAGGLE_DATASET=olistbr/brazilian-ecommerce
KAGGLE_FILENAME=olist_orders_dataset.csv

# Dataset Source Path
# AUTO-SET oleh bronze/download_dataset.py selepas run — jangan edit manual
# dev     -> data/olist_dev_1000rows/ (local)
# staging -> abfss://olist-staging@[account].dfs.core.windows.net/landing/
# prod    -> abfss://olist-prod@[account].dfs.core.windows.net/landing/
DATASET_SOURCE_PATH=
DEV_SAMPLE_ROWS=1000
EOF

echo "✅ .env.example created"

# =============================================================================
# .mcp.json — Azure
# =============================================================================

cat > .mcp.json << 'EOF'
{
  "mcpServers": {
    "snowflake": {
      "command": "uvx",
      "args": ["mcp-server-snowflake"],
      "env": {
        "SNOWFLAKE_ACCOUNT": "${SNOWFLAKE_ACCOUNT}",
        "SNOWFLAKE_USER": "${SNOWFLAKE_USER}",
        "SNOWFLAKE_PASSWORD": "${SNOWFLAKE_PASSWORD}",
        "SNOWFLAKE_DATABASE": "${SNOWFLAKE_DATABASE}",
        "SNOWFLAKE_WAREHOUSE": "${SNOWFLAKE_WAREHOUSE}"
      }
    },
    "databricks": {
      "command": "databricks",
      "args": ["mcp", "serve"],
      "env": {
        "DATABRICKS_HOST": "${DATABRICKS_HOST}",
        "DATABRICKS_TOKEN": "${DATABRICKS_TOKEN}"
      }
    },
    "azure-docs": {
      "command": "uvx",
      "args": ["azure-docs-mcp-server@latest"]
    },
    "dbt": {
      "command": "dbt-mcp",
      "args": [],
      "env": { "DBT_PROFILES_DIR": "${DBT_PROFILES_DIR}" }
    }
  }
}
EOF

echo "✅ .mcp.json created (Azure)"

# =============================================================================
# bronze/download_dataset.py — Azure ADLS support
# =============================================================================

cat > bronze/download_dataset.py << 'EOF'
"""
download_dataset.py — Olist Brazilian E-Commerce
WHAT: Download semua 9 Olist CSVs dari Kaggle, sample untuk dev, upload ke ADLS untuk staging/prod
WHY : Single entry point untuk dataset acquisition semua environments
WHEN: Run sebelum Bronze pipeline — sekali per environment setup
"""

import os
import argparse
import pandas as pd
from pathlib import Path
from dotenv import load_dotenv

# =============================================================================
# CONFIG
# =============================================================================

KAGGLE_DATASET = "olistbr/brazilian-ecommerce"
OLIST_FILES = [
    "olist_orders_dataset.csv",
    "olist_order_items_dataset.csv",
    "olist_order_payments_dataset.csv",
    "olist_order_reviews_dataset.csv",
    "olist_customers_dataset.csv",
    "olist_sellers_dataset.csv",
    "olist_products_dataset.csv",
    "olist_geolocation_dataset.csv",
    "product_category_name_translation.csv",
]

# =============================================================================
# AZURE UPLOAD
# =============================================================================

def upload_to_adls(local_path: str, adls_path: str) -> None:
    """
    WHAT: Upload file ke Azure ADLS Gen2
    WHY : staging/prod environments guna ADLS sebagai landing zone
    WHEN: Dipanggil selepas download untuk env=staging/prod
    """
    from azure.storage.filedatalake import DataLakeServiceClient

    account = os.environ["AZURE_STORAGE_ACCOUNT"]
    key     = os.environ["AZURE_STORAGE_KEY"]
    env     = os.environ.get("ENV", "dev")

    container_map = {
        "staging": os.environ.get("ADLS_CONTAINER_STAGING", "olist-staging"),
        "prod"   : os.environ.get("ADLS_CONTAINER_PROD", "olist-prod"),
    }
    container = container_map.get(env, "olist-staging")

    service_client = DataLakeServiceClient(
        account_url=f"https://{account}.dfs.core.windows.net",
        credential=key
    )
    fs_client   = service_client.get_file_system_client(file_system=container)
    file_client = fs_client.get_file_client(adls_path)

    with open(local_path, "rb") as f:
        file_client.upload_data(f, overwrite=True)

    full_path = f"abfss://{container}@{account}.dfs.core.windows.net/{adls_path}"
    print(f"  ✅ Uploaded → {full_path}")
    return full_path


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", choices=["dev", "staging", "prod"], default="dev")
    args = parser.parse_args()

    env_file = f".env.{args.env}"
    load_dotenv(env_file)
    print(f"\n📦 download_dataset.py — env={args.env}")

    import kaggle
    kaggle.api.authenticate()

    # Download semua files
    download_dir = Path("data/raw")
    download_dir.mkdir(parents=True, exist_ok=True)
    print(f"⬇️  Downloading {KAGGLE_DATASET}...")
    kaggle.api.dataset_download_files(KAGGLE_DATASET, path=str(download_dir), unzip=True)
    print(f"✅ Download complete → {download_dir}/")

    if args.env == "dev":
        # Sample 1000 rows per file, save locally
        sample_dir = Path(f"data/olist_dev_{os.environ.get('DEV_SAMPLE_ROWS', 1000)}rows")
        sample_dir.mkdir(parents=True, exist_ok=True)
        for fname in OLIST_FILES:
            src = download_dir / fname
            if src.exists():
                df = pd.read_csv(src, nrows=int(os.environ.get("DEV_SAMPLE_ROWS", 1000)))
                dst = sample_dir / fname
                df.to_csv(dst, index=False)
                print(f"  ✅ Sampled {len(df)} rows → {dst}")
        # Update .env.dev
        with open(".env.dev", "a") as f:
            f.write(f"\nDATASET_SOURCE_PATH=data/olist_dev_{os.environ.get('DEV_SAMPLE_ROWS', 1000)}rows/\n")
        print(f"\n✅ Dev sample ready. DATASET_SOURCE_PATH updated in .env.dev")

    else:
        # Upload full dataset ke ADLS
        account   = os.environ["AZURE_STORAGE_ACCOUNT"]
        container = os.environ.get(f"ADLS_CONTAINER_{args.env.upper()}", f"olist-{args.env}")
        for fname in OLIST_FILES:
            src = download_dir / fname
            if src.exists():
                adls_path = f"landing/{fname}"
                full_path = upload_to_adls(str(src), adls_path)
        dataset_path = f"abfss://{container}@{account}.dfs.core.windows.net/landing/"
        with open(f".env.{args.env}", "a") as f:
            f.write(f"\nDATASET_SOURCE_PATH={dataset_path}\n")
        print(f"\n✅ Upload complete. DATASET_SOURCE_PATH updated in .env.{args.env}")


if __name__ == "__main__":
    main()
EOF

echo "✅ bronze/download_dataset.py created (Azure ADLS)"

# =============================================================================
# docs/ — Placeholder files
# =============================================================================

cat > docs/BRD.md << 'EOF'
# BRD: Olist E-Commerce Pipeline
> Status: DRAFT — Pending Phase 1 sign-off
> Domain: E-Commerce | Dataset: Olist Brazilian E-Commerce

## Stakeholders
| Stakeholder | Role | Data Need |
|-------------|------|-----------|
| Finance Team | Revenue reporting | DSO, Revenue Recognition per seller/month |
| Operations | Delivery performance | Fulfillment rate, on-time delivery rate |
| Seller Management | Seller health | GMV, review score, churn risk |
| Management | Executive dashboard | Overall GMV, customer retention, order trends |

## Business Requirements
1. Track Order-to-Cash cycle — dari order placed sampai payment received
2. Monitor seller performance — GMV, fulfillment rate, review score per seller
3. Analyse customer behaviour — retention, AOV, repeat purchase rate
4. Daily Gold layer available by 6AM untuk reporting consumers

## KPIs
| KPI | Formula | Target | Frequency |
|-----|---------|--------|-----------|
| DSO | AVG(payment_date - order_purchase_ts) | <30 days | Daily |
| Order Fulfillment Rate | delivered / placed * 100 | >95% | Daily |
| On-Time Delivery Rate | on_time / delivered * 100 | >90% | Daily |
| Seller GMV | SUM(price + freight_value) per seller | Trend | Monthly |
| Revenue Recognition | SUM(payment_value) per seller/month | Trend | Monthly |
| Customer Retention Rate | repeat_customers / total * 100 | >20% | Monthly |
| Avg Order Value | SUM(payment_value) / COUNT(orders) | Trend | Weekly |

## Business Definitions
- "Order" = record dalam olist_orders_dataset dengan unique order_id
- "Delivered" = order_status = 'delivered' AND order_delivered_customer_date IS NOT NULL
- "On-Time" = order_delivered_customer_date <= order_estimated_delivery_date
- "DSO" = payment approval date - order purchase timestamp
- "GMV" = price + freight_value (gross, sebelum deductions)
- "Repeat Customer" = customer_unique_id yang ada >1 order

## SLA
- Gold layer available by 6AM daily
- Pipeline failure alert dalam 15 minit via Slack

## Sign-off Gate
| Agent | Status | Reason | Date |
|-------|--------|--------|------|
| BA | PENDING | - | - |
| PO | PENDING | - | - |
| PM | PENDING | - | - |
| DQS | PENDING | - | - |
EOF

cat > docs/DRD.md << 'EOF'
# DRD: Olist E-Commerce Pipeline
> Status: DRAFT — Pending Phase 2 sign-off

## Source Overview
| Attribute | Value |
|-----------|-------|
| Source | Olist Brazilian E-Commerce (Kaggle) |
| Format | CSV (9 files) |
| Frequency | Static dataset — daily batch simulation |
| Volume | ~100k orders, ~830k order items, ~100k customers |
| Ingestion pattern | Snapshot |

## Source Files & Schema

### olist_orders_dataset.csv (→ fact_orders)
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| order_id | string | N | PK |
| customer_id | string | N | FK → customers |
| order_status | string | N | approved/delivered/shipped/etc |
| order_purchase_timestamp | timestamp | N | order placed time |
| order_approved_at | timestamp | Y | payment approved time |
| order_delivered_carrier_date | timestamp | Y | handed to carrier |
| order_delivered_customer_date | timestamp | Y | NULL if not delivered |
| order_estimated_delivery_date | timestamp | N | expected delivery |

### olist_order_items_dataset.csv (→ fact_order_items)
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| order_id | string | N | FK → orders |
| order_item_id | int | N | sequence within order |
| product_id | string | N | FK → products |
| seller_id | string | N | FK → sellers |
| shipping_limit_date | timestamp | N | seller must ship by |
| price | float | N | item price |
| freight_value | float | N | shipping cost |

### olist_order_payments_dataset.csv (→ fact_payments)
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| order_id | string | N | FK → orders |
| payment_sequential | int | N | installment sequence |
| payment_type | string | N | credit_card/boleto/etc |
| payment_installments | int | N | total installments |
| payment_value | float | N | value per installment |

### olist_customers_dataset.csv (→ dim_customers)
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| customer_id | string | N | PK (per order) |
| customer_unique_id | string | N | true customer identifier |
| customer_zip_code_prefix | string | N | SCD2 tracking key |
| customer_city | string | N | |
| customer_state | string | N | |

### olist_sellers_dataset.csv (→ dim_sellers)
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| seller_id | string | N | PK |
| seller_zip_code_prefix | string | N | SCD2 tracking key |
| seller_city | string | N | |
| seller_state | string | N | |

### olist_products_dataset.csv (→ dim_products)
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| product_id | string | N | PK |
| product_category_name | string | Y | Portuguese — join translation |
| product_name_lenght | int | Y | |
| product_description_lenght | int | Y | |
| product_photos_qty | int | Y | |
| product_weight_g | int | Y | |
| product_length_cm | int | Y | |
| product_height_cm | int | Y | |
| product_width_cm | int | Y | |

## Known Data Issues
| Issue | Observed | Impact | Strategy |
|-------|----------|--------|----------|
| order_delivered_customer_date NULLs | ~3% rows | DSO calculation incomplete | NULL = in-progress, flag dq_delivered_flag, exclude dari DSO calc |
| payments: multiple rows per order | installment pattern | grain confusion | grain = per installment (order_id + payment_sequential) |
| geolocation: duplicate zip_code_prefix | multiple lat/lng per zip | dim join fanout | dedupe by keeping first occurrence |
| product_category_name NULLs | ~600 products | category reporting gap | join translation table, NULL → 'uncategorized' |
| customer_id vs customer_unique_id | customer_id per-order, unique_id per-person | SCD2 key selection | use customer_unique_id as SCD2 natural key |

## Sign-off Gate
| Agent | Status | Reason |
|-------|--------|--------|
| BA | PENDING | - |
| DA | PENDING | - |
| SDE | PENDING | - |
| DPE | PENDING | - |
| DQS | PENDING | - |
| PM | PENDING | - |

## Hard Blockers Before Phase 3
[ ] Grain defined untuk setiap fact table (DONE — locked dalam CLAUDE.md)
[ ] DA + DPE sync confirmed
[ ] Upstream issues flagged + strategy decided (DONE — 5 issues above)
[ ] Source pattern decided: Snapshot
[ ] DEBATE_LOG_phase_2.md generated
EOF

cat > docs/DATA_DICTIONARY.md << 'EOF'
# Data Dictionary: Olist E-Commerce Pipeline
> Owner: DQS | Updated: setiap kali schema berubah

## Business Terms
| Term | Definition | Example |
|------|-----------|---------|
| Order | Unique transaction dalam olist_orders | order_id = "abc123" |
| Delivered | order_status='delivered' AND delivered_date NOT NULL | - |
| On-Time | delivered_date <= estimated_delivery_date | - |
| DSO | AVG(payment_approved_at - order_purchase_timestamp) | 12.5 days |
| GMV | SUM(price + freight_value) — gross, sebelum deductions | R$250.00 |
| Repeat Customer | customer_unique_id dengan >1 order | - |
| Installment | Satu baris dalam payments — satu bahagian payment | payment_sequential=2 |

## Gold Tables (dbt Marts)
### mart__fact_orders
| Column | Business Name | Type | KPI? | Formula | Notes |
|--------|--------------|------|------|---------|-------|
| order_id | Order ID | string | N | - | PK |
| customer_key | Customer Key | string | N | - | FK → dim_customers |
| order_status | Order Status | string | N | - | delivered/shipped/etc |
| order_purchase_date | Purchase Date | date | N | - | partition key |
| dso_days | Days Sales Outstanding | float | Y | payment_approved_at - order_purchase_ts | NULL if not approved |
| is_delivered | Delivered Flag | boolean | N | order_status = 'delivered' | - |
| is_on_time | On-Time Flag | boolean | Y | delivered_date <= estimated_date | NULL if not delivered |

### mart__fact_order_items
| Column | Business Name | Type | KPI? | Formula | Notes |
|--------|--------------|------|------|---------|-------|
| order_id | Order ID | string | N | - | FK → fact_orders |
| order_item_id | Item Sequence | int | N | - | - |
| seller_key | Seller Key | string | N | - | FK → dim_sellers |
| product_key | Product Key | string | N | - | FK → dim_products |
| price | Item Price | float | N | - | BRL |
| freight_value | Freight Value | float | N | - | BRL |
| gmv | GMV | float | Y | price + freight_value | BRL |

### mart__fact_payments
| Column | Business Name | Type | KPI? | Formula | Notes |
|--------|--------------|------|------|---------|-------|
| order_id | Order ID | string | N | - | FK → fact_orders |
| payment_sequential | Installment No. | int | N | - | PK component |
| payment_type | Payment Type | string | N | - | credit_card/boleto |
| payment_value | Payment Value | float | Y | - | BRL per installment |
EOF

cat > docs/DATA_MODEL.md << 'EOF'
# Data Model: Olist E-Commerce Pipeline
> Owner: Data Architect | Status: DRAFT — Pending Phase 3 sign-off
> Co-validated by: Data Platform Engineer (feasibility)

## Paradigm Decision
Chosen  : Kimball — Star Schema
Reason  : Aggregate-heavy analytics (DSO, fulfillment rate, GMV), 3 fact tables,
          manageable join complexity, 100k rows sesuai untuk Codespace + Databricks CE
Tradeoff: Less storage, more compute (joins needed at query time).
          Sesuai untuk free tier — ADLS storage Azure murah, compute Databricks CE 15GB fit.

## Why Not OBT
OBT rejected — complex Array/Struct types = memory risk kat Databricks CE 15GB.
100k orders tak justify OBT storage duplication. Kimball standard untuk analytics use case ni.

## Fact Tables
### fact_orders
- Grain   : 1 row = 1 order
- Source  : olist_orders_dataset.csv
- Pattern : Snapshot
- Key cols: order_id (PK), customer_id (FK)
- Partition: order_purchase_date

### fact_order_items
- Grain   : 1 row = 1 line item dalam 1 order
- Source  : olist_order_items_dataset.csv
- Pattern : Snapshot
- Key cols: order_id + order_item_id (composite PK), seller_id, product_id (FKs)
- Partition: order_purchase_date (dari fact_orders join)

### fact_payments
- Grain   : 1 row = 1 payment installment
- Source  : olist_order_payments_dataset.csv
- Pattern : Snapshot
- Key cols: order_id + payment_sequential (composite PK)
- Note    : SUM(payment_value) per order_id = total order value

## Dimension Tables
### dim_customers
- SCD Type: 2
- Reason  : customer_zip_code_prefix boleh berubah — nak track historical location
- Natural key: customer_unique_id
- Surrogate key: customer_key (hash)
- SCD cols: valid_from, valid_to, is_current

### dim_sellers
- SCD Type: 2
- Reason  : seller city/state boleh berubah — nak track seller location history
- Natural key: seller_id
- Surrogate key: seller_key (hash)
- SCD cols: valid_from, valid_to, is_current

### dim_products
- SCD Type: 1
- Reason  : product catalog — history tak penting, overwrite okay
- Natural key: product_id
- Note    : join product_category_name_translation untuk English name

### dim_date
- SCD Type: Static/None
- Source  : Generated (date spine 2016-2018)
- Cols    : date_id, year, quarter, month, week, day_of_week, is_weekend

## SCD Type 2 Implementation
start_date, end_date, is_current
Backfill supported via Delta Lake time travel
Dedup logic: MERGE INTO dim_customers USING staging ON natural_key

## Physical Layer (validated by DPE)
[x] Databricks CE 15GB — fit (100k orders, Kimball joins manageable)
[x] ADLS Gen2 storage — cost sustainable (<$10 untuk dataset size ni)
[x] Delta Lake MERGE — supported untuk SCD Type 2
[x] Snowflake credit — Gold queries only, sustainable

## Sign-off Gate
| Agent | Status | Reason |
|-------|--------|--------|
| DA | PENDING | - |
| DPE | PENDING | - |
| SDE | PENDING | - |
| AE | PENDING | - |
| PM | PENDING | - |

## Hard Blockers Before Phase 4
[ ] Grain locked — explicit, agreed (DONE)
[ ] SCD type per dimension confirmed (DONE)
[ ] Storage vs compute tradeoff documented (DONE)
[ ] DA + DPE feasibility sync confirmed
[ ] Paradigm ADR written
[ ] DEBATE_LOG_phase_3.md generated
EOF

echo "✅ Core docs created (BRD, DRD, DATA_DICTIONARY, DATA_MODEL)"

# =============================================================================
# Remaining docs
# =============================================================================

cat > docs/PIPELINE_SPEC.md << 'EOF'
# Pipeline SPEC: Olist E-Commerce Pipeline
> Status: DRAFT — Pending Phase 3 sign-off

## Bronze Layer
Input  : ADLS landing/ (9 Olist CSVs) atau data/ (dev local)
Output : Delta Lake bronze.[table_name]
Logic  : Store as-is + ingestion_ts, source_system='olist_kaggle', batch_id

Tables:
  bronze.raw_orders, bronze.raw_order_items, bronze.raw_payments
  bronze.raw_customers, bronze.raw_sellers, bronze.raw_products
  bronze.raw_reviews, bronze.raw_geolocation, bronze.raw_category_translation

## Silver Layer
Steps per fact/dim:

### silver.orders (→ fact_orders)
1. TYPE CAST   : timestamps STRING → TIMESTAMP
2. NULL HANDLE : order_delivered_customer_date NULL → allowed (in-progress)
                 order_approved_at NULL → dq_approved_flag = False
3. DERIVE      : is_delivered = (order_status = 'delivered' AND delivered_date IS NOT NULL)
                 is_on_time = (delivered_date <= estimated_date) WHERE delivered
4. DEDUPLICATE : Keep latest ingestion_ts per order_id

### silver.order_items (→ fact_order_items)
1. TYPE CAST   : price, freight_value → FLOAT
2. DERIVE      : gmv = price + freight_value
3. DEDUPLICATE : Keep latest per (order_id, order_item_id)

### silver.payments (→ fact_payments)
1. TYPE CAST   : payment_value → FLOAT
2. VALIDATE    : SUM(payment_value) per order_id should match expected
3. DEDUPLICATE : Keep latest per (order_id, payment_sequential)

### silver.customers (→ dim_customers SCD2)
1. DEDUPLICATE : Keep latest per customer_unique_id
2. SCD TYPE 2  : MERGE on customer_unique_id
                 INSERT new record if zip_code_prefix changed
                 UPDATE old record: valid_to = today, is_current = False

### silver.sellers (→ dim_sellers SCD2)
1. SCD TYPE 2  : MERGE on seller_id
                 INSERT new record if city/state changed
                 UPDATE old record: valid_to = today, is_current = False

### silver.products (→ dim_products SCD1)
1. JOIN        : product_category_name_translation for English name
2. NULL HANDLE : category NULL → 'uncategorized'
3. OVERWRITE   : Full refresh (SCD Type 1)

### silver.geolocation
1. DEDUPLICATE : Keep first occurrence per zip_code_prefix

## Gold Layer (dbt)
Models : staging → intermediate → marts
See .claude/agents/06-analytics-engineer.md for full model list

## Error Handling
- NULL critical cols (order_id, customer_id) → quarantine + CRITICAL alert
- Duplicates → keep latest by ingestion_ts, log count
- FK violation → quarantine + HIGH alert to DQS
- Geolocation dedup → log count removed, continue
EOF

cat > docs/ARCHITECTURE.md << 'EOF'
# Architecture: Olist E-Commerce Pipeline
> Status: DRAFT — Pending Phase 3 sign-off

## Stack
| Layer | Tool | Constraint |
|-------|------|------------|
| Storage | Azure ADLS Gen2 | $200 credit, 30 hari |
| Bronze | Delta Lake | ACID, time travel |
| Silver | PySpark + Databricks CE | 15GB RAM |
| Gold | dbt Core + Snowflake | $400 credit |
| Orchestration | Airflow standalone | localhost:8080 |
| Quality | Great Expectations | Suite per layer |
| BI | Power BI | Gold consumer |

## Data Flow
Kaggle CSV (9 files)
  → ADLS landing/ (staging/prod) atau data/ (dev)
  → Bronze Delta Lake (raw + metadata)
  → Silver PySpark (clean, dedupe, SCD2)
  → Gold dbt/Snowflake (Star Schema, KPIs)
  → Power BI (dashboards)

## Data Modelling
Paradigm : Kimball — Star Schema
Facts    : fact_orders, fact_order_items, fact_payments
Dims     : dim_customers (SCD2), dim_sellers (SCD2), dim_products (SCD1), dim_date (static)
Grain    : See docs/DATA_MODEL.md

## Environments
dev     → 1000 rows, local PySpark, manual trigger
staging → full 100k orders, Airflow scheduled, GX validation
prod    → cloud promote (ADF/Databricks), screenshot evidence
EOF

cat > docs/DQD.md << 'EOF'
# DQD: Olist E-Commerce Pipeline
> Status: DRAFT — Pending Phase 5 sign-off

## Bronze Suite
| Check | Rule | Severity | Action |
|-------|------|----------|--------|
| Row count | Source count = Bronze count | CRITICAL | Block + alert |
| ingestion_ts | NOT NULL | CRITICAL | Reject |
| order_id format | 32-char hex string | HIGH | Quarantine |
| All 9 files ingested | File count = 9 | CRITICAL | Block |

## Silver Suite
| Column | Rule | Severity | Action |
|--------|------|----------|--------|
| order_id | NOT NULL, UNIQUE in orders | CRITICAL | Reject + alert |
| (order_id, order_item_id) | UNIQUE in order_items | HIGH | Keep latest |
| (order_id, payment_sequential) | UNIQUE in payments | HIGH | Keep latest |
| customer_unique_id | NOT NULL | CRITICAL | Reject |
| is_current per customer | Only one True per customer_unique_id | CRITICAL | Alert DQS |
| price, freight_value | >= 0 | HIGH | Quarantine negative |

## Gold Suite (dbt tests)
| Check | Rule | Severity |
|-------|------|----------|
| fact_orders.customer_key | FK in dim_customers | CRITICAL |
| fact_order_items.seller_key | FK in dim_sellers | CRITICAL |
| fact_order_items.product_key | FK in dim_products | CRITICAL |
| fact_payments.order_id | FK in fact_orders | CRITICAL |
| dbt tests | All not_null, unique, relationships pass | CRITICAL |

## Action on Failure
CRITICAL : Block downstream + Slack alert dalam 15 minit
HIGH     : Quarantine bad rows, continue clean rows
MEDIUM   : dq_flag=True + log warning + continue
EOF

cat > docs/OPS_RUNBOOK.md << 'EOF'
# OPS Runbook: Olist E-Commerce Pipeline
> Status: DRAFT — Pending Phase 5 sign-off

## Monitoring
Airflow UI : localhost:8080
GX Report  : docs/screenshots/gx_report_[date].html
Slack      : #olist-pipeline-alerts

## Alert SLAs
CRITICAL : 15 minit | HIGH : 1 jam | MEDIUM : Hari bekerja

## Bronze Fail — File Missing
Check : ADLS landing/ — semua 9 files ada?
Fix 1 : Re-run download_dataset.py --env staging
Fix 2 : Check AZURE_STORAGE_ACCOUNT credentials dalam .env.staging
Rerun : Airflow UI → Clear bronze_ingest task → Trigger

## Bronze Fail — Schema Mismatch
Check : Compare schema dalam bronze vs docs/DRD.md
Fix   : Kaggle dataset mungkin updated — re-check column names
Action: Update DRD + Bronze schema, escalate ke DA

## Silver GX CRITICAL Fail
Check  : docs/screenshots/gx_report.html → which expectation failed?
Fix 1  : NULL dalam critical cols → check Bronze quarantine table
Fix 2  : Dedup fail → check source for new duplicates
Rerun  : Clear silver_transform task → Trigger

## Databricks Cluster Terminated
Fix     : Login CE → Restart cluster → load latest checkpoint
Prevent : Checkpoint setiap 30 minit dalam Silver script

## dbt Test Fail — FK Violation
Check : Which fact/dim? Check Silver quarantine table
Fix 1 : FK violation → source data ada orphan records → quarantine + alert DQS
Fix 2 : SCD2 is_current issue → check Silver SCD merge logic
Rerun : dbt run → dbt test

## Backfill Procedure
1. Identify affected date range
2. Delete Silver partition (order_purchase_date = affected dates)
3. Rerun Bronze → Silver → Gold dengan date param
4. Verify: row count Silver = Bronze untuk affected dates
5. Verify: dbt test pass

## Azure Credit Monitor
Check : Azure Portal → Cost Management
Alert : <$150 remaining → DPE review + optimize
Alert : <$100 remaining → escalate ke human — pause cloud runs
EOF

echo "✅ Remaining docs created"

# =============================================================================
# docs/ADR/
# =============================================================================

cat > docs/ADR/ADR-000-template.md << 'EOF'
# ADR-[NNN]: [Decision Title]
Status: [Proposed / Accepted]
Date  : [YYYY-MM-DD]
Owner : [DA / DPE / SDE]

## Context
[Kenapa decision ni perlu.]

## Decision
[Apa yang dipilih.]

## Consequences
(+) [Benefit 1]
(-) [Trade-off 1]

## Alternatives Rejected
- [Alternative A]: rejected sebab [reason]
EOF

cat > docs/ADR/ADR-001-data-modelling-paradigm.md << EOF
# ADR-001: Data Modelling Paradigm — Kimball Star Schema
Status: Accepted
Date  : $(date +%Y-%m-%d)
Owner : Data Architect + Data Platform Engineer

## Context
Olist dataset: 9 source tables, ~100k orders, ~830k order items.
Need to decide modelling paradigm for Gold layer serving analytics consumers.

## Decision
Paradigm : Kimball — Star Schema
Grain    :
  fact_orders      → 1 row = 1 order
  fact_order_items → 1 row = 1 line item
  fact_payments    → 1 row = 1 payment installment
Dims     : dim_customers (SCD2), dim_sellers (SCD2), dim_products (SCD1), dim_date (static)

## Consequences
(+) Standard analytics pattern — 80-90% use cases covered
(+) Aggregate queries (DSO, fulfillment rate, GMV) performant dengan Star Schema joins
(+) Databricks CE 15GB sufficient — no memory risk
(+) ADLS storage cost manageable — no duplication overhead
(-) Join required at query time — Kimball trade-off
(-) Denormalized OBT would eliminate joins but memory risk too high

## Alternatives Rejected
- OBT (One Big Table): rejected — complex Array/Struct types = OOM risk Databricks CE 15GB;
  100k rows tak justify storage duplication
- Hybrid: rejected — overkill untuk portfolio scope, Kimball sufficient
EOF

echo "✅ ADR files created"

# =============================================================================
# Airflow DAG
# =============================================================================

cat > airflow/dags/olist_pipeline_dag.py << 'EOF'
"""
olist_pipeline_dag.py — Olist E-Commerce Pipeline
Modelling    : Kimball — Star Schema
Facts        : fact_orders, fact_order_items, fact_payments
Dimensions   : dim_customers (SCD2), dim_sellers (SCD2), dim_products (SCD1), dim_date
Schedule     : @daily (trigger manually untuk demo)
Alerting     : Slack webhook on success + failure
"""

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'raja-luqman',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
}

def slack_success(context):
    SlackWebhookOperator(
        task_id='slack_success',
        slack_webhook_conn_id='slack_webhook',
        message=f"✅ *olist-pipeline* — Success | {context['ds']} | All tasks green",
    ).execute(context)

def slack_failure(context):
    SlackWebhookOperator(
        task_id='slack_failure',
        slack_webhook_conn_id='slack_webhook',
        message=f"❌ *olist-pipeline* — FAILED: {context['task_instance'].task_id} | {context['ds']}",
    ).execute(context)

with DAG(
    dag_id='olist_ecommerce_pipeline',
    default_args=default_args,
    schedule_interval='@daily',
    catchup=False,
    on_success_callback=slack_success,
    on_failure_callback=slack_failure,
    tags=['ecommerce', 'kimball', 'olist', 'portfolio'],
) as dag:

    bronze = PythonOperator(
        task_id='bronze_ingest',
        python_callable=lambda: __import__('bronze.bronze_pipeline', fromlist=['']).run(),
    )

    silver = PythonOperator(
        task_id='silver_transform',
        python_callable=lambda: __import__('silver.silver_pipeline', fromlist=['']).run(),
    )

    silver_dq = PythonOperator(
        task_id='silver_dq_check',
        python_callable=lambda: __import__('data_quality.run_silver_suite', fromlist=['']).run(),
    )

    gold_run = BashOperator(
        task_id='gold_dbt_run',
        bash_command='cd gold && dbt run --profiles-dir . --project-dir .',
    )

    gold_test = BashOperator(
        task_id='gold_dbt_test',
        bash_command='cd gold && dbt test --profiles-dir . --project-dir .',
    )

    bronze >> silver >> silver_dq >> gold_run >> gold_test
EOF

echo "✅ Airflow DAG created"

# =============================================================================
# dbt profiles.yml
# =============================================================================

cat > gold/profiles.yml << 'EOF'
olist_ecommerce:
  target: dev
  outputs:
    dev:
      type: snowflake
      account: "{{ env_var('SNOWFLAKE_ACCOUNT') }}"
      user: "{{ env_var('SNOWFLAKE_USER') }}"
      password: "{{ env_var('SNOWFLAKE_PASSWORD') }}"
      role: "{{ env_var('SNOWFLAKE_ROLE', 'SYSADMIN') }}"
      database: "{{ env_var('SNOWFLAKE_DATABASE') }}"
      warehouse: "{{ env_var('SNOWFLAKE_WAREHOUSE') }}"
      schema: "{{ env_var('SNOWFLAKE_SCHEMA_DEV') }}"
      threads: 4
    staging:
      type: snowflake
      account: "{{ env_var('SNOWFLAKE_ACCOUNT') }}"
      user: "{{ env_var('SNOWFLAKE_USER') }}"
      password: "{{ env_var('SNOWFLAKE_PASSWORD') }}"
      role: "{{ env_var('SNOWFLAKE_ROLE', 'SYSADMIN') }}"
      database: "{{ env_var('SNOWFLAKE_DATABASE') }}"
      warehouse: "{{ env_var('SNOWFLAKE_WAREHOUSE') }}"
      schema: "{{ env_var('SNOWFLAKE_SCHEMA_STAGING') }}"
      threads: 4
    prod:
      type: snowflake
      account: "{{ env_var('SNOWFLAKE_ACCOUNT') }}"
      user: "{{ env_var('SNOWFLAKE_USER') }}"
      password: "{{ env_var('SNOWFLAKE_PASSWORD') }}"
      role: "{{ env_var('SNOWFLAKE_ROLE', 'SYSADMIN') }}"
      database: "{{ env_var('SNOWFLAKE_DATABASE') }}"
      warehouse: "{{ env_var('SNOWFLAKE_WAREHOUSE') }}"
      schema: "{{ env_var('SNOWFLAKE_SCHEMA_PROD') }}"
      threads: 4
EOF

echo "✅ dbt profiles.yml created"

# =============================================================================
# Internal docs
# =============================================================================

cat > docs/JOURNEY_LOG.md << 'EOF'
# Journey Log: Olist E-Commerce Pipeline
> Auto-updated setiap sign-off gate. JANGAN commit ke GitHub.

## Entry Format
[NNN] [YYYY-MM-DD · Phase N]
DECISION  : apa yang diputuskan
AGENTS    : siapa argue apa
REASON    : kenapa pilih solution tu
TRADEOFF  : apa yang dikorbankan
OUTCOME   : result selepas decision
STAR_NOTE : Y/N — keyword interview
LEARN     : apa yang kau belajar

---

[001] [2026-05-12 · Pre-Phase 1]
DECISION  : Kimball Star Schema dipilih sebagai paradigm
AGENTS    : DA propose Kimball, DPE validate feasibility (15GB fit), PO approve scope
REASON    : Aggregate-heavy analytics (DSO, GMV, fulfillment rate); 100k rows manageable; standard pattern
TRADEOFF  : OBT rejected — memory risk Databricks CE; Hybrid overkill untuk portfolio
OUTCOME   : Grain locked, SCD types decided, ADR-001 written pre-setup
STAR_NOTE : Y — "Kenapa Kimball?" interview question ready
LEARN     : Lock paradigm + grain sebelum scaffold — jimat rework masa Phase 3
EOF

cat > COST_LOG.md << 'EOF'
# Cost Log: Olist E-Commerce Pipeline
> Updated by FinOps setiap phase. JANGAN commit.

## Token Usage
| Phase | Sonnet | Haiku | Est. Cost |
|-------|--------|-------|-----------|
| Pre-setup (simulation) | ~10 | 0 | ~$0.05 |
| 1 — BRD | - | - | $0.00 |
| 2 — DRD | - | - | $0.00 |
| 3 — Architecture | - | - | $0.00 |
| 4 — CODE | - | - | $0.00 |
| 5 — DQD+OPS | - | - | $0.00 |
| Total | | | ~$0.05 |

## Azure Usage
| Service | Used | Budget | Remaining |
|---------|------|--------|-----------|
| ADLS Gen2 | 0 GB | monitor | $200 |
| ADF pipeline runs | 0 | monitor | $200 |
| Databricks CE | 0 hours | free | free |
| Snowflake | $0 | $400 | $400 |
| Azure Total | $0 | $200 | $200 |

## FinOps Flags
- [ ] Azure credit <$150 → DPE review + optimize
- [ ] Azure credit <$100 → pause cloud runs, escalate human
- [ ] Snowflake <$50 remaining → suspend warehouse aggressively
- [ ] Databricks idle >30min → terminate cluster
EOF

cat > PROJECT_STATUS.md << EOF
# PROJECT_STATUS.md — Olist E-Commerce Pipeline
Last updated : $(date +%Y-%m-%d)
Current phase: Phase 0 — Setup Complete
Modelling    : Kimball — Star Schema
Cloud        : Azure (ADLS Gen2 + ADF)
Resume       : Raja Ahmad Luqman — Analytics & DE Specialist

---

## Phase Overview
| Phase | Document | Status | Sign-off Date |
|-------|----------|--------|---------------|
| 0 | Setup + Scaffold | ✅ Done | $(date +%Y-%m-%d) |
| 1 | BRD | ⏳ | - |
| 2 | DRD + Data Model Conceptual | ⏳ | - |
| 3 | Architecture + SPEC + Data Model Logical | ⏳ | - |
| 4a | CODE — local dev | ⏳ | - |
| 4b | CODE — cloud promote | ⏳ | - |
| 5 | DQD + OPS | ⏳ | - |

---

## Pre-locked Decisions (from simulation)
- Paradigm  : Kimball — Star Schema ✅
- Grain     : fact_orders=1 order, fact_order_items=1 line item, fact_payments=1 installment ✅
- SCD types : dim_customers=Type2, dim_sellers=Type2, dim_products=Type1, dim_date=Static ✅
- Cloud     : Azure ADLS Gen2 + ADF ✅
- ADR-001   : Written ✅

---

## Next Step When Resuming
1. Prompt: "Baca CLAUDE.md dan PROJECT_STATUS.md. Start Phase 1 — BRD."
2. Terus execute — jangan explain semula

---

## Hard Blockers Tracker
| Blocker | Phase Gate | Resolved? |
|---------|------------|-----------|
| Grain defined | 2→3 | ✅ Done |
| DA + DPE sync | 2→3 | ⏳ |
| Upstream issues flagged | 2→3 | ✅ Pre-flagged (5 issues) |
| DEBATE_LOG_phase_2.md | 2→3 | ⏳ |
| DATA_MODEL.md signed off | 3→4 | ⏳ |
| SCD type confirmed | 3→4 | ✅ Done |
| Paradigm ADR written | 3→4 | ✅ ADR-001 done |
| DEBATE_LOG_phase_3.md | 3→4 | ⏳ |
| Unit tests pass | 4a→4b | ⏳ |
| QA sign-off local | 4a→4b | ⏳ |
| DPE cloud readiness | 4a→4b | ⏳ |
| DEBATE_LOG_phase_4a.md | 4a→4b | ⏳ |

---

## Open Loops
- [ ] DA + DPE feasibility sync — confirm kat Phase 2/3
- [ ] dim_reviews scope — confirmed OUT but revisit if time permits Phase 5
EOF

cat > sign-offs/SIGN_OFF_LOG.md << 'EOF'
# Sign-off Log: Olist E-Commerce Pipeline
> Auto-updated by PM setiap phase. JANGAN commit.

---

## Phase 1 — BRD
Date: PENDING | Status: PENDING
| Agent | Decision | Reason |
|-------|----------|--------|
| BA | PENDING | - |
| PO | PENDING | - |
| PM | PENDING | - |
| DQS | PENDING | - |

Hard Blockers:
[ ] BRD stakeholders + KPIs agreed
[ ] Business definitions documented
[ ] DEBATE_LOG_phase_1.md generated

---

## Phase 2 — DRD + Data Model (Conceptual)
Date: PENDING | Status: PENDING
Hard Blockers:
[x] Grain defined — locked dalam CLAUDE.md
[ ] DA + DPE sync confirmed
[x] Upstream data issues flagged (5 issues documented)
[x] Source pattern decided: Snapshot
[ ] DATA_DICTIONARY.md draft done
[ ] DEBATE_LOG_phase_2.md generated

---

## Phase 3 — Architecture + Data Model (Logical)
Date: PENDING | Status: PENDING
Hard Blockers:
[ ] DATA_MODEL.md complete + signed off
[x] Paradigm ADR written (ADR-001)
[x] SCD type per dimension confirmed
[x] Storage vs compute tradeoff documented
[x] Grain locked — AE boleh start build
[ ] DPE confirm platform feasibility (formal sign-off)
[ ] DEBATE_LOG_phase_3.md generated

---

## Phase 4a — CODE Local
Date: PENDING | Status: PENDING

---

## Phase 4b — Cloud Promote
Date: PENDING | Status: PENDING

---

## Phase 5 — DQD + OPS
Date: PENDING | Status: PENDING
EOF

cat > HOW_IT_WORKS.txt << 'EOF'
=== HOW THIS PROJECT WORKS ===
(JANGAN COMMIT — for local reference only)

PROJECT : Olist E-Commerce Pipeline
DATASET : Olist Brazilian E-Commerce (Kaggle: olistbr/brazilian-ecommerce)
PROBLEM : Order-to-Cash KPIs + Seller/Customer Ops reporting
MODEL   : Kimball — Star Schema
CLOUD   : Azure (ADLS Gen2 + ADF)

WORKFLOW:
1. Scaffold done (setup.sh) — 14 agents, all placeholder docs created
2. Claude Code → reads CLAUDE.md → spawns agents → Phase 1 BRD
3. Agents debate → DEBATE_LOG written → sign-off → git commit
4. Repeat Phase 2 → 3 → 4a → 4b → 5

RESUME COVERAGE:
  Project 1 (Order-to-Cash AE) ← Gold layer: dbt + Snowflake + KPIs
  Project 2 (E-Commerce Pipeline DE) ← Bronze/Silver: PySpark + Airflow + Delta Lake

TO START:
  cp .env.example .env.dev
  # Fill KAGGLE_USERNAME + KAGGLE_KEY + Azure creds
  python bronze/download_dataset.py --env dev
  code .
  # Claude Code: "Baca CLAUDE.md dan PROJECT_STATUS.md. Start Phase 1 — BRD."
EOF

echo "✅ Internal docs created"

# =============================================================================
# requirements.txt
# =============================================================================

cat > requirements.txt << 'EOF'
# Core
pyspark==3.5.0
pandas==2.1.0
python-dotenv==1.0.0
delta-spark==3.0.0

# Quality
great-expectations==0.18.0

# Airflow
apache-airflow==2.8.0
apache-airflow-providers-slack==8.0.0
apache-airflow-providers-microsoft-azure==8.0.0
apache-airflow-providers-databricks==6.0.0
apache-airflow-providers-snowflake==5.0.0

# Snowflake
snowflake-connector-python==3.6.0
snowflake-sqlalchemy==1.5.0

# dbt
dbt-core==1.7.0
dbt-snowflake==1.7.0

# Azure storage
azure-storage-file-datalake==12.14.0
azure-identity==1.15.0

# Testing
pytest==7.4.0
pytest-cov==4.1.0

# Utils
PyYAML==6.0.1
kaggle==1.6.14
EOF

echo "✅ requirements.txt created"

# =============================================================================
# SETUP_GUIDE.txt
# =============================================================================

cat > infrastructure/credentials/SETUP_GUIDE.txt << 'EOF'
=== CREDENTIAL SETUP GUIDE — Olist E-Commerce Pipeline ===
Stack: Azure ADLS Gen2 + Databricks + Snowflake + Airflow + Kaggle
(COMMIT this file — no sensitive data)

STEP 1 — Copy env template
  cp .env.example .env.dev

STEP 2 — Kaggle API
  https://www.kaggle.com/settings → API → Create New Token → kaggle.json
  Edit .env.dev: KAGGLE_USERNAME + KAGGLE_KEY
  Test: python bronze/download_dataset.py --env dev

STEP 3 — Azure ADLS Gen2 ($200 free credit)
  Portal → Create Storage Account
  Enable: "Hierarchical namespace" = Yes (makes it ADLS Gen2)
  Portal → Storage Account → Access keys → copy key1
  Create containers: olist-dev, olist-staging, olist-prod
  Edit .env.dev:
    AZURE_STORAGE_ACCOUNT=yourstorageaccount
    AZURE_STORAGE_KEY=yourkey1here
  Verify: python -c "from azure.storage.filedatalake import DataLakeServiceClient; print('OK Azure')"

STEP 4 — Databricks CE
  https://community.cloud.databricks.com → Register (free)
  User Settings → Access Tokens → Generate New Token
  Create cluster: 15GB RAM, Spark 3.5, Python 3.11
  Edit .env.dev:
    DATABRICKS_HOST=https://community.cloud.databricks.com
    DATABRICKS_TOKEN=yourtoken
    DATABRICKS_CLUSTER_ID=yourclusterid

STEP 5 — Snowflake Trial ($400 credit)
  https://trial.snowflake.com → Register
  Account format: xy12345.ap-southeast-1.azure (pilih Azure region)
  Run in Snowflake UI:
    CREATE DATABASE olist_ecommerce;
    CREATE WAREHOUSE COMPUTE_WH WITH WAREHOUSE_SIZE = 'X-SMALL' AUTO_SUSPEND = 60;
  Edit .env.dev:
    SNOWFLAKE_ACCOUNT=xy12345.ap-southeast-1.azure
    SNOWFLAKE_USER=yourusername
    SNOWFLAKE_PASSWORD=yourpassword

STEP 6 — Airflow Standalone
  pip install apache-airflow==2.8.0
  export AIRFLOW_HOME=$(pwd)/airflow
  airflow standalone
  UI: http://localhost:8080 (admin / check standalone_admin_password.txt)
  Add Slack connection: Admin → Connections → slack_webhook

STEP 7 — Slack Webhook
  https://api.slack.com/apps → Create App → Incoming Webhooks → Activate
  Add to Workspace → Copy Webhook URL
  Edit .env.dev: SLACK_WEBHOOK_URL=https://hooks.slack.com/...

VERIFY ALL (source .env.dev first):
  python -c "import kaggle; kaggle.api.authenticate(); print('OK Kaggle')"
  python -c "from azure.storage.filedatalake import DataLakeServiceClient; print('OK Azure')"
  python -c "import snowflake.connector; print('OK Snowflake')"
  cd gold && dbt debug --profiles-dir .

MONITOR AZURE CREDIT:
  Portal → Cost Management + Billing → Current balance
  Target: spend <$50 total untuk portfolio project ni
EOF

echo "✅ SETUP_GUIDE.txt created"

# =============================================================================
# README.md
# =============================================================================

cat > README.md << 'EOF'
# Olist E-Commerce Pipeline

End-to-end Medallion Architecture pipeline — Olist Brazilian E-Commerce dataset (100k+ orders).
Backs two resume projects: E-Commerce DE pipeline (Bronze/Silver) + Order-to-Cash AE layer (Gold).

## Data Model
- Paradigm : Kimball — Star Schema
- Facts    : fact_orders (1 order), fact_order_items (1 line item), fact_payments (1 installment)
- Dims     : dim_customers (SCD2), dim_sellers (SCD2), dim_products (SCD1), dim_date (static)

## Tech Stack
| Layer | Tool |
|-------|------|
| Storage | Azure ADLS Gen2 + Delta Lake |
| Silver | PySpark + Databricks CE |
| Gold | dbt Core + Snowflake |
| Orchestration | Apache Airflow standalone |
| Quality | Great Expectations |
| BI | Power BI |

## Architecture
```
Kaggle (9 CSVs)
  → ADLS Gen2 landing/
  → Bronze Delta Lake (raw + metadata)
  → Silver PySpark/Databricks (clean, dedupe, SCD Type 2)
  → Gold dbt/Snowflake (Star Schema, KPIs)
  → Power BI
```

## KPIs
- DSO (Days Sales Outstanding)
- Order Fulfillment Rate
- On-Time Delivery Rate
- Seller GMV
- Revenue Recognition per Seller
- Customer Retention Rate
- Average Order Value

## Quick Start
```bash
cp .env.example .env.dev
# Fill credentials — see infrastructure/credentials/SETUP_GUIDE.txt
python bronze/download_dataset.py --env dev
# Claude Code: "Baca CLAUDE.md dan PROJECT_STATUS.md. Start Phase 1 — BRD."
```

## Progress
| Phase | Document | Status |
|-------|----------|--------|
| 0 | Setup + Scaffold | ✅ |
| 1 | BRD | ⏳ |
| 2 | DRD + Data Model | ⏳ |
| 3 | Architecture + SPEC | ⏳ |
| 4 | CODE + Evidence | ⏳ |
| 5 | DQD + OPS | ⏳ |

## Pipeline Evidence
### Airflow DAG
![airflow](docs/screenshots/airflow_dag_success.png)

### GX Validation Report
![gx](docs/screenshots/gx_validation_report.png)

### Snowflake Gold Layer
![snowflake](docs/screenshots/snowflake_gold_table.png)

### Slack Alert
![slack](docs/screenshots/slack_alert_success.png)
EOF

echo "✅ README.md created"

# =============================================================================
# Git init + initial commit
# =============================================================================

git init

git add \
  .gitignore \
  .env.example \
  .mcp.json \
  docs/BRD.md \
  docs/DRD.md \
  docs/DATA_DICTIONARY.md \
  docs/DATA_MODEL.md \
  docs/PIPELINE_SPEC.md \
  docs/ARCHITECTURE.md \
  docs/DQD.md \
  docs/OPS_RUNBOOK.md \
  docs/ADR/ \
  airflow/dags/olist_pipeline_dag.py \
  bronze/download_dataset.py \
  gold/profiles.yml \
  README.md \
  requirements.txt \
  infrastructure/credentials/SETUP_GUIDE.txt

git commit -m "[Phase 0] olist-ecommerce-pipeline — ecommerce Kimball pipeline initialized | Azure ADLS Gen2"

# =============================================================================
# DONE
# =============================================================================

echo ""
echo "=========================================="
echo "✅ olist-ecommerce-pipeline — scaffold complete!"
echo "=========================================="
echo ""
echo "Modelling : Kimball — Star Schema"
echo "Cloud     : Azure (ADLS Gen2 + ADF)"
echo "Agents    : 14 persona files dalam .claude/agents/ ✅"
echo "Docs      : BRD, DRD, DATA_DICTIONARY, DATA_MODEL, PIPELINE_SPEC, ARCHITECTURE, DQD, OPS_RUNBOOK ✅"
echo "ADR       : ADR-001 Kimball paradigm written ✅"
echo "Status    : PROJECT_STATUS.md ✅ (grain + SCD pre-locked)"
echo ""
echo "Pre-locked decisions:"
echo "  Paradigm  : Kimball ✅"
echo "  Grain     : fact_orders=1 order, fact_order_items=1 item, fact_payments=1 installment ✅"
echo "  SCD types : customers=Type2, sellers=Type2, products=Type1, date=Static ✅"
echo "  ADR-001   : Written ✅"
echo ""
echo "NOT committed (gitignored):"
echo "  CLAUDE.md, PROJECT_STATUS.md, COST_LOG.md"
echo "  HOW_IT_WORKS.txt, JOURNEY_LOG.md, SIGN_OFF_LOG.md"
echo "  docs/DEBATE_LOG_phase_*.md, .env.*"
echo ""
echo "Next steps:"
echo "  1. Salin CLAUDE.md ke dalam folder ni (dari outputs/CLAUDE.md)"
echo "  2. cp .env.example .env.dev"
echo "  3. Fill in credentials — ikut infrastructure/credentials/SETUP_GUIDE.txt"
echo "  4. python bronze/download_dataset.py --env dev"
echo "  5. code ."
echo "  6. Claude Code: 'Baca CLAUDE.md dan PROJECT_STATUS.md. Start Phase 1 — BRD.'"
echo ""
