# Interview Guide — Olist E-Commerce Pipeline

> Owned jointly by @business-analyst (evidence) and @documentation-sherpa (structure).
> Every resume bullet traces to `file:line` evidence below, or is flagged unsupported.
> "(unverified)" means checked-but-not-confirmed this turn (e.g. no live Databricks/Snowflake
> session available); never silently upgraded to "confirmed" without re-running the check.

## Resume Claim ↔ Repo Evidence

| # | Claim | Status | Evidence |
|---|---|---|---|
| 1 | "Azure Data Factory (ADF)" for ingestion | ❌ Unsupported | `grep -rni "data factory\|adf" bronze/ silver/ airflow/ databricks_notebooks/` → 0 hits in actual pipeline code. Ingestion is `bronze/download_dataset.py` (Kaggle Competition API) → `bronze/bronze_pipeline.py` / `bronze/ingest_to_delta.py` (Databricks COPY INTO into Unity Catalog Delta tables). `docs/ARCHITECTURE.md:375` mentions "cloud ADF (staging/prod)" only as an aspirational note, never implemented anywhere in the codebase. **Action needed: correct the resume wording to "Kaggle API + Databricks COPY INTO" — do not claim ADF, it is not in this repo.** |
| 2 | Kimball star schema (3 facts + 4 dims) | ✅ Confirmed | `gold/dbt_models/models/marts/{fact_orders,fact_order_items,fact_payments,dim_customers,dim_sellers,dim_products,dim_date}.sql` — 7 files, matches `docs/ADR/ADR-001-data-modelling-paradigm.md` |
| 3 | SCD Type 2 for customer/seller history | ✅ Confirmed | `silver/transform_silver.py:233` `transform_customers_scd2` (MERGE-expire pattern, `customer_key` surrogate, `valid_from`/`valid_to`/`is_current`), mirrored in `silver/transform_silver.py` `transform_sellers_scd2`; mart-side `gold/dbt_models/models/intermediate/int_customers_scd2.sql` + `int_sellers_scd2.sql` → `dim_customers.sql`/`dim_sellers.sql`. Gated by `tests/identity_contract.py` (passes). |
| 4 | SCD Type 1 for product catalog | ✅ Confirmed | `silver/transform_silver.py:471` `transform_products_scd1` — overwrite mode, `product_key` surrogate, no historical tracking by design (ADR-002) |
| 5 | Delta Lake / Unity Catalog Bronze with ACID + time travel | ✅ Confirmed | `bronze/ingest_to_delta.py` (PySpark `DeltaTable`), `databricks_notebooks/01_bronze_ingestion.py` — 9 raw Delta tables |
| 6 | Great Expectations data quality gates | ✅ Confirmed | `data_quality/run_bronze_validation.py` (9 checks per CLAUDE.md stack table), `data_quality/run_silver_suite.py`/`run_silver_validation.py` (12 checks) — real `great_expectations` `BatchRequest` usage, not stubs |
| 7 | dbt Core Gold layer, staging → intermediate → marts | ✅ Confirmed | `gold/dbt_models/models/{staging,intermediate,marts}/` — 6 staging + 2 intermediate (SCD2) + 7 mart models |
| 8 | Snowflake external stage serving Gold | ✅ Confirmed | `gold/dbt_models/profiles.yml` (adapter `type: snowflake`), `scripts/snowflake_setup*.sql`, `scripts/snowflake_load_*.sql` |
| 9 | Apache Airflow orchestration | ⚠️ Confirmed with a major nuance (found 2026-06-29) | `airflow/dags/olist_pipeline_dag.py` — 1 chained DAG (bronze → silver → silver_dq → gold_dbt_run → gold_dbt_test), `@daily`, IS real and DOES run. But 3 of its 5 tasks (`bronze_ingest`, `silver_transform`, `silver_dq_check`) call `bronze/bronze_pipeline.py`, `silver/silver_pipeline.py`, `data_quality/run_silver_validation.py` — each is an explicit print-stub ("Demo/Portfolio: Validates configuration and reports success" / "Skipping actual validation — Silver tables in Databricks (cloud)"), not a live Databricks REST API trigger. Only `gold_dbt_run`/`gold_dbt_test` execute real work (`dbt run`/`dbt test` against Snowflake) on every scheduled run. The real Bronze/Silver execution happened ONCE, manually, via `databricks_notebooks/01_bronze_ingestion.py`/`02_silver_transformation.py` during Phase 4b. **Action: do not claim "fully automated Bronze→Gold pipeline" — say "Airflow orchestrates Gold dbt build automatically; Bronze/Silver were run once via Databricks notebooks, with Airflow stub tasks documenting that production flow for the demo."** |
| 10 | Slack alerting on pipeline failure | ✅ Confirmed (this retrofit) | `airflow/dags/olist_pipeline_dag.py` `_notify_slack_failure`, wired as `on_failure_callback` in `default_args` — graceful no-op if `SLACK_WEBHOOK_URL` unset (per ADR-003). **Prior to this retrofit this was print-only** — be ready to explain that the dependency (`apache-airflow-providers-slack` in `requirements.txt`) existed before the wiring did. |
| 11 | Power BI as the BI/serving consumer | ✅ Confirmed | `docs/ARCHITECTURE.md` "Serving Layer" + `docs/screenshots/` (no Power BI artifact committed, dashboard is external to the repo — expected, BI tools aren't typically version-controlled) |

## Doc gaps surfaced during retrofit (separate from resume reconciliation)
1. `docs/ARCHITECTURE.md` (lines 64, 191) referenced `gold/models/` — the real dbt project
   root is `gold/dbt_models/`. Fixed during this retrofit (was breaking
   `tests/doc_reference_contract.py` C2).
2. `docs/PIPELINE_SPEC.md:115` referenced `tests/great_expectations/bronze_suite.json` — the
   real path is `data_quality/great_expectations/expectations/bronze_suite.json`. Fixed.
3. **(found 2026-06-29, owner audit ahead of a Microsoft Fabric migration)** `README.md`'s
   Stack table + architecture diagram claimed "Silver | Databricks SQL Warehouse (Serverless)
   | SQL transforms + SCD Type 2" / "Databricks SQL Warehouse — SQL CTAS + window functions".
   The real `silver/transform_silver.py` is plain PySpark DataFrame API (no SQL CTAS anywhere
   in the file). Fixed in `README.md`, `CLAUDE.md`, `docs/ARCHITECTURE.md`.
4. **(found 2026-06-29, same audit)** The Airflow DAG's Bronze/Silver "automation" is
   print-stub theater, not live orchestration — see row 9 above. This was undocumented
   anywhere prior to this audit; now flagged in `CLAUDE.md` (the "Automation gap" callout)
   and `docs/ARCHITECTURE.md`.

All 4 logged in `PROJECT_STATUS.md` "Doc gaps found" / `DECISION_LOG.md`.

## Interview Q&A drills (answer from the artifact, not memory)
1. **"Walk me through your SCD2 implementation."** → `silver/transform_silver.py:233`
   `transform_customers_scd2` — initial load assigns `customer_key` via `row_number()`,
   subsequent runs do a MERGE-expire: existing `is_current=TRUE` rows get `valid_to` /
   `is_current=False` set, then a fresh row is inserted with a new `customer_key`. Mirrored
   for sellers. Gated statically by `tests/identity_contract.py` (no live warehouse needed to
   catch a dropped column or renamed function).
2. **"Why SCD2 for customers/sellers but SCD1 for products?"** → `docs/ADR/ADR-002-scd-strategy.md`
   — customer/seller location changes matter for regional retention/operations analysis
   (point-in-time correctness); product catalog overwrites are acceptable (no compliance or
   historical-attribution need for product attribute changes at this dataset's scope).
3. **"Why Kimball over a wide/OBT table?"** → `docs/ADR/ADR-001-data-modelling-paradigm.md`.
4. **"What's actually wired for alerting, and why is it failure-only?"** → ADR-003 — the
   dependency existed unused; this retrofit wires `on_failure_callback` only (a success
   channel would be noisy for a `@daily` demo DAG; failure-only matches
   `docs/ARCHITECTURE.md`'s "#olist-pipeline-alerts" framing).
5. **"Is the ADF claim on your resume accurate?"** → No — be upfront that it's not (see row 1
   above); the actual ingestion path is the Kaggle Competition API + Databricks COPY INTO.
6. **"Walk me through what actually runs when your Airflow DAG fires."** → Be precise:
   `gold_dbt_run`/`gold_dbt_test` genuinely execute `dbt run`/`dbt test` against Snowflake
   every time. `bronze_ingest`/`silver_transform`/`silver_dq_check` are stub tasks that print a
   summary of what Phase 4b's manual Databricks-notebook run already did — they don't re-run
   Bronze/Silver. This is an honest "portfolio demo of the orchestration shape" pattern, not a
   defect to hide; explain it as a deliberate scope choice (re-running the full Databricks
   ingest/transform job on every `@daily` tick wasn't the point of the demo), not as "I didn't know."
