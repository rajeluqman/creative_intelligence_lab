#!/usr/bin/env python3
"""Identity contract — deterministic gate over the SCD2 customer/seller grain.

Ported from creative_intelligence_lab's tests/lineage_contract.py pattern (via home-credit's
"identity contract" rename) — this repo's identity keys are `customer_key`/`seller_key`
(surrogate, SCD Type 2), assigned in `silver/transform_silver.py` and carried through
`gold/dbt_models/models/intermediate/int_customers_scd2.sql` / `int_sellers_scd2.sql` into
`dim_customers.sql` / `dim_sellers.sql`. `product_key` is SCD Type 1 (no historical tracking,
intentionally out of scope for this contract — ADR-002).

Encodes @data-architect's "exactly 1 is_current=TRUE row per business key" SCD2 guarantee
statically, WITHOUT requiring a live Snowflake/Databricks connection — it checks the dbt
SOURCE (intermediate SCD model + mart alias SQL) and the Silver transform script, not
warehouse data. Run actual `dbt test` / GX suites for the runtime complement.

Stdlib only. Exit 0 = contract holds. Exit 1 = hard violation.

Rules:
  ID1  silver/transform_silver.py must define both transform_customers_scd2 and
       transform_sellers_scd2, each assigning a surrogate key (customer_key/seller_key) and
       carrying valid_from/valid_to/is_current columns (the SCD2 columns) — a stray rename or
       a dropped column is caught here
  ID2  dim_customers.sql / dim_sellers.sql (mart models) must reference their matching
       int_*_scd2 intermediate model and select valid_from/valid_to/is_current — a
       hand-rolled current-flag that bypasses the intermediate SCD model would drift silently
  ID3  every mart SQL file with a "-- Grain:" comment must name the table's real surrogate
       key column (customer_key/seller_key/product_key/order_id/...) — catches a renamed/
       typo'd grain comment going stale vs the SQL

Run:  python tests/identity_contract.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
SILVER_TRANSFORM = REPO / "silver" / "transform_silver.py"
MART_DIR = REPO / "gold" / "dbt_models" / "models" / "marts"
DIM_CUSTOMERS = MART_DIR / "dim_customers.sql"
DIM_SELLERS = MART_DIR / "dim_sellers.sql"

GRAIN_COMMENT_RE = re.compile(r"--\s*Grain:\s*(.+)$", re.IGNORECASE)
SCD2_COLS = ("valid_from", "valid_to", "is_current")

# Per-model expected grain phrase (substring, case-insensitive) — catches a renamed/typo'd
# grain comment going stale vs the model's actual SQL, without requiring the literal column
# name in prose (this repo's house style is a plain-English grain sentence, not "1 row =
# customer_key" — see gold/dbt_models/models/marts/*.sql).
EXPECTED_GRAIN_PHRASE: dict[str, str] = {
    "dim_customers.sql": "customer",
    "dim_sellers.sql": "seller",
    "dim_products.sql": "product",
    "dim_date.sql": "date",
    "fact_orders.sql": "order",
    "fact_order_items.sql": "line item",
    "fact_payments.sql": "payment",
}


def check() -> list[str]:
    errors: list[str] = []

    # ID1 — silver/transform_silver.py SCD2 functions exist and carry SCD2 columns + surrogate key
    if not SILVER_TRANSFORM.exists():
        errors.append(f"ID1: {SILVER_TRANSFORM.relative_to(REPO)} missing — Silver SCD transform not found")
    else:
        text = SILVER_TRANSFORM.read_text()
        for fn_name, key_col in (
            ("def transform_customers_scd2", "customer_key"),
            ("def transform_sellers_scd2", "seller_key"),
        ):
            if fn_name not in text:
                errors.append(f"ID1: {fn_name} not found in silver/transform_silver.py — SCD2 transform missing")
                continue
            if key_col not in text:
                errors.append(f"ID1: surrogate key '{key_col}' not found in silver/transform_silver.py "
                               f"(expected from {fn_name}) — grain drift")
        for col in SCD2_COLS:
            if col not in text:
                errors.append(f"ID1: SCD2 column '{col}' not found in silver/transform_silver.py — "
                               "is_current/valid_from/valid_to semantics may have drifted")

    # ID2 — mart dims reference the matching intermediate SCD model and select SCD2 columns
    for mart_path, int_model, key_col in (
        (DIM_CUSTOMERS, "int_customers_scd2", "customer_key"),
        (DIM_SELLERS, "int_sellers_scd2", "seller_key"),
    ):
        if not mart_path.exists():
            errors.append(f"ID2: {mart_path.relative_to(REPO)} missing — mart dim model not found")
            continue
        text = mart_path.read_text()
        if int_model not in text:
            errors.append(f"ID2: {mart_path.name} does not reference {int_model} (SCD2 source broken)")
        if key_col not in text:
            errors.append(f"ID2: {mart_path.name} does not select '{key_col}' — surrogate key missing")
        for col in SCD2_COLS:
            if col not in text:
                errors.append(f"ID2: {mart_path.name} does not select '{col}' (SCD2 column missing "
                               "— hand-rolled current-flag risks drifting from the intermediate model)")

    # ID3 — every mart SQL file with a grain comment must mention its expected entity noun
    # (catches a copy-pasted/stale grain comment going out of sync with the model it's in)
    if MART_DIR.exists():
        for sql_file in sorted(MART_DIR.glob("*.sql")):
            expected = EXPECTED_GRAIN_PHRASE.get(sql_file.name)
            if expected is None:
                continue
            for lineno, line in enumerate(sql_file.read_text().splitlines(), 1):
                m = GRAIN_COMMENT_RE.search(line)
                if m and expected not in m.group(1).lower():
                    errors.append(
                        f"ID3: {sql_file.relative_to(REPO)}:{lineno}: grain comment does not "
                        f"mention expected entity '{expected}' — comment may be stale: {line.strip()!r}"
                    )

    return errors


def main() -> int:
    errors = check()
    if errors:
        print(f"\n❌ IDENTITY CONTRACT FAILED — {len(errors)} violation(s):", file=sys.stderr)
        for e in errors:
            print(f"   • {e}", file=sys.stderr)
        print("\n   See docs/DATA_MODEL.md + docs/ADR/ADR-002-scd-strategy.md. Fix before proceeding.",
              file=sys.stderr)
        return 1
    print("✅ identity contract OK (customer_key/seller_key SCD2 grain)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
