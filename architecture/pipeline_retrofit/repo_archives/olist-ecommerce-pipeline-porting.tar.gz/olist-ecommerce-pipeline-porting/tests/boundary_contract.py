#!/usr/bin/env python3
"""Stack + scope boundary contract — deterministic gate over this repo's locked stack.

Ported from creative_intelligence_lab's tests/boundary_contract.py pattern (via home-credit's
retarget), retargeted to THIS repo's real rejected-tech axis (docs/ARCHITECTURE.md +
docs/ADR/ADR-001-data-modelling-paradigm.md):
  - Bronze/Silver compute is Databricks (Unity Catalog Delta Lake + Databricks SQL Warehouse/
    Serverless) — PySpark is sanctioned there (`silver/*.py`, `bronze/*.py`,
    `databricks_notebooks/*.py`), never as a standalone cluster elsewhere
  - Gold compute is Snowflake/dbt only — `gold/dbt_models/profiles.yml` adapter `type:` must
    stay `snowflake` (never duckdb/bigquery/postgres)
  - No new ingestion connector beyond the Kaggle Competition API (no Fivetran/Airbyte/ADF —
    the resume's "Azure Data Factory" claim does not correspond to anything in this codebase,
    see INTERVIEW_GUIDE.md)
  - No AWS S3/Glue, no MinIO, no dedicated vector DB anywhere in pipeline code

Stdlib only ($0, no deps). Exit 0 = contract holds. Exit 1 = hard violation.

Rules:
  ST1  no `pyspark` import outside bronze/, silver/, databricks_notebooks/ (Spark is a
       Databricks-only surface in this repo)
  ST2  no AWS Glue/Lambda/S3-as-storage SDK import anywhere (storage is ADLS Gen2, not S3)
  ST3  no Fivetran/Airbyte/azure-data-factory-mgmt dependency (Kaggle API is the sole
       ingestion path; the resume's ADF claim is unsupported by this repo, flagged not silenced)
  ST4  dbt profile adapter `type:` must be `snowflake` (Gold compute is locked to Snowflake)

Run:  python tests/boundary_contract.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent

PY_GLOBS_ALL = ["airflow/dags/*.py", "data_quality/*.py", "scripts/*.py"]
# Spark is sanctioned wherever Databricks is the actual compute target in this repo, AND in
# tests/unit/ which unit-tests those same Bronze/Silver modules (pytest fixtures build a local
# SparkSession to exercise bronze/ingest_to_delta.py and silver/transform_silver.py directly).
PY_GLOBS_DATABRICKS = ["silver/*.py", "bronze/*.py", "databricks_notebooks/*.py", "tests/unit/*.py"]
REQUIREMENTS_FILES = ["requirements.txt"]
PROFILE_FILES = ["gold/dbt_models/profiles.yml"]

IMPORT_RE = re.compile(r"^\s*(?:import|from)\s+([A-Za-z0-9_.]+)")
REQ_LINE_RE = re.compile(r"^([A-Za-z0-9_.-]+)")

DATABRICKS_ONLY_DENY: dict[str, str] = {}  # pyspark is allowed here, nothing additionally denied
ALWAYS_DENY: dict[str, str] = {
    "boto3": "docs/ARCHITECTURE.md — storage is ADLS Gen2 (Azure), not S3/AWS",
    "awswrangler": "docs/ARCHITECTURE.md — storage is ADLS Gen2 (Azure), not S3/AWS",
    "fivetran": "no ingestion connector beyond the Kaggle Competition API",
    "airbyte": "no ingestion connector beyond the Kaggle Competition API",
}
PYSPARK_OUTSIDE_DATABRICKS_DENY: dict[str, str] = {
    "pyspark": "docs/ARCHITECTURE.md — Bronze/Silver compute is Databricks-only; no standalone Spark elsewhere",
}


def _hits(module: str, deny: dict[str, str]) -> str | None:
    parts = module.lower().split(".")
    for i in range(1, len(parts) + 1):
        prefix = ".".join(parts[:i])
        if prefix in deny:
            return deny[prefix]
    return None


def _scan_python(path: Path, errors: list[str], deny: dict[str, str]) -> None:
    rel = path.relative_to(REPO)
    for lineno, line in enumerate(path.read_text(errors="ignore").splitlines(), start=1):
        m = IMPORT_RE.match(line)
        if not m:
            continue
        reason = _hits(m.group(1), deny)
        if reason:
            errors.append(f"{rel}:{lineno}: banned import '{m.group(1)}' — {reason}")


def _scan_requirements(path: Path, errors: list[str]) -> None:
    rel = path.relative_to(REPO)
    deny = {**ALWAYS_DENY}
    for lineno, line in enumerate(path.read_text(errors="ignore").splitlines(), start=1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = REQ_LINE_RE.match(line)
        if not m:
            continue
        pkg = m.group(1).lower().replace("-", "_")
        reason = deny.get(pkg)
        if reason:
            errors.append(f"{rel}:{lineno}: banned dependency '{m.group(1)}' — {reason}")


def _scan_profile_adapter(path: Path, errors: list[str]) -> None:
    rel = path.relative_to(REPO)
    type_re = re.compile(r"^\s*type:\s*(\S+)")
    for lineno, line in enumerate(path.read_text(errors="ignore").splitlines(), start=1):
        m = type_re.match(line)
        if m and m.group(1) != "snowflake":
            errors.append(
                f"{rel}:{lineno}: dbt profile adapter type '{m.group(1)}' != 'snowflake' — "
                "this repo's Gold compute is locked to Snowflake"
            )


def check() -> list[str]:
    errors: list[str] = []

    for pattern in PY_GLOBS_ALL:
        for path in REPO.glob(pattern):
            _scan_python(path, errors, {**PYSPARK_OUTSIDE_DATABRICKS_DENY, **ALWAYS_DENY})

    for pattern in PY_GLOBS_DATABRICKS:
        for path in REPO.glob(pattern):
            _scan_python(path, errors, ALWAYS_DENY)  # pyspark IS allowed here

    for name in REQUIREMENTS_FILES:
        path = REPO / name
        if path.exists():
            _scan_requirements(path, errors)

    for name in PROFILE_FILES:
        path = REPO / name
        if path.exists():
            _scan_profile_adapter(path, errors)

    return errors


def main() -> int:
    errors = check()
    if errors:
        print(f"\n❌ BOUNDARY CONTRACT FAILED — {len(errors)} violation(s):", file=sys.stderr)
        for e in sorted(set(errors)):
            print(f"   • {e}", file=sys.stderr)
        print("\n   See docs/ARCHITECTURE.md. Fix before proceeding.", file=sys.stderr)
        return 1
    print("✅ boundary contract OK (Databricks-only Bronze/Silver Spark, Snowflake-locked Gold)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
