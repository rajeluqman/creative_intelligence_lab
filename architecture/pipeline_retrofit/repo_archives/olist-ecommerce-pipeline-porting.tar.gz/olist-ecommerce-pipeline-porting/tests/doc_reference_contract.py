#!/usr/bin/env python3
"""Doc-reference contract — deterministic gate against documentation drift.

Ported from creative_intelligence_lab's tests/doc_reference_contract.py (pipeline-retrofit
effort, via home-credit's retarget) — same mechanism, retargeted to this repo's dbt project
root (`gold/dbt_models/` not `dbt_home_credit/` or `models/`/`seeds/` at repo root). Proves
every model/path a Markdown doc references ACTUALLY EXISTS, so doc drift fails the build
instead of misleading the next reader.

Stdlib only ($0, no deps). Exit 0 = every checked reference resolves. Exit 1 = drift.

What it checks:
  C1  MODEL refs — backtick-wrapped tokens shaped like a dbt object (prefix
      fact_/fct_/dim_/stg_/int_/snap_/bridge_/mart_) must be a real model under
      gold/dbt_models/models/**/*.sql.
  C2  PATH refs — backtick tokens and []() link targets that point at a repo path
      (bronze/ silver/ gold/ docs/ tests/ airflow/ .claude/ data_quality/ scripts/
      databricks_notebooks/ architecture/ learning/ simulation/) must exist on disk.

Run:  python tests/doc_reference_contract.py
      python tests/doc_reference_contract.py path/to/FILE.md ...
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
DBT_ROOT = REPO / "gold" / "dbt_models"

MODEL_TOKEN = re.compile(r"^(?:fact|fct|dim|stg|int|snap|bridge|mart)_[a-z0-9_]+$")
PATH_ROOTS = ("bronze/", "silver/", "gold/", "docs/", "tests/", "airflow/", ".claude/",
              "data_quality/", "scripts/", "databricks_notebooks/", "architecture/",
              "learning/", "simulation/", "confluence/")

# Intentionally-not-yet-existing names a doc may legitimately reference. Each entry MUST
# carry a reason so the allowlist can't quietly rot into a dumping ground.
ALLOW: dict[str, str] = {}


def _known_objects() -> set[str]:
    return {p.stem for p in (DBT_ROOT / "models").rglob("*.sql")} if (DBT_ROOT / "models").exists() else set()


def _default_docs() -> list[Path]:
    docs = [p for p in sorted((REPO / "docs").glob("*.md"))]
    adr = sorted((REPO / "docs" / "ADR").glob("*.md")) if (REPO / "docs" / "ADR").exists() else []
    return docs + adr


def check(docs: list[Path]) -> list[str]:
    known = _known_objects()
    errors: list[str] = []

    backtick = re.compile(r"`([^`]+)`")
    link = re.compile(r"\]\(([^)]+)\)")

    for doc in docs:
        if not doc.exists():
            errors.append(f"{doc}: doc file does not exist")
            continue
        rel = doc.relative_to(REPO)
        for lineno, line in enumerate(doc.read_text(encoding="utf-8").splitlines(), 1):
            for tok in backtick.findall(line):
                tok = tok.strip()
                if MODEL_TOKEN.match(tok) and tok not in known and tok not in ALLOW:
                    errors.append(
                        f"{rel}:{lineno}  C1 model `{tok}` referenced but no "
                        f"gold/dbt_models/models/**/{tok}.sql exists (drift)"
                    )

            candidates = backtick.findall(line) + link.findall(line)
            for cand in candidates:
                cand = cand.strip().split("#", 1)[0].strip()
                if cand.startswith(("http://", "https://", "s3://", "abfss://", "mailto:")):
                    continue
                if not cand.startswith(PATH_ROOTS):
                    continue
                if "*" in cand or "{" in cand:
                    continue
                if not (REPO / cand).exists():
                    errors.append(f"{rel}:{lineno}  C2 path `{cand}` referenced but not found on disk")

    return errors


def main(argv: list[str]) -> int:
    docs = [Path(a) for a in argv[1:]] if len(argv) > 1 else _default_docs()
    docs = [d if d.is_absolute() else (REPO / d) for d in docs]
    errors = check(docs)
    if errors:
        print(f"DOC-REFERENCE CONTRACT: {len(errors)} drift violation(s)\n")
        for e in errors:
            print(f"  ✗ {e}")
        print("\nFix the doc or add a reasoned entry to ALLOW. Drift is a lie waiting to mislead.")
        return 1
    print(f"DOC-REFERENCE CONTRACT: OK — {len(docs)} doc(s), all model/path references resolve.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
