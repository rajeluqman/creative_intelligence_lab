"""
Unit tests for bronze/ingest_to_delta.py
Phase 4a — Bronze layer ingestion validation
"""

import pytest
from pyspark.sql import SparkSession


@pytest.fixture(scope="module")
def spark():
    """Create Spark session for tests"""
    return (
        SparkSession.builder
        .appName("test_bronze_ingest")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .getOrCreate()
    )


def test_metadata_columns_present(spark):
    """
    Test: Bronze tables must have all 5 metadata columns
    Expected: ingestion_timestamp, source_system, batch_id, source_file_name, row_hash
    """
    # TODO: Implement after Bronze ingestion runs
    # bronze_df = spark.read.format("delta").load("data/bronze/raw_orders")
    # expected_cols = ["ingestion_timestamp", "source_system", "batch_id", "source_file_name", "row_hash"]
    # assert all(col in bronze_df.columns for col in expected_cols)
    pass


def test_batch_id_format():
    """
    Test: batch_id must follow YYYYMMDD_HHMMSS format
    Expected: regex match ^\\d{8}_\\d{6}$
    """
    # TODO: Implement batch_id validation
    pass


def test_row_hash_uniqueness(spark):
    """
    Test: row_hash should be unique per (source_file_name, batch_id)
    Expected: No duplicate row_hash within same batch and file
    """
    # TODO: Implement row_hash deduplication test
    pass


def test_source_system_value(spark):
    """
    Test: source_system must be 'olist_kaggle'
    Expected: All rows have source_system = 'olist_kaggle'
    """
    # TODO: Implement source_system validation
    pass
