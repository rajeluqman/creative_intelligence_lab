# Olist E-Commerce Pipeline — Tests

## Test Structure

```
tests/
├── unit/                       # Unit tests for individual scripts
│   ├── test_bronze_ingest.py   # Bronze layer ingestion validation
│   ├── test_silver_transform.py # Silver layer transformation validation
│   └── ...
├── integration/                # Integration tests for E2E flows
│   ├── test_end_to_end.py      # Full pipeline validation
│   └── ...
└── README.md                   # This file
```

## Running Tests

### Prerequisites
```bash
pip install pytest pytest-spark
```

### Run all tests
```bash
pytest tests/
```

### Run specific test suite
```bash
pytest tests/unit/test_bronze_ingest.py -v
```

### Run with coverage
```bash
pytest tests/ --cov=bronze --cov=silver --cov-report=html
```

## Test Status — Phase 4a

- [x] Test structure created
- [ ] Unit tests implemented (TODO — requires Bronze/Silver data)
- [ ] Integration tests implemented (TODO — requires E2E run)
- [ ] Coverage: Target 80%+

## Notes

- Unit tests require Bronze/Silver Delta Lake tables to exist
- Integration tests will be fully implemented in Phase 4b (cloud promote)
- For local dev (Phase 4a), run `pytest tests/ -k "not integration"` to skip integration tests
