# Databricks notebook source
# MAGIC %md
# MAGIC # Export Silver Delta → Parquet for Snowflake
# MAGIC
# MAGIC **Phase:** 4b — Gold Layer Setup
# MAGIC **Owner:** DPE
# MAGIC
# MAGIC **Purpose:**
# MAGIC Export Silver Delta Lake tables ke Parquet format di ADLS Gen2,
# MAGIC untuk Snowflake external tables.
# MAGIC
# MAGIC **Output:**
# MAGIC - Parquet files: `silver_parquet/<table_name>/*.parquet`
# MAGIC - Snowflake boleh read via external stage

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Setup & Config

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from delta.tables import DeltaTable
import os

# Unity Catalog paths
CATALOG = "olist_catalog"
SILVER_SCHEMA = "silver"

# ADLS Gen2 paths
STORAGE_ACCOUNT = "azolistpiepeline"
CONTAINER = "olist-staging"
SILVER_DELTA_PATH = f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/silver"
PARQUET_OUTPUT_PATH = f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/silver_parquet"

# Tables to export
TABLES = [
    "orders",
    "order_items",
    "payments",
    "customers",
    "sellers",
    "products"
]

print(f"✅ Config loaded")
print(f"   Input  : {SILVER_DELTA_PATH}")
print(f"   Output : {PARQUET_OUTPUT_PATH}")
print(f"   Tables : {len(TABLES)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Export Functions

# COMMAND ----------

def export_delta_to_parquet(table_name: str, delta_path: str, parquet_path: str):
    """
    Export single Delta table to Parquet format.

    Args:
        table_name: Table name (e.g., "orders")
        delta_path: Source Delta table path
        parquet_path: Target Parquet output path
    """
    try:
        print(f"\n▶ Exporting {table_name}...")

        # Read Delta table
        df = spark.read.format("delta").load(f"{delta_path}/{table_name}")
        row_count = df.count()

        # Write to Parquet (overwrite existing)
        # Coalesce to reduce number of files for portfolio dataset (100k rows)
        output_path = f"{parquet_path}/{table_name}"

        df.coalesce(5).write \
            .mode("overwrite") \
            .format("parquet") \
            .save(output_path)

        print(f"   ✅ {table_name:15} | {row_count:>8} rows → {output_path}")

        return {
            "table": table_name,
            "rows": row_count,
            "status": "success",
            "path": output_path
        }

    except Exception as e:
        print(f"   ❌ {table_name} FAILED: {str(e)}")
        return {
            "table": table_name,
            "rows": 0,
            "status": "failed",
            "error": str(e)
        }

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Execute Export (All Tables)

# COMMAND ----------

results = []

print("=" * 70)
print("SILVER DELTA → PARQUET EXPORT")
print("=" * 70)

for table in TABLES:
    result = export_delta_to_parquet(
        table_name=table,
        delta_path=SILVER_DELTA_PATH,
        parquet_path=PARQUET_OUTPUT_PATH
    )
    results.append(result)

print("\n" + "=" * 70)
print("EXPORT SUMMARY")
print("=" * 70)

success_count = sum(1 for r in results if r["status"] == "success")
total_rows = sum(r["rows"] for r in results)

print(f"✅ Success: {success_count}/{len(TABLES)} tables")
print(f"📊 Total rows exported: {total_rows:,}")
print()

for r in results:
    status_icon = "✅" if r["status"] == "success" else "❌"
    print(f"{status_icon} {r['table']:15} | {r['rows']:>8} rows")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Verification

# COMMAND ----------

# Verify Parquet files created
print("\n" + "=" * 70)
print("PARQUET FILES VERIFICATION")
print("=" * 70)

for table in TABLES:
    try:
        parquet_path = f"{PARQUET_OUTPUT_PATH}/{table}"

        # List files
        files = dbutils.fs.ls(parquet_path)
        parquet_files = [f for f in files if f.name.endswith('.parquet')]

        # Read and count rows
        df = spark.read.parquet(parquet_path)
        row_count = df.count()
        file_count = len(parquet_files)

        print(f"✅ {table:15} | {file_count:>3} Parquet files | {row_count:>8} rows")

    except Exception as e:
        print(f"❌ {table:15} | ERROR: {str(e)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Sample Data Check

# COMMAND ----------

# Read sample data from Parquet to verify structure
print("\n" + "=" * 70)
print("SAMPLE DATA (orders)")
print("=" * 70)

sample_df = spark.read.parquet(f"{PARQUET_OUTPUT_PATH}/orders")
display(sample_df.limit(5))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Output for Snowflake Setup

# COMMAND ----------

print("\n" + "=" * 70)
print("SNOWFLAKE EXTERNAL STAGE CONFIG")
print("=" * 70)
print()
print("-- Use this URL in Snowflake external stage:")
print(f"URL = 'azure://{STORAGE_ACCOUNT}.blob.core.windows.net/{CONTAINER}/silver_parquet/'")
print()
print("-- External table locations:")
for table in TABLES:
    print(f"-- {table:15} → @silver_stage/{table}/")
print()
print("✅ Parquet export complete. Proceed to Snowflake setup.")
print("   Next: Run scripts/snowflake_setup.sql")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC ## Notes
# MAGIC
# MAGIC **Export format:**
# MAGIC - Coalesced to 5 partitions per table (portfolio dataset size)
# MAGIC - Overwrite mode (for Phase 4b one-time setup)
# MAGIC - Parquet format (Snowflake-compatible)
# MAGIC
# MAGIC **Next steps:**
# MAGIC 1. Run this notebook in Databricks
# MAGIC 2. Verify Parquet files created in ADLS Gen2
# MAGIC 3. Run `scripts/snowflake_setup.sql` to create external stage
# MAGIC 4. Run `dbt run` to build Gold marts
# MAGIC
# MAGIC **Production notes:**
# MAGIC - For incremental updates: filter by valid_from > last_export_timestamp
# MAGIC - Add partitioning for large datasets
# MAGIC - Consider Delta sharing or Snowflake Delta Lake connector (alternative)
