# Databricks notebook source
# MAGIC %md
# MAGIC # Bronze Layer Ingestion — Olist E-Commerce
# MAGIC **WHAT:** Ingest 9 CSV files from ADLS Gen2 landing/ → Bronze Delta Lake
# MAGIC **WHY:** Raw data persistence with ACID guarantees + metadata tracking
# MAGIC **WHEN:** First step in Medallion pipeline (Bronze layer)
# MAGIC
# MAGIC **Environment:** Serverless Starter Warehouse
# MAGIC **Storage:** Azure ADLS Gen2

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration

# COMMAND ----------

# Environment setup
ENV = "staging"  # Change to "prod" for production run

# Azure ADLS Gen2 Configuration
AZURE_STORAGE_ACCOUNT = "azolistpiepeline"
ADLS_CONTAINER = "olist-staging" if ENV == "staging" else "olist-prod"

# Paths
LANDING_PATH = f"abfss://{ADLS_CONTAINER}@{AZURE_STORAGE_ACCOUNT}.dfs.core.windows.net/landing"
BRONZE_PATH = f"abfss://{ADLS_CONTAINER}@{AZURE_STORAGE_ACCOUNT}.dfs.core.windows.net/bronze"

# Source files (9 CSVs from Kaggle Olist dataset)
OLIST_FILES = {
    "raw_orders": "olist_orders_dataset.csv",
    "raw_order_items": "olist_order_items_dataset.csv",
    "raw_payments": "olist_order_payments_dataset.csv",
    "raw_reviews": "olist_order_reviews_dataset.csv",
    "raw_customers": "olist_customers_dataset.csv",
    "raw_sellers": "olist_sellers_dataset.csv",
    "raw_products": "olist_products_dataset.csv",
    "raw_geolocation": "olist_geolocation_dataset.csv",
    "raw_category_translation": "product_category_name_translation.csv",
}

# Batch ID (YYYYMMDD_HHMMSS format)
from datetime import datetime
BATCH_ID = datetime.now().strftime("%Y%m%d_%H%M%S")

print(f"🔧 Configuration:")
print(f"   ENV: {ENV}")
print(f"   LANDING_PATH: {LANDING_PATH}")
print(f"   BRONZE_PATH: {BRONZE_PATH}")
print(f"   BATCH_ID: {BATCH_ID}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Azure Authentication
# MAGIC
# MAGIC **Unity Catalog Managed Identity** — authentication handled automatically via External Location.
# MAGIC No explicit configuration needed for Serverless compute.

# COMMAND ----------

# Unity Catalog authentication (automatic via External Location)
# Storage access configured through:
# - Storage Credential: olist_storage_credential (Azure Managed Identity)
# - External Location: olist_staging_landing
# - Permissions: Storage Blob Data Contributor + EventGrid + Queue

print("✅ Unity Catalog authentication active (via Managed Identity)")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Helper Functions

# COMMAND ----------

import hashlib
from pyspark.sql import functions as F
from pyspark.sql.types import StringType

def compute_row_hash(*cols):
    """Compute MD5 hash for deduplication"""
    concat_str = F.concat_ws("||", *cols)
    return F.md5(concat_str)

def ingest_csv_to_bronze(table_name: str, csv_filename: str, bronze_path: str, batch_id: str):
    """
    WHAT: Ingest single CSV → Bronze Delta Lake
    WHY : Standardize ingestion with metadata columns + deduplication
    WHEN: Called per CSV file

    Steps:
    1. Read CSV from landing/ (schema inference OFF — all STRING)
    2. Add metadata columns (ingestion_timestamp, source_system, batch_id, source_file_name, row_hash)
    3. Deduplicate by row_hash
    4. Write to Delta Lake (OVERWRITE mode for simplicity in Phase 4b)
    """

    print(f"\n📦 Ingesting {csv_filename} → bronze.{table_name}")

    # Read CSV (all columns as STRING to preserve raw data)
    landing_file = f"{LANDING_PATH}/{csv_filename}"
    df = spark.read.format("csv") \
        .option("header", "true") \
        .option("inferSchema", "false") \
        .load(landing_file)

    row_count_raw = df.count()
    print(f"   📊 Raw rows: {row_count_raw}")

    # Add metadata columns
    df = df.withColumn("ingestion_timestamp", F.current_timestamp()) \
           .withColumn("source_system", F.lit("kaggle_olist")) \
           .withColumn("batch_id", F.lit(batch_id)) \
           .withColumn("source_file_name", F.lit(csv_filename))

    # Compute row_hash for deduplication (MD5 of all original columns)
    original_cols = [c for c in df.columns if c not in ["ingestion_timestamp", "source_system", "batch_id", "source_file_name"]]
    df = df.withColumn("row_hash", compute_row_hash(*original_cols))

    # Deduplicate by row_hash (keep first occurrence)
    df = df.dropDuplicates(["row_hash"])

    row_count_deduped = df.count()
    duplicates = row_count_raw - row_count_deduped
    print(f"   🔍 Duplicates removed: {duplicates}")
    print(f"   ✅ Unique rows: {row_count_deduped}")

    # Write to Bronze Delta Lake
    output_path = f"{bronze_path}/{table_name}"
    df.write.format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(output_path)

    print(f"   💾 Written to: {output_path}")

    return row_count_deduped

# COMMAND ----------

# MAGIC %md
# MAGIC ## Execute Bronze Ingestion

# COMMAND ----------

print("="*70)
print("🚀 STARTING BRONZE LAYER INGESTION")
print("="*70)

summary = {}

for table_name, csv_filename in OLIST_FILES.items():
    try:
        row_count = ingest_csv_to_bronze(
            table_name=table_name,
            csv_filename=csv_filename,
            bronze_path=BRONZE_PATH,
            batch_id=BATCH_ID
        )
        summary[table_name] = {"status": "✅ SUCCESS", "rows": row_count}
    except Exception as e:
        summary[table_name] = {"status": f"❌ FAILED: {str(e)}", "rows": 0}
        print(f"   ❌ ERROR: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Summary

# COMMAND ----------

print("\n" + "="*70)
print("✅ BRONZE INGESTION COMPLETE")
print("="*70)
print(f"{'Table':<30} {'Status':<20} {'Rows':>10}")
print("-"*70)

for table_name, result in summary.items():
    status = result["status"]
    rows = result["rows"]
    print(f"{table_name:<30} {status:<20} {rows:>10,}")

print("="*70)

total_rows = sum([r["rows"] for r in summary.values() if isinstance(r["rows"], int)])
print(f"{'TOTAL':<30} {'':<20} {total_rows:>10,}")
print("="*70)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation — Check Delta Tables

# COMMAND ----------

# Verify Delta Lake tables are queryable
print("\n🔍 Validating Bronze Delta tables...")

for table_name in OLIST_FILES.keys():
    table_path = f"{BRONZE_PATH}/{table_name}"
    try:
        df = spark.read.format("delta").load(table_path)
        count = df.count()
        print(f"   ✅ {table_name}: {count:,} rows — Delta table valid")
    except Exception as e:
        print(f"   ❌ {table_name}: ERROR — {e}")

print("\n✅ Bronze validation complete")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Next Step
# MAGIC
# MAGIC Run notebook: **`02_silver_transformation.py`**
