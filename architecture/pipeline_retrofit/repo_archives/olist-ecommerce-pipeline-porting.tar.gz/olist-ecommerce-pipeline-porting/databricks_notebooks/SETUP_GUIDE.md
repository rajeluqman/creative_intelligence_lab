# Databricks Notebooks Setup Guide

## Quick Start (Phase 4b Execution)

### Option A: Quick Setup (Hardcode Credentials) — FASTEST ✅

**For portfolio/staging environment only. Not recommended for production.**

1. **Edit notebooks** — replace this line in BOTH notebooks:
   ```python
   AZURE_STORAGE_KEY = dbutils.secrets.get(scope="azure-secrets", key="storage-account-key")
   ```
   
   With:
   ```python
   AZURE_STORAGE_KEY = "<YOUR_AZURE_STORAGE_ACCOUNT_KEY>"
   ```

2. **Upload notebooks** to Databricks Workspace:
   - Databricks UI → **Workspace** → **Create** → **Import**
   - Select files: `01_bronze_ingestion.py`, `02_silver_transformation.py`
   - Upload to folder: `/Users/<your-email>/olist-pipeline/`

3. **Attach to Serverless Warehouse**:
   - Open each notebook
   - Click **"Connect"** dropdown → Select **"Serverless Starter Warehouse"**

4. **Execute**:
   - Run `01_bronze_ingestion.py` first (Bronze layer)
   - Then run `02_silver_transformation.py` (Silver layer)

---

### Option B: Secure Setup (Databricks Secrets) — RECOMMENDED for PROD

**Uses Azure Key Vault-backed Databricks Secrets Scope.**

#### Step 1: Create Azure Key Vault (if not exists)

```bash
# Azure CLI
az keyvault create \
  --name "olist-keyvault" \
  --resource-group "olist-ecommerce-pipeline" \
  --location "southeastasia"

# Store storage key in Key Vault
az keyvault secret set \
  --vault-name "olist-keyvault" \
  --name "storage-account-key" \
  --value "<YOUR_AZURE_STORAGE_ACCOUNT_KEY>"
```

#### Step 2: Create Databricks Secrets Scope

1. Go to: `https://dbc-c0cb6d3f-be56.cloud.databricks.com/#secrets/createScope`
2. Fill in:
   - **Scope Name**: `azure-secrets`
   - **Manage Principal**: `All Users` (for simplicity; restrict in prod)
   - **DNS Name**: (from Key Vault properties → Vault URI, e.g., `https://olist-keyvault.vault.azure.net/`)
   - **Resource ID**: (from Key Vault properties → Resource ID)

3. Click **Create**

#### Step 3: Verify Secret Access

In any Databricks notebook, run:
```python
storage_key = dbutils.secrets.get(scope="azure-secrets", key="storage-account-key")
print("✅ Secret retrieved successfully (length: " + str(len(storage_key)) + ")")
# DO NOT print the actual key!
```

#### Step 4: Upload & Run Notebooks

Same as Option A steps 2-4, but no need to edit the notebooks (they already reference the secrets scope).

---

## Execution Flow

```
1. bronze/download_dataset.py --env staging
   → Download 100k rows from Kaggle → upload to ADLS Gen2 landing/
   → Run locally (Codespace) BEFORE Databricks notebooks

2. Databricks: 01_bronze_ingestion.py
   → Read from ADLS landing/ → write Bronze Delta Lake
   → Expected: ~10 mins

3. Databricks: 02_silver_transformation.py
   → Read Bronze → transform → write Silver Delta Lake
   → Expected: ~15 mins

4. Snowflake: External Stage + dbt run
   → Read Silver Delta → create Gold marts
   → Run from local (dbt Core)
```

---

## Troubleshooting

### Error: "No module named 'delta'"
- Databricks Serverless Warehouse should have Delta Lake pre-installed
- Check notebook environment: **Base environment-standard v5** should include Delta

### Error: "Unable to access ADLS Gen2"
- Verify storage account key is correct
- Check container name matches: `olist-staging` (for staging env)
- Verify ADLS Gen2 firewall allows Databricks IPs (or set to "Allow all networks" for testing)

### Error: "Secrets scope not found"
- Go to `https://dbc-c0cb6d3f-be56.cloud.databricks.com/#secrets/list/scopes`
- Verify `azure-secrets` scope exists
- Check Key Vault access permissions

---

## Cost Monitoring

- Databricks Serverless: Check **SQL Warehouses** → **Starter Warehouse** → **Billing** tab
- ADLS Gen2: Azure Portal → Storage Account → **Metrics** (Storage used, Transactions)
- Expected Phase 4b cost: ~$3-5 USD total

---

## Next Steps After Notebooks Complete

1. Verify Silver Delta tables in ADLS Gen2: `abfss://olist-staging@azolistpiepeline.dfs.core.windows.net/silver/`
2. Configure Snowflake external stage (see `gold/dbt_models/README.md`)
3. Run `dbt run --target staging` from local
4. Execute Great Expectations validation suites
