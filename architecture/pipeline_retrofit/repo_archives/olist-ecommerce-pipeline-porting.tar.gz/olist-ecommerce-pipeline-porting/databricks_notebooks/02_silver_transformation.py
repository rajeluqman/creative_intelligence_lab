# Databricks notebook source
# MAGIC %md
# MAGIC # Silver Layer Transformation — Olist E-Commerce
# MAGIC **WHAT:** Transform Bronze → Silver dengan type casting, business rules, SCD Type 2
# MAGIC **WHY:** Cleansed, strongly-typed data ready untuk Gold dimensional modelling
# MAGIC **WHEN:** Run selepas Bronze ingestion — Silver layer pipeline
# MAGIC
# MAGIC **Environment:** Serverless Starter Warehouse (16GB RAM)
# MAGIC **Storage:** Azure ADLS Gen2

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration

# COMMAND ----------

# Environment setup
ENV = "staging"  # Change to "prod" for production run

# Azure ADLS Gen2 Configuration
AZURE_STORAGE_ACCOUNT = "azolistpiepeline"
ADLS_CONTAINER = "olist-staging" if ENV == "staging" else "olist-prod"

# Paths
BRONZE_PATH = f"abfss://{ADLS_CONTAINER}@{AZURE_STORAGE_ACCOUNT}.dfs.core.windows.net/bronze"
SILVER_PATH = f"abfss://{ADLS_CONTAINER}@{AZURE_STORAGE_ACCOUNT}.dfs.core.windows.net/silver"

print(f"🔧 Configuration:")
print(f"   ENV: {ENV}")
print(f"   BRONZE_PATH: {BRONZE_PATH}")
print(f"   SILVER_PATH: {SILVER_PATH}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Azure Authentication

# COMMAND ----------

# Unity Catalog authentication (automatic via External Location)
# Storage access configured through:
# - Storage Credential: olist_storage_credential (Azure Managed Identity)
# - External Location: olist_staging_landing
# - Permissions: Storage Blob Data Contributor + EventGrid + Queue

print("✅ Unity Catalog authentication active (via Managed Identity)")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import Libraries

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from delta.tables import DeltaTable
from datetime import datetime

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC # FACT TABLES TRANSFORMATION
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Transform Orders (Fact)

# COMMAND ----------

print("\n📦 Transforming bronze.raw_orders → silver.orders")

# Read Bronze
bronze_orders = spark.read.format("delta").load(f"{BRONZE_PATH}/raw_orders")
bronze_reviews = spark.read.format("delta").load(f"{BRONZE_PATH}/raw_reviews")

# Type casting
silver_orders = bronze_orders \
    .withColumn("order_purchase_timestamp", F.to_timestamp("order_purchase_timestamp")) \
    .withColumn("order_approved_at", F.to_timestamp("order_approved_at")) \
    .withColumn("order_delivered_carrier_date", F.to_timestamp("order_delivered_carrier_date")) \
    .withColumn("order_delivered_customer_date", F.to_timestamp("order_delivered_customer_date")) \
    .withColumn("order_estimated_delivery_date", F.to_timestamp("order_estimated_delivery_date"))

# Derived columns
silver_orders = silver_orders \
    .withColumn("is_delivered",
                (F.col("order_status") == "delivered") & F.col("order_delivered_customer_date").isNotNull()) \
    .withColumn("is_on_time",
                F.when(F.col("is_delivered"),
                       F.col("order_delivered_customer_date") <= F.col("order_estimated_delivery_date"))
                 .otherwise(None)) \
    .withColumn("dq_approved_flag",
                F.col("order_approved_at").isNotNull())

# Join reviews for review_score aggregation
# Use SQL TRY_CAST expression to handle malformed values
from pyspark.sql.functions import expr

avg_review = bronze_reviews.groupBy("order_id") \
    .agg(F.avg(expr("TRY_CAST(review_score AS DOUBLE)")).cast("decimal(3,2)").alias("review_score"))

silver_orders = silver_orders.join(avg_review, on="order_id", how="left")

# Deduplication (keep latest by ingestion_timestamp)
window = Window.partitionBy("order_id").orderBy(F.desc("ingestion_timestamp"))
silver_orders = silver_orders \
    .withColumn("row_num", F.row_number().over(window)) \
    .filter(F.col("row_num") == 1) \
    .drop("row_num")

# Metadata
silver_orders = silver_orders \
    .withColumn("valid_from", F.current_timestamp()) \
    .withColumn("valid_to", F.lit(None).cast("timestamp")) \
    .withColumn("is_current", F.lit(True)) \
    .withColumn("source_batch_id", F.col("batch_id"))

# Select final columns
silver_orders = silver_orders.select(
    "order_id",
    "customer_id",
    "order_status",
    "order_purchase_timestamp",
    "order_approved_at",
    "order_delivered_carrier_date",
    "order_delivered_customer_date",
    "order_estimated_delivery_date",
    "is_delivered",
    "is_on_time",
    "review_score",
    "dq_approved_flag",
    "valid_from",
    "valid_to",
    "is_current",
    "source_batch_id"
)

# Write to Delta
silver_orders.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(f"{SILVER_PATH}/orders")
orders_count = silver_orders.count()
print(f"  ✅ silver.orders: {orders_count:,} rows written")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Transform Order Items (Fact)

# COMMAND ----------

print("\n📦 Transforming bronze.raw_order_items → silver.order_items")

bronze_order_items = spark.read.format("delta").load(f"{BRONZE_PATH}/raw_order_items")

silver_order_items = bronze_order_items \
    .withColumn("order_item_id", F.col("order_item_id").cast("int")) \
    .withColumn("price", F.col("price").cast("decimal(10,2)")) \
    .withColumn("freight_value", F.col("freight_value").cast("decimal(10,2)")) \
    .withColumn("shipping_limit_date", F.to_timestamp("shipping_limit_date")) \
    .withColumn("gmv", F.col("price") + F.col("freight_value")) \
    .withColumn("dq_zero_price_flag", F.col("price") == 0.00)

# Deduplication
window = Window.partitionBy("order_id", "order_item_id").orderBy(F.desc("ingestion_timestamp"))
silver_order_items = silver_order_items \
    .withColumn("row_num", F.row_number().over(window)) \
    .filter(F.col("row_num") == 1) \
    .drop("row_num")

# Metadata
silver_order_items = silver_order_items \
    .withColumn("valid_from", F.current_timestamp()) \
    .withColumn("source_batch_id", F.col("batch_id"))

# Select final columns
silver_order_items = silver_order_items.select(
    "order_id",
    "order_item_id",
    "product_id",
    "seller_id",
    "shipping_limit_date",
    "price",
    "freight_value",
    "gmv",
    "dq_zero_price_flag",
    "valid_from",
    "source_batch_id"
)

silver_order_items.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(f"{SILVER_PATH}/order_items")
order_items_count = silver_order_items.count()
print(f"  ✅ silver.order_items: {order_items_count:,} rows written")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Transform Payments (Fact)

# COMMAND ----------

print("\n📦 Transforming bronze.raw_payments → silver.payments")

bronze_payments = spark.read.format("delta").load(f"{BRONZE_PATH}/raw_payments")

silver_payments = bronze_payments \
    .withColumn("payment_sequential", F.col("payment_sequential").cast("int")) \
    .withColumn("payment_installments", F.col("payment_installments").cast("int")) \
    .withColumn("payment_value", F.col("payment_value").cast("decimal(10,2)"))

# Deduplication
window = Window.partitionBy("order_id", "payment_sequential").orderBy(F.desc("ingestion_timestamp"))
silver_payments = silver_payments \
    .withColumn("row_num", F.row_number().over(window)) \
    .filter(F.col("row_num") == 1) \
    .drop("row_num")

# Metadata
silver_payments = silver_payments \
    .withColumn("valid_from", F.current_timestamp()) \
    .withColumn("source_batch_id", F.col("batch_id"))

# Select final columns
silver_payments = silver_payments.select(
    "order_id",
    "payment_sequential",
    "payment_type",
    "payment_installments",
    "payment_value",
    "valid_from",
    "source_batch_id"
)

silver_payments.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(f"{SILVER_PATH}/payments")
payments_count = silver_payments.count()
print(f"  ✅ silver.payments: {payments_count:,} rows written")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC # DIMENSION TABLES TRANSFORMATION
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Transform Customers (SCD Type 2)

# COMMAND ----------

print("\n📦 Transforming bronze.raw_customers → silver.customers (SCD Type 2)")

bronze_customers = spark.read.format("delta").load(f"{BRONZE_PATH}/raw_customers")

silver_table_path = f"{SILVER_PATH}/customers"
table_exists = DeltaTable.isDeltaTable(spark, silver_table_path)

if not table_exists:
    # Initial load: assign customer_key
    print("  🆕 Initial load — assigning customer_key")
    silver_customers = bronze_customers \
        .withColumn("customer_key", F.row_number().over(Window.orderBy("customer_unique_id"))) \
        .withColumn("valid_from", F.current_timestamp()) \
        .withColumn("valid_to", F.lit(None).cast("timestamp")) \
        .withColumn("is_current", F.lit(True)) \
        .withColumn("source_batch_id", F.col("batch_id"))

    silver_customers = silver_customers.select(
        "customer_key",
        "customer_unique_id",
        "customer_id",
        "customer_zip_code_prefix",
        "customer_city",
        "customer_state",
        "valid_from",
        "valid_to",
        "is_current",
        "source_batch_id"
    )

    silver_customers.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(silver_table_path)
    customers_count = silver_customers.count()
    print(f"  ✅ silver.customers: {customers_count:,} rows written (initial load)")

else:
    # SCD Type 2 MERGE logic
    print("  🔄 Incremental load — applying SCD Type 2 logic")

    existing = spark.read.format("delta").load(silver_table_path)
    max_key = existing.agg(F.max("customer_key")).collect()[0][0] or 0

    # Identify changes (zip_code_prefix changed or new customer)
    changes = bronze_customers.alias("new") \
        .join(
            existing.filter(F.col("is_current")).alias("old"),
            on="customer_unique_id",
            how="left"
        ) \
        .where(
            (F.col("new.customer_zip_code_prefix") != F.col("old.customer_zip_code_prefix")) |
            F.col("old.customer_key").isNull()
        ) \
        .select("new.*")

    changes_count = changes.count()
    print(f"  📊 Detected {changes_count:,} changes/new customers")

    if changes_count > 0:
        # Expire old records
        delta_table = DeltaTable.forPath(spark, silver_table_path)
        changed_ids = changes.select("customer_unique_id").distinct()

        delta_table.alias("target") \
            .merge(
                changed_ids.alias("source"),
                "target.customer_unique_id = source.customer_unique_id AND target.is_current = TRUE"
            ) \
            .whenMatchedUpdate(
                set={
                    "valid_to": F.current_timestamp(),
                    "is_current": F.lit(False)
                }
            ) \
            .execute()

        # Insert new records with new customer_key
        new_records = changes \
            .withColumn("customer_key", F.row_number().over(Window.orderBy("customer_unique_id")) + max_key) \
            .withColumn("valid_from", F.current_timestamp()) \
            .withColumn("valid_to", F.lit(None).cast("timestamp")) \
            .withColumn("is_current", F.lit(True)) \
            .withColumn("source_batch_id", F.col("batch_id"))

        new_records = new_records.select(
            "customer_key",
            "customer_unique_id",
            "customer_id",
            "customer_zip_code_prefix",
            "customer_city",
            "customer_state",
            "valid_from",
            "valid_to",
            "is_current",
            "source_batch_id"
        )

        new_records.write.format("delta").mode("append").save(silver_table_path)
        print(f"  ✅ silver.customers: {changes_count:,} new versions appended")

    else:
        print(f"  ℹ️  No changes detected — SCD Type 2 MERGE skipped")

    customers_count = spark.read.format("delta").load(silver_table_path).count()

print(f"  📊 Total rows in silver.customers: {customers_count:,}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Transform Sellers (SCD Type 2)

# COMMAND ----------

print("\n📦 Transforming bronze.raw_sellers → silver.sellers (SCD Type 2)")

bronze_sellers = spark.read.format("delta").load(f"{BRONZE_PATH}/raw_sellers")

silver_table_path = f"{SILVER_PATH}/sellers"
table_exists = DeltaTable.isDeltaTable(spark, silver_table_path)

if not table_exists:
    # Initial load
    print("  🆕 Initial load — assigning seller_key")
    silver_sellers = bronze_sellers \
        .withColumn("seller_key", F.row_number().over(Window.orderBy("seller_id"))) \
        .withColumn("valid_from", F.current_timestamp()) \
        .withColumn("valid_to", F.lit(None).cast("timestamp")) \
        .withColumn("is_current", F.lit(True)) \
        .withColumn("source_batch_id", F.col("batch_id"))

    silver_sellers = silver_sellers.select(
        "seller_key",
        "seller_id",
        "seller_zip_code_prefix",
        "seller_city",
        "seller_state",
        "valid_from",
        "valid_to",
        "is_current",
        "source_batch_id"
    )

    silver_sellers.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(silver_table_path)
    sellers_count = silver_sellers.count()
    print(f"  ✅ silver.sellers: {sellers_count:,} rows written (initial load)")

else:
    # SCD Type 2 MERGE logic
    print("  🔄 Incremental load — applying SCD Type 2 logic")

    existing = spark.read.format("delta").load(silver_table_path)
    max_key = existing.agg(F.max("seller_key")).collect()[0][0] or 0

    # Identify changes (city/state changed or new seller)
    changes = bronze_sellers.alias("new") \
        .join(
            existing.filter(F.col("is_current")).alias("old"),
            on="seller_id",
            how="left"
        ) \
        .where(
            (F.col("new.seller_city") != F.col("old.seller_city")) |
            (F.col("new.seller_state") != F.col("old.seller_state")) |
            F.col("old.seller_key").isNull()
        ) \
        .select("new.*")

    changes_count = changes.count()
    print(f"  📊 Detected {changes_count:,} changes/new sellers")

    if changes_count > 0:
        # Expire old records
        delta_table = DeltaTable.forPath(spark, silver_table_path)
        changed_ids = changes.select("seller_id").distinct()

        delta_table.alias("target") \
            .merge(
                changed_ids.alias("source"),
                "target.seller_id = source.seller_id AND target.is_current = TRUE"
            ) \
            .whenMatchedUpdate(
                set={
                    "valid_to": F.current_timestamp(),
                    "is_current": F.lit(False)
                }
            ) \
            .execute()

        # Insert new records
        new_records = changes \
            .withColumn("seller_key", F.row_number().over(Window.orderBy("seller_id")) + max_key) \
            .withColumn("valid_from", F.current_timestamp()) \
            .withColumn("valid_to", F.lit(None).cast("timestamp")) \
            .withColumn("is_current", F.lit(True)) \
            .withColumn("source_batch_id", F.col("batch_id"))

        new_records = new_records.select(
            "seller_key",
            "seller_id",
            "seller_zip_code_prefix",
            "seller_city",
            "seller_state",
            "valid_from",
            "valid_to",
            "is_current",
            "source_batch_id"
        )

        new_records.write.format("delta").mode("append").save(silver_table_path)
        print(f"  ✅ silver.sellers: {changes_count:,} new versions appended")

    else:
        print(f"  ℹ️  No changes detected — SCD Type 2 MERGE skipped")

    sellers_count = spark.read.format("delta").load(silver_table_path).count()

print(f"  📊 Total rows in silver.sellers: {sellers_count:,}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Transform Products (SCD Type 1)

# COMMAND ----------

print("\n📦 Transforming bronze.raw_products → silver.products (SCD Type 1)")

bronze_products = spark.read.format("delta").load(f"{BRONZE_PATH}/raw_products")
bronze_translation = spark.read.format("delta").load(f"{BRONZE_PATH}/raw_category_translation")

# Join with translation table
silver_products = bronze_products \
    .join(bronze_translation, on="product_category_name", how="left") \
    .withColumn("product_category_name_english",
                F.coalesce(F.col("product_category_name_english"), F.lit("uncategorized")))

# Type casting for numeric columns
silver_products = silver_products \
    .withColumn("product_name_length", F.col("product_name_length").cast("int")) \
    .withColumn("product_description_length", F.col("product_description_length").cast("int")) \
    .withColumn("product_photos_qty", F.col("product_photos_qty").cast("int")) \
    .withColumn("product_weight_g", F.col("product_weight_g").cast("int")) \
    .withColumn("product_length_cm", F.col("product_length_cm").cast("int")) \
    .withColumn("product_height_cm", F.col("product_height_cm").cast("int")) \
    .withColumn("product_width_cm", F.col("product_width_cm").cast("int"))

# Assign product_key
silver_products = silver_products \
    .withColumn("product_key", F.row_number().over(Window.orderBy("product_id"))) \
    .withColumn("valid_from", F.current_timestamp()) \
    .withColumn("source_batch_id", F.col("batch_id"))

# Select final columns
silver_products = silver_products.select(
    "product_key",
    "product_id",
    "product_category_name",
    "product_category_name_english",
    "product_name_length",
    "product_description_length",
    "product_photos_qty",
    "product_weight_g",
    "product_length_cm",
    "product_height_cm",
    "product_width_cm",
    "valid_from",
    "source_batch_id"
)

# Overwrite mode (SCD Type 1)
silver_products.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(f"{SILVER_PATH}/products")
products_count = silver_products.count()
print(f"  ✅ silver.products: {products_count:,} rows written (SCD Type 1)")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Transform Geolocation (Reference)

# COMMAND ----------

print("\n📦 Transforming bronze.raw_geolocation → silver.geolocation")

bronze_geo = spark.read.format("delta").load(f"{BRONZE_PATH}/raw_geolocation")

silver_geo = bronze_geo \
    .withColumn("geolocation_lat", F.col("geolocation_lat").cast("decimal(9,6)")) \
    .withColumn("geolocation_lng", F.col("geolocation_lng").cast("decimal(9,6)")) \
    .withColumn("valid_from", F.current_timestamp()) \
    .withColumn("source_batch_id", F.col("batch_id"))

# Deduplicate by zip_code_prefix (keep first)
window = Window.partitionBy("geolocation_zip_code_prefix").orderBy("ingestion_timestamp")
silver_geo = silver_geo \
    .withColumn("row_num", F.row_number().over(window)) \
    .filter(F.col("row_num") == 1) \
    .drop("row_num")

silver_geo = silver_geo.select(
    "geolocation_zip_code_prefix",
    "geolocation_lat",
    "geolocation_lng",
    "geolocation_city",
    "geolocation_state",
    "valid_from",
    "source_batch_id"
)

silver_geo.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(f"{SILVER_PATH}/geolocation")
geolocation_count = silver_geo.count()
print(f"  ✅ silver.geolocation: {geolocation_count:,} rows written")

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC # SUMMARY
# MAGIC ---

# COMMAND ----------

print("\n" + "="*70)
print("✅ SILVER TRANSFORMATION COMPLETE")
print("="*70)
print(f"  silver.orders              : {orders_count:>10,} rows")
print(f"  silver.order_items         : {order_items_count:>10,} rows")
print(f"  silver.payments            : {payments_count:>10,} rows")
print(f"  silver.customers           : {customers_count:>10,} rows")
print(f"  silver.sellers             : {sellers_count:>10,} rows")
print(f"  silver.products            : {products_count:>10,} rows")
print(f"  silver.geolocation         : {geolocation_count:>10,} rows")
print("="*70)

total_rows = orders_count + order_items_count + payments_count + customers_count + sellers_count + products_count + geolocation_count
print(f"  TOTAL                      : {total_rows:>10,} rows")
print("="*70)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation — Check Delta Tables

# COMMAND ----------

print("\n🔍 Validating Silver Delta tables...")

tables = ["orders", "order_items", "payments", "customers", "sellers", "products", "geolocation"]

for table_name in tables:
    table_path = f"{SILVER_PATH}/{table_name}"
    try:
        df = spark.read.format("delta").load(table_path)
        count = df.count()
        print(f"   ✅ {table_name}: {count:,} rows — Delta table valid")
    except Exception as e:
        print(f"   ❌ {table_name}: ERROR — {e}")

print("\n✅ Silver validation complete")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Next Step
# MAGIC
# MAGIC Configure Snowflake external stage pointing to Silver Delta tables, then run dbt models.
