# REPO_MAP — generated navigation index

> **GENERATED — do not hand-edit.** `python scripts/gen_repo_map.py` rebuilds it from
> ground truth; CI runs `--check` and fails if this file is stale. Purpose is extracted
> from each file's own docstring / first heading / leading comment; *Uses* and *Used by*
> are parsed (`ast` for Python, `ref()` for dbt), never authored.
>
> **This is a pointer, not a cache.** It tells you which file to open — then READ THAT
> FILE FRESH before you edit or assert about it (ANTI-SHORTCUT PROTOCOL, CLAUDE.md).

**108 files mapped.**

## Architecture Decision Records

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `docs/ADR/ADR-000-template.md` | ADR-[NNN]: [Decision Title] | — | — |
| `docs/ADR/ADR-001-data-modelling-paradigm.md` | ADR-001: Data Modelling Paradigm — Kimball Star Schema | — | — |
| `docs/ADR/ADR-002-scd-strategy.md` | ADR-002: SCD Strategy — Type 2 for customers/sellers, Type 1 for products | — | — |
| `docs/ADR/ADR-003-slack-alerting.md` | ADR-003: Slack Failure Alerting — backfill from print-based callbacks | — | — |

## Top-level docs

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `CLAUDE.md` | Olist E-Commerce Pipeline — AI Context | — | — |
| `COST_LOG.md` | Cost Log — Olist E-Commerce Pipeline | — | — |
| `DECISION_LOG.md` | Decision Log — Olist E-Commerce Pipeline | — | — |
| `INTERVIEW_GUIDE.md` | Interview Guide — Olist E-Commerce Pipeline | — | — |
| `PROJECT_STATUS.md` | Olist E-Commerce Pipeline — Project Status | — | — |
| `README.md` | olist-ecommerce-pipeline | — | — |
| `confluence/00_START_HERE.md` | Start Here — Olist E-Commerce Pipeline | — | — |
| `docs/ARCHITECTURE.md` | ARCHITECTURE: Olist E-Commerce Pipeline | — | — |
| `docs/BRD.md` | BRD: Olist E-Commerce Pipeline | — | — |
| `docs/DATA_DICTIONARY.md` | Data Dictionary: Olist E-Commerce Pipeline | — | — |
| `docs/DATA_MODEL.md` | DATA_MODEL: Olist E-Commerce Pipeline | — | — |
| `docs/DQD.md` | DQD: Olist E-Commerce Pipeline | — | — |
| `docs/DRD.md` | DRD: Data Requirements Document | — | — |
| `docs/OPS_RUNBOOK.md` | OPS Runbook: Olist E-Commerce Pipeline | — | — |
| `docs/PHASE_4B_TECHNICAL_LOG.md` | Phase 4B Technical Decision & Troubleshooting Log | — | — |
| `docs/PHASE_4B_TROUBLESHOOTING_LOG.md` | Phase 4B Troubleshooting & Technical Decisions Log | — | — |
| `docs/PIPELINE_SPEC.md` | PIPELINE_SPEC: Olist E-Commerce Pipeline | — | — |

## dbt — staging

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `gold/dbt_models/models/staging/schema.yml` | — | — | — |
| `gold/dbt_models/models/staging/stg_customers.sql` | (no leading -- comment) | — | int_customers_scd2.sql |
| `gold/dbt_models/models/staging/stg_order_items.sql` | (no leading -- comment) | — | fact_order_items.sql |
| `gold/dbt_models/models/staging/stg_orders.sql` | (no leading -- comment) | — | fact_orders.sql |
| `gold/dbt_models/models/staging/stg_payments.sql` | (no leading -- comment) | — | fact_payments.sql |
| `gold/dbt_models/models/staging/stg_products.sql` | (no leading -- comment) | — | dim_products.sql |
| `gold/dbt_models/models/staging/stg_sellers.sql` | (no leading -- comment) | — | int_sellers_scd2.sql |

## dbt — intermediate

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `gold/dbt_models/models/intermediate/int_customers_scd2.sql` | (no leading -- comment) | stg_customers.sql | dim_customers.sql |
| `gold/dbt_models/models/intermediate/int_sellers_scd2.sql` | (no leading -- comment) | stg_sellers.sql | dim_sellers.sql |

## dbt — marts

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `gold/dbt_models/models/marts/dim_customers.sql` | (no leading -- comment) | int_customers_scd2.sql | fact_orders.sql |
| `gold/dbt_models/models/marts/dim_date.sql` | (no leading -- comment) | — | fact_orders.sql |
| `gold/dbt_models/models/marts/dim_products.sql` | (no leading -- comment) | stg_products.sql | fact_order_items.sql |
| `gold/dbt_models/models/marts/dim_sellers.sql` | (no leading -- comment) | int_sellers_scd2.sql | fact_order_items.sql |
| `gold/dbt_models/models/marts/fact_order_items.sql` | (no leading -- comment) | dim_products.sql, dim_sellers.sql, stg_order_items.sql | — |
| `gold/dbt_models/models/marts/fact_orders.sql` | (no leading -- comment) | dim_customers.sql, dim_date.sql, stg_orders.sql | — |
| `gold/dbt_models/models/marts/fact_payments.sql` | (no leading -- comment) | stg_payments.sql | — |
| `gold/dbt_models/models/marts/schema.yml` | — | — | — |

## dbt — other

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `gold/dbt_models/.user.yml` | — | — | — |
| `gold/dbt_models/dbt_project.yml` | dbt_project.yml — Olist E-Commerce Gold Layer | — | — |
| `gold/dbt_models/package-lock.yml` | — | — | — |
| `gold/dbt_models/packages.yml` | packages.yml — dbt dependencies | — | — |

## Databricks notebooks (Bronze/Silver)

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `databricks_notebooks/01_bronze_ingestion.py` | (no module docstring) | — | — |
| `databricks_notebooks/02_silver_transformation.py` | (no module docstring) | — | — |
| `databricks_notebooks/03_export_silver_to_parquet.py` | (no module docstring) | — | — |
| `databricks_notebooks/SETUP_GUIDE.md` | Databricks Notebooks Setup Guide | — | — |

## Bronze ingestion

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `bronze/bronze_pipeline.py` | Bronze Layer Pipeline Wrapper | — | — |
| `bronze/download_dataset.py` | download_dataset.py — Olist Brazilian E-Commerce | — | — |
| `bronze/ingest_to_delta.py` | ingest_to_delta.py — Bronze Layer Ingestion | — | — |

## Silver transforms

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `silver/silver_pipeline.py` | Silver Layer Pipeline Wrapper | — | — |
| `silver/transform_silver.py` | transform_silver.py — Silver Layer Transformation | — | — |

## Airflow DAGs

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `airflow/dags/olist_pipeline_dag.py` | olist_pipeline_dag.py — Olist E-Commerce Pipeline | — | — |

## Great Expectations / data quality

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `data_quality/great_expectations/.gitignore` | — | — | — |
| `data_quality/great_expectations/checkpoints/bronze_checkpoint.yml` | — | — | — |
| `data_quality/great_expectations/checkpoints/silver_checkpoint.yml` | — | — | — |
| `data_quality/great_expectations/expectations/.ge_store_backend_id` | — | — | — |
| `data_quality/great_expectations/expectations/bronze_suite.json` | — | — | — |
| `data_quality/great_expectations/expectations/gold_suite.json` | — | — | — |
| `data_quality/great_expectations/expectations/silver_suite.json` | — | — | — |
| `data_quality/great_expectations/great_expectations.yml` | Welcome to Great Expectations! Always know what to expect from your data. | — | — |
| `data_quality/great_expectations/plugins/custom_data_docs/styles/data_docs_custom_styles.css` | — | — | — |
| `data_quality/run_bronze_validation.py` | Bronze Layer Data Quality Validation | — | — |
| `data_quality/run_silver_suite.py` | Airflow-compatible wrapper for Silver layer data quality validation | — | — |
| `data_quality/run_silver_validation.py` | Silver Layer Data Quality Validation | — | — |
| `data_quality/validation_summary.html` | — | — | — |

## Tests / contracts

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `tests/README.md` | Olist E-Commerce Pipeline — Tests | — | — |
| `tests/boundary_contract.py` | Stack + scope boundary contract — deterministic gate over this repo's locked stack. | — | — |
| `tests/doc_reference_contract.py` | Doc-reference contract — deterministic gate against documentation drift. | — | — |
| `tests/identity_contract.py` | Identity contract — deterministic gate over the SCD2 customer/seller grain. | — | — |
| `tests/integration/test_end_to_end.py` | Integration tests for end-to-end pipeline | — | — |
| `tests/unit/test_bronze_ingest.py` | Unit tests for bronze/ingest_to_delta.py | — | — |
| `tests/unit/test_silver_transform.py` | Unit tests for silver/transform_silver.py | — | — |

## Governance hooks

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `.claude/hooks/governance_guard.py` | Governance hook — makes Claude check governed docs/ADRs BEFORE and AFTER touching governed | — | — |

## Cabinet agents

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `.claude/agents/business-analyst.md` | name: business-analyst | — | — |
| `.claude/agents/cikgu.md` | name: cikgu | — | — |
| `.claude/agents/data-architect.md` | name: data-architect | — | — |
| `.claude/agents/data-platform-engineer.md` | name: data-platform-engineer | — | — |
| `.claude/agents/data-quality-steward.md` | name: data-quality-steward | — | — |
| `.claude/agents/documentation-sherpa.md` | name: documentation-sherpa | — | — |
| `.claude/agents/product-owner.md` | name: product-owner | — | — |
| `.claude/agents/scope-guardian.md` | name: scope-guardian | — | — |
| `.claude/agents/senior-data-engineer.md` | name: senior-data-engineer | — | — |

## Learning

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `learning/CURRICULUM.md` | Learning Curriculum — Olist E-Commerce Pipeline | — | — |
| `learning/LEARNING_LOG.md` | Learning Log — Olist E-Commerce Pipeline | — | — |

## Simulation lab

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `simulation/ISOLATION_CONTRACT.md` | Isolation Contract — Olist Simulation Lab | — | — |
| `simulation/check_isolation.py` | Isolation guard for the Olist simulation lab (simulation/). | — | — |
| `simulation/faults/README.md` | Fault Catalog — Olist Simulation Lab | — | — |
| `simulation/faults/inject.py` | Inject a named, reversible fault into the SIM lab only (never touches real models). | — | — |
| `simulation/faults/reset.py` | Reset the SIM lab to clean baseline — re-seed + re-build sim only. Never hand-patched. | — | — |
| `simulation/sim_dbt/dbt_project.yml` | — | — | — |
| `simulation/specs/01_SIM_scd2_troubleshoot.md` | SIM Spec — SCD2 Effective-Date Troubleshoot Drill | — | — |
| `simulation/specs/02_SIM_migration_bronze_partition.md` | SIM Spec — Bronze Delta Partition Migration Drill | — | — |
| `simulation/specs/03_SIM_snowflake_stage_optimize.md` | SIM Spec — Snowflake External Stage Permission Optimization Drill | — | — |
| `simulation/specs/04_SIM_value_reconciliation_dso.md` | SIM Spec — DSO Value-Reconciliation Drill | — | — |

## Scripts

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `scripts/PHASE_4B_EXECUTION_GUIDE.md` | Phase 4b Execution Guide — Gold Layer (Snowflake + dbt) | — | — |
| `scripts/gen_repo_map.py` | Repo-map generator — the NAVIGATION half of the ANTI-SHORTCUT PROTOCOL (see CLAUDE.md). | — | — |
| `scripts/run_dbt.sh` | — | — | — |
| `scripts/snowflake_create_tables_from_parquet.sql` | snowflake_create_tables_from_parquet.sql | — | — |
| `scripts/snowflake_load_WORKING.sql` | snowflake_load_WORKING.sql | — | — |
| `scripts/snowflake_load_parquet_FIXED.sql` | snowflake_load_parquet_FIXED.sql | — | — |
| `scripts/snowflake_setup.sql` | snowflake_setup.sql | — | — |
| `scripts/snowflake_setup_READY.sql` | snowflake_setup_READY.sql | — | — |
| `scripts/snowflake_setup_STORAGE_KEY.sql` | snowflake_setup_STORAGE_KEY.sql | — | — |
| `scripts/sync_docs_to_confluence.py` | Publish this repo's real docs/ set to Confluence as living documentation. | — | — |
| `scripts/test_pipeline_orchestration.py` | Pipeline Orchestration Test Script | — | — |
| `scripts/verify_credentials.py` | Credential Verification Script — DPE owned | — | — |

## Config

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `setup.sh` | — | — | — |

## Other

| File | Purpose | Uses | Used by |
|------|---------|------|---------|
| `requirements.txt` | — | — | — |
