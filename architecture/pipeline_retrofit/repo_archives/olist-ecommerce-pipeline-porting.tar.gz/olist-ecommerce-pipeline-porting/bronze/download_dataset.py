"""
download_dataset.py — Olist Brazilian E-Commerce
WHAT: Download semua 9 Olist CSVs dari Kaggle, sample untuk dev, upload ke ADLS untuk staging/prod
WHY : Single entry point untuk dataset acquisition semua environments
WHEN: Run sebelum Bronze pipeline — sekali per environment setup
"""

import os
import argparse
import pandas as pd
from pathlib import Path
from dotenv import load_dotenv

# =============================================================================
# CONFIG
# =============================================================================

KAGGLE_DATASET = "olistbr/brazilian-ecommerce"
OLIST_FILES = [
    "olist_orders_dataset.csv",
    "olist_order_items_dataset.csv",
    "olist_order_payments_dataset.csv",
    "olist_order_reviews_dataset.csv",
    "olist_customers_dataset.csv",
    "olist_sellers_dataset.csv",
    "olist_products_dataset.csv",
    "olist_geolocation_dataset.csv",
    "product_category_name_translation.csv",
]

# =============================================================================
# AZURE UPLOAD
# =============================================================================

def upload_to_adls(local_path: str, adls_path: str) -> None:
    """
    WHAT: Upload file ke Azure ADLS Gen2
    WHY : staging/prod environments guna ADLS sebagai landing zone
    WHEN: Dipanggil selepas download untuk env=staging/prod
    """
    from azure.storage.filedatalake import DataLakeServiceClient

    account = os.environ["AZURE_STORAGE_ACCOUNT"]
    key     = os.environ["AZURE_STORAGE_KEY"]
    env     = os.environ.get("ENV", "dev")

    container_map = {
        "staging": os.environ.get("ADLS_CONTAINER_STAGING", "olist-staging"),
        "prod"   : os.environ.get("ADLS_CONTAINER_PROD", "olist-prod"),
    }
    container = container_map.get(env, "olist-staging")

    service_client = DataLakeServiceClient(
        account_url=f"https://{account}.dfs.core.windows.net",
        credential=key
    )
    fs_client   = service_client.get_file_system_client(file_system=container)
    file_client = fs_client.get_file_client(adls_path)

    with open(local_path, "rb") as f:
        file_client.upload_data(f, overwrite=True)

    full_path = f"abfss://{container}@{account}.dfs.core.windows.net/{adls_path}"
    print(f"  ✅ Uploaded → {full_path}")
    return full_path


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", choices=["dev", "staging", "prod"], default="dev")
    args = parser.parse_args()

    env_file = f".env.{args.env}"
    load_dotenv(env_file)
    print(f"\n📦 download_dataset.py — env={args.env}")

    import kaggle
    kaggle.api.authenticate()

    # Download semua files
    download_dir = Path("data/raw")
    download_dir.mkdir(parents=True, exist_ok=True)
    print(f"⬇️  Downloading {KAGGLE_DATASET}...")
    kaggle.api.dataset_download_files(KAGGLE_DATASET, path=str(download_dir), unzip=True)
    print(f"✅ Download complete → {download_dir}/")

    if args.env == "dev":
        # Sample 1000 rows per file, save locally
        sample_dir = Path(f"data/olist_dev_{os.environ.get('DEV_SAMPLE_ROWS', 1000)}rows")
        sample_dir.mkdir(parents=True, exist_ok=True)
        for fname in OLIST_FILES:
            src = download_dir / fname
            if src.exists():
                df = pd.read_csv(src, nrows=int(os.environ.get("DEV_SAMPLE_ROWS", 1000)))
                dst = sample_dir / fname
                df.to_csv(dst, index=False)
                print(f"  ✅ Sampled {len(df)} rows → {dst}")
        # Update .env.dev
        with open(".env.dev", "a") as f:
            f.write(f"\nDATASET_SOURCE_PATH=data/olist_dev_{os.environ.get('DEV_SAMPLE_ROWS', 1000)}rows/\n")
        print(f"\n✅ Dev sample ready. DATASET_SOURCE_PATH updated in .env.dev")

    else:
        # Upload full dataset ke ADLS
        account   = os.environ["AZURE_STORAGE_ACCOUNT"]
        container = os.environ.get(f"ADLS_CONTAINER_{args.env.upper()}", f"olist-{args.env}")
        for fname in OLIST_FILES:
            src = download_dir / fname
            if src.exists():
                adls_path = f"landing/{fname}"
                full_path = upload_to_adls(str(src), adls_path)
        dataset_path = f"abfss://{container}@{account}.dfs.core.windows.net/landing/"
        with open(f".env.{args.env}", "a") as f:
            f.write(f"\nDATASET_SOURCE_PATH={dataset_path}\n")
        print(f"\n✅ Upload complete. DATASET_SOURCE_PATH updated in .env.{args.env}")


if __name__ == "__main__":
    main()
