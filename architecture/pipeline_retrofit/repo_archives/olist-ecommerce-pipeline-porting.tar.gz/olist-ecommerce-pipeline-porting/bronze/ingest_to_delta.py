"""
ingest_to_delta.py — Bronze Layer Ingestion
WHAT: Ingest 9 Olist CSV files → Delta Lake Bronze layer dengan metadata columns
WHY : ACID guarantees + time travel capability untuk raw data persistence
WHEN: Run selepas download_dataset.py — Bronze layer pipeline step 1
"""

import os
import hashlib
import json
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, TimestampType


# =============================================================================
# CONFIG
# =============================================================================

OLIST_FILES = [
    "olist_orders_dataset.csv",
    "olist_order_items_dataset.csv",
    "olist_order_payments_dataset.csv",
    "olist_order_reviews_dataset.csv",
    "olist_customers_dataset.csv",
    "olist_sellers_dataset.csv",
    "olist_products_dataset.csv",
    "olist_geolocation_dataset.csv",
    "product_category_name_translation.csv",
]

BRONZE_TABLES = {
    "olist_orders_dataset.csv": "raw_orders",
    "olist_order_items_dataset.csv": "raw_order_items",
    "olist_order_payments_dataset.csv": "raw_payments",
    "olist_order_reviews_dataset.csv": "raw_reviews",
    "olist_customers_dataset.csv": "raw_customers",
    "olist_sellers_dataset.csv": "raw_sellers",
    "olist_products_dataset.csv": "raw_products",
    "olist_geolocation_dataset.csv": "raw_geolocation",
    "product_category_name_translation.csv": "raw_category_translation",
}


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_spark_session(app_name: str = "bronze_ingestion") -> SparkSession:
    """
    WHAT: Create SparkSession untuk local mode (PySpark standalone)
    WHY : Codespace constraint — PySpark local mode ONLY
    """
    spark = (
        SparkSession.builder
        .appName(app_name)
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .config("spark.driver.memory", "4g")
        .config("spark.executor.memory", "4g")
        .getOrCreate()
    )
    return spark


def compute_row_hash(row_dict: dict) -> str:
    """
    WHAT: Generate MD5 hash dari row content untuk dedup tracking
    WHY : DQS requirement — detect duplicate rows across batches
    """
    row_str = "|".join([str(v) for v in sorted(row_dict.items())])
    return hashlib.md5(row_str.encode()).hexdigest()


def add_metadata_columns(df, source_file_name: str, batch_id: str):
    """
    WHAT: Add Bronze metadata columns per PIPELINE_SPEC
    WHY : Lineage tracking + time travel support

    Metadata columns:
    - ingestion_timestamp: when row ingested
    - source_system: 'olist_kaggle'
    - batch_id: YYYYMMDD_HHMMSS format
    - source_file_name: original CSV filename
    - row_hash: MD5(row) untuk dedup tracking
    """
    df = df.withColumn("ingestion_timestamp", F.current_timestamp())
    df = df.withColumn("source_system", F.lit("olist_kaggle"))
    df = df.withColumn("batch_id", F.lit(batch_id))
    df = df.withColumn("source_file_name", F.lit(source_file_name))

    # Generate row_hash (concat all columns → MD5)
    all_cols = [c for c in df.columns if c not in ["ingestion_timestamp", "source_system", "batch_id", "source_file_name"]]
    df = df.withColumn(
        "row_hash",
        F.md5(F.concat_ws("|", *[F.coalesce(F.col(c).cast("string"), F.lit("NULL")) for c in all_cols]))
    )

    return df


# =============================================================================
# MAIN INGESTION LOGIC
# =============================================================================

def ingest_to_bronze(env: str = "dev"):
    """
    WHAT: Ingest CSV files → Delta Lake Bronze layer
    WHY : Per PIPELINE_SPEC — Bronze layer implementation

    Steps:
    1. Load env variables from .env.{env}
    2. Read DATASET_SOURCE_PATH (set by download_dataset.py)
    3. For each CSV file:
       a. Read CSV with schema inference OFF (all STRING types)
       b. Add metadata columns
       c. Write to Delta Lake (mode=append)
       d. Validate row count match
       e. Log success/failure
    4. Generate manifest file (bronze_manifest.json)
    """

    # Load environment
    env_file = f".env.{env}"
    load_dotenv(env_file)
    print(f"\n⚙️  ingest_to_bronze.py — env={env}")

    dataset_source_path = os.environ.get("DATASET_SOURCE_PATH")
    if not dataset_source_path:
        raise ValueError(f"DATASET_SOURCE_PATH not set in {env_file}. Run download_dataset.py first.")

    # Generate batch_id
    batch_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    print(f"📦 Batch ID: {batch_id}")
    print(f"📂 Source Path: {dataset_source_path}")

    # Initialize Spark
    spark = get_spark_session()

    # Bronze output path
    if env == "dev":
        bronze_path = "data/bronze"
    else:
        account = os.environ["AZURE_STORAGE_ACCOUNT"]
        container = os.environ.get(f"ADLS_CONTAINER_{env.upper()}", f"olist-{env}")
        bronze_path = f"abfss://{container}@{account}.dfs.core.windows.net/bronze"

    Path(bronze_path).mkdir(parents=True, exist_ok=True) if env == "dev" else None

    manifest = {
        "batch_id": batch_id,
        "env": env,
        "timestamp": datetime.now().isoformat(),
        "files_ingested": []
    }

    # Ingest each file
    for csv_file, table_name in BRONZE_TABLES.items():
        try:
            print(f"\n📄 Ingesting {csv_file} → bronze.{table_name}")

            # Read CSV (all columns as STRING — schema inference OFF)
            csv_path = f"{dataset_source_path}/{csv_file}" if dataset_source_path.endswith("/") else f"{dataset_source_path}{csv_file}"

            # Local file handling
            if not csv_path.startswith("abfss://"):
                csv_path = str(Path(csv_path).resolve())

            df = spark.read.csv(
                csv_path,
                header=True,
                inferSchema=False,  # All columns as STRING
                mode="PERMISSIVE"
            )

            source_row_count = df.count()
            print(f"  📊 Source rows: {source_row_count}")

            # Add metadata columns
            df = add_metadata_columns(df, csv_file, batch_id)

            # Write to Delta Lake (append mode)
            delta_table_path = f"{bronze_path}/{table_name}"
            df.write.format("delta").mode("append").save(delta_table_path)

            # Validate row count
            bronze_df = spark.read.format("delta").load(delta_table_path)
            total_rows = bronze_df.filter(F.col("batch_id") == batch_id).count()

            if total_rows != source_row_count:
                raise ValueError(f"Row count mismatch: source={source_row_count}, bronze={total_rows}")

            print(f"  ✅ Success: {total_rows} rows ingested → {delta_table_path}")

            manifest["files_ingested"].append({
                "file": csv_file,
                "table": table_name,
                "rows": total_rows,
                "status": "success",
                "delta_path": delta_table_path
            })

        except Exception as e:
            print(f"  ❌ FAILED: {csv_file} — {str(e)}")
            manifest["files_ingested"].append({
                "file": csv_file,
                "table": table_name,
                "rows": 0,
                "status": "failed",
                "error": str(e)
            })

    # Write manifest
    manifest_path = f"{bronze_path}/bronze_manifest_{batch_id}.json"
    if env == "dev":
        with open(manifest_path, "w") as f:
            json.dump(manifest, f, indent=2)
    else:
        # For cloud, write to ADLS (simplified — just print for now)
        print(f"\n📋 Manifest: {manifest_path}")
        print(json.dumps(manifest, indent=2))

    print(f"\n✅ Bronze ingestion complete — batch_id={batch_id}")
    print(f"   Files ingested: {len([f for f in manifest['files_ingested'] if f['status'] == 'success'])}/{len(BRONZE_TABLES)}")

    spark.stop()
    return manifest


# =============================================================================
# CLI
# =============================================================================

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", choices=["dev", "staging", "prod"], default="dev")
    args = parser.parse_args()

    ingest_to_bronze(env=args.env)
