# Olist E-Commerce Pipeline — AI Context

> Auto-loaded by Claude Code every session. Governance framework ported from
> `creative_intelligence_lab` (CIL) per the pipeline-retrofit effort (repo 2 of 4, after
> home-credit-pipeline) — see `architecture/pipeline_retrofit/` in CIL for provenance. Stack
> is UNCHANGED by the retrofit: this file documents the repo as it actually is (verified by
> reading bronze/, silver/, gold/, airflow/, data_quality/), not a stack swap.

## 🛑 STOP-GATE — read before ANY model/schema/identity work
This repo is governed. Before you edit a dbt mart model, the Silver SCD transform, a seed/
source, or before you "proceed" past a grain/identity question — you MUST:
1. **Open the governing doc first.** Grain/star schema → ADR-001 + `docs/DATA_MODEL.md`.
   SCD strategy (why SCD2 for customers/sellers, SCD1 for products) → ADR-002. Stack boundary
   (Databricks Bronze/Silver, Snowflake Gold-only) → `docs/ARCHITECTURE.md` +
   `tests/boundary_contract.py`.
2. **Validate identity BEFORE building downstream.** `dim_customers`/`dim_sellers` are SCD
   Type 2, surrogate-keyed on `customer_key`/`seller_key` — exactly one `is_current = TRUE`
   row per `customer_unique_id`/`seller_id` at all times (`silver/transform_silver.py`'s
   `transform_customers_scd2`/`transform_sellers_scd2`, mart-side in `dim_customers.sql`/
   `dim_sellers.sql`). Run `python tests/identity_contract.py` and
   `python tests/boundary_contract.py` before calling any mart/Silver change done — these are
   the binding checks, not your judgement.
3. **If a rule and the request conflict, STOP and surface it** — do not silently proceed.
   Mixed-grain dimension, Spark/compute outside Databricks, a non-Snowflake dbt target, a new
   ingestion connector beyond the Kaggle API → name it, cite the doc, and ask @data-architect /
   @scope-guardian before writing code.

Enforced three ways: this prompt (soft), `.claude/hooks/governance_guard.py` (blocks edits to
governed files without a context nudge), and CI (`tests/identity_contract.py` +
`tests/boundary_contract.py` + `tests/doc_reference_contract.py`, blocks the PR).

## 🔁 ANTI-SHORTCUT PROTOCOL — read-before-touch, reconcile-before-done
1. **Read-before-touch** — never edit or assert about a file from memory; read it THIS turn.
2. **Enumerate, don't sample** — for "all N tables/models" tasks, get N from `ls`/`grep` BEFORE
   acting (9 source CSVs, 7 Silver tables, 3 facts + 4 dims in Gold — verify the count, don't
   recall it).
3. **Reconcile-before-done** — before saying done/fixed/green, restate the request as a
   numbered checklist with `file:line` evidence per item. No evidence = "unverified".
4. **Tag assumptions** — any unchecked load-bearing claim is marked "(unverified)"; any
   reconstructed rationale (no contemporaneous deliberation) is marked
   "(reconstructed — owner confirm)".

The machine half: `tests/doc_reference_contract.py` proves every model/path a doc references
actually exists. `scripts/gen_repo_map.py` generates `architecture/REPO_MAP.md` — a pointer
index, not a cache; it tells you which file to open, then you read that file fresh.

## Project Overview
**Domain**: E-commerce / retail analytics (Order-to-Cash).
**Problem**: Turn the Olist Brazilian E-Commerce dataset (9 source CSVs, 100k+ orders, ~830k
order items) into a Kimball star schema serving DSO, fulfillment-rate, on-time-delivery, GMV,
and customer-retention KPIs via Power BI.
**Purpose**: Data Engineering portfolio project (single-dev, Raja Ahmad Luqman). This is a
**finished** pipeline (Phases 0–5 all ✅ per README.md "Phase Completion") now getting a
governance + learning layer added — there is no further pipeline build scope here, only
documentation/governance/learning backfill.

## Stack (locked — unchanged by this retrofit, verified by reading the repo)
| Layer | Storage | Compute / engine | Notes |
|-------|---------|------------------|-------|
| Source | Kaggle API (`olist_public_dataset`) | `bronze/download_dataset.py` | 9 CSVs, ~126MB, 100k+ orders |
| Landing | Azure ADLS Gen2 (staging container) | — | free tier, 5GB cap |
| Bronze | ADLS Gen2, Delta Lake | Databricks COPY INTO, Unity Catalog — REAL logic in `bronze/ingest_to_delta.py` + `databricks_notebooks/01_bronze_ingestion.py` | ACID, time travel, 9 raw Delta tables |
| Silver | ADLS Gen2, Delta Lake | PySpark (DataFrame API + Window functions), local or Databricks — REAL logic in `silver/transform_silver.py` + `databricks_notebooks/02_silver_transformation.py` | type casting, business rules, SCD2 (customers/sellers) + SCD1 (products) |
| Bridge | Parquet (ADLS Gen2) | `silver/export_silver_to_parquet.py` (referenced) | Delta Lake → Parquet → Snowflake external stage |
| Gold/marts | Snowflake (`OLIST_ECOMMERCE` DB, `STAGING_MARTS` schema) | dbt Core, `gold/dbt_models/models/{staging,intermediate,marts}` | Kimball star: 3 facts + 4 dims |
| Quality | Great Expectations | `data_quality/run_bronze_validation.py` (9 checks), `data_quality/run_silver_suite.py`/`run_silver_validation.py` (12 checks) | per-layer gates |
| Orchestration | — | Apache Airflow standalone, `airflow/dags/olist_pipeline_dag.py` (1 chained DAG: bronze → silver → silver_dq → gold_dbt_run → gold_dbt_test) | localhost:8080, `@daily` |

⚠️ **Automation gap (verified by reading the code, not assumed):** `airflow/dags/olist_pipeline_dag.py`'s
`bronze_ingest`, `silver_transform`, and `silver_dq_check` tasks call `bronze/bronze_pipeline.py`,
`silver/silver_pipeline.py`, and `data_quality/run_silver_validation.py` respectively — all
three are explicitly **print-stub wrappers** ("Demo/Portfolio: Validates configuration and
reports success" / "Skipping actual validation — Silver tables in Databricks (cloud)"), not
live Databricks REST API calls. The REAL Bronze/Silver execution happened ONCE, manually, via
the `databricks_notebooks/01_bronze_ingestion.py` / `02_silver_transformation.py` notebooks
during Phase 4b. Only `gold_dbt_run`/`gold_dbt_test` (real `BashOperator` → `dbt run`/`dbt test`)
actually execute on every DAG run. **Do not describe this DAG as "fully automating Bronze→Gold"
without this caveat** — see `INTERVIEW_GUIDE.md`.
| Alerting | print-based callbacks today; Slack backfilled this retrofit | `airflow/dags/olist_pipeline_dag.py` `on_success_callback`/`on_failure_callback` | `apache-airflow-providers-slack` already in `requirements.txt`, unused until this retrofit |
| Serving | reads Gold Snowflake | Power BI | dashboard consumer |

⚠️ Stack boundary (ADR-001 + `docs/ARCHITECTURE.md`): **Bronze/Silver compute = Databricks
only** (Unity Catalog Delta Lake + Databricks SQL Warehouse / Serverless — no standalone Spark
cluster outside Databricks, `tests/boundary_contract.py` ST1). **Gold compute = Snowflake/dbt
only** (no DuckDB/BigQuery/Postgres dbt target, ST4). No AWS S3/Glue, no MinIO, no dedicated
vector DB, no new ingestion connector beyond the Kaggle API (ST3).

## Architecture of Record
`docs/` — BRD.md, DRD.md, DATA_DICTIONARY.md, DATA_MODEL.md, ARCHITECTURE.md, PIPELINE_SPEC.md,
DQD.md, OPS_RUNBOOK.md, `ADR/` (ADR-001 Kimball star schema — sound, kept as-is; this retrofit
adds ADR-002 SCD strategy, ADR-003 Slack alerting). `architecture/REPO_MAP.md` (generated, see
above).

**Identity key**: `customer_key`/`seller_key` (surrogate, SCD Type 2) — assigned in
`silver/transform_silver.py`'s `transform_customers_scd2`/`transform_sellers_scd2`
(`row_number()` + MERGE-expire pattern), carried through `gold/dbt_models/models/intermediate/
int_customers_scd2.sql` / `int_sellers_scd2.sql` into `dim_customers.sql`/`dim_sellers.sql`.
`product_key` is SCD Type 1 (overwrite mode, no historical tracking) — `dim_products.sql`.

**Governance gate**: @data-architect holds veto on grain/model changes (Kimball star locked,
ADR-001); @scope-guardian holds veto on stack/scope creep (no compute outside Databricks/
Snowflake, no new ingestion connectors beyond the Kaggle API).

## Governed-file map
| Path | Governed by | Cite before editing |
|---|---|---|
| `gold/dbt_models/models/marts/` | @data-architect | ADR-001, `docs/DATA_MODEL.md` |
| `silver/transform_silver.py` (SCD2/SCD1 logic) | @data-architect | ADR-002, `docs/DATA_MODEL.md` |
| `docs/DATA_MODEL.md` | @data-architect | grain/star doctrine |
| `docs/ADR/` | @data-architect + @documentation-sherpa | ADR numbering, cross-references |
| `gold/dbt_models/profiles.yml`, `dbt_project.yml` | @scope-guardian | `docs/ARCHITECTURE.md` stack boundary |
| `airflow/dags/` | @scope-guardian + @data-platform-engineer | `docs/ARCHITECTURE.md`, `docs/PIPELINE_SPEC.md` |
| `requirements.txt` | @scope-guardian | stack boundary (no Spark outside Databricks, no non-Snowflake dbt adapter) |

## Known resume↔repo mismatch (flagged, not silently fixed)
A resume claim of "Azure Data Factory (ADF)" for ingestion does **not** match this repo:
ingestion is `bronze/download_dataset.py` (Kaggle CLI) + Databricks `COPY INTO` from ADLS Gen2
(`bronze/ingest_to_delta.py`) — there is no ADF pipeline anywhere in this codebase
(`grep -rni "data factory\|adf" .` returns zero infra hits). See `INTERVIEW_GUIDE.md`
"Resume Claim ↔ Repo Evidence" — recommend correcting the resume wording to "Databricks
COPY INTO + Kaggle CLI", not fabricating ADF usage here.

## Cabinet (9 agents) — see `.claude/agents/`
**Veto holders**: @data-architect (Opus, grain/model) · @scope-guardian (Sonnet, stack/scope).
**Build**: @senior-data-engineer (dbt + Silver SCD + Airflow, absorbs QA/orchestration) ·
@data-quality-steward (GX suites) · @product-owner (BRD/KPIs) · @business-analyst (DRD +
resume-claim reconciliation) · @data-platform-engineer (Airflow/Databricks/Azure infra,
absorbs devops) · @documentation-sherpa (docs/ADR/REPO_MAP/Confluence upkeep).
**Teaching**: @cikgu (English-first, mental-model → ETL use-case → production bug → debug →
syntax LAST) — NOT a build agent; runs `learning/CURRICULUM.md` drills on `drill/*` branches,
never `main`.

This roster is **leanest of the 4 retrofit repos** (8 build/veto agents + cikgu = 9; no
`finops-agent`/`infra-reality-agent` — olist runs on ADLS/Databricks/Snowflake free tiers with
no documented OOM-class infra risk the way home-credit's 27M-row Glue job has).

## What NOT to commit
`.env*`, `data/`, `*.parquet` (except dbt build output paths already gitignored), raw Kaggle
CSVs, `COST_LOG.md` if it ever contains real account IDs — keep cost figures estimate-only.

## Token Discipline
1. Checkpoint first: read `PROJECT_STATUS.md` "▶ RESUME HERE" before reading code.
2. Use `architecture/REPO_MAP.md` instead of re-grepping the whole repo for "where is X".
3. Read only files in the current module — max ~3 files/turn.
