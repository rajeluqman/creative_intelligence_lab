# PIPELINE_SPEC: Olist E-Commerce Pipeline
> Status: 🚧 DRAFT — Phase 3  
> Date: 2026-05-13  
> Agents: DA, DPE, SDE, AE  
> Purpose: Technical implementation specifications per layer

## Overview

This document specifies the technical implementation details for each pipeline layer:
- **Bronze**: Ingestion + Delta Lake persistence
- **Silver**: PySpark transformations + data quality
- **Gold**: dbt models + Star Schema

---

## Bronze Layer Specification

### Purpose
Raw data persistence with ACID guarantees + time travel capability.

### Input Sources

| Environment | Source Path | Format | Volume |
|-------------|-------------|--------|--------|
| dev | `data/olist_dev_1000rows/` | CSV | 1000 rows (sampled) |
| staging | `abfss://olist-staging@azolistpiepeline.dfs.core.windows.net/landing/` | CSV | ~100k orders |
| prod | `abfss://olist-prod@azolistpiepeline.dfs.core.windows.net/landing/` | CSV | ~100k orders |

**Source Files** (9 CSVs):
1. `olist_orders_dataset.csv`
2. `olist_order_items_dataset.csv`
3. `olist_order_payments_dataset.csv`
4. `olist_customers_dataset.csv`
5. `olist_sellers_dataset.csv`
6. `olist_products_dataset.csv`
7. `olist_geolocation_dataset.csv`
8. `olist_order_reviews_dataset.csv`
9. `product_category_name_translation.csv`

### Output Tables

| Bronze Table | Source CSV | Schema Preservation |
|--------------|------------|---------------------|
| bronze.raw_orders | olist_orders_dataset.csv | All columns as STRING |
| bronze.raw_order_items | olist_order_items_dataset.csv | All columns as STRING |
| bronze.raw_payments | olist_order_payments_dataset.csv | All columns as STRING |
| bronze.raw_customers | olist_customers_dataset.csv | All columns as STRING |
| bronze.raw_sellers | olist_sellers_dataset.csv | All columns as STRING |
| bronze.raw_products | olist_products_dataset.csv | All columns as STRING |
| bronze.raw_geolocation | olist_geolocation_dataset.csv | All columns as STRING |
| bronze.raw_reviews | olist_order_reviews_dataset.csv | All columns as STRING |
| bronze.raw_category_translation | product_category_name_translation.csv | All columns as STRING |

### Metadata Columns (Added to All Bronze Tables)

```sql
ingestion_timestamp    TIMESTAMP   -- when row ingested
source_system          STRING      -- 'olist_kaggle'
batch_id               STRING      -- YYYYMMDD_HHMMSS format
source_file_name       STRING      -- original CSV filename
row_hash               STRING      -- MD5(row) for dedup tracking
```

### Implementation Script

**Script**: `bronze/ingest_to_delta.py`

**Logic**:
```python
def ingest_to_bronze(env='dev'):
    """
    Ingest CSV files to Delta Lake Bronze layer
    
    Args:
        env: 'dev' | 'staging' | 'prod'
    
    Steps:
        1. Load env variables from .env.{env}
        2. Read DATASET_SOURCE_PATH (set by download_dataset.py)
        3. For each CSV file:
           a. Read CSV with schema inference OFF (all STRING types)
           b. Add metadata columns (ingestion_ts, source_system, batch_id, source_file, row_hash)
           c. Write to Delta Lake (mode=append)
           d. Validate row count match
           e. Log success/failure
        4. Generate manifest file (bronze_manifest.json)
    """
```

**PySpark Schema Example** (bronze.raw_orders):
```python
from pyspark.sql.types import StructType, StructField, StringType, TimestampType

bronze_orders_schema = StructType([
    # Original CSV columns (all STRING)
    StructField("order_id", StringType(), nullable=True),
    StructField("customer_id", StringType(), nullable=True),
    StructField("order_status", StringType(), nullable=True),
    StructField("order_purchase_timestamp", StringType(), nullable=True),
    StructField("order_approved_at", StringType(), nullable=True),
    StructField("order_delivered_carrier_date", StringType(), nullable=True),
    StructField("order_delivered_customer_date", StringType(), nullable=True),
    StructField("order_estimated_delivery_date", StringType(), nullable=True),
    # Metadata columns
    StructField("ingestion_timestamp", TimestampType(), nullable=False),
    StructField("source_system", StringType(), nullable=False),
    StructField("batch_id", StringType(), nullable=False),
    StructField("source_file_name", StringType(), nullable=False),
    StructField("row_hash", StringType(), nullable=False),
])
```

### Data Quality — Bronze

**Great Expectations Suite**: `data_quality/great_expectations/expectations/bronze_suite.json`

**Validations**:
1. **File-level**:
   - Row count match: CSV row count = Delta table row count (per batch_id)
   - Column count match: CSV columns + 5 metadata columns
   - File checksum: MD5 hash validation

2. **Schema-level**:
   - All source columns present
   - Metadata columns not NULL
   - batch_id format: `YYYYMMDD_HHMMSS`

3. **Data-level**:
   - No completely NULL rows
   - row_hash unique per (source_file_name, batch_id)

**Failure Handling**:
- File validation fail → CRITICAL alert, stop pipeline
- Row count mismatch → CRITICAL alert, quarantine batch
- Schema mismatch → CRITICAL alert, stop pipeline

---

## Silver Layer Specification

### Purpose
Cleansed, strongly-typed, business-rule-applied data with surrogate keys.

### Input Tables
Bronze Delta Lake tables (bronze.raw_*)

### Output Tables

| Silver Table | Grain | Target Layer | SCD Type |
|--------------|-------|--------------|----------|
| silver.orders | 1 row = 1 order | Gold fact_orders | Snapshot |
| silver.order_items | 1 row = 1 line item | Gold fact_order_items | Snapshot |
| silver.payments | 1 row = 1 installment | Gold fact_payments | Snapshot |
| silver.customers | 1 row = 1 customer version | Gold dim_customers | SCD Type 2 |
| silver.sellers | 1 row = 1 seller version | Gold dim_sellers | SCD Type 2 |
| silver.products | 1 row = 1 product | Gold dim_products | SCD Type 1 |
| silver.geolocation | 1 row = 1 zip_code_prefix | Reference table | Static |
| silver.reviews | 1 row = 1 review | Reference (optional dim) | Snapshot |

### Implementation Script

**Script**: `silver/transform_silver.py`

**Execution**: PySpark on Databricks SQL Warehouse (Serverless)

---

### Transformation Specs — silver.orders

**Source**: bronze.raw_orders

**Business Rules**:
1. Type cast timestamps (STRING → TIMESTAMP)
2. Handle NULL order_approved_at (DQS Flag #1): fallback to order_purchase_timestamp for DSO calc
3. Derive is_delivered, is_on_time
4. Aggregate review_score per order
5. Deduplicate by order_id (keep latest ingestion_timestamp)

**Schema**:
```sql
CREATE TABLE silver.orders (
    order_id                        STRING      NOT NULL,  -- PK
    customer_id                     STRING      NOT NULL,  -- FK to silver.customers
    order_status                    STRING      NOT NULL,
    order_purchase_timestamp        TIMESTAMP   NOT NULL,
    order_approved_at               TIMESTAMP,             -- nullable
    order_delivered_carrier_date    TIMESTAMP,
    order_delivered_customer_date   TIMESTAMP,
    order_estimated_delivery_date   TIMESTAMP   NOT NULL,
    -- Derived columns
    is_delivered                    BOOLEAN     NOT NULL,
    is_on_time                      BOOLEAN,               -- NULL if not delivered
    review_score                    DECIMAL(3,2),          -- AVG score (1.00 - 5.00)
    dq_approved_flag                BOOLEAN     NOT NULL,  -- FALSE if order_approved_at NULL
    -- Metadata
    valid_from                      TIMESTAMP   NOT NULL,
    valid_to                        TIMESTAMP,             -- NULL = current
    is_current                      BOOLEAN     NOT NULL,  -- TRUE = latest version
    source_batch_id                 STRING      NOT NULL
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/silver/orders'
```

**PySpark Transformation Logic**:
```python
from pyspark.sql import functions as F
from pyspark.sql.window import Window

# Read bronze
bronze_orders = spark.read.format("delta").load("bronze.raw_orders")

# Type casting
silver_orders = bronze_orders \
    .withColumn("order_purchase_timestamp", F.to_timestamp("order_purchase_timestamp")) \
    .withColumn("order_approved_at", F.to_timestamp("order_approved_at")) \
    .withColumn("order_delivered_carrier_date", F.to_timestamp("order_delivered_carrier_date")) \
    .withColumn("order_delivered_customer_date", F.to_timestamp("order_delivered_customer_date")) \
    .withColumn("order_estimated_delivery_date", F.to_timestamp("order_estimated_delivery_date"))

# Derived columns
silver_orders = silver_orders \
    .withColumn("is_delivered", 
                (F.col("order_status") == "delivered") & F.col("order_delivered_customer_date").isNotNull()) \
    .withColumn("is_on_time", 
                F.when(F.col("is_delivered"), 
                       F.col("order_delivered_customer_date") <= F.col("order_estimated_delivery_date"))
                 .otherwise(None)) \
    .withColumn("dq_approved_flag", 
                F.col("order_approved_at").isNotNull())

# Join reviews for review_score aggregation
bronze_reviews = spark.read.format("delta").load("bronze.raw_reviews")
avg_review = bronze_reviews.groupBy("order_id") \
    .agg(F.avg("review_score").cast("decimal(3,2)").alias("review_score"))

silver_orders = silver_orders.join(avg_review, on="order_id", how="left")

# Deduplication (keep latest by ingestion_timestamp)
window = Window.partitionBy("order_id").orderBy(F.desc("ingestion_timestamp"))
silver_orders = silver_orders \
    .withColumn("row_num", F.row_number().over(window)) \
    .filter(F.col("row_num") == 1) \
    .drop("row_num")

# Metadata
silver_orders = silver_orders \
    .withColumn("valid_from", F.current_timestamp()) \
    .withColumn("valid_to", F.lit(None).cast("timestamp")) \
    .withColumn("is_current", F.lit(True)) \
    .withColumn("source_batch_id", F.col("batch_id"))

# Write to Delta
silver_orders.write.format("delta").mode("overwrite").save("silver.orders")
```

**Data Quality — silver.orders**:
- NOT NULL: order_id, customer_id, order_status, order_purchase_timestamp
- Range check: order_purchase_timestamp < order_delivered_customer_date (if delivered)
- Referential integrity: customer_id exists in silver.customers
- Deduplication: unique order_id per batch

---

### Transformation Specs — silver.order_items

**Source**: bronze.raw_order_items

**Business Rules**:
1. Type cast price, freight_value (STRING → DECIMAL)
2. Derive gmv = price + freight_value
3. Flag price = 0.00 anomaly (DQS Flag #2)
4. Deduplicate by (order_id, order_item_id)

**Schema**:
```sql
CREATE TABLE silver.order_items (
    order_id                STRING          NOT NULL,  -- PK part 1
    order_item_id           INT             NOT NULL,  -- PK part 2
    product_id              STRING          NOT NULL,  -- FK to silver.products
    seller_id               STRING          NOT NULL,  -- FK to silver.sellers
    shipping_limit_date     TIMESTAMP       NOT NULL,
    price                   DECIMAL(10,2)   NOT NULL,
    freight_value           DECIMAL(10,2)   NOT NULL,
    -- Derived columns
    gmv                     DECIMAL(10,2)   NOT NULL,  -- price + freight_value
    dq_zero_price_flag      BOOLEAN         NOT NULL,  -- TRUE if price = 0.00
    -- Metadata
    valid_from              TIMESTAMP       NOT NULL,
    source_batch_id         STRING          NOT NULL,
    PRIMARY KEY (order_id, order_item_id)
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/silver/order_items'
```

**PySpark Logic**:
```python
silver_order_items = bronze_order_items \
    .withColumn("order_item_id", F.col("order_item_id").cast("int")) \
    .withColumn("price", F.col("price").cast("decimal(10,2)")) \
    .withColumn("freight_value", F.col("freight_value").cast("decimal(10,2)")) \
    .withColumn("shipping_limit_date", F.to_timestamp("shipping_limit_date")) \
    .withColumn("gmv", F.col("price") + F.col("freight_value")) \
    .withColumn("dq_zero_price_flag", F.col("price") == 0.00)

# Deduplication
window = Window.partitionBy("order_id", "order_item_id").orderBy(F.desc("ingestion_timestamp"))
silver_order_items = silver_order_items \
    .withColumn("row_num", F.row_number().over(window)) \
    .filter(F.col("row_num") == 1) \
    .drop("row_num")
```

**Data Quality — silver.order_items**:
- NOT NULL: order_id, order_item_id, product_id, seller_id
- Range check: price >= 0, freight_value >= 0, gmv >= 0
- Referential integrity: order_id exists in silver.orders
- Deduplication: unique (order_id, order_item_id)

---

### Transformation Specs — silver.payments

**Source**: bronze.raw_payments

**Business Rules**:
1. Type cast payment_value, payment_installments (STRING → DECIMAL, INT)
2. Validate payment_value > 0
3. Deduplicate by (order_id, payment_sequential)

**Schema**:
```sql
CREATE TABLE silver.payments (
    order_id                STRING          NOT NULL,  -- PK part 1
    payment_sequential      INT             NOT NULL,  -- PK part 2 (installment seq)
    payment_type            STRING          NOT NULL,  -- credit_card, boleto, etc
    payment_installments    INT             NOT NULL,
    payment_value           DECIMAL(10,2)   NOT NULL,
    -- Metadata
    valid_from              TIMESTAMP       NOT NULL,
    source_batch_id         STRING          NOT NULL,
    PRIMARY KEY (order_id, payment_sequential)
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/silver/payments'
```

**Data Quality — silver.payments**:
- NOT NULL: order_id, payment_sequential, payment_type, payment_value
- Range check: payment_value > 0, payment_installments > 0
- Referential integrity: order_id exists in silver.orders
- Aggregate validation: SUM(payment_value) per order_id (log anomalies)

---

### Transformation Specs — silver.customers (SCD Type 2)

**Source**: bronze.raw_customers

**Business Rules**:
1. Track zip_code_prefix changes (SCD Type 2)
2. Generate surrogate key: customer_key (INT)
3. Deduplicate by customer_unique_id (keep latest)

**Schema**:
```sql
CREATE TABLE silver.customers (
    customer_key            INT         NOT NULL,  -- Surrogate PK (auto-increment)
    customer_unique_id      STRING      NOT NULL,  -- Business key
    customer_id             STRING      NOT NULL,  -- Order FK (per order)
    customer_zip_code_prefix STRING     NOT NULL,  -- SCD tracked attribute
    customer_city           STRING      NOT NULL,
    customer_state          STRING      NOT NULL,
    -- SCD Type 2 columns
    valid_from              TIMESTAMP   NOT NULL,
    valid_to                TIMESTAMP,             -- NULL = current version
    is_current              BOOLEAN     NOT NULL,  -- TRUE = latest version
    -- Metadata
    source_batch_id         STRING      NOT NULL,
    PRIMARY KEY (customer_key)
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/silver/customers'
```

**PySpark Logic** (SCD Type 2 MERGE):
```python
from delta.tables import DeltaTable

# Read existing Silver customers (if exists)
if DeltaTable.isDeltaTable(spark, "silver.customers"):
    existing = spark.read.format("delta").load("silver.customers")
else:
    existing = None

# Read new Bronze customers
new_customers = spark.read.format("delta").load("bronze.raw_customers")

if existing is None:
    # Initial load: assign customer_key
    silver_customers = new_customers \
        .withColumn("customer_key", F.row_number().over(Window.orderBy("customer_unique_id"))) \
        .withColumn("valid_from", F.current_timestamp()) \
        .withColumn("valid_to", F.lit(None).cast("timestamp")) \
        .withColumn("is_current", F.lit(True))
    silver_customers.write.format("delta").save("silver.customers")
else:
    # SCD Type 2 MERGE logic
    # 1. Detect changes: zip_code_prefix changed
    # 2. Expire old record: set valid_to = current_timestamp, is_current = False
    # 3. Insert new record: assign new customer_key, valid_from = current_timestamp
    
    delta_table = DeltaTable.forPath(spark, "silver.customers")
    
    # Find max customer_key for new surrogate key generation
    max_key = existing.agg(F.max("customer_key")).collect()[0][0]
    
    # Identify changes
    changes = new_customers.alias("new") \
        .join(existing.filter(F.col("is_current")).alias("old"),
              on="customer_unique_id",
              how="left") \
        .where((F.col("new.customer_zip_code_prefix") != F.col("old.customer_zip_code_prefix")) |
               F.col("old.customer_key").isNull())  # new customer
    
    # Expire old records
    delta_table.update(
        condition="customer_unique_id IN (SELECT customer_unique_id FROM changes) AND is_current = TRUE",
        set={"valid_to": F.current_timestamp(), "is_current": F.lit(False)}
    )
    
    # Insert new records with new customer_key
    new_records = changes \
        .withColumn("customer_key", F.row_number().over(Window.orderBy("customer_unique_id")) + max_key) \
        .withColumn("valid_from", F.current_timestamp()) \
        .withColumn("valid_to", F.lit(None).cast("timestamp")) \
        .withColumn("is_current", F.lit(True))
    
    new_records.write.format("delta").mode("append").save("silver.customers")
```

**Data Quality — silver.customers**:
- NOT NULL: customer_key, customer_unique_id, customer_zip_code_prefix
- Unique: customer_key
- SCD validation: Only one is_current=TRUE per customer_unique_id

---

### Transformation Specs — silver.sellers (SCD Type 2)

**Source**: bronze.raw_sellers

**Business Rules**:
1. Track city/state changes (SCD Type 2)
2. Generate surrogate key: seller_key (INT)

**Schema**: Similar to silver.customers with seller_key, seller_id (business key), seller_city, seller_state (tracked attributes).

---

### Transformation Specs — silver.products (SCD Type 1)

**Source**: bronze.raw_products + bronze.raw_category_translation

**Business Rules**:
1. JOIN translation table for English category name
2. Handle NULL category: replace with 'uncategorized'
3. Overwrite mode (SCD Type 1)
4. Generate surrogate key: product_key (INT)

**Schema**:
```sql
CREATE TABLE silver.products (
    product_key                     INT     NOT NULL,  -- Surrogate PK
    product_id                      STRING  NOT NULL,  -- Business key
    product_category_name           STRING,            -- Portuguese name (nullable)
    product_category_name_english   STRING  NOT NULL,  -- English name (default: 'uncategorized')
    product_name_length             INT,
    product_description_length      INT,
    product_photos_qty              INT,
    product_weight_g                INT,
    product_length_cm               INT,
    product_height_cm               INT,
    product_width_cm                INT,
    -- Metadata
    valid_from                      TIMESTAMP NOT NULL,
    source_batch_id                 STRING    NOT NULL,
    PRIMARY KEY (product_key)
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/silver/products'
```

**PySpark Logic**:
```python
bronze_products = spark.read.format("delta").load("bronze.raw_products")
bronze_translation = spark.read.format("delta").load("bronze.raw_category_translation")

silver_products = bronze_products \
    .join(bronze_translation, on="product_category_name", how="left") \
    .withColumn("product_category_name_english", 
                F.coalesce(F.col("product_category_name_english"), F.lit("uncategorized"))) \
    .withColumn("product_key", F.row_number().over(Window.orderBy("product_id")))

# Overwrite mode (SCD Type 1)
silver_products.write.format("delta").mode("overwrite").save("silver.products")
```

---

## Gold Layer Specification (dbt Core)

### Purpose
Analytics-ready Star Schema in Snowflake for BI consumption.

### Input Source
Silver Delta Lake tables (ADLS Gen2) → Snowflake External Stage

### dbt Project Structure

```
gold/
├── dbt_project.yml
├── profiles.yml
├── models/
│   ├── staging/
│   │   ├── schema.yml
│   │   ├── stg_orders.sql
│   │   ├── stg_order_items.sql
│   │   ├── stg_payments.sql
│   │   ├── stg_customers.sql
│   │   ├── stg_sellers.sql
│   │   ├── stg_products.sql
│   ├── intermediate/
│   │   ├── schema.yml
│   │   ├── int_customers_scd2.sql
│   │   ├── int_sellers_scd2.sql
│   ├── marts/
│   │   ├── schema.yml
│   │   ├── dim_customers.sql
│   │   ├── dim_sellers.sql
│   │   ├── dim_products.sql
│   │   ├── dim_date.sql
│   │   ├── fact_orders.sql
│   │   ├── fact_order_items.sql
│   │   ├── fact_payments.sql
├── tests/
│   ├── assert_fact_orders_row_count.sql
│   ├── assert_payment_sum_match.sql
└── macros/
    ├── generate_date_spine.sql
    └── generate_surrogate_key.sql
```

### Snowflake External Stage Setup

```sql
-- Create Azure storage integration
CREATE STORAGE INTEGRATION azure_adls_integration
    TYPE = EXTERNAL_STAGE
    STORAGE_PROVIDER = AZURE
    ENABLED = TRUE
    AZURE_TENANT_ID = '<tenant_id>'
    STORAGE_ALLOWED_LOCATIONS = (
        'azure://azolistpiepeline.blob.core.windows.net/olist-dev/silver/',
        'azure://azolistpiepeline.blob.core.windows.net/olist-staging/silver/',
        'azure://azolistpiepeline.blob.core.windows.net/olist-prod/silver/'
    );

-- Create external stage
CREATE STAGE olist_silver_stage
    STORAGE_INTEGRATION = azure_adls_integration
    URL = 'azure://azolistpiepeline.blob.core.windows.net/olist-dev/silver/'
    FILE_FORMAT = (TYPE = PARQUET);
```

### dbt Model Example — stg_orders.sql

```sql
{{ config(
    materialized='view',
    schema='staging'
) }}

WITH source AS (
    SELECT *
    FROM @olist_silver_stage/orders
    WHERE is_current = TRUE  -- Only current records
),

renamed AS (
    SELECT
        order_id,
        customer_id,
        order_status,
        order_purchase_timestamp,
        order_approved_at,
        order_delivered_carrier_date,
        order_delivered_customer_date,
        order_estimated_delivery_date,
        is_delivered,
        is_on_time,
        review_score,
        dq_approved_flag,
        valid_from,
        source_batch_id
    FROM source
)

SELECT * FROM renamed
```

### dbt Model Example — dim_customers.sql (SCD Type 2)

```sql
{{ config(
    materialized='table',
    schema='marts',
    unique_key='customer_key'
) }}

WITH source AS (
    SELECT
        customer_key,
        customer_unique_id,
        customer_id,
        customer_zip_code_prefix,
        customer_city,
        customer_state,
        valid_from,
        valid_to,
        is_current
    FROM {{ ref('int_customers_scd2') }}
)

SELECT * FROM source
```

### dbt Model Example — fact_orders.sql

```sql
{{ config(
    materialized='table',
    schema='marts',
    unique_key='order_id'
) }}

WITH orders AS (
    SELECT * FROM {{ ref('stg_orders') }}
),

customers AS (
    SELECT * FROM {{ ref('dim_customers') }}
    WHERE is_current = TRUE
),

dates AS (
    SELECT * FROM {{ ref('dim_date') }}
),

joined AS (
    SELECT
        o.order_id,
        c.customer_key,
        d.date_key AS order_date_key,
        o.order_status,
        o.order_purchase_timestamp,
        o.order_approved_at,
        o.order_delivered_customer_date,
        o.order_estimated_delivery_date,
        o.is_delivered,
        o.is_on_time,
        o.review_score,
        o.dq_approved_flag
    FROM orders o
    INNER JOIN customers c
        ON o.customer_id = c.customer_id
    INNER JOIN dates d
        ON DATE(o.order_purchase_timestamp) = d.date_actual
)

SELECT * FROM joined
```

### dbt Tests — schema.yml

```yaml
version: 2

models:
  - name: fact_orders
    description: "Fact table for orders — grain: 1 row = 1 order"
    columns:
      - name: order_id
        description: "Primary key"
        tests:
          - unique
          - not_null
      - name: customer_key
        description: "Foreign key to dim_customers"
        tests:
          - not_null
          - relationships:
              to: ref('dim_customers')
              field: customer_key
      - name: order_date_key
        description: "Foreign key to dim_date"
        tests:
          - not_null
          - relationships:
              to: ref('dim_date')
              field: date_key

  - name: dim_customers
    description: "Customer dimension — SCD Type 2"
    columns:
      - name: customer_key
        description: "Surrogate primary key"
        tests:
          - unique
          - not_null
      - name: customer_unique_id
        description: "Business key (can have multiple versions)"
        tests:
          - not_null
```

### Data Quality — Gold

**dbt tests**:
- unique, not_null, relationships (FK validation)
- accepted_values (order_status IN ('delivered', 'shipped', ...))
- Custom tests: assert_fact_orders_row_count.sql, assert_payment_sum_match.sql

**Great Expectations** (optional layer on top of dbt):
- Aggregate validation: SUM(payment_value) Gold = SUM(payment_value) Silver
- Row count validation: fact_orders count = silver.orders is_current=TRUE count

---

## Error Handling & Quarantine Strategy

### Quarantine Table

```sql
CREATE TABLE quarantine.invalid_records (
    quarantine_id       STRING      NOT NULL,  -- UUID
    layer               STRING      NOT NULL,  -- 'bronze' | 'silver' | 'gold'
    table_name          STRING      NOT NULL,
    error_type          STRING      NOT NULL,  -- 'null_pk' | 'fk_violation' | 'dup' | 'range'
    error_message       STRING      NOT NULL,
    record_payload      STRING      NOT NULL,  -- JSON dump of invalid row
    quarantine_timestamp TIMESTAMP  NOT NULL,
    batch_id            STRING      NOT NULL,
    resolved            BOOLEAN     NOT NULL DEFAULT FALSE,
    resolution_notes    STRING
) USING DELTA
```

### Error Handling Rules

| Error Type | Action | Alert Level | Quarantine? |
|------------|--------|-------------|-------------|
| NULL in PK column | Quarantine | CRITICAL | YES |
| FK violation | Quarantine | HIGH | YES |
| Duplicate PK | Keep latest by ingestion_ts, log count | MEDIUM | NO (logged) |
| Range check fail (price < 0) | Quarantine | HIGH | YES |
| Type cast fail | Quarantine | HIGH | YES |
| File not found | Stop pipeline | CRITICAL | N/A |
| Schema mismatch | Stop pipeline | CRITICAL | N/A |

---

## Performance Optimization

### Bronze Layer
- No partitioning (100k rows small dataset)
- Compression: Snappy (Delta default)
- Optimize: `OPTIMIZE bronze.raw_orders` after each load

### Silver Layer
- PySpark broadcast joins for small dims (products, geolocation)
- SCD Type 2: Delta MERGE optimized with Z-order on customer_unique_id
- Checkpoint: Save intermediate DataFrames to avoid recomputation

### Gold Layer
- Snowflake clustering key: fact_orders ON (order_date_key, customer_key)
- Materialized tables (not views) for fact tables
- Incremental dbt models (future enhancement — Phase 5)

---

## Sign-off Checklist — Pipeline Spec Phase

- [x] Bronze layer spec defined (schema, metadata columns, script logic)
- [x] Silver layer spec defined (transformations per table, SCD logic, PySpark code)
- [x] Gold layer spec defined (dbt models, Snowflake integration, Star Schema)
- [x] Data quality strategy documented (GX + dbt tests)
- [x] Error handling + quarantine strategy documented
- [x] Performance optimization considerations documented
- [ ] DATA_MODEL.md generated (next deliverable — logical DDL)
- [ ] DEBATE_LOG_phase_3.md generated

---

**Next Step**: Generate DATA_MODEL.md — logical schema DDL for Bronze, Silver, Gold layers.
