# ADR-002: SCD Strategy — Type 2 for customers/sellers, Type 1 for products
Status: Accepted
Date  : 2026-06-28 (backfilled during governance retrofit; the strategy itself was already
        implemented in `silver/transform_silver.py` and `gold/dbt_models/models/marts/
        dim_*.sql` before this ADR — this document makes binding what the code already does,
        same pattern as home-credit-pipeline's ADR-002/003 backfill)
Owner : Data Architect

## Context
ADR-001 locked the Kimball star schema and named the per-dim SCD strategy in one line
(`dim_customers (SCD2), dim_sellers (SCD2), dim_products (SCD1)`) without justifying WHY each
dimension got its strategy. `silver/transform_silver.py` already implements this split
(`transform_customers_scd2`, `transform_sellers_scd2` via `row_number()` surrogate-key
assignment + Delta MERGE expire-then-insert; `transform_products_scd1` via plain `overwrite`
mode) and `gold/dbt_models/models/marts/dim_customers.sql`/`dim_sellers.sql` carry
`valid_from`/`valid_to`/`is_current` through from `int_customers_scd2.sql`/
`int_sellers_scd2.sql`, while `dim_products.sql` selects straight from `stg_products` with no
SCD2 columns at all. This ADR records the rationale that justifies the split, not a new
decision.

## Decision
**SCD Type 2** (`dim_customers`, `dim_sellers`) — track `customer_zip_code_prefix` /
`seller_city` + `seller_state` changes over time:
- Customer/seller location is a real analytical dimension (README.md's own KPI table: "Track
  customer location changes over time for regional analysis", "Track seller location changes,
  support seller operations reporting") — losing history would silently corrupt any
  region-over-time GMV or retention trend.
- Implementation: `silver/transform_silver.py` assigns a surrogate key
  (`customer_key`/`seller_key`) via `row_number()` on initial load, then on incremental runs
  detects a changed tracked attribute via a `left join` + `where` filter, expires the old
  `is_current=TRUE` row via a Delta `MERGE ... whenMatchedUpdate` (sets `valid_to` +
  `is_current=False`), and appends a new row with a fresh surrogate key. This is the
  expire-then-insert pattern, not `dbt snapshot` — the SCD2 logic lives in Silver
  (Databricks/PySpark), not in dbt (Gold/Snowflake), because Silver is where the source data
  (Delta Lake, Bronze) and the change-detection join both already live; pushing it into dbt
  would mean re-reading Bronze from Gold, an unnecessary cross-layer hop.

**SCD Type 1** (`dim_products`) — overwrite on every run:
- Product catalog attributes (category, dimensions, weight) are reference data, not a
  business event to track historically — README.md: "Product catalog (catalog overwrites
  acceptable)". A product's weight changing between catalog updates has no analytical value
  to preserve as history.
- Implementation: `silver/transform_silver.py`'s `transform_products_scd1` writes with
  `.mode("overwrite")` — no surrogate-key versioning, no `valid_from`/`valid_to`. `product_key`
  is reassigned by `row_number()` on every run (acceptable because dbt models join on
  `product_id`, the natural key, not `product_key`, for any historical fact — see
  `fact_order_items.sql`).

## Consequences
(+) `dim_customers`/`dim_sellers` support point-in-time regional analysis (a fact joined to
    the dimension AS OF the fact's `order_purchase_timestamp` gets the correct historical
    location, not today's).
(+) `dim_products` stays simple — no MERGE complexity for a dimension with no real
    historical-tracking business need.
(-) `dim_products`'s `product_key` is NOT stable across runs (re-assigned by `row_number()` on
    `product_id` order each overwrite) — any fact table that stored a `product_key` foreign
    key from a previous run would silently point at the wrong row after a re-run. Mitigated
    today because `fact_order_items.sql` joins on `product_id`, never a persisted
    `product_key`, but this is a real fragility if a future model starts persisting
    `product_key` as a stored FK. Flagged for @data-architect awareness, not yet fixed.
(-) The customer/seller MERGE-expire pattern in `silver/transform_silver.py` is NOT inside an
    atomic multi-statement transaction across "expire old" + "insert new" (two separate
    Delta operations) — a crash between them could leave zero `is_current=TRUE` rows for an
    affected customer/seller until the next run repairs it. `tests/identity_contract.py` ID1/ID2
    statically guards the SOURCE code shape, not a live invariant; a runtime GX check for
    "exactly 1 is_current=TRUE per customer_unique_id" would close this gap (see
    `docs/DQD.md` — recommend @data-quality-steward add this as a 13th Silver check).

## Alternatives Rejected
- `dbt snapshot` (dbt-native SCD2, the home-credit-pipeline pattern): rejected for THIS repo
  because the change-detection source (Bronze Delta Lake) and the SCD2 write target (Silver
  Delta Lake) are both pre-Gold; doing it in dbt would require sourcing Bronze data into
  Snowflake first, an extra unnecessary hop for data that's already co-located in
  ADLS Gen2/Databricks.
- SCD Type 2 for `dim_products` too: rejected — no business requirement to track catalog
  attribute history (BRD has no KPI that depends on point-in-time product attributes).
