# ADR-003: Slack Failure Alerting — backfill from print-based callbacks
Status: Accepted
Date  : 2026-06-28
Owner : Data Platform Engineer

## Context
`airflow/dags/olist_pipeline_dag.py`'s `pipeline_success`/`pipeline_failure` callbacks only
`print()` to the Airflow task log (README.md "Stack" table: "Alerting | Print-based callbacks |
Pipeline pass/fail (Slack integration pending)" — confirmed by reading the DAG file). This is
a documented, known gap, not a surprise finding. `docs/ARCHITECTURE.md` already names Slack
as the intended alerting channel ("Slack alert: DAG failure within 15 minutes",
"#olist-pipeline-alerts channel") and `requirements.txt` already lists
`apache-airflow-providers-slack==8.0.0` — the dependency was added but never wired up.
`creative_intelligence_lab`'s `dags/creative_intel_pipeline.py` `_notify_slack_failure`
(~line 111) is the reference pattern for THIS retrofit effort (per CIL's
architecture/pipeline_retrofit/01_OPUS_DECISIONS.md decision #2 — path is in the CIL repo,
not this one: "CIL Slack is BUILT ... reference for olist/Volve backfill").

## Decision
Backfill `airflow/dags/olist_pipeline_dag.py`'s `on_failure_callback` with a real Slack
webhook POST, following CIL's `_notify_slack_failure` shape:
- stdlib `urllib.request` only (no new dependency beyond the already-declared
  `apache-airflow-providers-slack`, used opportunistically if present, with a stdlib fallback —
  matches CIL's "dependency-minimal" rationale)
- reads `SLACK_WEBHOOK_URL` from the environment; **graceful no-op (log a warning, do not
  raise) if unset** — alerting being unconfigured must never raise a SECOND failure on top of
  the real pipeline failure
- message includes `dag_id`, failed `task_id`, run date, and a link to the task log
- wired via `default_args["on_failure_callback"]` so it fires for ANY task in the DAG
  (bronze_ingest, silver_transform, silver_dq_check, gold_dbt_run, gold_dbt_test) automatically
  — a future 6th task is covered without further wiring, same rationale as CIL's ADR-009
- success path keeps the existing `pipeline_success` print (no Slack-on-success spam; only
  failures alert, matching `docs/ARCHITECTURE.md`'s stated intent of a failure-only channel)

## Consequences
(+) Closes a documented README.md gap ("Slack integration pending") without adding new infra
    — the dependency was already declared, just unused.
(+) Graceful degradation means this ships safely even before the owner fills in
    `SLACK_WEBHOOK_URL` in `.env` — CI and local dev runs are unaffected.
(+) Reuses a proven pattern (CIL's, already running in `creative_intelligence_lab`) rather than
    inventing new alerting logic.
(-) Uses `BashOperator`/`PythonOperator` callback wiring, not the declared
    `apache-airflow-providers-slack` `SlackWebhookOperator` class directly — chosen for
    parity with CIL's stdlib-only pattern and to avoid a second, divergent Slack-calling
    convention inside the same repo. If the owner later wants `SlackWebhookOperator`'s richer
    formatting (blocks/attachments), that's a follow-up, not blocked by this ADR.

## Alternatives Rejected
- Leave print-based callbacks as-is: rejected — README.md itself flags this as "pending", and
  the retrofit's job is to close documented gaps, not just add new docs on top of them.
- Use `SlackWebhookOperator` as a separate DAG task (home-credit's `gold_dbt_dag.py` pattern,
  two extra `BashOperator` tasks gated by `TriggerRule.ALL_SUCCESS`/`ONE_FAILED`): considered,
  but olist's DAG is a single linear chain (not home-credit's per-layer multi-DAG structure)
  — an `on_failure_callback` on `default_args` is the simpler fit for a 1-DAG, 5-task chain.
