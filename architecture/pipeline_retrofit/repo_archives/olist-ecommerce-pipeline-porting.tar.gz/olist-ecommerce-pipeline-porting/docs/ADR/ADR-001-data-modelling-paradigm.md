# ADR-001: Data Modelling Paradigm — Kimball Star Schema
Status: Accepted
Date  : 2026-05-13
Owner : Data Architect + Data Platform Engineer

## Context
Olist dataset: 9 source tables, ~100k orders, ~830k order items.
Need to decide modelling paradigm for Gold layer serving analytics consumers.

## Decision
Paradigm : Kimball — Star Schema
Grain    :
  fact_orders      → 1 row = 1 order
  fact_order_items → 1 row = 1 line item
  fact_payments    → 1 row = 1 payment installment
Dims     : dim_customers (SCD2), dim_sellers (SCD2), dim_products (SCD1), dim_date (static)

## Consequences
(+) Standard analytics pattern — 80-90% use cases covered
(+) Aggregate queries (DSO, fulfillment rate, GMV) performant dengan Star Schema joins
(+) Databricks CE 15GB sufficient — no memory risk
(+) ADLS storage cost manageable — no duplication overhead
(-) Join required at query time — Kimball trade-off
(-) Denormalized OBT would eliminate joins but memory risk too high

## Alternatives Rejected
- OBT (One Big Table): rejected — complex Array/Struct types = OOM risk Databricks CE 15GB;
  100k rows tak justify storage duplication
- Hybrid: rejected — overkill untuk portfolio scope, Kimball sufficient
