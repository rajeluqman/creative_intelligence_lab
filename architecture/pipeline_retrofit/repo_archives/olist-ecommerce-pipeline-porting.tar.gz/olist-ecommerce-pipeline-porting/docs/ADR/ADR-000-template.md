# ADR-[NNN]: [Decision Title]
Status: [Proposed / Accepted]
Date  : [YYYY-MM-DD]
Owner : [DA / DPE / SDE]

## Context
[Kenapa decision ni perlu.]

## Decision
[Apa yang dipilih.]

## Consequences
(+) [Benefit 1]
(-) [Trade-off 1]

## Alternatives Rejected
- [Alternative A]: rejected sebab [reason]
