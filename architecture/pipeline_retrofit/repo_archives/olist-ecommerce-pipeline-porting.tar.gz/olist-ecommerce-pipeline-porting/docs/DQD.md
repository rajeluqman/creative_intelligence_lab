# DQD: Olist E-Commerce Pipeline
> Status: ✅ APPROVED — Phase 5 Complete  
> Date: 2026-05-14

## Bronze Suite
| Check | Rule | Severity | Action |
|-------|------|----------|--------|
| Row count | Source count = Bronze count | CRITICAL | Block + alert |
| ingestion_ts | NOT NULL | CRITICAL | Reject |
| order_id format | 32-char hex string | HIGH | Quarantine |
| All 9 files ingested | File count = 9 | CRITICAL | Block |

## Silver Suite
| Column | Rule | Severity | Action |
|--------|------|----------|--------|
| order_id | NOT NULL, UNIQUE in orders | CRITICAL | Reject + alert |
| (order_id, order_item_id) | UNIQUE in order_items | HIGH | Keep latest |
| (order_id, payment_sequential) | UNIQUE in payments | HIGH | Keep latest |
| customer_unique_id | NOT NULL | CRITICAL | Reject |
| is_current per customer | Only one True per customer_unique_id | CRITICAL | Alert DQS |
| price, freight_value | >= 0 | HIGH | Quarantine negative |

## Gold Suite (dbt tests)
| Check | Rule | Severity |
|-------|------|----------|
| fact_orders.customer_key | FK in dim_customers | CRITICAL |
| fact_order_items.seller_key | FK in dim_sellers | CRITICAL |
| fact_order_items.product_key | FK in dim_products | CRITICAL |
| fact_payments.order_id | FK in fact_orders | CRITICAL |
| dbt tests | All not_null, unique, relationships pass | CRITICAL |

## Action on Failure
CRITICAL : Block downstream + Slack alert dalam 15 minit
HIGH     : Quarantine bad rows, continue clean rows
MEDIUM   : dq_flag=True + log warning + continue

---

## Implementation (Phase 5)

### Great Expectations Setup
- GX Version: 0.15.50
- Context: `/data_quality/great_expectations/`
- Expectation Suites:
  - `bronze_suite.json` — 9 expectations (row count, metadata columns, batch_id format)
  - `silver_suite.json` — 12 expectations (NOT NULL, UNIQUE, SCD Type 2 validation)
  - `gold_suite.json` — dbt tests (47/48 passed, 98% pass rate)

### Checkpoints
- `bronze_checkpoint.yml` — Bronze layer validation
- `silver_checkpoint.yml` — Silver layer validation
- Runner scripts:
  - `run_bronze_validation.py`
  - `run_silver_validation.py`
  - `run_silver_suite.py` (Airflow-compatible wrapper)

### Integration
- Airflow DAG: `airflow/dags/olist_pipeline_dag.py`
- Pipeline orchestration: Bronze → Silver → Silver DQ → Gold (dbt)
- Manual test: `scripts/test_pipeline_orchestration.py`

### Validation Results (Phase 4b Baseline)
| Layer | Tables | Rows | Critical Tests | Pass Rate |
|-------|--------|------|----------------|-----------|
| Bronze | 9 | ~1.5M | Metadata cols | 100% |
| Silver | 7 | ~450k | NOT NULL, UNIQUE | 100% |
| Gold | 7 marts | ~450k | FK, relationships | 98% |

**Note:** 1 dbt test failure in `fact_payments` — payment_type accepted values (data issue, not modeling error). Documented for future data cleanup.
