# Data Dictionary: Olist E-Commerce Pipeline
> Owner: DQS | Updated: setiap kali schema berubah

## Business Terms
| Term | Definition | Example |
|------|-----------|---------|
| Order | Unique transaction dalam olist_orders | order_id = "abc123" |
| Delivered | order_status='delivered' AND delivered_date NOT NULL | - |
| On-Time | delivered_date <= estimated_delivery_date | - |
| DSO | AVG(payment_approved_at - order_purchase_timestamp) | 12.5 days |
| GMV | SUM(price + freight_value) — gross, sebelum deductions | R$250.00 |
| Repeat Customer | customer_unique_id dengan >1 order | - |
| Installment | Satu baris dalam payments — satu bahagian payment | payment_sequential=2 |

## Gold Tables (dbt Marts)
### mart__fact_orders
| Column | Business Name | Type | KPI? | Formula | Notes |
|--------|--------------|------|------|---------|-------|
| order_id | Order ID | string | N | - | PK |
| customer_key | Customer Key | string | N | - | FK → dim_customers |
| order_status | Order Status | string | N | - | delivered/shipped/etc |
| order_purchase_date | Purchase Date | date | N | - | partition key |
| dso_days | Days Sales Outstanding | float | Y | payment_approved_at - order_purchase_ts | NULL if not approved |
| is_delivered | Delivered Flag | boolean | N | order_status = 'delivered' | - |
| is_on_time | On-Time Flag | boolean | Y | delivered_date <= estimated_date | NULL if not delivered |

### mart__fact_order_items
| Column | Business Name | Type | KPI? | Formula | Notes |
|--------|--------------|------|------|---------|-------|
| order_id | Order ID | string | N | - | FK → fact_orders |
| order_item_id | Item Sequence | int | N | - | - |
| seller_key | Seller Key | string | N | - | FK → dim_sellers |
| product_key | Product Key | string | N | - | FK → dim_products |
| price | Item Price | float | N | - | BRL |
| freight_value | Freight Value | float | N | - | BRL |
| gmv | GMV | float | Y | price + freight_value | BRL |

### mart__fact_payments
| Column | Business Name | Type | KPI? | Formula | Notes |
|--------|--------------|------|------|---------|-------|
| order_id | Order ID | string | N | - | FK → fact_orders |
| payment_sequential | Installment No. | int | N | - | PK component |
| payment_type | Payment Type | string | N | - | credit_card/boleto |
| payment_value | Payment Value | float | Y | - | BRL per installment |
