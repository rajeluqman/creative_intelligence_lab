# BRD: Olist E-Commerce Pipeline
> Status: ✅ APPROVED — Phase 1 signed off 2026-05-13
> Domain: E-Commerce | Dataset: Olist Brazilian E-Commerce

## Stakeholders
| Stakeholder | Role | Data Need |
|-------------|------|-----------|
| Finance Team | Revenue reporting | DSO, Revenue Recognition per seller/month |
| Operations | Delivery performance | Fulfillment rate, on-time delivery rate |
| Seller Management | Seller health | GMV, review score, churn risk |
| Management | Executive dashboard | Overall GMV, customer retention, order trends |

## Business Requirements
1. Track Order-to-Cash cycle — dari order placed sampai payment received
2. Monitor seller performance — GMV, fulfillment rate, review score per seller
3. Analyse customer behaviour — retention, AOV, repeat purchase rate
4. Daily Gold layer available by 7AM untuk reporting consumers (6AM stretch target)
5. Batch processing via daily scheduled DAGs (source = historical snapshot, no streaming)

## KPIs
| KPI | Formula | Industry Benchmark (Reference) | Frequency |
|-----|---------|-------------------------------|-----------|
| DSO | AVG(payment_date - order_purchase_ts) | <30 days | Daily |
| Order Fulfillment Rate | delivered / placed * 100 | >95% | Daily |
| On-Time Delivery Rate | on_time / delivered * 100 | >90% | Daily |
| Seller GMV | SUM(price + freight_value) per seller | Trend | Monthly |
| Revenue Recognition | SUM(payment_value) per seller/month | Trend | Monthly |
| Customer Retention Rate | repeat_customers / total * 100 | >20% | Monthly |
| Avg Order Value | SUM(payment_value) / COUNT(orders) | Trend | Weekly |

> **Note**: Benchmarks are industry references. Actual Olist dataset performance calculated as-is tanpa manipulation.

## Business Definitions
- "Order" = record dalam olist_orders_dataset dengan unique order_id
- "Delivered" = order_status = 'delivered' AND order_delivered_customer_date IS NOT NULL
- "On-Time" = order_delivered_customer_date <= order_estimated_delivery_date
- "DSO" = payment approval date - order purchase timestamp
- "GMV" = price + freight_value (gross, sebelum deductions)
- "Repeat Customer" = customer_unique_id yang ada >1 order

## Scope Notes
- **Avg Review Score per Seller**: Calculated via fact_orders.review_score aggregation (bukan separate dim_reviews)
- **dim_reviews**: OUT of Phase 1-4 scope. Optional Phase 5 extension if time permits.
- **Source files**: 7 of 9 CSVs in scope (orders, order_items, payments, customers, sellers, products, geolocation). Reviews + translation handled via joins, bukan dedicated dimensions.

## SLA
- Gold layer available by **7AM daily** (hard deadline)
  - 6AM stretch target untuk demonstrate production-ready mindset
  - Alert triggers at 7:15AM kalau pipeline belum complete
- Pipeline failure alert dalam 15 minit via Slack

## Sign-off Gate
| Agent | Status | Reason | Date |
|-------|--------|--------|------|
| BA | ✅ APPROVED | Business requirements clear, stakeholders defined, KPIs validated | 2026-05-13 |
| PO | ✅ APPROVED | Scope appropriate, dim_reviews deferred, targets as benchmarks | 2026-05-13 |
| PM | ✅ APPROVED | All debates resolved, cloud platform confirmed (Azure) | 2026-05-13 |
| DQS | ✅ APPROVED | SLA feasibility confirmed, baseline approach validated | 2026-05-13 |
