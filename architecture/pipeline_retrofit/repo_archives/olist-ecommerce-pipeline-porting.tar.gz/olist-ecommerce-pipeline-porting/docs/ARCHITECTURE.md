# ARCHITECTURE: Olist E-Commerce Pipeline
> Status: 🚧 DRAFT — Phase 3  
> Date: 2026-05-13  
> Agents: DA, DPE, SDE, AE

## Overview

**Architecture Pattern**: Medallion (Bronze → Silver → Gold)  
**Data Modelling Paradigm**: Kimball — Star Schema (ADR-001)  
**Orchestration**: Apache Airflow standalone  
**Data Quality**: Great Expectations (suite per layer)  
**Alerting**: Slack webhook (DAG pass/fail)

**Resume Alignment**: Tools selected for industry-standard data engineering portfolio — Azure, Databricks, Snowflake, dbt, Airflow.

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                         INGESTION LAYER                             │
│  Kaggle API → Local dev (1000 rows) / ADLS Gen2 (full dataset)     │
│  Script: bronze/download_dataset.py                                 │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         BRONZE LAYER                                │
│  Storage : Azure ADLS Gen2 (abfss://...)                            │
│  Format  : Delta Lake (ACID, time travel)                           │
│  Schema  : Raw CSV schema preserved                                 │
│  Quality : File-level validation (row count, schema match)          │
│  Script  : bronze/ingest_to_delta.py                                │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         SILVER LAYER                                │
│  Processing: PySpark (Databricks CE — local mode dev)               │
│  Storage   : ADLS Gen2 Delta Lake                                   │
│  Transform : Cleansing, derived columns, type casting               │
│              - Deduplication (order_id, customer_id)                │
│              - Derived: is_delivered, is_on_time, gmv               │
│              - Surrogate key generation (customer_key, seller_key)  │
│  Quality   : Great Expectations suite (nullability, range checks)   │
│  Script    : silver/transform_silver.py                             │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         GOLD LAYER                                  │
│  Processing: dbt Core (SQL-based transformations)                   │
│  Storage   : Snowflake (staging → intermediate → mart)              │
│  Transform : Star Schema — 3 facts + 4 dimensions                   │
│              - dim_customers (SCD Type 2)                           │
│              - dim_sellers (SCD Type 2)                             │
│              - dim_products (SCD Type 1)                            │
│              - dim_date (static)                                    │
│              - fact_orders (grain: 1 order)                         │
│              - fact_order_items (grain: 1 line item)                │
│              - fact_payments (grain: 1 installment)                 │
│  Quality   : dbt tests (unique, not_null, relationships)            │
│  Script    : gold/dbt_models/ (dbt models)                          │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         SERVING LAYER                               │
│  BI Tool   : Power BI Desktop                                       │
│  Consumers : Finance (DSO), Ops (fulfillment), Mgmt (exec dash)     │
│  Source    : Snowflake Gold layer (fact_* + dim_*)                  │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Layer-by-Layer Design

### 1. Ingestion Layer

**Purpose**: Acquire Olist dataset from Kaggle and land to appropriate storage.

| Aspect | Value |
|--------|-------|
| Source | Kaggle API (olistbr/brazilian-ecommerce) |
| Auth | kaggle.json credentials (KAGGLE_USERNAME, KAGGLE_KEY) |
| Script | `bronze/download_dataset.py` |
| Dev mode | Download → sample 1000 rows → `data/olist_dev_1000rows/` (local only) |
| Staging mode | Download → full dataset → ADLS Gen2 `staging/landing/` |
| Prod mode | Download → full dataset → ADLS Gen2 `prod/landing/` |
| Files acquired | 9 CSVs (orders, order_items, payments, customers, sellers, products, geolocation, reviews, translation) |

**Environment-specific paths**:
- `dev`: `data/olist_dev_1000rows/` (local filesystem — NO cloud upload)
- `staging`: `abfss://olist-staging@azolistpiepeline.dfs.core.windows.net/landing/`
- `prod`: `abfss://olist-prod@azolistpiepeline.dfs.core.windows.net/landing/`

**DPE Note**: DATASET_SOURCE_PATH auto-set dalam .env.dev selepas run `download_dataset.py --env dev`.

---

### 2. Bronze Layer

**Purpose**: Raw data persistence dengan ACID guarantees + time travel.

| Aspect | Value |
|--------|-------|
| Storage | Azure ADLS Gen2 (Delta Lake format) |
| Schema | Raw CSV schema preserved (string types, nullable) |
| Partitioning | None (static dataset, 100k rows tidak memerlukan partitioning) |
| Compression | Snappy (Delta default) |
| Retention | 7 days (time travel window untuk dev/staging) |
| Script | `bronze/ingest_to_delta.py` |

**Bronze paths**:
- `dev`: `abfss://olist-dev@azolistpiepeline.dfs.core.windows.net/bronze/`
- `staging`: `abfss://olist-staging@azolistpiepeline.dfs.core.windows.net/bronze/`
- `prod`: `abfss://olist-prod@azolistpiepeline.dfs.core.windows.net/bronze/`

**Data Quality — Bronze**:
- File-level validation: row count match dengan source CSV
- Schema validation: column names + count match expected
- Checksum validation: MD5 hash per file
- Great Expectations suite: `bronze_suite.json`

**DA Note**: Delta Lake chosen untuk ACID + time travel. Parquet alone insufficient untuk production-grade landing zone.

---

### 3. Silver Layer

**Purpose**: Cleansed, typed, business-rule-applied data ready for Gold modelling.

| Aspect | Value |
|--------|-------|
| Processing | PySpark (Databricks CE Serverless SQL Warehouse) |
| Storage | ADLS Gen2 Delta Lake |
| Schema | Strongly typed (INT, DECIMAL, TIMESTAMP, BOOLEAN) |
| Deduplication | order_id, customer_id based on latest timestamp |
| Derived columns | is_delivered, is_on_time, gmv, review_score (aggregated) |
| Surrogate keys | customer_key, seller_key, product_key (generated) |
| Script | `silver/transform_silver.py` |

**Silver paths**:
- `dev`: `abfss://olist-dev@azolistpiepeline.dfs.core.windows.net/silver/`
- `staging`: `abfss://olist-staging@azolistpiepeline.dfs.core.windows.net/silver/`
- `prod`: `abfss://olist-prod@azolistpiepeline.dfs.core.windows.net/silver/`

**Transformations**:

1. **Type casting**:
   - `order_purchase_timestamp` → TIMESTAMP
   - `price`, `freight_value`, `payment_value` → DECIMAL(10,2)
   - `order_item_id`, `payment_sequential` → INT

2. **Derived columns** (orders table):
   - `is_delivered` = (order_status = 'delivered' AND order_delivered_customer_date IS NOT NULL)
   - `is_on_time` = (order_delivered_customer_date <= order_estimated_delivery_date) WHERE is_delivered=TRUE
   - `review_score` = AVG(review_score) per order_id from reviews table

3. **Derived columns** (order_items table):
   - `gmv` = price + freight_value

4. **Surrogate key generation**:
   - `customer_key` = ROW_NUMBER() OVER (ORDER BY customer_id, valid_from)
   - `seller_key` = ROW_NUMBER() OVER (ORDER BY seller_id, valid_from)
   - `product_key` = ROW_NUMBER() OVER (ORDER BY product_id)

**Data Quality — Silver**:
- Nullability checks: NOT NULL constraints per DRD
- Range checks: price >= 0, freight_value >= 0
- Referential integrity: order_id exists in orders table for every order_items row
- Deduplication validation: no duplicate order_id with same timestamp
- Great Expectations suite: `silver_suite.json`

**SDE Note**: PySpark local mode untuk dev. Databricks CE cluster untuk staging/prod. Auto-terminate 2 jam.

---

### 4. Gold Layer

**Purpose**: Analytics-ready Star Schema serving BI consumers.

| Aspect | Value |
|--------|-------|
| Processing | dbt Core (SQL transformations) |
| Storage | Snowflake (DEV / STAGING / PROD schemas) |
| Paradigm | Kimball — Star Schema (3 facts, 4 dimensions) |
| SCD | dim_customers (Type 2), dim_sellers (Type 2), dim_products (Type 1), dim_date (Static) |
| Script | `gold/dbt_models/` (dbt project) |

**Gold schemas** (Snowflake):
- `dev`: `olist_ecommerce.DEV`
- `staging`: `olist_ecommerce.STAGING`
- `prod`: `olist_ecommerce.PROD`

**dbt Project Structure**:
```
gold/
├── models/
│   ├── staging/         # Source from Silver Delta Lake via external stage
│   │   ├── stg_orders.sql
│   │   ├── stg_order_items.sql
│   │   ├── stg_payments.sql
│   │   ├── stg_customers.sql
│   │   ├── stg_sellers.sql
│   │   ├── stg_products.sql
│   ├── intermediate/    # SCD transformations
│   │   ├── int_customers_scd2.sql
│   │   ├── int_sellers_scd2.sql
│   ├── marts/           # Final Star Schema
│   │   ├── dim_customers.sql
│   │   ├── dim_sellers.sql
│   │   ├── dim_products.sql
│   │   ├── dim_date.sql
│   │   ├── fact_orders.sql
│   │   ├── fact_order_items.sql
│   │   ├── fact_payments.sql
├── dbt_project.yml
├── profiles.yml
```

**Star Schema Design**:

**Dimensions**:
- `dim_customers` — SCD Type 2 (zip_code_prefix changes tracked)
- `dim_sellers` — SCD Type 2 (city/state changes tracked)
- `dim_products` — SCD Type 1 (catalog overwrite)
- `dim_date` — Static (preloaded date spine)

**Facts**:
- `fact_orders` — grain: 1 row = 1 order | FK: customer_key, order_date_key
- `fact_order_items` — grain: 1 row = 1 line item | FK: order_id, product_key, seller_key
- `fact_payments` — grain: 1 row = 1 installment | FK: order_id

**Data Quality — Gold**:
- dbt tests: unique, not_null, relationships, accepted_values
- Aggregate validation: SUM(payment_value) in fact_payments = SUM(payment_value) in Silver
- Row count validation: fact_orders count = unique order_id count in Silver
- Great Expectations suite: `gold_suite.json`

**AE Note**: dbt Cloud deployment REJECTED — dbt Core sufficient untuk portfolio. Snowflake $400 credit = Gold layer ONLY, no Bronze/Silver storage.

---

## Technology Stack — Layer Summary

| Layer | Storage | Processing | Quality | Orchestration |
|-------|---------|------------|---------|---------------|
| Bronze | ADLS Gen2 Delta Lake | Python (kaggle API) + PySpark (Databricks COPY INTO, `bronze/ingest_to_delta.py`) | GX file validation | Airflow DAG (stub task — see note below) |
| Silver | ADLS Gen2 Delta Lake | PySpark (DataFrame API + Window functions), local or Databricks (`silver/transform_silver.py`) | GX suite + PySpark assertions | Airflow DAG (stub task — see note below) |
| Gold | Snowflake | dbt Core | dbt tests + GX suite | Airflow DAG (real — `dbt run`/`dbt test`) |

> **Note on Bronze/Silver "Airflow DAG" orchestration:** the DAG's `bronze_ingest`/
> `silver_transform`/`silver_dq_check` tasks (`bronze/bronze_pipeline.py`,
> `silver/silver_pipeline.py`, `data_quality/run_silver_validation.py`) are print-stub
> wrappers by design ("Demo/Portfolio: Validates configuration and reports success") — the
> real Bronze/Silver execution ran once, manually, via `databricks_notebooks/
> 01_bronze_ingestion.py` / `02_silver_transformation.py` during Phase 4b. Only the Gold dbt
> tasks execute real work on every scheduled run. See `CLAUDE.md` + `INTERVIEW_GUIDE.md`.

---

## Infrastructure — Platform Constraints

### Codespace (Local Dev)
- **Specs**: 2 core, 8GB RAM, 32GB storage
- **Constraints**:
  - PySpark local mode ONLY (no cluster)
  - Airflow standalone (pip install, localhost:8080)
  - 1000 rows sample dataset
  - NO cloud storage upload (local data/ folder)

### Azure Free Tier
- **ADLS Gen2**: 5GB storage limit
  - `olist-dev` container: Bronze + Silver dev data
  - `olist-staging` container: Bronze + Silver staging data
  - `olist-prod` container: Bronze + Silver prod data
- **ADF**: Pay-per-pipeline-run
  - Cloud promote ONLY (Phase 4b)
  - NOT used for dev/local

### Databricks CE (Community Edition)
- **Specs**: 1 Serverless SQL Warehouse, 15GB RAM
- **Constraints**:
  - Auto-terminate 2 jam
  - Save checkpoint sebelum terminate
  - Silver + Gold processing ONLY
  - Local mode PySpark untuk dev

### Snowflake Trial
- **Credit**: $400, 30 hari
- **Usage**: Gold layer ONLY (no Bronze/Silver)
- **Schemas**: DEV, STAGING, PROD
- **Warehouse**: COMPUTE_WH (X-Small)

**FinOps Note**: Token budget monitor active. Cloud spend logged dalam COST_LOG.md.

---

## Data Flow — End-to-End

```
[Kaggle API]
    │
    ▼
[download_dataset.py --env dev]
    │
    ├──> dev: data/olist_dev_1000rows/ (local)
    ├──> staging: ADLS Gen2 staging/landing/
    └──> prod: ADLS Gen2 prod/landing/
         │
         ▼
[ingest_to_delta.py]  ← Bronze layer
    │
    └──> ADLS Gen2 bronze/ (Delta Lake)
         │
         ▼
[transform_silver.py]  ← Silver layer (PySpark on Databricks)
    │
    └──> ADLS Gen2 silver/ (Delta Lake)
         │
         ▼
[dbt run]  ← Gold layer (dbt Core + Snowflake)
    │
    └──> Snowflake marts/ (Star Schema)
         │
         ▼
[Power BI Desktop]  ← BI consumption
    │
    └──> Finance/Ops/Mgmt dashboards
```

**Orchestration** (Airflow DAGs):
- `dag_bronze_ingest` — Trigger: daily 12AM | Run: download → ingest_to_delta
- `dag_silver_transform` — Trigger: after Bronze success | Run: PySpark transformations
- `dag_gold_dbt` — Trigger: after Silver success | Run: dbt run + dbt test
- Slack alert: DAG failure within 15 minutes

**SLA**: Gold layer available by 7AM daily (6AM stretch target).

---

## Security & Credentials

| Service | Credential | Storage |
|---------|-----------|---------|
| Kaggle API | KAGGLE_USERNAME, KAGGLE_KEY | .env.dev (gitignored) |
| Azure ADLS Gen2 | AZURE_STORAGE_ACCOUNT, AZURE_STORAGE_KEY | .env.dev |
| Databricks | DATABRICKS_HOST, DATABRICKS_TOKEN, DATABRICKS_HTTP_PATH | .env.dev |
| Snowflake | SNOWFLAKE_ACCOUNT, SNOWFLAKE_USER, SNOWFLAKE_PASSWORD | .env.dev |
| Airflow | AIRFLOW__CORE__FERNET_KEY, AIRFLOW__WEBSERVER__SECRET_KEY | .env.dev |
| Slack | SLACK_WEBHOOK_URL | .env.dev |

**DPE Note**: All credentials verified 2026-05-13 via `scripts/verify_credentials.py`. Status: ✅ 4/4 critical services connected.

---

## Environments

| Environment | Dataset | Trigger | Cloud Storage | Purpose |
|-------------|---------|---------|---------------|---------|
| `dev` | 1000 rows | Manual | Local data/ folder (NO cloud) | Local Codespace development |
| `staging` | Full dataset | Airflow scheduled | ADLS Gen2 staging/ | Pre-prod validation |
| `prod` | Full dataset | Airflow scheduled | ADLS Gen2 prod/ | Production serving |

**Environment isolation**:
- Snowflake schemas: `DEV` / `STAGING` / `PROD`
- ADLS containers: `olist-dev` / `olist-staging` / `olist-prod`
- dbt profiles: `target: dev` / `target: staging` / `target: prod`

---

## Monitoring & Observability

**Data Quality**:
- Great Expectations validation per layer
- dbt test failures → Slack alert
- Suite execution: Bronze (file-level) → Silver (row-level) → Gold (aggregate-level)

**Pipeline Monitoring**:
- Airflow UI: localhost:8080 (dev), cloud ADF (staging/prod)
- DAG run status: success/fail logged
- Slack alerts: #olist-pipeline-alerts channel

**Performance Metrics**:
- Bronze ingest time: target <5 min (100k rows)
- Silver transform time: target <10 min (PySpark)
- Gold dbt run time: target <15 min (Snowflake)
- End-to-end SLA: 7AM daily (total 30 min pipeline)

---

## Disaster Recovery & Rollback

**Delta Lake Time Travel** (Bronze/Silver):
- Retention: 7 days
- Rollback: `RESTORE TABLE bronze.orders TO VERSION AS OF <version>`

**Snowflake Time Travel** (Gold):
- Retention: 1 day (Snowflake trial default)
- Rollback: `CREATE TABLE dim_customers CLONE dim_customers AT(TIMESTAMP => '<timestamp>')`

**Backup Strategy**:
- Bronze: ADLS Gen2 snapshot (Azure Portal manual trigger)
- Silver/Gold: Rely on time travel (7 days / 1 day)
- Source CSVs: Retained in Kaggle (immutable dataset)

---

## Sign-off Checklist — Architecture Phase

- [x] Medallion architecture defined (Bronze, Silver, Gold)
- [x] Technology stack per layer documented
- [x] Storage patterns documented (ADLS Gen2, Snowflake)
- [x] Processing patterns documented (Python, PySpark, dbt)
- [x] Data flow end-to-end mapped
- [x] Platform constraints validated (Codespace, Azure, Databricks, Snowflake)
- [x] Credentials verified (4/4 critical services)
- [x] Environment strategy defined (dev, staging, prod)
- [x] SLA defined (7AM daily Gold availability)
- [x] Disaster recovery strategy documented
- [ ] PIPELINE_SPEC.md generated (next deliverable)
- [ ] DATA_MODEL.md generated (next deliverable)
- [ ] DEBATE_LOG_phase_3.md generated

---

**Next Step**: Generate PIPELINE_SPEC.md — technical specifications per layer (Bronze, Silver, Gold).
