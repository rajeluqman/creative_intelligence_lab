# DRD: Data Requirements Document
> Status: 🚧 IN PROGRESS — Phase 2
> Date: 2026-05-13
> Agents: BA, DA, SDE, DPE, DQS

## Source Overview
| Attribute | Value |
|-----------|-------|
| Source | Olist Brazilian E-Commerce (Kaggle) |
| Format | CSV (9 files) |
| Frequency | Static dataset — daily batch simulation |
| Volume | ~100k orders, ~830k order items, ~100k customers |
| Ingestion pattern | Snapshot |

---

## Conceptual Data Model

### Paradigm: Kimball — Star Schema
> Confirmed via ADR-001 (sign-off 2026-05-13)

```
          ┌─────────────────┐
          │  dim_customers  │
          │  (SCD Type 2)   │
          └────────┬────────┘
                   │
                   │
    ┌──────────────▼──────────────┐         ┌─────────────────┐
    │      fact_orders            │◄────────┤   dim_sellers   │
    │  grain: 1 row = 1 order     │         │   (SCD Type 2)  │
    └──────────────┬──────────────┘         └─────────────────┘
                   │
                   │
    ┌──────────────▼──────────────┐         ┌─────────────────┐
    │   fact_order_items          │◄────────┤  dim_products   │
    │ grain: 1 row = 1 line item  │         │   (SCD Type 1)  │
    └─────────────────────────────┘         └─────────────────┘
    
    ┌─────────────────────────────┐         ┌─────────────────┐
    │     fact_payments           │◄────────┤    dim_date     │
    │ grain: 1 row = 1 installment│         │     (Static)    │
    └─────────────────────────────┘         └─────────────────┘
```

**DA Note**: 3 fact tables, 4 dimensions. Star schema = join-heavy but storage-efficient. Validated for Codespace + Databricks CE constraints.

---

## Source Files & Schema

### olist_orders_dataset.csv (→ fact_orders)
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| order_id | string | N | PK |
| customer_id | string | N | FK → customers |
| order_status | string | N | approved/delivered/shipped/etc |
| order_purchase_timestamp | timestamp | N | order placed time |
| order_approved_at | timestamp | Y | payment approved time |
| order_delivered_carrier_date | timestamp | Y | handed to carrier |
| order_delivered_customer_date | timestamp | Y | NULL if not delivered |
| order_estimated_delivery_date | timestamp | N | expected delivery |

**Derived Columns** (added in Silver layer):
- `is_delivered` (BOOLEAN): order_status='delivered' AND order_delivered_customer_date IS NOT NULL
- `is_on_time` (BOOLEAN): order_delivered_customer_date <= order_estimated_delivery_date (NULL if not delivered)
- `review_score` (INT): AVG(review_score) per order_id from olist_order_reviews_dataset.csv — aggregated for Seller Performance KPI
- `order_date_key` (INT FK): DATE(order_purchase_timestamp) → dim_date lookup

**BA Note**: review_score aggregated at order level. No separate dim_reviews dimension.

**DQS Flag #1**: order_approved_at NULL dalam ~160 orders. Strategy: Use order_purchase_timestamp as fallback for DSO calculation.

### olist_order_items_dataset.csv (→ fact_order_items)
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| order_id | string | N | FK → orders |
| order_item_id | int | N | sequence within order |
| product_id | string | N | FK → products |
| seller_id | string | N | FK → sellers |
| shipping_limit_date | timestamp | N | seller must ship by |
| price | float | N | item price |
| freight_value | float | N | shipping cost |

**Derived Columns** (added in Silver layer):
- `gmv` (DECIMAL): price + freight_value — Gross Merchandise Value per line item
- `product_key` (INT FK): Lookup dim_products via product_id
- `seller_key` (INT FK): Lookup dim_sellers via seller_id

**Grain**: Composite PK = (order_id, order_item_id)

**SDE Note**: 112,650 rows untuk 99k orders = avg 1.13 items per order. Multi-item orders validated.

**DQS Flag #2**: price = 0.00 observed dalam 2 rows. Strategy: Flag as anomaly, retain in dataset for completeness.

### olist_order_payments_dataset.csv (→ fact_payments)
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| order_id | string | N | FK → orders |
| payment_sequential | int | N | installment sequence |
| payment_type | string | N | credit_card/boleto/etc |
| payment_installments | int | N | total installments |
| payment_value | float | N | value per installment |

**Grain**: Composite PK = (order_id, payment_sequential)

**BA Note**: payment_sequential > 1 indicates multiple payment methods per order. Observed dalam ~3% orders.

**DQS Flag #3**: payment_value mismatch dengan SUM(fact_order_items.gmv) dalam ~0.8% orders. Strategy: Accept source data as-is, log reconciliation issue in Silver layer.

### olist_customers_dataset.csv (→ dim_customers)
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| customer_id | string | N | PK (per order) |
| customer_unique_id | string | N | true customer identifier |
| customer_zip_code_prefix | string | N | SCD2 tracking key |
| customer_city | string | N | |
| customer_state | string | N | |

**SCD Type 2 Columns** (added in Silver layer):
- `customer_key` (INT PK): Surrogate key — auto-increment
- `effective_date` (DATE): Snapshot date when record became active
- `expiration_date` (DATE): Next snapshot date or 9999-12-31 for current record
- `is_current` (BOOLEAN): TRUE if expiration_date = 9999-12-31

**Natural Key**: customer_id
**SCD Trigger**: Changes to customer_zip_code_prefix, customer_city, or customer_state

**DA Note**: customer_id ≠ customer_unique_id. Use customer_unique_id untuk Customer Retention KPI (persistent across orders). customer_id = order-specific identifier.

### olist_sellers_dataset.csv (→ dim_sellers)
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| seller_id | string | N | PK |
| seller_zip_code_prefix | string | N | SCD2 tracking key |
| seller_city | string | N | |
| seller_state | string | N | |

**SCD Type 2 Columns** (added in Silver layer):
- `seller_key` (INT PK): Surrogate key — auto-increment
- `effective_date` (DATE): Snapshot date when record became active
- `expiration_date` (DATE): Next snapshot date or 9999-12-31 for current record
- `is_current` (BOOLEAN): TRUE if expiration_date = 9999-12-31

**Natural Key**: seller_id
**SCD Trigger**: Changes to seller_zip_code_prefix, seller_city, or seller_state

**DPE Note**: 3,095 sellers total. SCD Type 2 overhead minimal — projected <5k rows over 2-year timeframe.

### olist_products_dataset.csv (→ dim_products)
| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| product_id | string | N | PK |
| product_category_name | string | Y | Portuguese — join translation |
| product_name_lenght | int | Y | |
| product_description_lenght | int | Y | |
| product_photos_qty | int | Y | |
| product_weight_g | int | Y | |
| product_length_cm | int | Y | |
| product_height_cm | int | Y | |
| product_width_cm | int | Y | |

**Transform Logic**:
- Join product_category_name_translation.csv via LEFT JOIN on product_category_name
- Add `product_category_name_english` column (English translation)
- Add `product_key` (INT PK): Surrogate key — auto-increment

**SCD Type**: Type 1 — catalog overwrites accepted (no history tracking)

**DQS Flag #4**: product_category_name NULL dalam ~610 products. Strategy: Map NULL to 'unknown' category.

**DQS Flag #5**: Physical dimensions (weight, length, height, width) all NULLABLE. 2k+ products missing dimensions. Impact: Shipping cost correlation analysis limited.

---

## dim_date (Static Calendar Table)

**SCD Type**: Static — pre-generated

| Column | Type | Description |
|--------|------|-------------|
| date_key | INT (PK) | YYYYMMDD format (e.g., 20160101) |
| full_date | DATE | Actual date value |
| year | INT | Year (2016-2020) |
| quarter | INT | Quarter (1-4) |
| month | INT | Month (1-12) |
| month_name | STRING | 'January', 'February', etc. |
| day_of_month | INT | Day (1-31) |
| day_of_week | INT | 1=Monday, 7=Sunday |
| day_of_week_name | STRING | 'Monday', 'Tuesday', etc. |
| is_weekend | BOOLEAN | TRUE if Saturday/Sunday |

**Date Range**: 2016-01-01 to 2020-12-31 (covers Olist dataset timeframe)

**DPE Note**: Pre-generate via dbt seed or SQL script. ~1,800 rows — negligible storage cost.

---

## Data Quality Expectations

### Bronze Layer (Great Expectations)
| Rule | Scope | Severity | Action on Fail |
|------|-------|----------|----------------|
| expect_table_row_count_to_be_between | All tables | WARN | Log + continue |
| expect_column_values_to_not_be_null | PK/FK columns | CRITICAL | Stop pipeline |
| expect_column_values_to_be_unique | PK columns | CRITICAL | Stop pipeline |
| expect_column_values_to_match_regex | UUID columns (order_id, customer_id, etc.) | WARN | Log + continue |
| expect_column_values_to_be_in_set | order_status, payment_type | WARN | Log + continue |
| expect_column_values_to_be_between | price, freight_value, payment_value | WARN | Log + flag |

**DQS**: Bronze = validation ONLY, no transformation. Fail fast on schema breaks.

### Silver Layer (Transformation + enrichment)
| Rule | Logic | Action on Fail |
|------|-------|----------------|
| FK referential integrity | All FK lookups must resolve | Drop orphan rows + log count |
| Timestamp ordering | order_approved_at > order_purchase_timestamp | Flag anomaly, retain row |
| Payment reconciliation | fact_payments.payment_value vs fact_order_items.gmv (±5% tolerance) | Log mismatch |
| SCD effective_date logic | No overlapping date ranges per natural key | Stop pipeline — data corruption |

### Gold Layer (dbt tests)
| Test | Model | Logic |
|------|-------|-------|
| unique | All PKs | dbt test unique |
| not_null | All PKs/FKs | dbt test not_null |
| relationships | All FKs | dbt test relationships |
| accepted_values | order_status, payment_type | dbt test accepted_values |

---

## Platform Constraints — DPE Review

| Layer | Platform | Constraint | Impact |
|-------|----------|------------|--------|
| Bronze | ADLS Gen2 | 5GB storage limit | 9 CSVs = ~350MB raw. Delta Lake parquet = ~150MB compressed. ✅ Within limit |
| Silver | Databricks CE | 15GB RAM, 2hr auto-terminate | PySpark local mode. Max 1M rows per transform. Checkpoint after each stage. ✅ Feasible |
| Gold | Snowflake | $400 credit, 30 days | Store Gold layer ONLY. Estimated: 300MB Gold + queries = ~$50 usage. ✅ Within budget |

**DPE Decision**: 
- **olist_geolocation_dataset.csv (1M rows)** = EXCLUDE from Bronze to save storage. Use zip_code_prefix from customers/sellers tables only.
- **Databricks CE auto-terminate** = Checkpoint after each Silver transform via `.checkpoint()` API calls.
- **Snowflake cost monitoring** = Track daily usage. Gold layer refresh = ~$2-3 per run.

**SDE Sync**: ✅ Confirmed — DA + DPE aligned on storage vs compute tradeoff. Star schema validated for platform constraints.

---

## Transform Logic Summary

### Bronze → Silver
1. **Parse timestamps**: ISO8601 string → TIMESTAMP type (all date/time columns)
2. **Deduplicate**: Based on PK columns (order_id, product_id, etc.)
3. **FK resolution**: 
   - fact_orders → dim_customers (customer_id lookup)
   - fact_order_items → dim_products (product_id lookup)
   - fact_order_items → dim_sellers (seller_id lookup)
   - All facts → dim_date (order_purchase_timestamp → date_key)
4. **SCD Type 2 logic**: For dim_customers, dim_sellers
   - Add effective_date, expiration_date, is_current
   - Detect changes in zip_code_prefix, city, state
5. **Aggregate review_score**: AVG(review_score) per order_id from olist_order_reviews_dataset.csv → fact_orders.review_score
6. **Derived columns**: is_delivered, is_on_time, gmv

### Silver → Gold (dbt models)
- **staging/**: 1:1 with Silver tables, add surrogate keys, basic cleaning
- **intermediate/**: Business logic transforms (is_delivered, is_on_time, gmv calculations)
- **marts/**: Final fact/dimension tables with dbt tests + documentation

---

## Upstream Data Issues — Pre-Flagged (5 Total)

| Issue | Impact | Mitigation Strategy | Severity |
|-------|--------|---------------------|----------|
| **#1** order_approved_at NULL dalam ~160 orders | DSO calculation incomplete | Use order_purchase_timestamp as fallback for DSO | MEDIUM |
| **#2** price = 0.00 dalam 2 order_items | GMV calculation skewed (minor) | Flag as data anomaly, retain in dataset | LOW |
| **#3** payment_value mismatch dengan order_items.gmv (~0.8%) | Revenue reconciliation gap | Accept source as-is, log mismatch in Silver | MEDIUM |
| **#4** product_category_name NULL dalam ~610 products | Category analysis incomplete | Map NULL to 'unknown' category | LOW |
| **#5** Physical dimensions NULL dalam 2k+ products | Shipping cost analysis limited | Exclude NULL dimension rows from freight correlation | LOW |

**DQS Recommendation**: Document all 5 issues dalam JOURNEY_LOG.md untuk interview storytelling — demonstrates realistic data pipeline challenges + mitigation strategies.

---

## Sign-off Gate

| Agent | Status | Comments | Date |
|-------|--------|----------|------|
| BA | ✅ APPROVED | Column mappings validated. KPI calculation logic clear. review_score aggregation strategy confirmed. | 2026-05-13 |
| DA | ✅ APPROVED | Conceptual model validated. Star schema aligns with platform constraints. SCD Type 2/1 assignments locked. | 2026-05-13 |
| SDE | ✅ APPROVED | Grain definitions validated. FK resolution logic clear. Transform complexity within Databricks CE capability. | 2026-05-13 |
| DPE | ✅ APPROVED | Platform constraints reviewed. ADLS Gen2 5GB sufficient. Databricks CE 15GB feasible. Snowflake $400 budget safe. geolocation exclusion confirmed. | 2026-05-13 |
| DQS | ✅ APPROVED | 5 upstream issues documented with mitigation strategies. Bronze/Silver/Gold DQ rules defined. Great Expectations suite scoped. | 2026-05-13 |
| PM | ✅ APPROVED | All Phase 2 deliverables complete. Hard blockers resolved. Ready for Phase 3 — Architecture + SPEC. | 2026-05-13 |

---

## Hard Blockers Before Phase 3 — Status

| Blocker | Status | Notes |
|---------|--------|-------|
| ✅ Grain defined untuk setiap fact table | DONE | fact_orders=1 order, fact_order_items=1 line item, fact_payments=1 installment |
| ✅ DA + DPE sync confirmed | DONE | Storage vs compute tradeoff validated. Star schema locked. |
| ✅ Upstream issues flagged + strategy decided | DONE | 5 issues documented with mitigation strategies above |
| ✅ Source pattern decided: Snapshot | DONE | Confirmed — daily batch, no streaming |
| ⏳ DEBATE_LOG_phase_2.md generated | NEXT | Generate before Phase 3 kickoff |

---

## Next Steps After Sign-off
1. ✅ DRD.md complete — all agents signed off
2. ⏳ Generate docs/DEBATE_LOG_phase_2.md
3. ⏳ Proceed to Phase 3 — Architecture + DATA_MODEL.md (logical model + DDL schema)
4. ⏳ SDE + DA finalize DDL schema definitions in Phase 3
