# DATA_MODEL: Olist E-Commerce Pipeline  
> Status: 🚧 DRAFT — Phase 3  
> Date: 2026-05-13  
> Owner: Data Architect  
> Validated by: DPE (platform feasibility), SDE (implementation feasibility), AE (analytics feasibility)

## Overview

**Paradigm**: Kimball — Star Schema (ADR-001)  
**Layers**: Bronze (raw) → Silver (cleansed) → Gold (dimensional)  
**SCD Strategy**: Type 2 for customers/sellers, Type 1 for products, Static for date  
**Grain Locked**: ✅ fact_orders (1 order), fact_order_items (1 line item), fact_payments (1 installment)

---

## Paradigm Decision — Kimball Star Schema

**Chosen**: Kimball — Star Schema  
**Reason**: 
- Aggregate-heavy analytics (DSO, fulfillment rate, GMV, revenue recognition)
- 3 fact tables, 4 dimensions = manageable join complexity
- 100k rows fit Codespace + Databricks CE 15GB constraints
- Storage-efficient for free-tier cloud (ADLS Gen2 5GB limit)

**Tradeoff**:
- (+) Less storage, standard analytics pattern, BI tool friendly
- (+) Databricks CE 15GB sufficient — no OOM risk
- (+) ADLS Gen2 5GB sufficient — no storage duplication
- (-) Joins required at query time (vs denormalized OBT)
- (-) OBT rejected — complex Array/Struct types = memory risk on CE

**Validated by DPE**: 
- [x] Databricks CE 15GB — fit (100k orders, Kimball joins manageable)
- [x] ADLS Gen2 storage — cost sustainable (<5GB for dataset)
- [x] Delta Lake MERGE — supported for SCD Type 2
- [x] Snowflake $400 credit — Gold queries only, sustainable

---

## Entity Relationship Diagram (Star Schema)

```
                              ┌────────────────────┐
                              │   dim_customers    │
                              │  (SCD Type 2)      │
                              │ PK: customer_key   │
                              │ NK: customer_id    │
                              └──────────┬─────────┘
                                         │
                                         │ 1:N
                                         │
    ┌──────────────────┐         ┌──────▼─────────────────┐         ┌────────────────────┐
    │    dim_date      │         │     fact_orders        │         │   dim_sellers      │
    │    (Static)      │ 1:N     │ PK: order_id           │     N:1 │  (SCD Type 2)      │
    │ PK: date_key     ├─────────┤ FK: customer_key       ├─────────┤ PK: seller_key     │
    └──────────────────┘         │ FK: order_date_key     │         │ NK: seller_id      │
                                 └────────────────────────┘         └──────────┬─────────┘
                                           │ 1:N                              │
                                           │                                  │
                                           │                                  │ N:1
                                 ┌─────────▼──────────────┐                  │
                                 │  fact_order_items      │                  │
                                 │ PK: (order_id,         ├──────────────────┘
                                 │      order_item_id)    │
                                 │ FK: order_id           │         ┌────────────────────┐
                                 │ FK: product_key        ├─────────┤  dim_products      │
                                 │ FK: seller_key         │     N:1 │  (SCD Type 1)      │
                                 └────────────────────────┘         │ PK: product_key    │
                                           │ 1:N                    │ NK: product_id     │
                                           │                        └────────────────────┘
                                 ┌─────────▼──────────────┐
                                 │   fact_payments        │
                                 │ PK: (order_id,         │
                                 │      payment_seq)      │
                                 │ FK: order_id           │
                                 └────────────────────────┘
```

**Relationships**:
- dim_customers 1:N fact_orders (one customer can have many orders)
- dim_date 1:N fact_orders (one date can have many orders)
- fact_orders 1:N fact_order_items (one order can have many line items)
- dim_products N:1 fact_order_items (many line items can reference one product)
- dim_sellers N:1 fact_order_items (many line items can reference one seller)
- fact_order_items 1:N fact_payments (one order can have many payment installments, linked via order_id)

---

## Bronze Layer — Raw Data Schema

### Purpose
Store raw CSV data as-is with metadata columns for lineage + time travel.

### bronze.raw_orders

```sql
CREATE TABLE bronze.raw_orders (
    -- Source columns (all STRING, preserving raw format)
    order_id                        STRING,
    customer_id                     STRING,
    order_status                    STRING,
    order_purchase_timestamp        STRING,
    order_approved_at               STRING,
    order_delivered_carrier_date    STRING,
    order_delivered_customer_date   STRING,
    order_estimated_delivery_date   STRING,
    -- Metadata columns
    ingestion_timestamp             TIMESTAMP   NOT NULL,
    source_system                   STRING      NOT NULL DEFAULT 'olist_kaggle',
    batch_id                        STRING      NOT NULL,
    source_file_name                STRING      NOT NULL,
    row_hash                        STRING      NOT NULL
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/bronze/raw_orders';
```

**Similar structure for**:
- bronze.raw_order_items
- bronze.raw_payments
- bronze.raw_customers
- bronze.raw_sellers
- bronze.raw_products
- bronze.raw_geolocation
- bronze.raw_reviews
- bronze.raw_category_translation

---

## Silver Layer — Cleansed Data Schema

### Purpose
Strongly-typed, cleansed data with business rules applied, SCD tracking for dimensions.

### silver.orders

```sql
CREATE TABLE silver.orders (
    -- Primary Key
    order_id                        STRING          NOT NULL,
    
    -- Foreign Keys
    customer_id                     STRING          NOT NULL,  -- FK to silver.customers
    
    -- Attributes
    order_status                    STRING          NOT NULL,
    order_purchase_timestamp        TIMESTAMP       NOT NULL,
    order_approved_at               TIMESTAMP,                 -- nullable (DQS Flag #1)
    order_delivered_carrier_date    TIMESTAMP,
    order_delivered_customer_date   TIMESTAMP,
    order_estimated_delivery_date   TIMESTAMP       NOT NULL,
    
    -- Derived Columns (Business Logic)
    is_delivered                    BOOLEAN         NOT NULL,  -- order_status='delivered' AND delivered_date NOT NULL
    is_on_time                      BOOLEAN,                   -- delivered_date <= estimated_date (NULL if not delivered)
    review_score                    DECIMAL(3,2),              -- AVG(review_score) from reviews table (1.00-5.00)
    dq_approved_flag                BOOLEAN         NOT NULL,  -- FALSE if order_approved_at NULL (DQS Flag #1)
    
    -- Metadata
    valid_from                      TIMESTAMP       NOT NULL,
    valid_to                        TIMESTAMP,                 -- NULL = current version
    is_current                      BOOLEAN         NOT NULL DEFAULT TRUE,
    source_batch_id                 STRING          NOT NULL,
    
    -- Constraints
    PRIMARY KEY (order_id),
    CHECK (order_purchase_timestamp < order_delivered_customer_date OR order_delivered_customer_date IS NULL),
    CHECK (review_score BETWEEN 1.00 AND 5.00 OR review_score IS NULL)
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/silver/orders';
```

### silver.order_items

```sql
CREATE TABLE silver.order_items (
    -- Composite Primary Key
    order_id                        STRING          NOT NULL,  -- PK part 1
    order_item_id                   INT             NOT NULL,  -- PK part 2
    
    -- Foreign Keys
    product_id                      STRING          NOT NULL,  -- FK to silver.products
    seller_id                       STRING          NOT NULL,  -- FK to silver.sellers
    
    -- Attributes
    shipping_limit_date             TIMESTAMP       NOT NULL,
    price                           DECIMAL(10,2)   NOT NULL,
    freight_value                   DECIMAL(10,2)   NOT NULL,
    
    -- Derived Columns
    gmv                             DECIMAL(10,2)   NOT NULL,  -- price + freight_value
    dq_zero_price_flag              BOOLEAN         NOT NULL,  -- TRUE if price = 0.00 (DQS Flag #2)
    
    -- Metadata
    valid_from                      TIMESTAMP       NOT NULL,
    source_batch_id                 STRING          NOT NULL,
    
    -- Constraints
    PRIMARY KEY (order_id, order_item_id),
    CHECK (price >= 0),
    CHECK (freight_value >= 0),
    CHECK (gmv = price + freight_value)
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/silver/order_items';
```

### silver.payments

```sql
CREATE TABLE silver.payments (
    -- Composite Primary Key
    order_id                        STRING          NOT NULL,  -- PK part 1
    payment_sequential              INT             NOT NULL,  -- PK part 2 (installment seq)
    
    -- Attributes
    payment_type                    STRING          NOT NULL,  -- credit_card, boleto, voucher, debit_card
    payment_installments            INT             NOT NULL,
    payment_value                   DECIMAL(10,2)   NOT NULL,
    
    -- Metadata
    valid_from                      TIMESTAMP       NOT NULL,
    source_batch_id                 STRING          NOT NULL,
    
    -- Constraints
    PRIMARY KEY (order_id, payment_sequential),
    CHECK (payment_value > 0),
    CHECK (payment_installments > 0),
    CHECK (payment_type IN ('credit_card', 'boleto', 'voucher', 'debit_card'))
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/silver/payments';
```

### silver.customers (SCD Type 2)

```sql
CREATE TABLE silver.customers (
    -- Surrogate Primary Key
    customer_key                    INT             NOT NULL,  -- Surrogate PK (auto-increment)
    
    -- Natural Key
    customer_unique_id              STRING          NOT NULL,  -- Business key (can have multiple versions due to SCD2)
    customer_id                     STRING          NOT NULL,  -- Order FK (per order, can differ from unique_id)
    
    -- SCD Type 2 Tracked Attributes
    customer_zip_code_prefix        STRING          NOT NULL,  -- Tracked for location history
    customer_city                   STRING          NOT NULL,
    customer_state                  STRING          NOT NULL,
    
    -- SCD Type 2 Control Columns
    valid_from                      TIMESTAMP       NOT NULL,
    valid_to                        TIMESTAMP,                 -- NULL = current version
    is_current                      BOOLEAN         NOT NULL DEFAULT TRUE,
    
    -- Metadata
    source_batch_id                 STRING          NOT NULL,
    
    -- Constraints
    PRIMARY KEY (customer_key),
    CHECK ((valid_to IS NULL AND is_current = TRUE) OR (valid_to IS NOT NULL AND is_current = FALSE))
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/silver/customers';

-- Index for SCD lookups
CREATE INDEX idx_customer_natural_key ON silver.customers (customer_unique_id, is_current);
```

**SCD Type 2 Logic**:
- When customer_zip_code_prefix changes:
  1. Expire old record: SET valid_to = CURRENT_TIMESTAMP, is_current = FALSE
  2. Insert new record: new customer_key, valid_from = CURRENT_TIMESTAMP, is_current = TRUE
- Only one record per customer_unique_id with is_current = TRUE

### silver.sellers (SCD Type 2)

```sql
CREATE TABLE silver.sellers (
    -- Surrogate Primary Key
    seller_key                      INT             NOT NULL,
    
    -- Natural Key
    seller_id                       STRING          NOT NULL,
    
    -- SCD Type 2 Tracked Attributes
    seller_zip_code_prefix          STRING          NOT NULL,
    seller_city                     STRING          NOT NULL,  -- Tracked for location history
    seller_state                    STRING          NOT NULL,  -- Tracked for location history
    
    -- SCD Type 2 Control Columns
    valid_from                      TIMESTAMP       NOT NULL,
    valid_to                        TIMESTAMP,
    is_current                      BOOLEAN         NOT NULL DEFAULT TRUE,
    
    -- Metadata
    source_batch_id                 STRING          NOT NULL,
    
    -- Constraints
    PRIMARY KEY (seller_key),
    CHECK ((valid_to IS NULL AND is_current = TRUE) OR (valid_to IS NOT NULL AND is_current = FALSE))
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/silver/sellers';

CREATE INDEX idx_seller_natural_key ON silver.sellers (seller_id, is_current);
```

### silver.products (SCD Type 1)

```sql
CREATE TABLE silver.products (
    -- Surrogate Primary Key
    product_key                     INT             NOT NULL,
    
    -- Natural Key
    product_id                      STRING          NOT NULL UNIQUE,
    
    -- Attributes
    product_category_name           STRING,                    -- Portuguese (nullable)
    product_category_name_english   STRING          NOT NULL,  -- English (default: 'uncategorized')
    product_name_length             INT,
    product_description_length      INT,
    product_photos_qty              INT,
    product_weight_g                INT,
    product_length_cm               INT,
    product_height_cm               INT,
    product_width_cm                INT,
    
    -- Metadata
    valid_from                      TIMESTAMP       NOT NULL,
    source_batch_id                 STRING          NOT NULL,
    
    -- Constraints
    PRIMARY KEY (product_key),
    UNIQUE (product_id)
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/silver/products';
```

**SCD Type 1 Logic**: Full refresh (OVERWRITE mode). No history tracking.

### silver.geolocation (Reference Table)

```sql
CREATE TABLE silver.geolocation (
    geolocation_zip_code_prefix     STRING          NOT NULL,
    geolocation_lat                 DECIMAL(9,6),
    geolocation_lng                 DECIMAL(9,6),
    geolocation_city                STRING,
    geolocation_state               STRING,
    
    -- Metadata
    valid_from                      TIMESTAMP       NOT NULL,
    source_batch_id                 STRING          NOT NULL,
    
    PRIMARY KEY (geolocation_zip_code_prefix)
) USING DELTA
LOCATION 'abfss://olist-{env}@azolistpiepeline.dfs.core.windows.net/silver/geolocation';
```

---

## Gold Layer — Star Schema (Snowflake)

### Purpose
Analytics-ready dimensional model for BI consumption.

### dim_customers (SCD Type 2)

```sql
CREATE OR REPLACE TABLE olist_ecommerce.{env}.dim_customers (
    -- Surrogate Primary Key
    customer_key                    NUMBER(38,0)    NOT NULL,
    
    -- Natural Key
    customer_unique_id              VARCHAR(100)    NOT NULL,
    customer_id                     VARCHAR(100)    NOT NULL,
    
    -- Attributes
    customer_zip_code_prefix        VARCHAR(10)     NOT NULL,
    customer_city                   VARCHAR(100)    NOT NULL,
    customer_state                  VARCHAR(2)      NOT NULL,
    
    -- SCD Type 2 Control Columns
    valid_from                      TIMESTAMP_NTZ   NOT NULL,
    valid_to                        TIMESTAMP_NTZ,
    is_current                      BOOLEAN         NOT NULL DEFAULT TRUE,
    
    -- Metadata
    source_batch_id                 VARCHAR(50)     NOT NULL,
    dbt_updated_at                  TIMESTAMP_NTZ   NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    
    -- Constraints
    PRIMARY KEY (customer_key),
    CONSTRAINT chk_dim_customers_scd2 CHECK (
        (valid_to IS NULL AND is_current = TRUE) OR 
        (valid_to IS NOT NULL AND is_current = FALSE)
    )
);

-- Clustering for performance
ALTER TABLE olist_ecommerce.{env}.dim_customers 
CLUSTER BY (customer_unique_id, is_current);
```

### dim_sellers (SCD Type 2)

```sql
CREATE OR REPLACE TABLE olist_ecommerce.{env}.dim_sellers (
    seller_key                      NUMBER(38,0)    NOT NULL,
    seller_id                       VARCHAR(100)    NOT NULL,
    seller_zip_code_prefix          VARCHAR(10)     NOT NULL,
    seller_city                     VARCHAR(100)    NOT NULL,
    seller_state                    VARCHAR(2)      NOT NULL,
    valid_from                      TIMESTAMP_NTZ   NOT NULL,
    valid_to                        TIMESTAMP_NTZ,
    is_current                      BOOLEAN         NOT NULL DEFAULT TRUE,
    source_batch_id                 VARCHAR(50)     NOT NULL,
    dbt_updated_at                  TIMESTAMP_NTZ   NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    
    PRIMARY KEY (seller_key),
    CONSTRAINT chk_dim_sellers_scd2 CHECK (
        (valid_to IS NULL AND is_current = TRUE) OR 
        (valid_to IS NOT NULL AND is_current = FALSE)
    )
);

ALTER TABLE olist_ecommerce.{env}.dim_sellers 
CLUSTER BY (seller_id, is_current);
```

### dim_products (SCD Type 1)

```sql
CREATE OR REPLACE TABLE olist_ecommerce.{env}.dim_products (
    product_key                     NUMBER(38,0)    NOT NULL,
    product_id                      VARCHAR(100)    NOT NULL UNIQUE,
    product_category_name           VARCHAR(100),
    product_category_name_english   VARCHAR(100)    NOT NULL,
    product_name_length             NUMBER(10,0),
    product_description_length      NUMBER(10,0),
    product_photos_qty              NUMBER(10,0),
    product_weight_g                NUMBER(10,0),
    product_length_cm               NUMBER(10,0),
    product_height_cm               NUMBER(10,0),
    product_width_cm                NUMBER(10,0),
    valid_from                      TIMESTAMP_NTZ   NOT NULL,
    source_batch_id                 VARCHAR(50)     NOT NULL,
    dbt_updated_at                  TIMESTAMP_NTZ   NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    
    PRIMARY KEY (product_key),
    UNIQUE (product_id)
);
```

### dim_date (Static)

```sql
CREATE OR REPLACE TABLE olist_ecommerce.{env}.dim_date (
    date_key                        NUMBER(8,0)     NOT NULL,  -- YYYYMMDD format
    date_actual                     DATE            NOT NULL UNIQUE,
    year                            NUMBER(4,0)     NOT NULL,
    quarter                         NUMBER(1,0)     NOT NULL,
    month                           NUMBER(2,0)     NOT NULL,
    month_name                      VARCHAR(20)     NOT NULL,
    week                            NUMBER(2,0)     NOT NULL,
    day_of_month                    NUMBER(2,0)     NOT NULL,
    day_of_week                     NUMBER(1,0)     NOT NULL,  -- 1=Monday, 7=Sunday
    day_name                        VARCHAR(20)     NOT NULL,
    is_weekend                      BOOLEAN         NOT NULL,
    is_holiday                      BOOLEAN         NOT NULL DEFAULT FALSE,
    
    PRIMARY KEY (date_key),
    UNIQUE (date_actual)
);

-- Pre-populate date spine (2016-2018 covering Olist dataset)
-- Generated via dbt macro: generate_date_spine()
```

### fact_orders

```sql
CREATE OR REPLACE TABLE olist_ecommerce.{env}.fact_orders (
    -- Primary Key
    order_id                        VARCHAR(100)    NOT NULL,
    
    -- Foreign Keys
    customer_key                    NUMBER(38,0)    NOT NULL,
    order_date_key                  NUMBER(8,0)     NOT NULL,
    
    -- Attributes
    order_status                    VARCHAR(20)     NOT NULL,
    order_purchase_timestamp        TIMESTAMP_NTZ   NOT NULL,
    order_approved_at               TIMESTAMP_NTZ,
    order_delivered_customer_date   TIMESTAMP_NTZ,
    order_estimated_delivery_date   TIMESTAMP_NTZ   NOT NULL,
    
    -- Derived Measures
    is_delivered                    BOOLEAN         NOT NULL,
    is_on_time                      BOOLEAN,
    review_score                    NUMBER(3,2),
    
    -- Data Quality Flags
    dq_approved_flag                BOOLEAN         NOT NULL,
    
    -- Metadata
    dbt_updated_at                  TIMESTAMP_NTZ   NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    
    -- Constraints
    PRIMARY KEY (order_id),
    FOREIGN KEY (customer_key) REFERENCES olist_ecommerce.{env}.dim_customers(customer_key),
    FOREIGN KEY (order_date_key) REFERENCES olist_ecommerce.{env}.dim_date(date_key),
    CONSTRAINT chk_fact_orders_dates CHECK (
        order_purchase_timestamp < order_delivered_customer_date OR 
        order_delivered_customer_date IS NULL
    )
);

-- Clustering for query performance
ALTER TABLE olist_ecommerce.{env}.fact_orders 
CLUSTER BY (order_date_key, customer_key);
```

### fact_order_items

```sql
CREATE OR REPLACE TABLE olist_ecommerce.{env}.fact_order_items (
    -- Composite Primary Key
    order_id                        VARCHAR(100)    NOT NULL,
    order_item_id                   NUMBER(10,0)    NOT NULL,
    
    -- Foreign Keys
    product_key                     NUMBER(38,0)    NOT NULL,
    seller_key                      NUMBER(38,0)    NOT NULL,
    
    -- Attributes
    shipping_limit_date             TIMESTAMP_NTZ   NOT NULL,
    
    -- Measures
    price                           NUMBER(10,2)    NOT NULL,
    freight_value                   NUMBER(10,2)    NOT NULL,
    gmv                             NUMBER(10,2)    NOT NULL,
    
    -- Data Quality Flags
    dq_zero_price_flag              BOOLEAN         NOT NULL,
    
    -- Metadata
    dbt_updated_at                  TIMESTAMP_NTZ   NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    
    -- Constraints
    PRIMARY KEY (order_id, order_item_id),
    FOREIGN KEY (order_id) REFERENCES olist_ecommerce.{env}.fact_orders(order_id),
    FOREIGN KEY (product_key) REFERENCES olist_ecommerce.{env}.dim_products(product_key),
    FOREIGN KEY (seller_key) REFERENCES olist_ecommerce.{env}.dim_sellers(seller_key),
    CONSTRAINT chk_fact_order_items_values CHECK (
        price >= 0 AND freight_value >= 0 AND gmv = price + freight_value
    )
);

ALTER TABLE olist_ecommerce.{env}.fact_order_items 
CLUSTER BY (order_id, product_key, seller_key);
```

### fact_payments

```sql
CREATE OR REPLACE TABLE olist_ecommerce.{env}.fact_payments (
    -- Composite Primary Key
    order_id                        VARCHAR(100)    NOT NULL,
    payment_sequential              NUMBER(10,0)    NOT NULL,
    
    -- Attributes
    payment_type                    VARCHAR(20)     NOT NULL,
    payment_installments            NUMBER(10,0)    NOT NULL,
    
    -- Measures
    payment_value                   NUMBER(10,2)    NOT NULL,
    
    -- Metadata
    dbt_updated_at                  TIMESTAMP_NTZ   NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    
    -- Constraints
    PRIMARY KEY (order_id, payment_sequential),
    FOREIGN KEY (order_id) REFERENCES olist_ecommerce.{env}.fact_orders(order_id),
    CONSTRAINT chk_fact_payments_values CHECK (
        payment_value > 0 AND payment_installments > 0
    ),
    CONSTRAINT chk_fact_payments_type CHECK (
        payment_type IN ('credit_card', 'boleto', 'voucher', 'debit_card')
    )
);

ALTER TABLE olist_ecommerce.{env}.fact_payments 
CLUSTER BY (order_id);
```

---

## SCD Type 2 Implementation — Detailed Example

### Scenario: Customer Zip Code Change

**Initial State** (silver.customers):
```
customer_key | customer_unique_id | customer_zip_code_prefix | valid_from | valid_to | is_current
-------------|-------------------|-------------------------|------------|----------|------------
1            | cust_001          | 12345                   | 2024-01-01 | NULL     | TRUE
```

**New Data Arrives**: customer cust_001 moved to zip 67890 (detected on 2024-02-01)

**After SCD Type 2 MERGE**:
```
customer_key | customer_unique_id | customer_zip_code_prefix | valid_from | valid_to   | is_current
-------------|-------------------|-------------------------|------------|------------|------------
1            | cust_001          | 12345                   | 2024-01-01 | 2024-02-01 | FALSE
2            | cust_001          | 67890                   | 2024-02-01 | NULL       | TRUE
```

**PySpark MERGE SQL**:
```sql
-- Expire old record
UPDATE silver.customers
SET valid_to = CURRENT_TIMESTAMP(),
    is_current = FALSE
WHERE customer_unique_id = 'cust_001'
  AND is_current = TRUE
  AND customer_zip_code_prefix != '67890';

-- Insert new record
INSERT INTO silver.customers (
    customer_key, customer_unique_id, customer_zip_code_prefix,
    valid_from, valid_to, is_current
)
VALUES (
    2, 'cust_001', '67890',
    CURRENT_TIMESTAMP(), NULL, TRUE
);
```

---

## Grain Definitions — Locked

| Table | Grain | Example |
|-------|-------|---------|
| fact_orders | 1 row = 1 order | order_id = 'a1b2c3' = 1 row |
| fact_order_items | 1 row = 1 line item in an order | order_id='a1b2c3', order_item_id=1 = 1 row |
| fact_payments | 1 row = 1 payment installment | order_id='a1b2c3', payment_sequential=1 = 1 row |
| dim_customers | 1 row = 1 customer version | customer_unique_id='cust_001' can have 2+ rows (SCD2) |
| dim_sellers | 1 row = 1 seller version | seller_id='sell_001' can have 2+ rows (SCD2) |
| dim_products | 1 row = 1 product | product_id='prod_001' = 1 row (SCD1, overwrite) |
| dim_date | 1 row = 1 calendar date | 2024-01-01 = 1 row |

---

## Data Quality Constraints Summary

| Layer | Table | Constraint | Enforcement |
|-------|-------|------------|-------------|
| Silver | orders | order_id NOT NULL, UNIQUE | PK constraint |
| Silver | orders | customer_id EXISTS in silver.customers | FK validation (GX) |
| Silver | orders | review_score BETWEEN 1.00 AND 5.00 | CHECK constraint |
| Silver | order_items | (order_id, order_item_id) UNIQUE | Composite PK |
| Silver | order_items | price >= 0, freight_value >= 0 | CHECK constraint |
| Silver | payments | payment_value > 0 | CHECK constraint |
| Silver | customers | Only ONE is_current=TRUE per customer_unique_id | Unique index + validation |
| Gold | fact_orders | customer_key FK to dim_customers | Snowflake FK |
| Gold | fact_order_items | order_id FK to fact_orders | Snowflake FK |
| Gold | All facts | Clustering on FK columns | Performance optimization |

---

## Sign-off Checklist — Data Model Phase

- [x] Paradigm documented (Kimball Star Schema, ADR-001)
- [x] Grain explicitly defined for all fact tables
- [x] SCD type confirmed for all dimensions (Type 2: customers/sellers, Type 1: products, Static: date)
- [x] Complete logical DDL for Bronze, Silver, Gold layers
- [x] ERD diagram with relationships documented
- [x] SCD Type 2 implementation logic with examples
- [x] Data quality constraints documented
- [x] Storage vs compute tradeoff documented (ADR-001)
- [x] Platform feasibility validated by DPE
- [ ] DEBATE_LOG_phase_3.md generated
- [ ] Phase 3 sign-off

---

**Next Step**: Generate DEBATE_LOG_phase_3.md — document Phase 3 architectural decisions and debates.
