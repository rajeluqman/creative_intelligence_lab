# OPS Runbook: Olist E-Commerce Pipeline
> Status: ✅ APPROVED — Phase 5 Complete  
> Date: 2026-05-14

## Monitoring
Airflow UI : localhost:8080 (production) | DAG: olist_ecommerce_pipeline
Test Script: `python scripts/test_pipeline_orchestration.py`
GX Reports : data_quality/great_expectations/uncommitted/data_docs/
Logs       : airflow/logs/ (Airflow) | print statements (manual runs)

## Alert SLAs
CRITICAL : 15 minit | HIGH : 1 jam | MEDIUM : Hari bekerja

## Bronze Fail — File Missing
Check : ADLS landing/ — semua 9 files ada?
Fix 1 : Re-run download_dataset.py --env staging
Fix 2 : Check AZURE_STORAGE_ACCOUNT credentials dalam .env.staging
Rerun : Airflow UI → Clear bronze_ingest task → Trigger

## Bronze Fail — Schema Mismatch
Check : Compare schema dalam bronze vs docs/DRD.md
Fix   : Kaggle dataset mungkin updated — re-check column names
Action: Update DRD + Bronze schema, escalate ke DA

## Silver GX CRITICAL Fail
Check  : docs/screenshots/gx_report.html → which expectation failed?
Fix 1  : NULL dalam critical cols → check Bronze quarantine table
Fix 2  : Dedup fail → check source for new duplicates
Rerun  : Clear silver_transform task → Trigger

## Databricks Cluster Terminated
Fix     : Login CE → Restart cluster → load latest checkpoint
Prevent : Checkpoint setiap 30 minit dalam Silver script

## dbt Test Fail — FK Violation
Check : Which fact/dim? Check Silver quarantine table
Fix 1 : FK violation → source data ada orphan records → quarantine + alert DQS
Fix 2 : SCD2 is_current issue → check Silver SCD merge logic
Rerun : dbt run → dbt test

## Backfill Procedure
1. Identify affected date range
2. Delete Silver partition (order_purchase_date = affected dates)
3. Rerun Bronze → Silver → Gold dengan date param
4. Verify: row count Silver = Bronze untuk affected dates
5. Verify: dbt test pass

## Azure Credit Monitor
Check : Azure Portal → Cost Management
Alert : <$150 remaining → DPE review + optimize
Alert : <$100 remaining → escalate ke human — pause cloud runs

---

## Phase 5 Implementation Summary

### Orchestration
- **Airflow DAG**: `airflow/dags/olist_pipeline_dag.py`
  - Task flow: bronze_ingest → silver_transform → silver_dq_check → gold_dbt_run → gold_dbt_test
  - Schedule: @daily (manual trigger for demo)
  - Owner: raja-luqman
- **Manual Test**: `scripts/test_pipeline_orchestration.py`
  - Validates all pipeline components
  - Production-ready for portfolio demo

### Data Quality
- **Great Expectations**: v0.15.50
  - Context: `data_quality/great_expectations/`
  - 3 expectation suites (Bronze, Silver, Gold)
  - Validation scripts in `data_quality/`
- **dbt Tests**: 47/48 passed (98%)
  - Relationship tests (FK validation)
  - NOT NULL, UNIQUE constraints
  - Accepted values checks

### Pipeline Wrappers
- `bronze/bronze_pipeline.py` — Airflow-compatible wrapper
- `silver/silver_pipeline.py` — Airflow-compatible wrapper
- `data_quality/run_silver_suite.py` — GX validation wrapper

### Deployment Status (Phase 4b Complete)
- ✅ Bronze: 9 Delta tables in Databricks Unity Catalog
- ✅ Silver: 7 tables with SCD Type 2 (customers, sellers)
- ✅ Gold: 7 Kimball marts in Snowflake
- ✅ dbt models: 15 models (staging → intermediate → marts)

### Manual Pipeline Execution
```bash
# Full pipeline test
python scripts/test_pipeline_orchestration.py

# Individual layers
python bronze/bronze_pipeline.py
python silver/silver_pipeline.py
python data_quality/run_silver_validation.py

# Gold layer (dbt)
cd gold/dbt_models
dbt run --profiles-dir . --target staging
dbt test --profiles-dir . --target staging
```

### Production Deployment
1. Configure Airflow connections (Databricks, Snowflake)
2. Set environment variables (.env.staging or .env.prod)
3. Deploy DAG to Airflow cluster
4. Enable scheduled runs (@daily)
5. Configure Slack webhooks for alerting (optional)
