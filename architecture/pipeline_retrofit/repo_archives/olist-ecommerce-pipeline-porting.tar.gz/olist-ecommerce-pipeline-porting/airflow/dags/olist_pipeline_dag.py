"""
olist_pipeline_dag.py — Olist E-Commerce Pipeline
Modelling    : Kimball — Star Schema
Facts        : fact_orders, fact_order_items, fact_payments
Dimensions   : dim_customers (SCD2), dim_sellers (SCD2), dim_products (SCD1), dim_date
Schedule     : @daily (trigger manually untuk demo)
Alerting     : Slack webhook on failure (ADR-003) — graceful no-op if SLACK_WEBHOOK_URL unset;
               on success, the existing print-based summary is kept (failure-only channel, per
               docs/ARCHITECTURE.md "#olist-pipeline-alerts").
"""

import json
import logging
import os
import urllib.request
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator

log = logging.getLogger(__name__)

default_args = {
    'owner': 'raja-luqman',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
}

def pipeline_success(context):
    """Log success message"""
    print("=" * 80)
    print(f"✅ olist-pipeline SUCCESS — {context['ds']}")
    print("All tasks completed successfully")
    print("=" * 80)

def pipeline_failure(context):
    """Log failure message, then notify Slack (ADR-003)."""
    print("=" * 80)
    print(f"❌ olist-pipeline FAILED — {context['ds']}")
    print(f"Failed task: {context['task_instance'].task_id}")
    print("=" * 80)
    _notify_slack_failure(context)

def _notify_slack_failure(context: dict) -> None:
    """ADR-003 on_failure_callback — fires for ANY task failure in this DAG (wired via
    default_args below, not per-task, so a future 6th task is covered automatically).
    Ported from creative_intelligence_lab's dags/creative_intel_pipeline.py
    _notify_slack_failure (~line 111), per the pipeline-retrofit effort.

    Graceful no-op if SLACK_WEBHOOK_URL is unset/empty — alerting being unconfigured must
    never raise a second failure on top of the real one. Uses stdlib urllib only, no
    dependency beyond what requirements.txt already declares
    (apache-airflow-providers-slack is present but unused here by design — see ADR-003)."""
    webhook = os.environ.get("SLACK_WEBHOOK_URL", "")
    if not webhook:
        log.warning("SLACK_WEBHOOK_URL not set — skipping Slack alert (credentials not filled in yet)")
        return

    ti = context["task_instance"]
    text = (
        f":red_circle: *Airflow task failed*\n"
        f"*DAG:* `{ti.dag_id}`  *Task:* `{ti.task_id}`\n"
        f"*Run:* `{context.get('run_id', context.get('ds', '?'))}`\n"
        f"<{ti.log_url}|View logs>"
    )
    body = json.dumps({"text": text}).encode("utf-8")
    req = urllib.request.Request(
        webhook, data=body, headers={"Content-Type": "application/json"}, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            log.info("Slack alert sent (status %s)", resp.status)
    except Exception as e:  # noqa: BLE001 — alerting must never raise into the task's own failure handling
        log.warning("Slack alert failed to send: %s", e)

with DAG(
    dag_id='olist_ecommerce_pipeline',
    default_args=default_args,
    schedule_interval='@daily',
    catchup=False,
    on_success_callback=pipeline_success,
    on_failure_callback=pipeline_failure,
    tags=['ecommerce', 'kimball', 'olist', 'portfolio'],
) as dag:

    bronze = PythonOperator(
        task_id='bronze_ingest',
        python_callable=lambda: __import__('bronze.bronze_pipeline', fromlist=['']).run(),
    )

    silver = PythonOperator(
        task_id='silver_transform',
        python_callable=lambda: __import__('silver.silver_pipeline', fromlist=['']).run(),
    )

    silver_dq = PythonOperator(
        task_id='silver_dq_check',
        python_callable=lambda: __import__('data_quality.run_silver_suite', fromlist=['']).run(),
    )

    gold_run = BashOperator(
        task_id='gold_dbt_run',
        bash_command='cd gold && dbt run --profiles-dir . --project-dir .',
    )

    gold_test = BashOperator(
        task_id='gold_dbt_test',
        bash_command='cd gold && dbt test --profiles-dir . --project-dir .',
    )

    bronze >> silver >> silver_dq >> gold_run >> gold_test
